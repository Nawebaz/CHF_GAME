#!/usr/bin/env bash
systemctl --user disable --now faro.service || true
rm -f "$HOME/.config/systemd/user/faro.service"; systemctl --user daemon-reload
echo "Servicio quitado. La carpeta ~/faro (config y datos) se conserva."
