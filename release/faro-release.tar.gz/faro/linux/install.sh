#!/usr/bin/env bash
# Instalador de Faro para Linux (servicio de usuario con systemd). Uso: bash linux/install.sh
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
DEST="${FARO_HOME:-$HOME/faro}"
PORT=8787
command -v python3 >/dev/null || { echo "Falta python3 (sudo apt install python3 / sudo dnf install python3)"; exit 1; }
python3 -c 'import sys; assert sys.version_info >= (3,9)' || { echo "Hace falta Python 3.9 o superior"; exit 1; }
mkdir -p "$DEST/web" "$DEST/data" "$DEST/tools"
if [ "$(cd "$SRC" && pwd -P)" != "$(cd "$DEST" && pwd -P)" ]; then
  cp "$SRC/faro.py" "$SRC/config.example.json" "$SRC/README.md" "$SRC/actualizar.sh" "$DEST/" 2>/dev/null || cp "$SRC/faro.py" "$SRC/config.example.json" "$SRC/README.md" "$DEST/"
  cp -r "$SRC/web/." "$DEST/web/"; cp "$SRC/tools/"* "$DEST/tools/"
fi
chmod +x "$DEST/tools/faro-report.sh"
[ -f "$DEST/config.json" ] || { cp "$DEST/config.example.json" "$DEST/config.json"; echo "Creado $DEST/config.json: edítalo con tus datos."; }
[ -d "$HOME/Obsidian/Nahuel" ] && sed -i 's#~/Documentos/Obsidian/Nahuel#~/Obsidian/Nahuel#' "$DEST/config.json"
mkdir -p "$HOME/.config/systemd/user"
cat > "$HOME/.config/systemd/user/faro.service" <<UNIT
[Unit]
Description=Faro, panel de estado
After=network-online.target

[Service]
WorkingDirectory=$DEST
ExecStart=$(command -v python3) $DEST/faro.py
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
UNIT
systemctl --user daemon-reload
systemctl --user enable --now faro.service
# Que siga corriendo sin sesión iniciada (necesita sudo una vez)
loginctl enable-linger "$USER" 2>/dev/null || sudo loginctl enable-linger "$USER" || echo "Aviso: sin linger, Faro solo corre con tu sesión abierta."
if command -v ufw >/dev/null && sudo -n true 2>/dev/null; then sudo ufw allow from 192.168.0.0/16 to any port $PORT proto tcp || true; sudo ufw allow in on tailscale0 to any port $PORT || true; fi
# Icono «Faro» en el menú de aplicaciones
[ -f "$DEST/abrir.sh" ] && [ "$SRC/abrir.sh" -ef "$DEST/abrir.sh" ] || cp "$SRC/abrir.sh" "$DEST/abrir.sh"; chmod +x "$DEST/abrir.sh"
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/faro.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Faro
Comment=Panel y puesto de mando
Exec=$DEST/abrir.sh
Icon=$DEST/web/icon.svg
Terminal=false
Categories=Utility;
DESK
cp "$HOME/.local/share/applications/faro.desktop" "$(xdg-user-dir DESKTOP 2>/dev/null || echo $HOME/Escritorio)/" 2>/dev/null && \
  gio set "$(xdg-user-dir DESKTOP 2>/dev/null || echo $HOME/Escritorio)/faro.desktop" metadata::trusted true 2>/dev/null; \
  chmod +x "$(xdg-user-dir DESKTOP 2>/dev/null || echo $HOME/Escritorio)/faro.desktop" 2>/dev/null || true
sleep 3
curl -s "http://127.0.0.1:$PORT/api/health" >/dev/null && echo "Faro funcionando." || echo "Faro no responde aún: journalctl --user -u faro -n 50"
xdg-open "http://127.0.0.1:$PORT" >/dev/null 2>&1 || true
echo "Abre en el móvil o el Mac: http://$(hostname -I 2>/dev/null | awk '{print $1}'):$PORT"
