# Real activity reporting

Only explicit fresh reports and executed orders indicate active work. No CPU inference, scheduled-window inference, example workers or time-extrapolated percentages. Expired or dead-PID workers become bad. Local update lock remains available.

Tests: python3 -m unittest discover -s tests -v; node tests/test_no_progress.js.
No configuration, logs, user data or credentials are included.
