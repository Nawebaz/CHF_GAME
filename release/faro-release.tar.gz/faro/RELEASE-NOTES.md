# 2026.11.12-oficina-v2.17 (incluye v2 a v2.16)

- v2.17: Codex puede trabajar de verdad. Su caja de arena solo le dejaba escribir en ~/FaroTrabajo y le cortaba localhost: ahora recibe la bóveda con --add-dir (si su versión lo entiende) y red para informar a Faro, igual que Claude ya tenía la bóveda. Strata se encuentra solo si cambia de puerto al reiniciar (busca en 18500-18505 con su misma cabecera, solo en localhost, y guarda el puerto). conectar-strata.sh v3 (lee la clave de ~/.strata/data/native-instances sin mostrarla).
- v2.16: la bóveda se repasa sola. Cada vez que alguien modifica una nota (como mucho cada 30 s), `tools/vault_links.py` une encargo ↔ respuesta, mantiene bloques automáticos en Inicio, Faro, CHF y el Índice de tareas (entre marcadores `<!-- faro:auto:… -->`, sin tocar lo escrito a mano), aparta las copias de conflicto de Syncthing a `_to_delete/` (nunca borra) y no toca notas editadas hace menos de 90 s. Lo que necesita criterio (enlaces rotos, huérfanas, duplicados, encargos respondidos que siguen en inbox) va a `Faro/Conexiones de la bóveda` y a «Te toca». Espejo del repo público cada 5 min: `30 Recursos/GitHub CHF_GAME` con enlaces, ramas, últimos cambios del juego y versión de Faro. Desactivar: `vault_links.enabled` / `repo_mirror.enabled` a false.

- v2.15: modo ahorro en el propio PC (127.0.0.1/localhost o ?ahorro): su escritorio pinta sin aceleración y cada fotograma de Faro le costaba CPU a gnome-shell. Allí la oficina va a 15 fps, las gráficas en vivo a 2 fps y la lluvia de fondo se apaga. En el iPhone y el Mac, la oficina a 30 fps (antes 60) y la lluvia algo más lenta.
- v2.14: une la v2.13 de la Máquina GTA VI (tele y pantallas) con conectar-strata.sh v2: pregunta a la biblioteca de control de Strata en qué puerto está su API, prueba 18500 y 18501, busca la clave en el perfil de la app y en sus procesos y guarda puerto + clave; Faro usa ese puerto para el ejecutor y para ver si Strata está libre o pensando.
- v2.13: la Máquina GTA VI se muda a la oficina. En la sala de descanso hay una tele con la carretera de la máquina en vivo (un coche por clip avanzando por las paradas, los tres jueces como luces, barrera roja si el peaje está bloqueado) y la pantalla de la mesa de cada agente que trabaja en GTA muestra la misma carretera en pequeño. Tocar la tele abre la ficha de los clips con el enlace al panel. La tarjeta de la vista principal se quita: todo está en la oficina.

- v2.12: Strata con clave. Faro envía la clave de acceso de la IA local (data/secrets/strata.json, solo legible por el usuario del PC) y solo a localhost, nunca a otra dirección; no se puede cambiar desde la red. `tools/conectar-strata.sh` la busca en el propio Strata (proceso y configuración), la prueba contra localhost y la guarda sin mostrarla; si no la encuentra, la pide con escritura oculta. Desde el Mac: `ssh -t -l iceland -o HostName=iceland iceland 'bash <(curl -fsSL https://raw.githubusercontent.com/Nawebaz/CHF_GAME/faro-buzon/conectar-strata.sh)'`.
- v2.11: rendimiento de verdad en vivo. Los procesos del PC se miden por la diferencia de tiempos de /proc entre lecturas (antes «ps» daba la media de toda su vida y parecían clavados) y se suman por programa; el vigía del Mac usa la segunda muestra de «top» (la CPU de este segundo, no la media de un minuto). En la oficina, un punto late con cada lectura nueva y la ficha de Máquinas dibuja los últimos 2 min de CPU y GPU. Bóveda: el nombre de quien toca una nota solo se pone si ese agente declara que trabaja en la bóveda; si solo es «el único en marcha», sale como probable (¿Hermes?) y sin haz; las lecturas del historial horario de git se marcan como tales.
- v2.10: Máquina GTA VI en vivo en la vista principal. Si una sesión de Claude manda el campo «gta» (solo etapas y series, nada de contenido), aparece una tarjeta con la carretera de la máquina: un coche por clip avanzando por las paradas (fuentes, guion, captura, voz, rótulos, montaje, ITV ×3, taller, ITV 2, empaque, peaje, publicado), los tres jueces como luces sobre cada coche (ámbar revisando, verde aprobado, rojo cambios), barrera roja si el peaje está bloqueado y sirena azul si tiene prioridad. Tocarla abre el panel de la máquina. `faro-informa.py --json '{"gta":{...}}'`.

- v2.9: bóveda viva. El vigía del PC (inotify, sin instalar nada) avisa al instante de cada nota que se lee, se escribe, nace, se renombra o se borra; lo que llega del Mac por Syncthing se reconoce como tal. En la oficina el grafo se mueve como el de Obsidian: florece al abrir, la nota nueva nace junto a la que enlaza y empuja a sus vecinas, la nota tocada se enciende con sus enlaces y vecinas (azul lee, amarillo escribe, verde nueva, rojo borrada) y un haz sale de la mesa de quien la toca. Quién: solo si no hay duda. Tocar la bóveda abre el grafo en grande con nombres y el registro de accesos. En el móvil la bóveda es casi el doble de grande (zonas en fichas). Los agentes de la nube pueden decir qué notas leyeron con `faro-informa.py --notes`. API: GET /api/vault/live.
- v2.8: máquinas en vivo. Barra de la oficina con CPU y gráfica del PC (proc + nvidia-smi) y del Mac (vigía, cada 3 s), cada 2 s con la oficina abierta; rojo por encima del 85 %. Ficha con RAM, VRAM, temperatura, vatios y qué procesos/agentes usan la gráfica y la CPU; chip «GPU» en la mesa del agente que la está usando. API: GET /api/machines, POST /api/machine. El vigía del Mac se actualiza solo cada hora.
- v2.7: mesas estables: cada agente conserva su mesa; solo se reordena si quien trabaja se queda sin mesa o, cada 45 s como mucho, para acercar al faro a quien trabaja. Antes se paseaban en cada refresco y las zonas no llegaban a encenderse.
- v2.6: Claude del PC puede leer la bóveda (--add-dir); las órdenes recuerdan que en la bóveda solo se escribe dentro de _agentes/.
- v2.5: los agentes del PC ya no se quedan esperando: Codex con --skip-git-repo-check y sin entrada de teclado; Claude con -p y permiso de editar en ~/FaroTrabajo; Hermes en modo una respuesta. Sin cuota (429): la orden vuelve a la cola y se reintenta sola cuando hay cuota; mientras, Faro reparte a otros.
- v2.4: cada orden sabe qué pide (bóveda, código, web, vídeo, correo, sistema, escritura) y la oficina coloca a quien la hace en esa zona.
- v2.3: agentes encendibles desde Faro (data/overrides.json, sin poder tocar el comando) y órdenes por la bóveda (_agentes/inbox/faro → reparto → _agentes/outbox).

- v2.2: la oficina no levanta edificio para proyectos en silencio (el lab de trading hasta que tenga resultados).
- v2.1: las tareas de Codex y Hermes se agrupan por nombre aunque lleguen con otra marca.
Oficina (prioridad: móvil)
- Bóveda: el grafo de tus notas de Obsidian (nodos y enlaces reales, posiciones estables calculadas en el PC). En amarillo, lo tocado en los últimos 15 min; si alguien consulta la bóveda, la señal recorre los enlaces.
- Mesas por prioridad: cerca del faro quien trabaja; luego quien tiene una tarea de fondo; luego quien está libre. Agentes y mesas se reasignan solos.
- Descanso: solo quien tiene una tarea corriendo de fondo (su pantalla sigue girando en la mesa).
- El ojo marca el compás de 15 s (el sondeo de Faro): recorre a quien trabaja por orden de mesa y a cada uno le «late» la pantalla y el teclado cuando lo mira; nadie va al unísono.
- Flexos orientados a la pantalla que la iluminan. Pantallas con el símbolo de lo que usa cada agente, su color, nube/PC y avance.
- Entrada nueva con tres canales reales (Tú · Faro, Nube, PC · Mac) que se encienden cuando llega algo, pulso del sondeo de 15 s y banquillo (hechos, libres sin mesa, sin señal).
- Las chispas que suben por el faro son cambios reales de un agente; se quitaron las partículas decorativas.

Vista principal
- El aviso de arriba cuenta lo mismo que «Te necesitamos para» (antes decía «1 para ti» con la lista vacía).
- «Cómo vamos»: trabajan · de fondo · en cola · sin señal, y la lista de quién trabaja y en qué. Cada proyecto dice quién está en él.

Servidor
- Una ficha por agente real: las tareas que un agente del PC informa con nombres distintos (Hermes · chf-3d, Hermes · CHF3D…) se pliegan en su ficha; las vencidas, como «sin cierre».
- `action` solo admite el vocabulario (code, web, write, think, edit, obsidian, mail, system, skills; también en español). Si llega una frase, pasa a `step`.
- Sesiones de la nube terminadas hace más de 30 min: «hechas», al banquillo.
- Ejecutor sin sesión (p. ej. «Not logged in»): se aparta 6 h del reparto, se avisa en «Te toca» y `/api/health` dice por qué.
- Strata detectado en su puerto real (18501, compatible con OpenAI) y usable como ejecutor gratis. Reparto de reserva sin coste primero: Codex, Hermes, Strata, Claude.
- Autoactualización en pausa por REAL_ACTIVITY_LOCK: ahora se ve como aviso.
- Grafo de la bóveda en `vault.graph`.

Tests: python3 -m unittest discover -s tests -v; node tests/test_no_progress.js.
