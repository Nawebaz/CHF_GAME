## 2026.11.18-oficina-v3.00
- **Faro entiende el ritmo de cada uno**: quien trabaja tiene un tiempo esperado entre noticias: el que él mismo anuncia (`--expect` en el informador, para cálculos largos), si no el que Faro aprende de sus informes reales por tipo de trabajo (mediana ×1,5) y, si aún no hay historia, una tabla (web 5 min, código/pensar 15, edición/voz 30, render 60). Si se pasa, deja la mesa y va al banquillo «va tarde: esperaba noticias cada X, la última hace Y». Los agentes del PC los sondea Faro cada pocos segundos.
- **Avisos en el buzón**: el tablón `_agentes/avisos/` sale arriba en el buzón de la oficina con tipo, para quién, cuánto le queda y **quién lo ha abierto**. Caducan según su tipo (versión 2 días, de hoy 1, decisión 7, norma 14, resto 3; o `caduca:` en horas en el frontmatter) y pasan a `avisos/caducados/` (no se borran).

## 2026.11.18-oficina-v2.99
- **Quien no trabaja se va de la oficina** (decisión del 14 y 17 nov). Antes, una sesión cerrada se quedaba hasta 12 h en el banquillo, y un agente local en reposo (p. ej. Claude Code del PC, sin actividad en 4 días) se quedaba siempre. Ahora el servidor marca cada ficha con `presence` (mesa, banquillo o fuera) y el motivo: lo terminado se ve 10 min y sale; lo que lleva más de 45 min sin noticias pasa al banquillo «en pausa» (no ocupa mesa haciendo como que trabaja); los fallos se ven 1 h; los agentes locales solo están si trabajan, acaban de terminar o tienen órdenes en cola. Ajustable en `presence` de config.json.
- **Banquillo con motivo**: «en pausa», «esperando», «recién terminado», «sin señal», en lugar de «libres».
- **Galaxia del relay privado** junto a la bóveda: una estrella por informe del relay; laten las sesiones en marcha, quedan tenues las terminadas, en coral las que fallaron; cada informe nuevo lanza una onda y enciende el núcleo. Datos de `/api/office` (`relay`), refresco ≤ 20 s.

## 2026.11.18-oficina-v2.96 · Un relevo que no puede no cierra encargos
- Si el relevo responde que no ha podido (sin permisos, solo lectura, pide aprobación), la orden vuelve a su agente en cola, no se da por hecha ni se archiva el encargo. El relevo queda apartado 6 h.

## 2026.11.18-oficina-v2.95 · En la oficina solo quien está, y diciendo qué hace
- Hermes ya no sale «trabajando» por sus registros (los escribe aunque esté parado): trabaja si lleva un encargo de Faro o abre sesión.
- Las fichas de Hermes, Claude Code y Codex dicen el encargo de Faro que llevan («con «…» · relevo de Hermes») o por qué están parados («parado · sin cuota hasta las 12:15»).
- Lo terminado se ve 45 min y se va (config «agents_done_minutes»); lo apagado desde hace más de 6 h no sale («live_off_hide_hours»).
- Si Strata está cerrado, la ficha de la IA local se llama Ollama, no Strata.

## 2026.11.18-oficina-v2.94 · El relevo no gasta en lo apartado
- Las órdenes de prioridad «baja» no pasan al relevo (config «relief_skip»): esperan a su agente.

## 2026.11.18-oficina-v2.93 · Relevo que no pelea por la gráfica
- En modo relevo, antes de usar la gráfica para voz o vídeo, el agente descarga Ollama (keep_alive 0) para dejarle la memoria.

## 2026.11.18-oficina-v2.92 · Relevo ante atascos
- Si un agente no puede trabajar para rato (sin cupo o sin sesión, más de 10 min) y tiene órdenes en cola, Faro pasa la primera a su relevo, de una en una (config «relief»; por defecto Hermes → Claude Code). Al acabar coge la siguiente; cuando el agente vuelve, se queda con el resto.
- El relevo trabaja en «modo ahorro»: planifica corto, se apoya en scripts y usa la IA local (Ollama) para redactar o resumir texto largo; él solo decide, ejecuta y comprueba.
- Si el relevo también se queda sin cupo o sin sesión, la orden vuelve a su agente en vez de darse por fallida.
- El aviso «X del PC no puede trabajar» ya dice la verdad: a quién pasa sus órdenes o que esperan.
- Pruebas: tests/test_relevo_atascos.py.

## 2026.11.17-oficina-v2.91 · La bóveda en Faro, fiel a la vista gráfica de Obsidian
- El grafo de la bóveda sigue los filtros de la vista gráfica de Obsidian: sin «Adjuntos» desaparece el anillo dorado; sin «Etiquetas», sin etiquetas; sin «Huérfanas», sin lo que no tiene enlaces; con «Archivos no existentes» salen en gris los enlaces sin resolver; y respeta la búsqueda básica (palabras, path:, file:, tag:, «-» para quitar). Lo que la búsqueda no entiende no filtra.
- Los filtros salen de .obsidian/graph.json de la bóveda (Faro lo nota en segundos) o del plugin «Faro · grafo» 1.1, que ahora también los manda desde el Obsidian abierto (aunque el grafo esté cerrado). Manda lo más reciente.
- Pie del grafo: «filtros de Obsidian» cuando se aplican.
- Pruebas: tests/test_graph_filtros_obsidian.py y tests/test_obsidian_plugin_filtros.js.

## 2026.11.17-oficina-v2.90 · Diagnóstico del termómetro del Mac
- El vigía del Mac manda su versión (`vigia`) y por qué no lee la temperatura (`temp_diag`); Faro los guarda y los enseña en `/api/machines`. Sin cambios visibles.
- El lector de sensores carga IOKit también por ruta directa si el sistema no lo encuentra por nombre.

## 2026.11.17-oficina-v2.89 · Proyecto «Faro» y formas redondeadas
- **Proyecto nuevo «Faro»** en la oficina y en el panel: las sesiones que trabajan en Faro ya tienen columna (antes no salían en ninguna). Aparece solo aunque tengas tu propio `config.json`.
- El nombre del proyecto manda sobre las palabras clave: un texto con «faro» va a Faro, no a Agentes.
- **Formas redondeadas**: zonas, bóveda, marcos y paneles dejan el octógono (decisión de Nawe).

## 2026.11.17-oficina-v2.88 · Mesas, tele de GTA VI y voz con el dibujo nuevo
- Cada puesto es ahora la mesa de madera con pantalla de cristal del rediseño (`scr.deskscreen`), en vez del tablero dibujado a líneas.
- La tele de GTA VI va dentro de su marco ilustrado (`scr.tv`) y la tira de voz, en un bisel marfil con pilotos lavanda.
- Sin sprites nuevos ni créditos: se usan piezas del atlas que ya viajaban y no se dibujaban.

## 2026.11.17-oficina-v2.87 · termómetros de CPU y gráfica, y proyectos en vivo

- **Termómetros**: uno por fila en los medidores (CPU y gráfica del PC, con su cifra). El vigía del Mac manda ahora la temperatura del chip (sensores del sistema, sin sudo, en proceso aparte); si llega, el Mac tiene el suyo.
- **Proyectos**: diseño nuevo (pila de bloques redondeados sobre una peana, un bloque por entrega de la semana) y, encima, **las cabezas de los agentes que trabajan en cada proyecto ahora mismo**, leídas de la oficina en vivo. La obra llega con el sondeo rápido de 2 s (`build` en `/api/machines`), no con el estado general.
- La barra de medidores es más ancha para que quepan las cifras.

## 2026.11.17-oficina-v2.86
- **Relay privado de vuelta**: la v2.84 se construyó sobre la v2.82 y perdió el lector del relay de la v2.83. Repuesto tal cual (`sources.github_relay`, token en archivo, prueba `tests/test_relay.py`). En el PC ya está activado.
- **Arranque instantáneo**: la primera pasada de recolectores (noticias, Ollama, bóveda) va en segundo plano. Antes el panel tardaba casi 2 minutos en responder tras cada reinicio o actualización (medido hoy en el PC: 13:08:57 → 13:10:49); ahora, 1 s.

## 2026.11.17-oficina-v2.85 · rediseño, fase 2 (1): paleta nueva y termómetro

- **Paleta**: toda la oficina pasa del neón a la paleta del rediseño (pizarra, marfil, madera; turquesa, coral y lavanda). Cambia el color, no el significado: verde sigue siendo «trabaja», ámbar «en cola», rojo «alerta». Los halos son un 25 % más suaves.
- **Medidores**: termómetro en vivo junto al nombre de cada equipo, con lo más caliente entre CPU y gráfica; turquesa, ámbar desde 70 °C y rojo que late desde 85 °C. Solo sale si el equipo manda temperatura (el PC sí).
- Pendiente de la fase 2: mesas holográficas, paneles de proyectos, marcos de las pantallas de GTA VI y de voz, efectos y decoración.

## 2026.11.17-oficina-v2.84 · personaje genérico, bibliotecario y orbe palantír

- **Personaje genérico recoloreable**: tres cabezas (pelo corto, coleta, rizos con gafas) y ropa gris que se tiñe en vivo del color de la marca. Lo usa cualquier agente sin dibujo propio (antes salían todos como Hermes) y Faro.
- **Bibliotecario** con su sprite ilustrado (la figura dibujada en código queda de reserva).
- **Orbe**: vuelve a ser un palantír: piedra de cristal oscuro con aro fino de metal gris y dos garras laterales afiladas; más pequeño frente a sus anillos y satélites. Se dibuja en código: sus sprites salen del atlas.
- Atlas: 292 KB (antes 309 KB) con seis personajes propios, tres genéricos y las pantallas.

## 2026.11.17-oficina-v2.83 · rediseño de la oficina, fase 1: personajes, orbe y sala

- **Adiós al pixel art**: los cinco agentes (Claude, Codex, GPT, Hermes y el local) son ilustración 2D nueva, 8 poses cada uno, con su silla dibujada. Dirección de arte de GPT; generado en Higgsfield (GPT Image 2).
- **Orbe**: cuerpo de cerámica marfil y cristal ahumado; el iris, la mirada, los anillos y la luz siguen dibujándose en vivo.
- **Sala**: fondo ilustrado (loft de noche, 20 KB) bajo un velo oscuro; el suelo deja verla y la rejilla casi desaparece.
- Atlas nuevo: 309 KB (antes 327 KB) con personajes, orbe, pantallas y decoración. El mobiliario pixel art que ya no se usaba se ha quitado.
- Pendiente (fase 2, en código): paleta nueva en paneles y zonas, marcos ilustrados de las pantallas de GTA VI y de voz, y efectos según las reglas de la dirección de arte.

## 2026.11.17-oficina-v2.82
- **Mucho más ligero en el iPhone**: las respuestas van comprimidas (gzip) y los archivos del front se guardan en el navegador y solo se vuelven a bajar si cambian (ETag/304). Medido: primera carga de 1,1 MB a 213 KB, recarga de 1,1 MB a 31 KB, oficina abierta 60 s de 292 KB a 88 KB.
- **Fuente recortada** a los caracteres que usa Faro (latín, puntuación, flechas, símbolos): de 742 KB a 156 KB (92 KB comprimida). Lo que falte cae en la fuente del sistema.
- **Bocadillos de la oficina** sin salirse del borde: el globo se encaja en el lienzo y el pico sigue apuntando a quien habla.
- Comparación del token en tiempo constante.
- Auditoría de producto de Claude (17 nov).

## 2026.11.17-oficina-v2.81 · historia de la bóveda

- Botón **«▶ Historia de la bóveda»** en la ficha de la bóveda (como «Animar» en la vista gráfica de Obsidian): las notas aparecen por orden de nacimiento, con fecha y contador, en la ficha y en el octógono a la vez. Un segundo toque la para.
- Fecha de nacimiento de cada nodo (`c`): la del nombre de la nota, o `creado:` de su ficha, o su última modificación (Linux no guarda la fecha de creación). Etiquetas: la de la primera nota que las usa.

## 2026.11.17-oficina-v2.80 · la bóveda con las posiciones reales de Obsidian

- **Plugin de Obsidian «Faro · grafo»** (`extras/obsidian-faro-grafo/`): manda a Faro dónde está cada punto de la vista gráfica (`POST /api/vault/layout`). Solo envía cuando algo se mueve; con el grafo quieto o cerrado, nada.
- Con ese dibujo, la oficina coloca cada nodo donde está en Obsidian (de frente coincide; en 3D, bola + cinturón). Sin él, o si no cubre el 60 % de la bóveda, sigue el dibujo propio de Faro.
- El último dibujo se guarda (`data/obsidian_layout.json`) y se conserva aunque Obsidian se cierre. La ficha de la bóveda dice de dónde sale el dibujo y de cuándo es.

## 2026.11.16-oficina-v2.79 · el bibliotecario también se ve sintetizando

- Terminada la descarga, el mismo agente pasa a **«Bibliotecario · síntesis»** (misma figura y mesa) mientras alguien reescriba `~/Biblioteca/sintesis.json` (`{fase, hechas, total, actual, motor}`) al menos cada 2 min. Su pantalla enseña fase, fichas hechas sobre el total y barra. Si aún hay descarga, manda la descarga; si el archivo deja de tocarse 3 min, el agente se va.
- `biblio_probe()` devuelve además `sint`. Pruebas ampliadas. **Sin validar en pantalla real.**

## 2026.11.16-oficina-v2.78 · la bóveda, como la vista gráfica de Obsidian pero en 3D

- **Mismo contenido que Obsidian**: además de las notas, ahora son nodos las **etiquetas** (verde) y los **adjuntos** (amarillo). Lo que no tiene ningún enlace forma un **cinturón** alrededor, como allí; lo enlazado, una bola en el centro.
- **Misma forma**: el servidor coloca lo enlazado solo con centro + repulsión + enlaces (se quitan las islas por carpeta y el calor ya no deforma el grafo). De frente se reconoce el grafo 2D; al girar, tiene volumen. Hasta 700 notas (antes 400).
- **Color por conexiones, no por tránsito**: gris lila (1 enlace) → azul → cian → violeta → magenta → naranja → rojo, y oro en el núcleo. El tránsito queda como un aro blanco que late.
- **Cámara**: abre con la vista completa (teleobjetivo, casi de frente, meciéndose ±35°) y alterna con los vuelos de cerca de siempre.
- **Física**: el radio de choque se adapta al número de notas (antes la nube se hinchaba y borraba la forma) y el cinturón no entra en la física.
- Servidor: repaso corto del grafo (45 pasadas en vez de 160) cuando casi todo está ya colocado.

## 2026.11.16-oficina-v2.77 · el bibliotecario tiene figura propia y su pantalla funciona

- **Figura propia** para «Bibliotecario · descarga», dibujada en código (sin créditos): túnica oscura con filo violeta de la bóveda, capucha, gafas redondas de neón y un libro-holograma abierto; trabajando pasa páginas y le orbitan tres hojas de datos (`drawLibrarian`). Antes salía con el sprite antiguo del faro.
- **Arreglo**: su pantalla de mesa enseñaba el icono de la bóveda en vez del porcentaje. La oficina identifica a los agentes como `"a:" + nombre`, no por el id del servidor; ahora se reconoce por el nombre (`isBiblio`). Prueba nueva `tests/test_bibliotecario_sprite.js`. **Sin validar en pantalla real.**

## 2026.11.16-oficina-v2.76 · quien descarga la biblioteca sale como agente con su pantalla

- Mientras la biblioteca offline se descarga, en la oficina aparece **«Bibliotecario · descarga»** en una mesa, con su pantalla: porcentaje real, GB bajados y barra (`biblio_agent()` en `faro.py`, `drawBiblioScreen()` en `office.js`). Es dato sondeado por Faro (`~/Biblioteca/progreso.json`), no un informe: si la descarga para más de 3 min, el agente se va.
- La franja al pie de la bóveda (v2.74) se mantiene. Prueba nueva en `tests/test_biblio_probe.py`. **Sin validar en pantalla real.**

## 2026.11.16-oficina-v2.75 · la oficina vuelve a ir fluida, proyectos fieles y paneles nuevos

- **Orbe y oficina a saltos (3 fotogramas/s)**: la física de la bóveda se disparaba cuando casi todas las notas estaban «calientes» (un proceso de git leyó la bóveda entera): ~1 millón de cálculos por fotograma. Ahora solo atraen las 14 notas más pesadas, los choques se calculan por barrido, hay tope de 3 pasos por fotograma (y 1 si la física cuesta) y un fotograma lento ya no pide más pasos.
- **Calor de la bóveda**: rojo = se toca más que la nota media. Las lecturas del sistema (git, indexadores) ya no calientan.
- **Proyectos**: la altura de cada aguja son las entregas reales de los últimos 7 días (`build.w7`), a escala común; antes todas las que pasaban de 12 quedaban iguales para siempre. Rótulo «N ESTA SEMANA» y ficha con hoy/semana/total. El servidor guarda 300 entregas con fecha y un total sin tope.
- **Paneles**: «Voz y audio» e «Imagen» sustituyen a «Correo» y «Skills» (1 uso cada uno en 88 informes). Acciones nuevas `voice` e `image`; `mail` va a Escritura y `skills` a Código.

## 2026.11.16-oficina-v2.74 · monitor de la biblioteca offline

- **Biblioteca en la oficina**: franja al pie de la bóveda con el estado de la biblioteca offline de carreras y másters (`~/Biblioteca` en el PC, o `biblioteca.dir` en config). Descargando: nivel, porcentaje, archivo actual y GB bajados sobre el total; lista: colecciones verificadas, GB y disciplinas. Cada cambio manda un dato al orbe.
- **Dato real, sin informes**: `biblio_probe()` lee cada 5 s `progreso.json` y `manifest.json` de esa carpeta (nunca los libros). Sale en `/api/machines` (`biblio`) y en el estado (`biblio_probe`). Si la carpeta no existe, no se dibuja nada.
- Pruebas nuevas: `tests/test_biblio_probe.py` y `tests/test_biblio_monitor.js` (no se sale del recuadro de la bóveda). **Sin validar visualmente** en pantalla real.

## 2026.11.15-oficina-v2.73 · los hilos no salen del octógono de la bóveda

- Los satélites que suelta el orbe recorren las conexiones dibujándose sobre la oficina, fuera de la capa recortada del grafo: con la cámara lejos o descolocada, o con muchos a la vez, sus tramos se salían del octógono. Ahora ese recorrido se recorta al octógono, se saltan los tramos con los dos extremos fuera, y el orbe solo suelta satélites en conexiones con las dos notas dentro.
- Prueba nueva `tests/test_hilos_boveda.js`: con una nota proyectada muy fuera, ningún trazo del recorrido queda sin recorte (la v2.72 suspende esta prueba).

## 2026.11.15-oficina-v2.72 · cámara de la bóveda en modo planetario

- La cámara de la bóveda deja de dar latigazos: gira con inercia (velocidad que sube y baja con aceleración limitada), con tope de 4,3°/s, y se mueve a menos de la mitad de velocidad.
- Se queda 25–40 s en cada sitio; una nota que se enciende solo le roba la mirada si lleva más de 25 s en lo anterior (antes cambiaba de objetivo unas 17 veces por minuto; ahora unas 2).
- Flota con una deriva lenta, como en un planetario; la órbita no salta al cambiar de objetivo y rodea lo que mira sin empujones.
- Medido en simulación (10 min, una nota encendida cada 3 s): giro medio 9,7 → 2,0°/s; máximo 24 → 4,3°/s; tirón máximo 270 → 1,3°/s².

## 2026.11.15-oficina-v2.71
- Expertos en la oficina: si un agente informa con `expert` (faro-informa `--expert`), bajo sus pies aparece una insignia con el papel con el que trabaja, de color propio.
- Máquina de GTA VI: el clip se rotula con el `id` de su clip.json, no con el nombre de la carpeta.

## 2026.11.15-oficina-v2.70
- **Máquina de GTA VI en directo**: Faro lee el estado de cada clip directamente de su carpeta en el PC (`clip.json`, que escribe el nuevo orquestador `gta.py`; carpeta `~/Descargas/gta6` o `gta.dir` en config.json), cada 8 s, sin esperar a que nadie informe. Va en `/api/machines` (`gta`) y en el estado (`gta_probe`); la tele y la ficha lo usan si es más reciente que el último informe. «Trabajando» = algún clip ha cambiado en los últimos 10 minutos. Prueba nueva: `tests/test_gta_probe.py`.
- **Nuevo orden de la carretera**: FUENTES → GUION → ITV GUION → VOZ → CAPTURA → RÓTULOS → MONTAJE → ITV VÍDEO → TALLER → EMPAQUE → PEAJE → PUBLICADO (los jueces miran el guion antes de gastar voz y gráfica; el montaje va después de la voz).

## 2026.11.15-oficina-v2.69
- **Ficha completa de la máquina de GTA VI y la voz**: pulsar la tele de GTA VI o el monitor de voz abre ahora una ficha ancha y ordenada (antes, una lista corta): estado en vivo → cifras (clips en marcha, publicados, bloqueados, audios de voz hoy) → qué te toca (bloqueos y encargos fallidos) → tramos con sus clips → tabla de clips (serie, tramo, jueces, motivo del bloqueo) → voz narradora (en directo: desde cuándo genera, último audio, audios de hoy por horas y por idioma, últimos archivos) → encargos de la máquina con su estado → enlace a la nota del proyecto en Obsidian. Se refresca sola cada 2–5 s sin perder el desplazamiento. Si la lista de clips es vieja (más de 6 h sin informar), lo dice arriba en rojo.
- **Voz, más datos en directo**: la sonda de Faro en el PC añade audios de hoy por horas, por idioma y los 8 últimos archivos (nombre, hora y tamaño; nunca el contenido). La onda del monitor sigue la carga real de la gráfica del PC mientras se genera.

## 2026.11.15-oficina-v2.68
- **Depósito del orbe, rehecho**: cuando lleva entre 7 y 12 satélites y pasa sobre la bóveda, se le van soltando uno tras otro, atraídos por la conexión más cercana. Al tocarla se meten dentro, la encienden y recorren el grafo por sus enlaces hasta apagarse; el orbe se queda con dos. **Con sentido informativo**: cada satélite va, por el camino más corto de enlaces reales, hasta una nota que se haya tocado de verdad hace poco (del registro de la bóveda, por turno), y esa nota late dos veces al recibirlo. Si no hay actividad reciente, vagan unos saltos y se apagan (ahí es solo adorno). No cuenta como actividad de las notas.
- **Haz del orbe sin apariciones bruscas**: al cambiar de agente nace fundido y crece desde el orbe (≈1,5 s); la retícula llega cuando el haz ya ha llegado.
- **Partículas atraídas por el orbe**: la mitad de fuentes, dos enjambres por fuente en vez de tres, más lentas y más tenues.

## 2026.11.15-oficina-v2.67
- Haz del orbe: fuera la línea del eje (queda solo el difuso), menos brillo, y el color se funde del color del orbe (en su origen) al de la tarea que atiende (al llegar); la retícula y la luz sobre el panel también van en el color de la tarea.

## 2026.11.15-oficina-v2.66
- **Haz de atención del orbe, rehecho**. Antes: trapecios planos y opacos, siempre ámbar, que tapaban media oficina. Ahora es luz: un cono volumétrico de bordes fundidos que se suma a lo que hay debajo (no lo tapa), del color que tenga el orbe en ese momento, con un hilo fino en el eje y motas de polvo dentro al enfocar. Donde mira: luz sobre el panel y una retícula de cuatro arcos que se cierra y gira despacio al enfocar. Desde arriba: cono suave hasta los pies y charco de luz elíptico con su anillo. El cono es una imagen ya calculada (una por color): una copia por fotograma, sin degradados.

## 2026.11.15-oficina-v2.65
- **Auditoría de consumo de la oficina** (medida con `FARO_PROF` en emulación de iPhone, 6 agentes): un fotograma costaba 9,9 ms, y el 73 % eran la bóveda (4,4 ms) y su física (2,8 ms). Dos causas: (1) la física daba un paso cada 8 ms de tiempo, así que a 20 fotogramas/s hacía 6 pasos por fotograma y a 10, 12: bajar los fotogramas no ahorraba cálculo; ahora un paso cada 16 ms en PC y cada 30 ms en táctiles. (2) cada conexión de la bóveda creaba un degradado y un trazo propios en cada fotograma; ahora se agrupan por color y grosor (un trazo por grupo). Resultado: 5,3 ms por fotograma (−46 %): física 2,8 → 0,9 ms, bóveda 4,4 → 2,5 ms.
- **El orbe deja leer los bocadillos**: si el sitio al que va pisa lo que dice un agente, se aparta al lado de la bóveda.
- **Con un solo agente trabajando, el orbe ya no se queda clavado**: lo mira (ciclo normal) → lo orbita → se aburre y baja a la bóveda (absorbe y deposita) → juega con sus satélites (los abre, los acelera y lanza uno al aire por turno) → vuelve. Duraciones con algo de azar (unos 50 s la vuelta).

## 2026.11.15-oficina-v2.64
- Las «comunicaciones» serenas de las conexiones de la bóveda ya no son rayas: son tres motas blandas en fila (la primera con un halo mínimo) que ondulan un poco al avanzar. Mismo ritmo y sentido que en v2.63.

## 2026.11.15-oficina-v2.63
- **Conexiones «vivas pero serenas»** en la bóveda: cuando la cámara pasa cerca (la conexión se ve larga en pantalla), por cada una corre de vez en cuando un pulso de luz muy tenue, desde la nota más conectada de las dos hacia la otra y del color de la nota a la que llega. Cada conexión tiene su ritmo (un pulso de 1,5–2,5 s cada 7–13 s) y su desfase, así que nunca laten a la vez; no se activan en las conexiones que ya están encendidas por una llamada real. Sin coste medible. (La bóveda no guarda quién enlaza a quién, solo que están enlazadas; por eso el sentido es «del nodo más conectado al otro».)

## 2026.11.15-oficina-v2.62 · la caída a la bóveda sin línea de puntos

- La llamada que cae en la bóveda sigue siendo la misma línea continua del lanzamiento: al cruzar el cristal se adelgaza y se apaga poco a poco, sin pasar a puntos (petición de Nawe).

## 2026.11.15-oficina-v2.61 · ficha de agentes y Bibliotecario

- **Ficha obligatoria** en las notas de agentes (`_agentes/`, `Faro/Órdenes/`) creadas desde el 15 nov: `autor`, `proyecto`, `experto`, `decision`. Si falta, Faro deduce lo que puede y lo marca «(deducido)»; lo que no puede deducir sale en «Te toca» como «notas de agentes sin firma». La firma `autor:` manda en la atribución de la oficina.
- **Bibliotecario nocturno**: entre 04:30 y 06:30, una vez al día y solo tras 20 min sin escrituras ajenas, Faro escribe `Faro/Biblioteca/Informe AAAA-MM-DD` (carpetas grandes, notas muy centrales, casi vacías, títulos casi iguales, inbox atascado, proyectos quietos, enlaces rotos) y encarga a Hermes las recomendaciones de estructura. No mueve, renombra ni borra nada. Las recomendaciones salen en «Te toca» hasta marcarlas `revisado: sí`. Configurable en `bibliotecario` (hora, hasta, calma_min, agente, enabled).
- **Restaura el enlazado por significado de v2.59** (mención, ficha, agente que trabaja, camino de vuelta), que v2.60 perdió al publicarse sobre v2.58.
- Corrección: lo que el propio repaso escribe en una pasada ya no cuenta como «nota recién editada por otro».

## 2026.11.15-oficina-v2.60
- **Llamadas a la bóveda, rehechas**. Idea: la oficina está arriba, sobre un suelo de cristal; la bóveda queda debajo y el octógono es la barandilla. Cada llamada es un lanzamiento: sale del panel del agente en arco por encima de la barandilla, toca el cristal (onda) y desde ahí cae bajo el cristal (línea fina a trazos, chispa que encoge) hasta su nota.
- **Los hilos ya no se salen del octógono**: si la nota queda fuera de la vista (cámara acercada), el hilo acaba en el borde interior; las curvas se calculan dentro. Antes iban a la posición de la nota aunque estuviera fuera.
- **Muchas llamadas a la vez**: solo las 8 más nuevas dibujan hilo, el resto solo su chispa; las de un mismo agente salen escalonadas (0,14 s) en vez de todas de golpe; sin degradados por hilo (menos coste).

## 2026.11.15-oficina-v2.59
- **Faro mira por sí mismo si se está generando voz** (ya no depende de que un agente informe): en el PC comprueba cada 3 s si hay un proceso lanzado desde la carpeta de la voz (`~/FaroTrabajo/voz`, o `voz.dir` en config.json) o de Chatterbox, y cada 6 s cuál es el último audio de esa carpeta, cuántos van hoy y su idioma si el nombre lo lleva. No lee ni copia audios ni textos. Va en `/api/machines` (`voz`) y en el estado (`voz_probe`); el monitor de voz de la oficina lo usa como señal principal y lo refleja en 2–5 s. Prueba nueva: `tests/test_voz_probe.py`.

## 2026.11.15-oficina-v2.58
- **Teletransporte**: los agentes ya no entran ni salen andando por la entrada. Se materializan en su mesa (columna de luz de su color, anillos en el suelo y barrido de abajo arriba, 0,85 s) y se desmaterializan igual al dejar de trabajar; si les cambian de mesa, saltan a la nueva.
- **El orbe deposita en la bóveda**: además de absorber partículas al pasar, cuando lleva entre 7 y 12 satélites (umbral al azar cada vez) los va soltando de uno en uno, cada 2–6 s, hacia notas cercanas, que laten al recibirlos; para al quedarse con dos. Guarda hasta 12 satélites (antes 10). Es una imagen de Faro como intermediario entre agentes y bóveda, no actividad real de las notas.

## 2026.11.15-oficina-v2.57
- **Monitor permanente de la voz narradora**, bajo la tele de GTA VI en Proyectos (tarea aparte dentro de esa cadena): micrófono, luz de estado (GENERANDO verde que late / EN ESPERA ámbar / SIN AVISOS gris), onda de voz que se mueve como alguien hablando mientras se genera y queda casi plana en espera, idioma activo (ES · EN · PT), el paso, cuántos clips esperan el OK de la voz y la última señal. Cada aviso nuevo destella y manda un dato al orbe. Se alimenta de los informes del proyecto `voz` (bloque opcional `{"voz": {"paso", "idioma", "cola", "revisar"}}`); Faro guarda el último aparte (`voz_last`) para que no se apague. Al tocarlo, ficha con el estado. Construido sobre v2.56.

## 2026.11.15-buzon-v2.56
- **Faro vigila todas las bandejas de la bóveda**, no solo `inbox/faro/`. Una tarea que entra en `_agentes/inbox/hermes/`, `inbox/codex/` o `inbox/claude/` se lanza como orden a ese agente; al terminar, la respuesta va a `outbox/` y la tarea a `archivo/`.
- Antes de lanzar nada se filtra:
  - lo que ya tiene RESPUESTA, o está marcado como hecho o cancelado, se archiva sin repetirse;
  - los AVISOS pasan al tablón `_agentes/avisos/` y no se lanzan;
  - una tarea que nadie vio en 7 días va a `archivo/sin-respuesta/` para que Nawe decida.
- `outbox/` queda solo con lo reciente: las respuestas de más de 72 h cuya tarea ya está archivada pasan a `archivo/`.
- El estado del buzón dice cuántas tareas hay pendientes por agente y avisa de cualquier bandeja sin dueño.
- Tests nuevos en `tests/test_vault_inbox.py`.

## 2026.11.14-oficina-v2.55
- **Un solo estilo para el panel y la oficina** («Plató nocturno»): colores, letra, radios y tiempos de animación salen de `web/tokens.css` y `web/tokens.js`, compartidos. Cada proyecto conserva su color.
- **Fuente servida desde Faro**: ya no se pide nada a Google; funciona sin internet.
- **Panel más claro**: solo la primera tarjeta dice «HAZLO YA»; las demás, «SIGUIENTE», con indicadores de relevancia, retorno y coste. Letra mínima de 13 px y botones de 44 px.
- **Panel más ligero**: `/api/status` lleva solo lo que pinta el panel (≈15 KB, antes ≈34 KB); la oficina pide aparte lo suyo en `/api/office` al abrirse.
- **Pausa real en segundo plano**: con la pestaña oculta se paran animaciones, temporizadores y consultas.
- La oficina del orbe no cambia: pasará a los colores comunes en su propia línea de trabajo.
- Auditoría de Claude; código de Codex; validación de Hermes.

## 2026.11.14-oficina-v2.54
- **Batería en el iPhone** (auditoría del panel entero, no solo la oficina). Lo que gastaba: la «lluvia digital» de fondo pintaba la pantalla completa unas 11 veces por segundo siempre, también debajo de la oficina; las gráficas en vivo, 15 veces por segundo; y con la oficina abierta se pedían datos al PC unas 2 veces por segundo (la radio no descansaba). Ahora, en pantallas táctiles: sin lluvia de fondo, gráficas a 4 por segundo, borde animado de «Mando» quieto; sondeos más lentos (estado 10 s, en vivo 6 s, bóveda 3 s, máquinas 5 s). En cualquier equipo: con la pestaña oculta no se pinta ni se pide nada, y con la oficina abierta el panel de debajo deja de pintarse y de pedir sus datos en vivo. Medido en emulación de iPhone con la oficina abierta: peticiones 25 → 8 cada 12 s; trabajos de pintado 2163 → 732.

## 2026.11.14-oficina-v2.53
- **Luz 3D en el orbe** (sustituye a los reflejos de v2.51–v2.52, que no eran físicos): el orbe se ilumina como una esfera pulida vista de frente. Luz de sala fija (arriba-izquierda) más hasta 4 luces del entorno (paneles encendidos con su color, nodos cálidos de la bóveda), con caída por el cuadrado de la distancia. Cada luz da difusa en su lado, un brillo especular en la normal intermedia (L + V), aplastado por el escorzo, y un filo de contraluz en el borde; el lado opuesto se oscurece. El brillo ya no sigue a la mirada ni a la velocidad. Entradas y salidas de cada luz, fundidas.

## 2026.11.14-oficina-v2.52
- El brillo principal del orbe (el punto blanco) ya no es fijo: se tiñe con la luz del entorno (el panel o el nodo que tenga cerca; si no, su propio color), se desliza hacia la luz más fuerte, acompaña a la mirada y se queda un poco atrás al volar. Transiciones suaves; nunca se sale del cristal.

## 2026.11.14-oficina-v2.51
- **Consumo en el móvil**: en pantallas táctiles la oficina pinta a 20 fotogramas por segundo (antes 30) y a 10 si llevas 40 s sin tocarla; resolución tope ×1,5 (antes ×2) en el lienzo, el fondo y la capa de la bóveda. En total, alrededor de un 60 % menos de píxeles pintados por segundo (un 80 % en reposo). El PC no cambia. Con `window.FARO_PROF = 1` la oficina mide cuánto tarda cada parte (`FaroOffice._orb().pf`).
- **Reflejos vivos en el orbe**: el cristal recoge la luz de lo que tiene cerca (paneles encendidos, con su color; nodos grandes y cálidos de la bóveda) como un destello y un arco en ese lado, y su brillo de siempre se queda un poco atrás según hacia dónde vuela. Se recalcula 5 veces por segundo con las 3 luces más cercanas.
- **Proyectos**: cada aguja usa el color propio del proyecto (`hue` de la configuración). Proyecto **terminado** (`"done": true` en su entrada de `projects` de config.json): aguja dorada, corona fija y sello «COMPLETO», sin latido ni obra. Si pasa del tope de 12 segmentos, dice cuántos lleva («17 HECHOS»).

## 2026.11.14-oficina-v2.50
- Partículas gravitatorias en **enjambres**: muchas, pequeñas y siguiendo el vector nota → orbe. Cada enjambre es una sola imagen ya pintada (13 motas con mini remolinos y chispas de CHF) teñida una vez por color: parecen cientos con unas 40 pinturas por fotograma, sin halos ni estelas aparte (menos cálculo que en v2.49). Se estiran al caer y pasan del color de su nota al del orbe.

## 2026.11.14-oficina-v2.49
- **Partículas de energía gravitatoria con sprites de CHF**: cuando el orbe sobrevuela la bóveda, de las notas que atrae salen partículas que caen en espiral hacia él, acelerando. Cada partícula es el **remolino** de CHF (`fx_viento`), su estela el **imán** de CHF (`fx_iman`, la atracción) y, al llegar, la **chispa** de CHF (`fx_chispa`). Salen con el color de su nota y van tomando el del orbe al caer. Atlas nuevo: `web/office-chf.webp` (10 KB, del repositorio del juego).
- Arreglo: un rayo de la bóveda con coordenadas no válidas lanzaba un error en cada fotograma y dejaba el lienzo sin restaurar; ahora se descarta.
- Proyectos: si los nombres no caben, van al tresbolillo (uno arriba, otro abajo).

## 2026.11.14-oficina-v2.48
- **El monitor de la máquina de GTA VI no se apaga** (como el de Strata): Faro guarda aparte el último informe que trae el bloque `gta` (`gta_last` en el estado), aunque ya no salga entre los agentes por tener más de 12 h. La tele enseña ese último dato con su antigüedad («datos hace 1 d»); si ahora mismo alguien trabaja en GTA VI en la oficina, la luz se pone verde y el paso es lo que está haciendo. Prueba nueva: `tests/test_gta_last.py`.
- La cabecera de la tele deja sitio a los jueces de cada clip (ya no se pisan).

## 2026.11.14-oficina-v2.47
- **«500 años después»** (mismo concepto, otra época; todo dibujado en código, sin gastar créditos): suelo de cristal oscuro con rejilla; **mesas flotantes de cristal** sobre una columna de luz, con la pantalla como **panel holográfico** que proyecta un emisor (adiós al flexo); quien trabaja se sienta en un **disco flotante** (adiós al puf); **puestos de zona holográficos** (plataforma, haz y panel con su símbolo, que se enciende y barre al usarse); **canales de entrada** como compuertas de cristal con filo de neón que barren al entrar algo; **espera** como carril de luz; **buzón** como baliza holográfica; **bocadillos** de cristal oscuro con el filo del color de quien habla; rótulos de interfaz espaciados.
- **Actividad, lavado de cara**: panel de mando de cristal con pasada de escáner; cada cifra lleva ahora su rótulo (TRABAJAN · EN COLA · LIBRES) y CPU/GPU van en barras segmentadas.
- **Proyectos auditados y rehechos**: antes, una planta por cada cosa sin decir qué era cada una. Ahora cada proyecto es una **aguja holográfica** con un segmento por cosa hecha y **color por tipo** (cian entregas, violeta artefactos, oro orgullo, que cuenta doble; gris azulado si la obra guardada es más alta), con **leyenda** en el panel, baliza en la punta y «EN OBRA» con anillo de escaneo cuando alguien trabaja en él. Ciudad holográfica de fondo con horizonte de neón y rejilla en perspectiva. La ficha dice cuántas entregas, artefactos y orgullo lleva y si ha llegado al tope de 12.
- **Máquina de GTA VI con monitor propio, como Strata**: luz de estado (verde que late = trabajando; ámbar = en pausa con aviso de hoy; gris = sin aviso reciente), recuento (en marcha, publicados, bloqueados), el paso en el que va y cuándo dio la última señal. En pausa la carretera se queda quieta y atenuada. Cada aviso nuevo (o cuando empieza o deja de trabajar) hace destellar la tele y manda un dato al orbe.
- **El orbe mantiene su ruta**: recorre a quien trabaja en orden de mesa y, si alguien entra o sale, sigue por donde iba (3 s de margen por si el estado parpadea); ya no vuelve a empezar ni salta a la bóveda. Sin trabajo se queda flotando donde estaba y solo a los 25 s va a sobrevolar la bóveda; en cuanto vuelve el trabajo, sale desde donde esté. Al cambiar entre PC y móvil conserva su sitio relativo.

## 2026.11.14-oficina-v2.46
- **El octógono, clave de diseño**: la bóveda central es un octógono (en el móvil, alargado), y también lo son las zonas, la entrada, los proyectos, la barra de arriba y el suelo de la sala. La capa de la bóveda se funde con su borde octogonal (máscara calculada una vez por tamaño).
- **Sin sala de descanso**: quien deja de trabajar se va (deja su mesa y sale andando por la entrada) y queda en el banquillo; en la sala solo está quien trabaja. El buzón pasa a la entrada; la tele de «GTA VI en vivo» pasa a Proyectos (arriba a la derecha, con los edificios a su izquierda); las charlas se encuentran a medio camino entre sus mesas. Nadie se planta ya en la bóveda: quien trabaja con ella lo hace desde su mesa, con su hebra hasta la nota.
- **Orbe mucho más suave**: se mueve por fuerzas (aceleración con tope, frenada al llegar, deriva lateral que curva el camino y un vaivén lento propio); cada dato lo mece un poco al llegar. Su brillo, su color y su giro dependen de lo que lo alimenta en tiempo real (más datos recientes, más luz y giro más vivo; el color es la mezcla de esos datos). **Le orbitan sus últimos puntos de energía** (los 10 últimos datos y visitas, cada uno con su color, que se apagan despacio en 4 minutos).
- **Ferrofluido suave**: la bóveda reacciona al orbe pero mandan sus propias fuerzas: tirón unas 4 veces menor, con caída gaussiana, y púas solo en las 8 notas más cercanas.

## 2026.11.14-oficina-v2.45
- Lo que rodea al orbe, sin saltos y animado. El color del halo y del iris pasa suave al del dato que llega y vuelve igual (antes cambiaba de golpe); el «hinchado» de cada golpe de energía crece y se deshace suave, y su onda entra fundida; el haz se estrecha poco a poco al pasar de iluminar a enfocar, y el paso de haz a foco cenital es un fundido; la onda de cada 15 s nace y se apaga fundida. Animación: los dos anillos precesan despacio (se inclinan y se abren como si giraran en 3D) y un polvo de luz orbita alrededor, más vivo cuanto más despierto está el ojo.

## 2026.11.14-oficina-v2.44
- Rediseño de la oficina (decisión de Nawe, 14 nov). **Ya no hay torre**: el ojo de Faro es un **orbe que flota** (diseño propio: esfera de cristal oscuro con un iris de luz dentro, dos anillos y su luz). Mismas reglas que el ojo de siempre: recorre a quien trabaja por orden de mesa, el haz se estrecha cuanto menos le falta a la tarea, y sin trabajo se apaga y parpadea. Ahora vuela: **ilumina → enfoca → persigue → ilumina desde arriba → siguiente** (cada visita dura lo que necesita el vuelo, mínimo 7,5 s; vuela con muelle amortiguado y tope de velocidad, sin tirones). Desde arriba deja un foco cenital blando sobre quien trabaja.
- **La bóveda pasa al centro**: es el objeto central (más grande, con luz propia y borde de membrana) y **todos acuden a ella**: quien trabaja con la bóveda va hasta ella y la consulta de pie, delante; las mesas quedan a sus lados (8 en el PC y 8 en el móvil) y las zonas en los extremos (en el móvil, fichas arriba).
- **Ferrofluido**: cuando el orbe pasa por encima de la bóveda, su gravedad tira de las notas que tiene cerca (más las ligeras que las pesadas) y se estiran hacia él en púas negras y brillantes; al irse, cada nota vuelve a su órbita con un rebote. Sin nadie trabajando, el orbe sobrevuela la bóveda despacio y la va removiendo.
- **Los datos alimentan al orbe**: cada cambio real de un agente sale como una chispa de su pantalla (o de su cabeza, si está en la bóveda), vuela en arco hasta donde esté el orbe y, al llegar, le da un golpe de energía del color de su zona (onda, destello y el núcleo se tiñe un momento).
- Tocar el orbe abre su ficha («El ojo de Faro»). Avisados del cambio Faro, Claude, Codex y Hermes (AVISOS.md en el buzón y `_agentes/inbox` en la bóveda).

## 2026.11.14-auditoria-v2.43
- Un informe mal formado ya no apaga el panel: se valida y normaliza al llegar, cada sección del estado falla por separado y los informes viejos o inválidos se limpian.
- Si no hay conexión con el PC o los datos son antiguos, la cabecera lo dice en ámbar (antes mostraba «Todo bien» sobre una foto fija).
- Acciones, actualizar, datos de máquina y respuestas del buzón exigen token desde fuera de la red local y Tailscale.
- Autoactualización con prueba de arranque y vuelta atrás: si la versión nueva no arranca, se queda la anterior y el error sale en «Te toca». Firma de versiones preparada (se activa con `update.pubkey`).
- Auditoría de Claude; código de Codex; validación de Hermes.

# 2026.11.14-oficina-v2.42 (incluye v2 a v2.41)

- v2.42: sin corte en la bóveda. El grafo se recortaba con dos capas rectangulares (una dentro de otra) y, al acercarse la cámara, los halos y las notas quedaban cortados por una línea recta arriba. Ahora se pinta en su propia capa y el borde se funde con el panel (degradado suave en los cuatro lados), en la oficina y en la ficha grande. Arreglado además que los halos de los colores de calor salían negros y que cada tono nuevo creaba otra textura sin límite (memoria). El resto de la oficina, en el mismo lenguaje que la bóveda: marcos como membranas luminosas (sin tinta), hebras orgánicas que se mecen de la mesa a su zona y a la nota de la bóveda, con chispas que viajan como en la bóveda (salen despacio, aceleran y frenan); envíos a proyectos como orbes con estela; el haz del faro con los lados difuminados y sin pasar por encima de la bóveda.

- v2.41: menos zoom y menos maraña. La cámara va más lejos y con un campo más abierto (las notas se ven a menos de la mitad de tamaño). Mucha más distancia: el mundo que ve la cámara se separa ×4, los choques guardan el doble de hueco y la gravedad aprieta menos; en simulación, separación entre vecinas en pantalla 10 → 12,4 px con notas mucho más pequeñas (solape 0,67 → 0,21). Hilos mucho más tenues y finos (opacidad 0,62 → 0,2). Márgenes: nada cruza un recorte interior; lo que se acerca al borde se desvanece y los nombres se quedan dentro.

- v2.40: la cámara navega sola por dentro de la bóveda. Va a lo que se acaba de encender, al núcleo, a lo caliente y a rincones al azar; de vez en cuando se aleja para ver el conjunto. Movimiento con muelles amortiguados, despacio (≤ 0,09 cerca y 0,16 de lejos, en unidades del mapa por segundo) y giro de la mirada con tope (≤ 26°/s); se orienta antes de avanzar y rodea lo que mira en vez de atravesarlo. Perspectiva real con niebla: lo cercano grande y nítido, lo lejano tenue; lo que queda detrás no se dibuja. Movimiento orgánico: el conjunto respira (medusa), las ramas se mecen, más cuanto más lejos del núcleo (alga), y chispas viajan por las conexiones desde lo caliente y encienden la nota al llegar (cerebro). Nombre de la nota que mira la cámara. Sin gestos manuales: la interacción la hace la cámara. Todo dentro del recuadro de la oficina. En simulación de 4 min: sin saltos, nunca a ciegas (mínimo 15 % del grafo a la vista, media 80 %).

- v2.39: la bóveda se toca. En la vista grande (toca la bóveda en la oficina; ahora mucho más grande, hasta 920 px de ancho y 62 % de la altura): arrastra una nota y la sigue al dedo, sus enlazadas la acompañan (las ligeras más) y al soltarla sale disparada y vuelve a su órbita con rebote; tócala para darle un golpe de energía con su onda y ver nombre, enlaces, calor y masa; arrastra el fondo para empujar el giro (se frena solo por inercia); pellizca o usa la rueda para el zoom (0,6× a 3×). Ratón y táctil (iPhone). Los toques de Nawe no suman calor: solo cuentan las lecturas y escrituras reales.

- v2.38: núcleo claramente visible. Fuerza hacia el centro ×5 (en la bóveda real, los 6 nudos más enlazados a 0,06 del centro frente a 0,30 el resto; islas aún separadas, 2,7). En la oficina: los nudos del núcleo hasta 2,3 veces más grandes, dorados, con aro y halo, y su nombre siempre a la vista; resplandor dorado que late en el centro de fuerzas.

- v2.37: mucho más espacio en el mapa de la bóveda. Servidor: el doble de repulsión, islas más abiertas (radio 1,4) y encuadre al 98,5 % (notas aplastadas contra el borde en la bóveda real: 35 → 9). Oficina: radio de choque 2,5 veces mayor, gravedad a menos de la mitad, más volumen en profundidad y el mapa ocupa el 82 % del recuadro en vez del 46 %. En simulación, la distancia en pantalla a la vecina más cercana pasa del 0,9 % al 2,2–2,7 %, y en una vuelta completa nada se sale del recuadro (máximo 88 %).

- v2.36: núcleo visible y energía en directo. Masa = calor o conexiones: lo muy enlazado pesa y atrae a lo pequeño. Los nudos más enlazados van al centro (en la bóveda real, a 0,20 del centro frente a 0,40 el resto) con halo dorado; encuadre simétrico alrededor del eje del giro (islas mejor separadas: 2,65 → 3,1). Cada entrada a la bóveda da una energía cinética concreta: leer 0,0012 · escribir 0,0035 · crear 0,006 (estalla y empuja a sus vecinas) · borrar 0,003 (las vecinas caen al hueco). v = √(2E/m): con la misma energía, lo ligero se mueve el doble que lo pesado. El golpe llega del lado de quien entra, se ve como una oscilación amortiguada con un anillo y se propaga a las notas enlazadas con 0,12 s de retraso. Amplitud en una nota ligera: 2,2 % del mapa al leer, 3,8 % al escribir, 4,9 % al crear.

- v2.35: conexiones bien visibles: más gruesas según la cercanía, más opacas y con el color de sus dos notas (degradado de calor de un extremo al otro); las del fondo solo se apagan un poco. Giro más lento: una vuelta cada 3 min.

- v2.34: física real en el mapa de la bóveda. La cámara queda quieta y gira el sistema (una vuelta cada 75 s): cada nota sigue su órbita atada con un muelle poco amortiguado, con fuerza proporcional a su masa (como m·ω²·r), así que lo que se retrasa se abre y vuelve con rebote. Choques en 3D con pérdida de energía (restitución 0,55); en el choque pesa el cuadrado de la masa, para que lo rojo no ceda ante un enjambre de ligeras. Gravedad suavizada (Plummer, sin hondas) de las calientes: en prueba, una nota caliente pasa de 17 a 35 vecinas cercanas. Calor en vivo: cada lectura (+1) o escritura (+2) cambia al momento color, masa y profundidad de esa nota y le da un empujón. Probado 180 s simulados a 30 y 15 fps: sin valores inválidos ni notas fuera del recuadro.

- v2.33: calor = masa. Degradado azul (poco visitada, ligera) → violeta → naranja → rojo (muy visitada, pesada). Las rojas atraen al resto con una gravedad suavizada y apenas se mueven (inercia); las azules se dejan llevar. La forma se recalcula cuando cambia el calor. Huérfanas de verdad en verde agua con anillo discontinuo, para no confundirlas con las rojas. Prueba: con una nota caliente, el resto queda un 27 % más cerca de ella.

- v2.32: mapa de la bóveda en 3D. Fuerzas de grupo: cada carpeta principal tiene un ancla en círculo y sus notas tiran hacia ella (en la bóveda real, separación entre islas 1,93 → 2,65). Gira 360° cada minuto con inclinación fija y perspectiva real: lo cercano, más grande y nítido; lo del fondo, detrás y apagado (aristas incluidas). Eje Z = calor (la bóveda no da otro dato de profundidad): lo más visitado, delante; grosor fijo por nota para que lo frío no sea un plano. Con «reducir movimiento» se queda quieto en un ángulo.

- v2.31: colores en la bóveda de la oficina. Huérfana de verdad: rosa con anillo discontinuo. Suelta a propósito: gris atenuado. Una sola conexión y poco visitada: gris claro. El resto, degradado de calor por visitas (violeta frío → lavanda → ámbar → naranja), con halo en los puntos más calientes. El calor suma cada lectura (1) y escritura (2) reales, no las de Faro, y se enfría a la mitad cada 3 días; se guarda en `data/vault_heat.json`. Pie: notas · enlaces · huérfanas · con 1 enlace. Las órdenes de Faro se enlazan solas con su proyecto (antes colgaban solo del índice de Faro).

- v2.30: la bóveda de la oficina es la bóveda real. Fuera `_to_delete/` y las copias de conflicto de Syncthing (salían como huérfanas falsas). Las huérfanas de verdad (sin ningún enlace) llevan un anillo rojo discontinuo y el pie dice cuántas hay; las sueltas a propósito (plantillas, bandeja, pruebas) salen atenuadas y no cuentan. El grafo se rehace al instante con cada cambio y, por si acaso, cada 2 min.

- v2.29: nuevo edificio «Voz» (clonación de voz de la narradora de GTA VI). Crece con las órdenes terminadas y los artefactos del proyecto `voz`, y lleva grúa cuando un agente trabaja en él. El barrio admite hasta 6 edificios.

- v2.28: Strata enseña toda su lectura y escritura. Pantalla de su mesa: cuatro barras (texto que lee en cian y que escribe en verde; disco que lee en ámbar y que escribe en rosa) y una gráfica de 2 min que alterna cada 5 s entre lo que escribe la IA y el disco, con su cifra ajustada al hueco (no pisa la temperatura). Ficha: modelo, estado, lectura y escritura de texto (en vivo o de la última orden), totales, lo leído y escrito en la última orden de Faro, disco de los procesos de Strata y disco del PC (MB/s), memoria de contexto, temperaturas y memoria de la gráfica. Faro mide el disco del PC con /proc/diskstats y el de Strata con /proc/<pid>/io de sus procesos (solo el programa, no órdenes que lo mencionen). La ficha de Máquinas suma el disco.

- v2.27: las páginas abiertas (Mac, iPhone…) se recargan solas cuando el PC se actualiza: antes seguían enseñando la oficina vieja hasta recargar a mano. Proyectos: edificios y grúas siempre dentro de su panel (con 12 plantas la grúa ya no tapa el título). La placa de Strata baja un punto la letra si el nombre del modelo no cabe.

- v2.26: lo que no tiene sprite se dibuja en estilo «Bruto» (juego Flash clásico: contorno grueso casi negro, color plano con una sola sombra, madera y pergamino), sin gastar créditos. Proyectos: edificios de colores con ventanas enmarcadas, cornisa, puerta y banderín; en obra, andamio de madera y grúa amarilla con la carga balanceándose; nombre en cartel de pergamino; barrio con luna, colinas y acera con bordillo. Entrada: los tres canales son carteles de madera con clavos (se encienden con su color al llegar algo) y quien espera turno se sienta en un banco de madera. Marcos de zonas, bóveda, descanso, proyectos, entrada y barra superior con tinta gruesa por fuera y su color por dentro. Bocadillos de pergamino con contorno. Barato de pintar: sin gradientes nuevos por fotograma.

- v2.25: la luz va donde debe. El haz del faro sale de la linterna por detrás de la torre (la propia torre lo tapa, ya no la cruza por encima), termina en la pantalla de quien vigila sin pasarse y no es más ancho que una mesa; el foco que deja en la pantalla sigue igual. Los flexos dibujados alumbran la mesa hacia abajo (cono corto y charco de luz), no la pantalla.

- v2.24: la placa de Strata da el nombre limpio del modelo (sin colas de empaquetado como «-unsloth-ud» o «-Q4_K_M»: «qwen3.8-flash-next»). Como Strata no publica métricas de entrada, la barra de lectura enseña, más tenue, la de la última orden de Faro; la de escritura sigue en directo mientras piensa.

- v2.23: la oficina con sprites (estilo «Plató nocturno», hechos con Higgsfield y elegidos por los agentes a partir de la bóveda). Cada agente tiene su personaje (Claude, GPT, Codex, Hermes y Strata) con poses de verdad: anda (y se gira hacia donde va), teclea sentado en un puf a la izquierda de su mesa mirando a la pantalla, toma café en el descanso, charla. Mesas, flexos, faro, sofá, planta, cafetera, buzón (abierto si hay sugerencias) y los siete puestos de zona en la vista ancha (en el móvil siguen las fichas) también son dibujos. Todo lo que es dato se sigue pintando en vivo encima: pantallas de las mesas y de los puestos, luces, haces, cifras. El faro llena su columna sin deformarse (linterna y base enteras, fuste con anillos) y su ojo es la lente: mira a quien trabaja, estrecha la pupila al concentrarse y parpadea si no hay nadie. Un solo atlas de 320 KB (`web/office-sprites.webp`, caché de 30 días con versión en la dirección); el fondo se dibuja a la resolución de la pantalla (hasta 2×) para que no se vea borroso en el iPhone; en el propio PC sigue en modo ahorro. Si el atlas no carga, o con `?vector`, la oficina es la de antes. Herramientas: `tools/recortar-sprites.py` (hoja sobre magenta → piezas) y `tools/sprites-atlas.py` (piezas → atlas + índice en office.js).
- v2.23: Strata con monitor propio. Igual que quien trabaja en GTA VI lleva la carretera en su pantalla, la mesa de Strata enseña su informe en directo: lo que lee (entrada, cian) y escribe (salida, verde) por segundo, la salida de los últimos 2 min y la temperatura de la gráfica (o de la CPU si la gráfica no responde). El modelo cargado va en su placa («Strata · Qwen3-14B») y su ficha lo detalla (modelo, estado, lectura y escritura por segundo o de media, totales, memoria de contexto, temperaturas, memoria de la gráfica). Faro lo pregunta a Strata en localhost cada 2 s solo con la oficina abierta (/v1/models, /slots y /metrics si los da; si no, el ritmo de la última orden de Faro). La ficha del PC suma la temperatura de la CPU.


- v2.22: el repaso de conexiones lee todas las notas para revisarlas; esas lecturas se marcan como de Faro antes de hacerse y el vigía ya no las pinta (antes salían ~140 lecturas falsas cada 10 s atribuidas a quien estuviera trabajando, y empujaban fuera de la ventana los eventos reales).

- v2.21: doble vía para la bóveda. (1) Al instante: cada lectura, escritura, alta o baja que ve el vigía (inotify) sale en la oficina, y cada escritura de otro dispara el repaso de conexiones en el siguiente ciclo (≤5 s). (2) Red de seguridad cada 15 s: se comparan fechas de todas las notas; si inotify perdió una escritura, sale igual marcada «sondeo», sin duplicar lo ya visto. El repaso de conexiones también corre cada 15 s si hubo cambios. Las escrituras del propio repaso se marcan como de Faro antes de hacerse.

- v2.20: grafo de la bóveda fiel a Obsidian: entiende los enlaces dentro de tablas (`[[nota\|alias]]`), compara nombres con acentos normalizados (NFC, lo que llega del Mac) y pinta hasta 400 notas (antes 140, la bóveda ya rondaba ese tope y las menos enlazadas desaparecían). El repaso de conexiones tampoco da por rotos esos enlaces.

- v2.19: la bóveda ya no «se raya». Al bajar la oficina a 30/15 fps (v2.15) cada paso de la física era el doble de grande y, cuando el grafo cambiaba, los nodos se pasaban de frenada y salían de la caja (en la vista de PC llegaban a salir todos). Ahora la física va en subpasos fijos, con velocidad limitada y cualquier nodo perdido vuelve a su sitio; el grafo se dibuja recortado a su caja y un fallo de dibujo ya no puede congelar la oficina. Prueba de estrés con la bóveda cambiando sin parar y un reinicio del servidor: 0 nodos perdidos y 0 errores.
- v2.18: el config.json del PC lanzaba «codex exec {prompt}» sin modo: Codex quedaba en solo lectura y sin red, así que el --add-dir de la v2.17 no servía. Si no viene modo, Faro añade «-s workspace-write» (escribe en ~/FaroTrabajo y en la bóveda, y puede avisar a Faro en localhost).
- v2.17: Codex puede trabajar de verdad. Su caja de arena solo le dejaba escribir en ~/FaroTrabajo y le cortaba localhost: ahora recibe la bóveda con --add-dir (si su versión lo entiende) y red para informar a Faro, igual que Claude ya tenía la bóveda. Strata se encuentra solo si cambia de puerto al reiniciar (busca en 18500-18505 con su misma cabecera, solo en localhost, y guarda el puerto). conectar-strata.sh v3 (lee la clave de ~/.strata/data/native-instances sin mostrarla).
- v2.16: la bóveda se repasa sola. Cada vez que alguien modifica una nota (como mucho cada 30 s), `tools/vault_links.py` une encargo ↔ respuesta, mantiene bloques automáticos en Inicio, Faro, CHF y el Índice de tareas (entre marcadores `<!-- faro:auto:… -->`, sin tocar lo escrito a mano), aparta las copias de conflicto de Syncthing a `_to_delete/` (nunca borra) y no toca notas editadas hace menos de 90 s. Lo que necesita criterio (enlaces rotos, huérfanas, duplicados, encargos respondidos que siguen en inbox) va a `Faro/Conexiones de la bóveda` y a «Te toca». Espejo del repo público cada 5 min: `30 Recursos/GitHub CHF_GAME` con enlaces, ramas, últimos cambios del juego y versión de Faro. Desactivar: `vault_links.enabled` / `repo_mirror.enabled` a false.

- v2.15: modo ahorro en el propio PC (127.0.0.1/localhost o ?ahorro): su escritorio pinta sin aceleración y cada fotograma de Faro le costaba CPU a gnome-shell. Allí la oficina va a 15 fps, las gráficas en vivo a 2 fps y la lluvia de fondo se apaga. En el iPhone y el Mac, la oficina a 30 fps (antes 60) y la lluvia algo más lenta.
- v2.14: une la v2.13 de la Máquina GTA VI (tele y pantallas) con conectar-strata.sh v2: pregunta a la biblioteca de control de Strata en qué puerto está su API, prueba 18500 y 18501, busca la clave en el perfil de la app y en sus procesos y guarda puerto + clave; Faro usa ese puerto para el ejecutor y para ver si Strata está libre o pensando.
- v2.13: la Máquina GTA VI se muda a la oficina. En la sala de descanso hay una tele con la carretera de la máquina en vivo (un coche por clip avanzando por las paradas, los tres jueces como luces, barrera roja si el peaje está bloqueado) y la pantalla de la mesa de cada agente que trabaja en GTA muestra la misma carretera en pequeño. Tocar la tele abre la ficha de los clips con el enlace al panel. La tarjeta de la vista principal se quita: todo está en la oficina.

- v2.12: Strata con clave. Faro envía la clave de acceso de la IA local (data/secrets/strata.json, solo legible por el usuario del PC) y solo a localhost, nunca a otra dirección; no se puede cambiar desde la red. `tools/conectar-strata.sh` la busca en el propio Strata (proceso y configuración), la prueba contra localhost y la guarda sin mostrarla; si no la encuentra, la pide con escritura oculta. Desde el Mac: `ssh -t -l iceland -o HostName=iceland iceland 'bash <(curl -fsSL https://raw.githubusercontent.com/Nawebaz/CHF_GAME/faro-buzon/conectar-strata.sh)'`.
- v2.11: rendimiento de verdad en vivo. Los procesos del PC se miden por la diferencia de tiempos de /proc entre lecturas (antes «ps» daba la media de toda su vida y parecían clavados) y se suman por programa; el vigía del Mac usa la segunda muestra de «top» (la CPU de este segundo, no la media de un minuto). En la oficina, un punto late con cada lectura nueva y la ficha de Máquinas dibuja los últimos 2 min de CPU y GPU. Bóveda: el nombre de quien toca una nota solo se pone si ese agente declara que trabaja en la bóveda; si solo es «el único en marcha», sale como probable (¿Hermes?) y sin haz; las lecturas del historial horario de git se marcan como tales.
- v2.10: Máquina GTA VI en vivo en la vista principal. Si una sesión de Claude manda el campo «gta» (solo etapas y series, nada de contenido), aparece una tarjeta con la carretera de la máquina: un coche por clip avanzando por las paradas (fuentes, guion, captura, voz, rótulos, montaje, ITV ×3, taller, ITV 2, empaque, peaje, publicado), los tres jueces como luces sobre cada coche (ámbar revisando, verde aprobado, rojo cambios), barrera roja si el peaje está bloqueado y sirena azul si tiene prioridad. Tocarla abre el panel de la máquina. `faro-informa.py --json '{"gta":{...}}'`.

- v2.9: bóveda viva. El vigía del PC (inotify, sin instalar nada) avisa al instante de cada nota que se lee, se escribe, nace, se renombra o se borra; lo que llega del Mac por Syncthing se reconoce como tal. En la oficina el grafo se mueve como el de Obsidian: florece al abrir, la nota nueva nace junto a la que enlaza y empuja a sus vecinas, la nota tocada se enciende con sus enlaces y vecinas (azul lee, amarillo escribe, verde nueva, rojo borrada) y un haz sale de la mesa de quien la toca. Quién: solo si no hay duda. Tocar la bóveda abre el grafo en grande con nombres y el registro de accesos. En el móvil la bóveda es casi el doble de grande (zonas en fichas). Los agentes de la nube pueden decir qué notas leyeron con `faro-informa.py --notes`. API: GET /api/vault/live.
- v2.8: máquinas en vivo. Barra de la oficina con CPU y gráfica del PC (proc + nvidia-smi) y del Mac (vigía, cada 3 s), cada 2 s con la oficina abierta; rojo por encima del 85 %. Ficha con RAM, VRAM, temperatura, vatios y qué procesos/agentes usan la gráfica y la CPU; chip «GPU» en la mesa del agente que la está usando. API: GET /api/machines, POST /api/machine. El vigía del Mac se actualiza solo cada hora.
- v2.7: mesas estables: cada agente conserva su mesa; solo se reordena si quien trabaja se queda sin mesa o, cada 45 s como mucho, para acercar al faro a quien trabaja. Antes se paseaban en cada refresco y las zonas no llegaban a encenderse.
- v2.6: Claude del PC puede leer la bóveda (--add-dir); las órdenes recuerdan que en la bóveda solo se escribe dentro de _agentes/.
- v2.5: los agentes del PC ya no se quedan esperando: Codex con --skip-git-repo-check y sin entrada de teclado; Claude con -p y permiso de editar en ~/FaroTrabajo; Hermes en modo una respuesta. Sin cuota (429): la orden vuelve a la cola y se reintenta sola cuando hay cuota; mientras, Faro reparte a otros.
- v2.4: cada orden sabe qué pide (bóveda, código, web, vídeo, correo, sistema, escritura) y la oficina coloca a quien la hace en esa zona.
- v2.3: agentes encendibles desde Faro (data/overrides.json, sin poder tocar el comando) y órdenes por la bóveda (_agentes/inbox/faro → reparto → _agentes/outbox).

- v2.2: la oficina no levanta edificio para proyectos en silencio (el lab de trading hasta que tenga resultados).
- v2.1: las tareas de Codex y Hermes se agrupan por nombre aunque lleguen con otra marca.
Oficina (prioridad: móvil)
- Bóveda: el grafo de tus notas de Obsidian (nodos y enlaces reales, posiciones estables calculadas en el PC). En amarillo, lo tocado en los últimos 15 min; si alguien consulta la bóveda, la señal recorre los enlaces.
- Mesas por prioridad: cerca del faro quien trabaja; luego quien tiene una tarea de fondo; luego quien está libre. Agentes y mesas se reasignan solos.
- Descanso: solo quien tiene una tarea corriendo de fondo (su pantalla sigue girando en la mesa).
- El ojo marca el compás de 15 s (el sondeo de Faro): recorre a quien trabaja por orden de mesa y a cada uno le «late» la pantalla y el teclado cuando lo mira; nadie va al unísono.
- Flexos orientados a la pantalla que la iluminan. Pantallas con el símbolo de lo que usa cada agente, su color, nube/PC y avance.
- Entrada nueva con tres canales reales (Tú · Faro, Nube, PC · Mac) que se encienden cuando llega algo, pulso del sondeo de 15 s y banquillo (hechos, libres sin mesa, sin señal).
- Las chispas que suben por el faro son cambios reales de un agente; se quitaron las partículas decorativas.

Vista principal
- El aviso de arriba cuenta lo mismo que «Te necesitamos para» (antes decía «1 para ti» con la lista vacía).
- «Cómo vamos»: trabajan · de fondo · en cola · sin señal, y la lista de quién trabaja y en qué. Cada proyecto dice quién está en él.

Servidor
- Una ficha por agente real: las tareas que un agente del PC informa con nombres distintos (Hermes · chf-3d, Hermes · CHF3D…) se pliegan en su ficha; las vencidas, como «sin cierre».
- `action` solo admite el vocabulario (code, web, write, think, edit, obsidian, mail, system, skills; también en español). Si llega una frase, pasa a `step`.
- Sesiones de la nube terminadas hace más de 30 min: «hechas», al banquillo.
- Ejecutor sin sesión (p. ej. «Not logged in»): se aparta 6 h del reparto, se avisa en «Te toca» y `/api/health` dice por qué.
- Strata detectado en su puerto real (18501, compatible con OpenAI) y usable como ejecutor gratis. Reparto de reserva sin coste primero: Codex, Hermes, Strata, Claude.
- Autoactualización en pausa por REAL_ACTIVITY_LOCK: ahora se ve como aviso.
- Grafo de la bóveda en `vault.graph`.

Tests: python3 -m unittest discover -s tests -v; node tests/test_no_progress.js.
