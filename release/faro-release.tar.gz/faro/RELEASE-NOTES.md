# Live 15 s (2026.11.12-live-15s-1)

Faro ya no espera solo a que le informen: pregunta él.
- Cada 15 s mira a cada agente del PC (Hermes, Codex, Claude Code, Strata). Prueba de trabajo: ha escrito en su registro de sesión en los últimos 2 min. Proceso vivo sin escribir = descansando. Sin proceso = apagado. No se usa la CPU.
- Buzón de la nube por git cada 15 s (sin la caché de 5 min de raw.githubusercontent). Corregido: los informes con solo `src_at` no se importaban.
- Una ficha por agente: sin duplicados por nombre; los informes de más de 12 h pasan a historia (`agents_keep_hours`).
- Si un agente local informa de su tarea, su ficha en vivo usa ese texto.
- Bucle interno 5 s (`tick`), panel cada 5 s. La oficina muestra a todos; los que no dan señal, en descanso con «sin señal».
- Opcional en config: `live_dirs` {"hermes": [...]} si Hermes guarda sus sesiones en otra carpeta.

Tests: python3 -m unittest discover -s tests -v; node tests/test_no_progress.js.
