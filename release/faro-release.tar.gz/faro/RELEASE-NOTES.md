# 2026.11.12-oficina-v2.7 (incluye v2 a v2.6)

- v2.7: mesas estables: cada agente conserva su mesa; solo se reordena si quien trabaja se queda sin mesa o, cada 45 s como mucho, para acercar al faro a quien trabaja. Antes se paseaban en cada refresco y las zonas no llegaban a encenderse.
- v2.6: Claude del PC puede leer la bóveda (--add-dir); las órdenes recuerdan que en la bóveda solo se escribe dentro de _agentes/.
- v2.5: los agentes del PC ya no se quedan esperando: Codex con --skip-git-repo-check y sin entrada de teclado; Claude con -p y permiso de editar en ~/FaroTrabajo; Hermes en modo una respuesta. Sin cuota (429): la orden vuelve a la cola y se reintenta sola cuando hay cuota; mientras, Faro reparte a otros.
- v2.4: cada orden sabe qué pide (bóveda, código, web, vídeo, correo, sistema, escritura) y la oficina coloca a quien la hace en esa zona.
- v2.3: agentes encendibles desde Faro (data/overrides.json, sin poder tocar el comando) y órdenes por la bóveda (_agentes/inbox/faro → reparto → _agentes/outbox).

- v2.2: la oficina no levanta edificio para proyectos en silencio (el lab de trading hasta que tenga resultados).
- v2.1: las tareas de Codex y Hermes se agrupan por nombre aunque lleguen con otra marca.
Oficina (prioridad: móvil)
- Bóveda: el grafo de tus notas de Obsidian (nodos y enlaces reales, posiciones estables calculadas en el PC). En amarillo, lo tocado en los últimos 15 min; si alguien consulta la bóveda, la señal recorre los enlaces.
- Mesas por prioridad: cerca del faro quien trabaja; luego quien tiene una tarea de fondo; luego quien está libre. Agentes y mesas se reasignan solos.
- Descanso: solo quien tiene una tarea corriendo de fondo (su pantalla sigue girando en la mesa).
- El ojo marca el compás de 15 s (el sondeo de Faro): recorre a quien trabaja por orden de mesa y a cada uno le «late» la pantalla y el teclado cuando lo mira; nadie va al unísono.
- Flexos orientados a la pantalla que la iluminan. Pantallas con el símbolo de lo que usa cada agente, su color, nube/PC y avance.
- Entrada nueva con tres canales reales (Tú · Faro, Nube, PC · Mac) que se encienden cuando llega algo, pulso del sondeo de 15 s y banquillo (hechos, libres sin mesa, sin señal).
- Las chispas que suben por el faro son cambios reales de un agente; se quitaron las partículas decorativas.

Vista principal
- El aviso de arriba cuenta lo mismo que «Te necesitamos para» (antes decía «1 para ti» con la lista vacía).
- «Cómo vamos»: trabajan · de fondo · en cola · sin señal, y la lista de quién trabaja y en qué. Cada proyecto dice quién está en él.

Servidor
- Una ficha por agente real: las tareas que un agente del PC informa con nombres distintos (Hermes · chf-3d, Hermes · CHF3D…) se pliegan en su ficha; las vencidas, como «sin cierre».
- `action` solo admite el vocabulario (code, web, write, think, edit, obsidian, mail, system, skills; también en español). Si llega una frase, pasa a `step`.
- Sesiones de la nube terminadas hace más de 30 min: «hechas», al banquillo.
- Ejecutor sin sesión (p. ej. «Not logged in»): se aparta 6 h del reparto, se avisa en «Te toca» y `/api/health` dice por qué.
- Strata detectado en su puerto real (18501, compatible con OpenAI) y usable como ejecutor gratis. Reparto de reserva sin coste primero: Codex, Hermes, Strata, Claude.
- Autoactualización en pausa por REAL_ACTIVITY_LOCK: ahora se ve como aviso.
- Grafo de la bóveda en `vault.graph`.

Tests: python3 -m unittest discover -s tests -v; node tests/test_no_progress.js.
