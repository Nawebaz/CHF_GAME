# Faro

Panel de estado personal: qué te toca, qué está en marcha, qué se lanza solo, cuánto has cobrado y qué pasa ahí fuera.
Un solo archivo Python sin dependencias, una página web y un `config.json`. Corre en Windows, Linux o Mac.

## Instalar

**Windows**: `powershell -ExecutionPolicy Bypass -File .\windows\install.ps1`. Para que el móvil llegue a Faro, ejecútalo como administrador, que es lo que abre el puerto.
Se instala en `%USERPROFILE%\Faro` y arranca al iniciar sesión mediante la tarea programada «Faro».

**Linux**: `bash linux/install.sh`
Se instala en `~/faro` como servicio de usuario (`systemctl --user status faro`).

Abre `http://IP-DEL-EQUIPO:8787` en el iPhone o el Mac y añádelo a la pantalla de inicio.

## Configurar (`config.json`)

| Bloque | Para qué | Qué necesitas |
|---|---|---|
| `scheduled` | Tareas con horario (p. ej. las de Claude en la nube). Faro calcula la próxima ejecución. | La expresión cron. |
| `sources.gmail` | Avisos de «Te toca», pagos entrantes y borradores de respuesta. | Contraseña de aplicación de Google (myaccount.google.com/apppasswords, exige verificación en dos pasos). La lectura es en modo solo lectura; solo escribe cuando le pides un borrador. |
| `sources.itch` | Visitas y ventas de tus juegos. | Clave API de itch.io. |
| `sources.freqtrade` | Beneficio del laboratorio de trading. | Usuario y contraseña de la API de freqtrade. |
| `sources.prices` | Cripto (CoinGecko) y acciones/ETF/oro (Stooq). Umbrales opcionales `alert_below` / `alert_above`. | Nada. |
| `sources.electricity` | Precio PVPC por horas (Red Eléctrica). | Nada. |
| `sources.news` | Noticias de tus fuentes filtradas por tus temas y palabras clave. | Nada. |
| `sources.github_inbox` | Buzón para tareas en la nube que no llegan a tu red. | Repo privado y token de solo lectura. |
| `ollama` | Explica por qué te importa cada noticia y responde preguntas libres por voz. Coste cero: corre en tu GPU. | Ollama con un modelo (p. ej. `qwen2.5:7b`). |
| `telegram` | Avisos al móvil solo de ámbar, rojo y umbrales de precio. | Token de un bot y tu chat_id. |

Cada fuente que falla aparece en ámbar en «Te toca» con el error. Las que no configures salen en gris.

## Que tus agentes informen

```
# Windows (Hermes, scripts, tareas)
.\tools\faro-report.ps1 -Id backtest-1 -Kind run -State run -Pct 35 -Step "Par 3 de 8" -Project trading -Name "Backtest"
# Mac / Linux
tools/faro-report.sh backtest-1 run run 35 "Par 3 de 8" trading "Backtest"
```

`kind`: `job` (tarea con resultado), `run` (trabajo con barra de progreso), `agent` (estado de un agente), `todo` (algo que te toca).
Basta con enviar el porcentaje cuando cambie: Faro calcula el ritmo y la página mueve la barra sola entre informes.
Si un `job` o un `agent` deja de informar más tiempo que su `ttl` (1 h por defecto), pasa a ámbar.

## Órdenes: Faro reparte el trabajo

Desde el puesto de mando escribes una orden, o abres un «Nuevo», que es un hilo con memoria propia. Faro decide quién la hace:
1. **Reglas** (`routing.rules`), a coste cero. Por ejemplo, «instala…» va a Hermes, «resume…» a la IA local y «escribe una propuesta…» a Claude.
2. Si ninguna regla encaja y la IA local está activa, **ella clasifica** la orden.
3. Si no, va al primer ejecutor disponible de `routing.fallback`.

Prioridad: las palabras «urgente» o «ya» la ponen en *alta*; «esta noche» la deja en cola hasta la madrugada (de 1 a 7 h), para no gastar cuota de día.
Cada orden muestra quién la hace y por qué. Puedes pasarla a otra IA, reintentarla, cancelarla o archivarla.

Los ejecutores van en `executors`:
- `faro`: interno, contesta con los datos del panel. Si una orden cae aquí sin pedirlo, es que ningún otro ejecutor está disponible: mira `/api/health` → `executors`.
- `local`: Ollama o Strata.
- `hermes`, `claude`, `codex`: programas de línea de comandos. **Comprueba en tu PC la sintaxis exacta de cada uno** (`hermes --help`, `claude --help`, `codex --help`) y ajusta `cmd`.

Ejecutor desactivado o programa no instalado = Faro lo salta.

## Manos libres (Siri y CarPlay)

1. Instala **Tailscale** en el equipo de Faro y en el iPhone (gratis), para llegar a Faro fuera de casa sin abrir puertos.
2. En Atajos, crea uno llamado **Faro** con estas acciones:
   1. **Dictar texto** (idioma: español).
   2. **Codificar URL** del texto dictado.
   3. **Obtener contenido de URL**: `http://NOMBRE-TAILSCALE:8787/api/voice?q=` + el texto codificado.
   4. **Leer texto** con el contenido obtenido.
3. Di «Oye Siri, Faro» y habla.

Cosas que entiende sin IA: *resumen · qué me toca · descarta el primero · hecho el segundo · contesta al primero: gracias, os llamo el lunes · precio de bitcoin · cómo está la luz · noticias · cuánto he cobrado · qué es lo próximo*.
Con Ollama activo, lo demás lo responde el modelo local usando solo los datos de Faro.
Las respuestas se guardan como borrador en Gmail y nunca se envían solas.

## Seguridad

- Desde la red local y Tailscale no pide token. Desde fuera exige la cabecera `X-Faro-Token`.
- No lo publiques en Internet abierto. Para acceso remoto, usa Tailscale.
- Las credenciales viven solo en `config.json`, en tu equipo.
- Ninguna fuente toca dinero. Los pagos se leen de los correos de aviso.

## Archivos

`faro.py` (servidor y recolectores) · `web/index.html` (la página) · `data/` (estado, histórico de precios, informes y registro `faro.log`).

## La oficina y el buzón

Botón **Oficina**: la oficina dibujada a tiza, con los agentes trabajando.
- Para que un agente aparezca en su puesto **real**, su informe lleva `action`: `obsidian`, `web`, `code`, `edit`, `think`, `write`, `mail`, `system`, `cards` o `skills`. Sin ese campo, la oficina lo coloca según el tipo de tarea.
- Campos opcionales del informe:
  - `project`: en qué edificio del muro de proyectos trabaja.
  - `skill`: la skill que usa, que se resalta en el armario.
  - `artifact`: `{"name":…}`, lo que ha producido.
  - `proud`: `{"title":…, "why":…}`, para la vitrina de orgullo.
- Conversaciones reales: un informe puede llevar `say`: `{"to":"Hermes · PC","text":"…"}`, o se envía `POST /api/message` con `{"from","to","text"}`. La sala de descanso solo enseña estos mensajes y los que genera el sistema (sugerencias, respuestas, encargos, entregas). Toca el descanso para ver el historial.
- Buzón de sugerencias: `POST /api/suggestion` con `{"from","text","why","imp","ret","cost"}`. Aparece en «Decide» y en la oficina.
- Bóveda: rellena `vault.path` en `config.json`. Con `write: true`, Faro deja en la carpeta `Faro` un parte diario y cada orden terminada.

## Decide

Faro ordena lo que te toca, las órdenes en cola y el buzón con **importancia × retorno × relevancia ÷ coste** (escala 1-3).
- La relevancia depende del proyecto (`decision.project_relevance`).
- Las reglas de `decision.rules` fijan valores por palabras clave.
- Cuadrantes: **Hazlo ya** (mucho retorno, poco coste), **Planifica**, **Rápido** y **Descarta**.
