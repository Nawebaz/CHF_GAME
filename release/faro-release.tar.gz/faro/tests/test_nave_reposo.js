// La nave no calienta el móvil: en reposo pinta unos 8 fotogramas por segundo (antes 30 sin parar), el palantír no reescribe
// su tamaño en cada fotograma y, si el PC tarda en contestar, los sondeos de api/status no se apilan.
// Reloj virtual: se ejecuta web/oficina.js con un DOM mínimo, sin navegador.
const fs = require('fs'), vm = require('vm'), assert = require('assert'), path = require('path');
function run({ W = 390, H = 844, slow = 0, secs = 25 } = {}) {
  let vnow = 0, seq = 0; const q = [], st = { frames: 0, style: 0, status: 0 };
  const at = (t, fn) => { const id = ++seq; q.push({ t, fn, id }); return id; }, cancel = id => { const i = q.findIndex(x => x.id === id); if (i >= 0) q.splice(i, 1); };
  const ctx = main => new Proxy({}, { get: (t, k) => k === 'measureText' ? () => ({ width: 10 }) : /^create(Radial|Linear)Gradient$/.test(k) ? () => ({ addColorStop() {} })
    : k === 'setTransform' && main ? () => { st.frames++; } : k in t ? t[k] : () => {}, set: (t, k, v) => { t[k] = v; return true; } });
  const els = {}, mk = id => { const c = ctx(id === '#art'), style = new Proxy({}, { set: (t, k, v) => { if (id === '#palantir-mobile') st.style++; t[k] = v; return true; }, get: (t, k) => k === 'setProperty' ? () => {} : t[k] });
    const e = { id, innerHTML: '', textContent: '', hidden: false, children: [], dataset: {}, style, classList: { toggle() {} }, setAttribute() {}, addEventListener() {}, querySelector: () => null,
      appendChild(x) { this.children.push(x); x.remove = () => this.children.splice(this.children.indexOf(x), 1); return x; }, getBoundingClientRect: () => ({ width: W, height: H * .61 }),
      getContext: () => c, play: () => Promise.resolve(), pause() {}, paused: false, remove() {} };
    let src = ''; Object.defineProperty(e, 'src', { get: () => src, set: v => { src = v; e.complete = true; e.naturalWidth = 256; if (e.onload) at(vnow + 5, () => e.onload()); } }); return e; };
  const now = new Date().toISOString(), status = { agents: [{ id: 'a1', name: 'Claude · Auditoría', state: 'run', presence: 'desk', at: now, ttl: 300, action: 'think', project: 'faro' },
    { id: 'a2', name: 'Hermes · Mimo síntesis', state: 'run', presence: 'desk', at: now, ttl: 300, action: 'code', project: 'agentes', pct: 70 }], running: [], decide: [], projects: [] };
  const reply = body => Promise.resolve({ ok: true, json: () => Promise.resolve(JSON.parse(JSON.stringify(body))) });
  const win = { document: { hidden: false, querySelector: s => els[s] || (els[s] = mk(s)), getElementById: i => els['#' + i] || null, createElement: mk, head: { appendChild() {} }, addEventListener() {} },
    location: { hostname: 'iceland', search: '' }, matchMedia: m => ({ matches: /min-aspect-ratio/.test(m) ? W >= H && W >= 700 : false, addEventListener() {} }), devicePixelRatio: 3,
    fetch: u => { u = String(u); if (u.startsWith('api/vault/live')) return new Promise(() => {}); if (u === 'api/status') { st.status++; if (slow) return new Promise(r => at(vnow + slow, () => r(reply(status)))); return reply(status); }
      return reply({ machines: [], voz: {}, gta: {}, strata: {} }); },
    setTimeout: (f, ms = 0) => at(vnow + ms, f), clearTimeout: cancel, setInterval: (f, ms) => { const tick = () => { f(); at(vnow + ms, tick); }; return at(vnow + ms, tick); },
    requestAnimationFrame: f => at(Math.ceil((vnow + .01) / (1000 / 120)) * (1000 / 120), () => f(vnow)), cancelAnimationFrame: cancel,
    performance: { now: () => vnow }, Image: function () { return mk('img'); }, CSS: { escape: s => s }, addEventListener() {} };
  win.window = win; vm.createContext(win);
  const web = f => path.join(__dirname, '../web', f);
  if (fs.existsSync(web('voz-estado.js'))) vm.runInContext(fs.readFileSync(web('voz-estado.js'), 'utf8'), win);
  vm.runInContext(fs.readFileSync(web('oficina.js'), 'utf8'), win);
  return (async () => { const flush = () => new Promise(r => setImmediate(r)); let mark = null; await flush();
    while (q.length && vnow < secs * 1000) { q.sort((a, b) => a.t - b.t || a.id - b.id); const x = q.shift(); vnow = Math.max(vnow, x.t); if (!mark && vnow >= 5000) mark = { ...st }; x.fn(); await flush(); }
    return { fps: (st.frames - mark.frames) / (secs - 5), style: (st.style - mark.style) / (secs - 5), status: st.status }; })();
}
(async () => {
  const m = await run();
  assert.ok(m.fps <= 10 && m.fps >= 4, 'móvil en reposo: ~8 fps, no 30 (' + m.fps + ')');
  assert.ok(m.style <= 10, 'palantír: sin escrituras de estilo a 90 por segundo (' + m.style + ')');
  const d = await run({ W: 1440, H: 900 });
  assert.ok(d.fps >= 28, 'escritorio igual que antes (' + d.fps + ')');
  const s = await run({ slow: 5000, secs: 21 });
  assert.ok(s.status <= 5, 'api/status lento (5 s): sin peticiones apiladas (' + s.status + ' en 21 s)');
  console.log(`PASS: nave en reposo a ${m.fps.toFixed(1)} fps en el móvil, escritorio a ${d.fps.toFixed(0)}, sondeos sin apilarse`);
})().catch(e => { console.error(e.message); process.exit(1); });
