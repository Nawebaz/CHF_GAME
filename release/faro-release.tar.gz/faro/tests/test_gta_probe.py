import importlib.util, json, os, pathlib, shutil, tempfile, unittest

# Faro lee en directo el estado de cada clip de la máquina de GTA VI (clip.json)
class GtaProbe(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR')); self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / 'faro.py'; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / 'faro.py', dst)
        spec = importlib.util.spec_from_file_location('faro_test_gtap', dst); self.m = importlib.util.module_from_spec(spec); spec.loader.exec_module(self.m)
        self.g = pathlib.Path(self.tmp.name) / 'gta6'; self.m.CFG = {'gta': {'dir': str(self.g)}}
    def probe(self):
        self.m._GP.update(t=0, v=None); return self.m.gta_probe()
    def test_empty_and_clips(self):
        r = self.probe(); self.assertFalse(r['dir']); self.assertIsNone(r['gta'])
        (self.g / '007').mkdir(parents=True); (self.g / 'tanda6' / 'n1').mkdir(parents=True); (self.g / 'roto').mkdir()
        (self.g / '007' / 'clip.json').write_text(json.dumps({'serie': 'cuenta', 'titulo': 'Prueba', 'paso': 'VOZ', 'bloqueo': 'falta OK', 'jueces': {'A': 'ok', 'B': 'rev'}, 'historial': [{'nota': 'pasa a VOZ'}]}))
        (self.g / 'tanda6' / 'n1' / 'clip.json').write_text(json.dumps({'serie': 'bolsa', 'titulo': 'Otro', 'paso': 'PUBLICADO'}))
        (self.g / 'roto' / 'clip.json').write_text('{no es json')
        r = self.probe(); c = {k['n']: k for k in r['gta']['clips']}
        self.assertEqual(set(c), {'007', 'n1'}); self.assertEqual(c['007']['st'], 3); self.assertEqual(c['007']['b'], 'falta OK'); self.assertEqual(c['007']['j'], ['ok', 'rev', ''])
        self.assertEqual(c['n1']['st'], 10); self.assertEqual(r['state'], 'run'); self.assertTrue(r['at'])

if __name__ == '__main__':
    unittest.main()
