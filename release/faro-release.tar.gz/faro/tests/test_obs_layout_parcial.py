import importlib.util, os, sys, tempfile, time, unittest
HERE = os.path.dirname(os.path.abspath(__file__))

class T(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, os.path.dirname(HERE))
        spec = importlib.util.spec_from_file_location("faro_p", os.path.join(os.path.dirname(HERE), "faro.py"))
        cls.m = importlib.util.module_from_spec(spec); spec.loader.exec_module(cls.m)
    def test_parcial_no_pisa(self):
        m = self.m; full = [["n%d.md" % i, i, i * 2] for i in range(100)]
        self.assertTrue(m.obs_layout_set({"nodes": full})["ok"]); self.assertEqual(len(m.OBS_LAYOUT["pos"]), 100)
        r = m.obs_layout_set({"nodes": full[:20]})                       # Obsidian animando: pocos nodos
        self.assertEqual(r.get("ignored"), "parcial"); self.assertEqual(len(m.OBS_LAYOUT["pos"]), 100)
        m.OBS_LAYOUT["pend"] = (time.time() - 200, 20)                  # el recorte se sostiene más de 2 min: se acepta
        r = m.obs_layout_set({"nodes": full[:21]}); self.assertNotIn("ignored", r); self.assertEqual(len(m.OBS_LAYOUT["pos"]), 21)
        self.assertTrue(m.obs_layout_set({"nodes": full})["ok"]); self.assertEqual(len(m.OBS_LAYOUT["pos"]), 100)

if __name__ == "__main__": unittest.main()
