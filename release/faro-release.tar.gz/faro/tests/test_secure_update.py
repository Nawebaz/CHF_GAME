import io
import json
import pathlib
import tarfile
import threading
import urllib.error
import urllib.request
import unittest
from unittest import mock
import test_real_activity


class SecureUpdate(unittest.TestCase):
    setUp = test_real_activity.RealActivity.setUp

    def package(self, code, extra=None):
        m = self.m
        buf = io.BytesIO()
        items = {'faro.py': code, 'VERSION': b'test-new', **(extra or {})}
        with tarfile.open(fileobj=buf, mode='w:gz') as tf:
            for name, body in items.items():
                member = tarfile.TarInfo('faro/' + name)
                member.size = len(body)
                tf.addfile(member, io.BytesIO(body))
        blob = buf.getvalue()
        meta = {'version': 'test-new', 'file': 'faro-release.tar.gz', 'sha256': m.hashlib.sha256(blob).hexdigest()}
        original_http = m.http
        def download(url, **kwargs):
            if url.startswith("http://127.0.0.1:"): return original_http(url, **kwargs)
            return json.dumps(meta).encode() if 'VERSION.json' in url else blob
        return mock.patch.object(m, 'http', side_effect=download)

    def test_public_post_without_token_is_401(self):
        m = self.m
        m.CFG['token'] = 'test-only'
        class PublicClient(m.H):
            def setup(self):
                super().setup()
                self.client_address = ('8.8.8.8', self.client_address[1])
        server = m.ThreadingHTTPServer(('127.0.0.1', 0), PublicClient)
        self.addCleanup(server.server_close)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.shutdown)
        with mock.patch.object(m, 'action') as action, mock.patch.object(m, 'self_update') as update, mock.patch.object(m, 'suggestion_action') as suggestion:
            for path in ('action', 'update', 'machine', 'suggestion/action'):
                req = urllib.request.Request('http://127.0.0.1:%d/api/%s' % (server.server_port, path), data=b'{}')
                with self.assertRaises(urllib.error.HTTPError) as caught:
                    urllib.request.urlopen(req)
                self.assertEqual(caught.exception.code, 401)
            action.assert_not_called(); update.assert_not_called(); suggestion.assert_not_called()
            self.assertEqual(m.MACHINES, {})

    def test_broken_update_restores_previous_and_state(self):
        m = self.m
        root = pathlib.Path(m.ROOT)
        before = (root/'faro.py').read_bytes()
        (root/'VERSION').write_text('test-old')
        m.VERSION = 'test-old'
        server = m.ThreadingHTTPServer(('127.0.0.1', 0), m.H)
        self.addCleanup(server.server_close)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.shutdown)
        base = 'http://127.0.0.1:%d' % server.server_port
        with self.package(b'invalid python !!!', {'new.txt': b'new'}), mock.patch.object(m.os, 'execv') as restart:
            req = urllib.request.Request(base + '/api/update', data=b'{}')
            with urllib.request.urlopen(req) as response:
                result = json.load(response)
            self.assertFalse(result['ok'])
            self.assertIn('no arranca', result['error'])
            restart.assert_not_called()
        with urllib.request.urlopen(base + '/api/health') as response:
            health = json.load(response)
        self.assertTrue(health['ok'])
        self.assertEqual(health['version'], 'test-old')
        with urllib.request.urlopen(base + '/api/status') as response:
            status = json.load(response)
        self.assertTrue(any(x['id'] == 'update-error' for x in status['todo']))
        self.assertEqual((root/'faro.py').read_bytes(), before)
        self.assertEqual((root/'VERSION').read_text(), 'test-old')
        self.assertFalse((root/'new.txt').exists())
        self.assertEqual((root/'data/prev/faro.py').read_bytes(), before)
        self.assertTrue(m.UPD['error'])
        self.assertEqual(m.jload('update-error.json', {})['error'], m.UPD['error'])
        self.assertTrue(any(x['id'] == 'update-error' for x in m.STATUS['todo']))

    def test_valid_package_starts_probe_and_schedules_restart(self):
        m = self.m
        code = pathlib.Path(m.ROOT, 'faro.py').read_bytes()
        with self.package(code), mock.patch.object(m.threading, 'Thread') as restart:
            result = m.self_update(force=True)
        self.assertTrue(result['updated'])
        restart.return_value.start.assert_called_once()
        self.assertIsNone(m.UPD['error'])
        self.assertFalse(m.jload('update-error.json', {}))

    def test_health_timeout_restores_previous(self):
        m = self.m
        root = pathlib.Path(m.ROOT)
        before = (root/'faro.py').read_bytes()
        code = b'import time\ntime.sleep(60)\n'
        start = m.time.monotonic()
        with self.package(code), mock.patch.object(m.threading, 'Thread') as restart:
            with self.assertRaisesRegex(RuntimeError, '20 s'):
                m.self_update(force=True)
            restart.assert_not_called()
        self.assertLess(m.time.monotonic()-start, 23)
        self.assertEqual((root/'faro.py').read_bytes(), before)

    def test_signature_optional_and_required(self):
        m = self.m
        with mock.patch.object(m.subprocess, 'run') as verify:
            m.verify_release(b'package', 'https://example.invalid/', {})
            verify.assert_not_called()
        with self.assertRaisesRegex(RuntimeError, 'no configurada'):
            m.verify_release(b'package', 'https://example.invalid/', {'pubkey': ''})
        # Clave ficticia: no se genera ninguna clave; se comprueba el contrato SSH.
        key = pathlib.Path(m.ROOT, 'public-test.pub')
        key.write_text('ssh-ed25519 TEST-ONLY')
        with mock.patch.object(m, 'http', return_value=b'fake signature'), mock.patch.object(m.subprocess, 'run', return_value=mock.Mock(returncode=0)) as verify:
            m.verify_release(b'package', 'https://example.invalid/', {'pubkey': str(key)})
            args, kwargs = verify.call_args
            self.assertEqual(args[0][:3], ['ssh-keygen', '-Y', 'verify'])
            self.assertEqual(kwargs['input'], b'package')
        with mock.patch.object(m, 'http', return_value=b'bad signature'), mock.patch.object(m.subprocess, 'run', return_value=mock.Mock(returncode=1)):
            with self.assertRaisesRegex(RuntimeError, 'firma'):
                m.verify_release(b'package', 'https://example.invalid/', {'pubkey': str(key)})
        with self.assertRaises(FileNotFoundError):
            m.verify_release(b'package', 'https://example.invalid/', {'pubkey': 'absent.pub'})

    def test_tar_link_rejected_before_copy(self):
        m = self.m
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode='w:gz') as tf:
            member = tarfile.TarInfo('faro/faro.py'); member.type = tarfile.SYMTYPE; member.linkname = '/tmp/escape'
            tf.addfile(member)
        blob = buf.getvalue()
        meta = {'version':'test-new','file':'faro-release.tar.gz','sha256':m.hashlib.sha256(blob).hexdigest()}
        with mock.patch.object(m, 'http', side_effect=[json.dumps(meta).encode(), blob]):
            with self.assertRaisesRegex(RuntimeError, 'ruta o tipo'):
                m.self_update(force=True)
        self.assertFalse(pathlib.Path(m.DATA, 'prev').exists())

if __name__ == '__main__': unittest.main()
