import importlib.util, os, pathlib, shutil, tempfile, unittest

# El grafo de la bóveda se parece al de Obsidian: etiquetas y adjuntos son nodos y lo que no tiene enlaces va en un cinturón
class VaultGraphObsidian(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR')); self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / 'faro.py'; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / 'faro.py', dst)
        spec = importlib.util.spec_from_file_location('faro_test_vgo', dst); self.m = importlib.util.module_from_spec(spec); spec.loader.exec_module(self.m)
        self.v = pathlib.Path(self.tmp.name) / 'v'; (self.v / 'a').mkdir(parents=True)
        (self.v / 'a' / 'Uno.md').write_text('---\ntags: [faro, gta]\n---\n[[Dos]] ![[foto.png]] #radar color `#fff` y #ff00aa\n', encoding='utf-8')
        (self.v / 'a' / 'Dos.md').write_text('[[Uno]] #radar\n', encoding='utf-8'); (self.v / 'Sola.md').write_text('nada\n', encoding='utf-8')
        (self.v / 'foto.png').write_bytes(b'x'); (self.v / 'suelto.pdf').write_bytes(b'x')
    def test_kinds_ring_tags(self):
        notes = [(1.0, 'a/Uno'), (1.0, 'a/Dos'), (1.0, 'Sola')]
        g = self.m.vault_graph(str(self.v), notes, atts=['foto.png', 'suelto.pdf']); N = {n['id']: n for n in g['nodes']}
        self.assertEqual(N['#radar']['k'], 1); self.assertEqual(N['#radar']['d'], 2); self.assertIn('#faro', N); self.assertNotIn('#fff', N); self.assertNotIn('#ff00aa', N)
        self.assertEqual(N['foto.png']['k'], 2); self.assertEqual(N['foto.png']['d'], 1); self.assertEqual(N['suelto.pdf']['o'], 3); self.assertEqual(N['Sola']['o'], 1)
        r = lambda n: ((n['x'] - .5) ** 2 + (n['y'] - .5) ** 2) ** .5
        self.assertGreater(r(N['suelto.pdf']), .39); self.assertGreater(r(N['Sola']), .39); self.assertLess(r(N['a/Uno']), .36)
        self.assertEqual(g['total'], 3); self.assertEqual(g['orphans'], 1)
    def test_born_dates(self):
        import datetime
        (self.v / 'a' / '2026-11-03 0930 encargo.md').write_text('[[Uno]]\n', encoding='utf-8')
        (self.v / 'Ficha.md').write_text('---\ncreado: 2026-10-07\n---\n[[Uno]] #radar\n', encoding='utf-8')
        import time; nowt = time.time()
        notes = [(nowt, 'a/Uno'), (nowt, 'a/Dos'), (nowt, 'a/2026-11-03 0930 encargo'), (nowt, 'Ficha')]
        g = self.m.vault_graph(str(self.v), notes, atts=[]); N = {n['id']: n for n in g['nodes']}
        d = lambda n: datetime.datetime.fromtimestamp(N[n]['c'])
        self.assertEqual((d('a/2026-11-03 0930 encargo').month, d('a/2026-11-03 0930 encargo').day, d('a/2026-11-03 0930 encargo').hour), (11, 3, 9))
        self.assertEqual((d('Ficha').month, d('Ficha').day), (10, 7)); self.assertLessEqual(N['#radar']['c'], N['Ficha']['c']); self.assertGreater(N['a/Uno']['c'], N['Ficha']['c'])

if __name__ == '__main__': unittest.main()
