import importlib.util, os, pathlib, shutil, tempfile, unittest
class GraphOrphans(unittest.TestCase):
    def test_marks_and_skips(self):
        d = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, d)
        for rel, t in {"A.md": "[[B]]", "B.md": "b", "Suelta.md": "s", "99 Plantillas/P.md": "p", "_to_delete/X.md": "x", "C.sync-conflict-1.md": "c"}.items():
            p = os.path.join(d, rel); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(t)
        dst = pathlib.Path(d) / ".faro.py"; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / "faro.py", dst)
        spec = importlib.util.spec_from_file_location("fo", dst); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        m.CFG = {"vault": {"path": d}}
        g = m.c_vault()["graph"]; o = {n["id"]: n["o"] for n in g["nodes"]}
        self.assertEqual(o, {"A": 0, "B": 0, "Suelta": 1, "99 Plantillas/P": 2})
        self.assertEqual((g["orphans"], g["lone"]), (1, 1))
    def test_heat(self):
        d = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, d)
        for rel, t in {"A.md": "[[B]]", "B.md": "b"}.items(): open(os.path.join(d, rel), "w").write(t)
        dst = pathlib.Path(d) / ".faro.py"; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / "faro.py", dst)
        spec = importlib.util.spec_from_file_location("fh", dst); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        m.CFG = {"vault": {"path": d}}; m.ROOT = d; os.makedirs(os.path.join(d, "data"), exist_ok=True)
        for _ in range(5): m.vault_event("A", "read", who="Hermes")
        m.vault_event("B", "read", who="Faro")           # lo de Faro no calienta
        h = {n["id"]: n["h"] for n in m.c_vault()["graph"]["nodes"]}
        self.assertEqual(h["A"], 1.0); self.assertEqual(h["B"], 0)
        m.HEAT["saved"] = 0; m.heat_io(); self.assertTrue(os.path.exists(os.path.join(d, "data", "vault_heat.json")))
if __name__ == "__main__": unittest.main()
