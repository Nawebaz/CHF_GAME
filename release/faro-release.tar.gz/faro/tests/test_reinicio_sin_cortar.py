import importlib.util, json, os, pathlib, shutil, subprocess, sys, tempfile, textwrap, threading, time, unittest

FARO = pathlib.Path(__file__).resolve().parents[1] / 'faro.py'

def load(tmp, name):
    dst = pathlib.Path(tmp) / 'faro.py'
    if not dst.exists(): shutil.copy(FARO, dst)
    spec = importlib.util.spec_from_file_location(name, dst); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    m.save_orders = lambda: None; m.say = lambda *a, **k: None; m.build_status = lambda: None
    return m

def order(i, prio='alta', st='queued', ex='hermes', **kw):
    return {'id': 'o:%d' % i, 'title': 'orden %d' % i, 'text': 'haz la %d' % i, 'executor': ex, 'priority': prio,
            'state': st, 'created': '2026-11-18T10:%02d' % i, 'started': None, **kw}

# Un reinicio o una actualización de Faro no debe cortar ni duplicar el trabajo de un agente
class ReinicioSinCortar(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR')); self.addCleanup(self.tmp.cleanup)
        self.m = load(self.tmp.name, 'faro_test_reinicio')
        self.m.CFG['executors'] = {'hermes': {'type': 'cmd', 'label': 'Hermes', 'cmd': ['echo', '{prompt}']}}
        self.m.EXEC_BLOCK.clear(); self.m.ORDERS[:] = []; self.m.ORPHANS.clear()

    def test_la_salida_va_a_archivo_y_se_apunta_el_pid(self):
        m = self.m; o = order(1); m.ORDERS.append(o)
        out = m.execute(o)
        self.assertIn('haz la 1', out)
        self.assertNotIn('pid', o, 'al terminar se limpia')
        self.assertEqual(os.listdir(m.RUNS), [], 'sin restos en data/runs')

    def test_error_y_tiempo_agotado(self):
        m = self.m; m.CFG['executors']['hermes']['cmd'] = ['sh', '-c', 'echo malo >&2; exit 3']
        with self.assertRaisesRegex(RuntimeError, 'malo'): m.execute(order(2))
        m.CFG['executors']['hermes'].update(cmd=['sleep', '30'], timeout=1)
        t0 = time.time()
        with self.assertRaisesRegex(RuntimeError, 'tiempo agotado'): m.execute(order(3))
        self.assertLess(time.time() - t0, 10)

    def test_arranque_cortado_se_retoma_avisando(self):
        m = self.m
        m.ORDERS += [order(1, st='running', started='2026-11-18T12:57:52'),          # cortada sin pid (versión antigua)
                     order(2, st='queued', started='2026-11-18T13:00:01'),           # cortada que la carrera dejó «en cola»
                     order(3, st='queued')]                                          # cola normal
        m.recover_orders()
        st = {o['id']: (o['state'], bool(o.get('resume'))) for o in m.ORDERS}
        self.assertEqual(st, {'o:1': ('queued', True), 'o:2': ('queued', True), 'o:3': ('queued', False)})
        out = m.execute(m.ORDERS[0])
        self.assertIn('se cortó por un reinicio', out); self.assertIn('2026-11-18 12:57', out)
        self.assertNotIn('se cortó', m.execute(m.ORDERS[2]))

    def test_ordenes_primero_por_prioridad_tras_reiniciar(self):
        # antes: los trabajadores arrancaban ANTES de reponer las órdenes «en marcha» y cogían la de prioridad normal
        m = self.m
        m.ORDERS += [order(1, prio='normal'), order(2, prio='alta', st='running', started='2026-11-18T12:57:52')]
        m.recover_orders()
        done = []
        m.execute = lambda o: done.append(o['id']) or 'ok'
        th = threading.Thread(target=m.worker, args=('hermes',), daemon=True); th.start()
        for _ in range(50):
            if len(done) == 2: break
            time.sleep(0.1)
        self.assertEqual(done, ['o:2', 'o:1'])

# Prueba real: un proceso «Faro» lanza un agente, se re-ejecuta con execv (como al actualizarse) y la nueva imagen
# adopta al agente vivo: no lo vuelve a lanzar y recoge su respuesta cuando acaba.
SCRIPT = textwrap.dedent('''
    import importlib.util, json, os, sys, threading, time
    tmp, fase = sys.argv[1], sys.argv[2]
    spec = importlib.util.spec_from_file_location("faro_x", os.path.join(tmp, "faro.py")); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    m.say = lambda *a, **k: None; m.build_status = lambda: None
    m.CFG["executors"] = {"hermes": {"type": "cmd", "label": "Hermes",
        "cmd": ["sh", "-c", "echo lanzado >> %s/lanzamientos; sleep 3; echo respuesta del agente" % tmp]}}
    if fase == "1":
        m.ORDERS[:] = [{"id": "o:1", "title": "voz", "text": "x", "executor": "hermes", "priority": "alta", "state": "queued",
                        "created": "2026-11-18T10:00", "started": None}]
        m.save_orders()
        threading.Thread(target=m.worker, args=("hermes",), daemon=True).start()
        for _ in range(100):
            if m.ORDERS[0].get("pid"): break
            time.sleep(0.05)
        os.execv(sys.executable, [sys.executable, __file__, tmp, "2"])    # «actualización»: mismo pid, el agente sigue vivo
    m.recover_orders()
    o = m.ORDERS[0]
    print("ADOPTADA", bool(o.get("adopted")), flush=True)
    threading.Thread(target=m.worker, args=("hermes",), daemon=True).start()
    for _ in range(200):
        if m.ORDERS[0]["state"] == "done": break
        time.sleep(0.05)
    print("FIN", json.dumps({k: m.ORDERS[0].get(k) for k in ("state", "result")}), flush=True)
''')

class ExecvAdopta(unittest.TestCase):
    def test_execv_adopta_al_agente_vivo(self):
        with tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR')) as tmp:
            shutil.copy(FARO, os.path.join(tmp, 'faro.py'))
            sc = os.path.join(tmp, 'sim.py'); open(sc, 'w').write(SCRIPT)
            r = subprocess.run([sys.executable, sc, tmp, '1'], capture_output=True, text=True, timeout=60)
            self.assertIn('ADOPTADA True', r.stdout, r.stdout + r.stderr)
            fin = json.loads(r.stdout.split('FIN ', 1)[1])
            self.assertEqual(fin, {'state': 'done', 'result': 'respuesta del agente'})
            self.assertEqual(open(os.path.join(tmp, 'lanzamientos')).read().count('lanzado'), 1, 'el agente se lanzó una sola vez')

class NombreDelMotorLocal(unittest.TestCase):
    def test_el_nombre_sigue_al_motor(self):
        with tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR')) as tmp:
            m = load(tmp, 'faro_test_label')
            m.CFG['executors'] = {'local': {'type': 'ollama', 'label': 'Strata (local)'}}
            self.assertEqual(m.ex_label('local'), 'Ollama (local)')
            m.CFG['executors']['local']['type'] = 'openai'; self.assertEqual(m.ex_label('local'), 'Strata (local)')
            m.CFG['executors']['local'].update(type='ollama', label='Mi motor'); self.assertEqual(m.ex_label('local'), 'Mi motor')

if __name__ == '__main__': unittest.main()
