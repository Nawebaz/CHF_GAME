import datetime as dt
import importlib.util
import pathlib
import shutil
import tempfile
import os
import unittest

# El monitor de la máquina de GTA VI no se apaga: Faro guarda aparte el último informe con su bloque «gta»
class GtaLast(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR'))
        self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / 'faro.py'
        shutil.copy(pathlib.Path(__file__).resolve().parents[1] / 'faro.py', dst)
        spec = importlib.util.spec_from_file_location('faro_test_gta', dst)
        self.m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.m)
        self.m.CFG = {'projects': [], 'sources': {}, 'scheduled': [], 'executors': {}}
        self.m.CACHE = {}
        self.m.REPORTS = {}
        self.m.ORDERS = []
    def at(self, hours):
        return self.m.iso(self.m.now() - dt.timedelta(hours=hours))
    def test_old_report_still_feeds_monitor(self):
        clips = [{'n': 1, 's': 'mito', 'st': 2}]
        self.m.REPORTS['gta-viejo'] = dict(id='gta-viejo', kind='agent', name='Claude · Tanda', state='ok', ttl=3600, at=self.at(30), gta={'paso': 'Tanda 2', 'clips': clips})
        self.m.REPORTS['otro'] = dict(id='otro', kind='agent', name='Claude · Otro', state='ok', ttl=3600, at=self.at(1))
        self.m.build_status()
        s = self.m.STATUS
        self.assertFalse(any(a.get('gta') for a in s['agents']))      # ya no está entre los agentes (más de 12 h)
        self.assertEqual(s['gta_last']['gta']['paso'], 'Tanda 2')
        self.assertEqual(s['gta_last']['state'], 'ok')
    def test_newest_wins_and_none_without_data(self):
        self.m.build_status()
        self.assertIsNone(self.m.STATUS['gta_last'])
        self.m.REPORTS['a'] = dict(id='a', kind='agent', name='A', state='ok', ttl=3600, at=self.at(5), gta={'paso': 'viejo', 'clips': []})
        self.m.REPORTS['b'] = dict(id='b', kind='run', name='B', state='run', pct=10, ttl=3600, at=self.at(0), gta={'paso': 'nuevo', 'clips': []})
        self.m.REPORTS['c'] = dict(id='c', kind='agent', name='C', state='ok', ttl=3600, at=self.at(0), gta={'paso': 'roto', 'clips': 'no'})
        self.m.build_status()
        self.assertEqual(self.m.STATUS['gta_last']['gta']['paso'], 'nuevo')
        self.assertEqual(self.m.STATUS['gta_last']['state'], 'run')

if __name__ == '__main__':
    unittest.main()
