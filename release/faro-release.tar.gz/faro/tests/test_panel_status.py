import copy
import json
import unittest
import test_real_activity

class PanelStatus(unittest.TestCase):
    setUp = test_real_activity.RealActivity.setUp

    def test_office_data_is_separate_without_mutating_status(self):
        status = {'generated': 'now', 'todo': [], 'running': [], 'projects': [],
                  'vault': {'links': {'nodes': ['private-note']}}, 'events': [1],
                  'orders': [{'id': 'one', 'title': 'Task', 'state': 'running',
                              'text': 'Complete prompt', 'result': 'Complete output'}]}
        before = copy.deepcopy(status)
        panel = self.m.panel_status(status)
        self.assertNotIn('vault', panel)
        self.assertNotIn('events', panel)
        self.assertEqual(panel['orders'], [{'id': 'one', 'title': 'Task', 'state': 'running'}])
        self.assertEqual(status, before)

    def test_existing_snapshot_payload(self):
        self.m.build_status()
        status = self.m.STATUS
        panel = self.m.panel_status(status)
        self.assertLessEqual(len(json.dumps(panel, ensure_ascii=False).encode()), 40000)
        for name in ('todo', 'running', 'projects', 'orders', 'radar'):
            self.assertIn(name, panel)

    def test_http_office_restores_complete_orb_payload(self):
        from http.server import ThreadingHTTPServer
        import threading
        import urllib.request
        self.m.STATUS = {'generated': 'now', 'agents': [], 'running': [],
                         'vault': {'links': {'nodes': []}}, 'machines': [],
                         'events': [], 'orders': [{'id': 'x', 'text': 'detail'}]}
        server = ThreadingHTTPServer(('127.0.0.1', 0), self.m.H)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            def get(path):
                with urllib.request.urlopen(f'http://127.0.0.1:{server.server_port}/api/{path}') as response:
                    return json.load(response)
            panel, office = get('status'), get('office')
            self.assertNotIn('vault', panel)
            self.assertEqual({**panel, **office}, self.m.STATUS)
        finally:
            server.shutdown()
            server.server_close()
            thread.join()
