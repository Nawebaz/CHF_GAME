// Bóveda estelar (28-nov): el diámetro crece con las conexiones y los nodos más conectados son supermasivas azules.
const fs = require('fs'), path = require('path'), assert = require('assert');
const src = fs.readFileSync(path.join(__dirname, '..', 'web', 'oficina.js'), 'utf8');
const pick = re => { const m = src.match(re); assert.ok(m, 'falta ' + re); return m[0]; };
const code = [pick(/const STAR = \{[^}]+\};/), pick(/const starCol = [^\n]+/), pick(/const starBase = [^\n]+/)].join('\n') + '\n;({ STAR, starCol, starBase })';
const { STAR, starCol, starBase } = eval(code);
const maxd = 788;
assert.strictEqual(starCol(788, maxd), STAR.o, 'Hermes, supermasiva azul');
assert.strictEqual(starCol(150, maxd), STAR.o, 'nodo muy conectado, azul');
assert.strictEqual(starCol(1, maxd), STAR.k, 'nota casi suelta, estrella pequeña anaranjada');
for (const [a, b] of [[0, 1], [1, 5], [5, 20], [20, 100], [100, 788]]) assert.ok(starBase(b) > starBase(a), `más conexiones, más diámetro (${a}→${b})`);
assert.ok(starBase(788) / starBase(1) < 6, 'las grandes no tapan la galaxia');
assert.ok(!/r: 1\.1 \+ Math\.sqrt\(d\) \* 5\.5/.test(src), 'ya no se usa el tamaño relativo antiguo');
assert.ok(/R0 \* \(still \? 1\.45 : 1\.45 \+ \.25 \* Math\.sin/.test(src), 'en el móvil la cámara se acerca a la nube');
console.log('ok test_boveda_estelar');
