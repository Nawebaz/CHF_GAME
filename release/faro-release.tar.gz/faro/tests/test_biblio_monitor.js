// Monitor de la biblioteca (v2.74): sin carpeta no dibuja nada; con ella, todo queda dentro del recuadro de la bóveda.
const fs = require('fs'), assert = require('assert'); const src = fs.readFileSync('web/office.js', 'utf8');
const a = src.indexOf('  function BBR()'), b = src.indexOf('  /* ───────── Strata: su pantalla'); assert(a > 0 && b > a, 'no encuentro el monitor');
const octSrc = (() => { const i = src.indexOf('  function oct(c, x, y, w, h, k)'), j = src.indexOf('\n  }\n', i); return src.slice(i, j) + '\n  }\n'; })();
let ops = 0, texts = [], xs = [], ys = [];
const pt = (x, y) => { xs.push(x); ys.push(y); };
const c = { save() {}, restore() {}, beginPath() {}, closePath() {}, moveTo: pt, lineTo: pt, fill() { ops++; }, stroke() { ops++; },
  fillRect(x, y, w, h) { ops++; pt(x, y); pt(x + w, y + h); }, fillText(s, x, y) { ops++; texts.push(String(s)); pt(x, y); }, measureText: s => ({ width: String(s).length * 5 }),
  set font(v) {}, set textAlign(v) {}, set fillStyle(v) {}, set strokeStyle(v) {}, set lineWidth(v) {} };
const mk = wide => ({ L: { wide, vault: wide ? { x: 430, y: 96, w: 540, h: 524 } : { x: 200, y: 216, w: 220, h: 500 } }, D: {}, sparks: [] });
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v)), hexA = () => 'x', glow = () => {}, ZONES = { obsidian: { c: '#a78bfa' } };
const txText = (cc, s, x, y) => cc.fillText(s, x, y), fitText = (cc, s, w) => s.length * 5 <= w ? s : s.slice(0, Math.max(1, Math.floor(w / 5) - 1)) + '…';
for (const wide of [true, false]) {
  const S = mk(wide), f = new Function('c', 'S', 'clamp', 'hexA', 'glow', 'ZONES', 'txText', 'fitText', octSrc + src.slice(a, b) + '\n return { drawBiblio, BBR };')(c, S, clamp, hexA, glow, ZONES, txText, fitText);
  ops = 0; f.drawBiblio(c, 1); assert.equal(ops, 0, 'sin datos no se dibuja');
  S.D.biblio_probe = { dir: false }; f.drawBiblio(c, 1); assert.equal(ops, 0, 'sin carpeta no se dibuja');
  for (const P of [{ dir: true, running: true, nivel: '1', done: 25e9, total: 100e9, actual: 'wikipedia_es_all_maxi_2026-10.zim con un nombre larguísimo', cols: 3, bytes: 12e9, disc: 4 },
                   { dir: true, running: false, cols: 14, bytes: 162.4e9, disc: 10 }, { dir: true, running: false, cols: 0 }]) {
    S.D.biblio_probe = P; xs = []; ys = []; texts = []; ops = 0; f.drawBiblio(c, 2); assert(ops > 0, 'debería dibujarse');
    const R = f.BBR(), V = S.L.vault;
    assert(R.x >= V.x && R.x + R.w <= V.x + V.w && R.y >= V.y && R.y + R.h <= V.y + V.h, 'el monitor se sale de la bóveda');
    assert(Math.min(...xs) >= R.x - 1 && Math.max(...xs) <= R.x + R.w + 1 && Math.min(...ys) >= R.y - 1 && Math.max(...ys) <= R.y + R.h + 1, 'se dibuja fuera de su recuadro');
    assert(texts.includes('BIBLIOTECA')); const all = texts.join(' | ');
    if (P.running) assert(/BAJANDO N1 · 25 %/.test(all) && /25,0 GB de 100,0 GB|…/.test(all), all);
    else if (P.cols) assert(/LISTA/.test(all) && /14 colecciones · 162 GB · 10 disciplinas|…/.test(all), all);
    else assert(/VACÍA/.test(all), all);
  }
  assert.equal(S.sparks.length, 2, 'cada cambio de estado manda un dato al orbe');
}
console.log('PASS: monitor de la biblioteca');
