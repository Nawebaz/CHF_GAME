// Una auditoría o revisión se ve con el juez, sea del proyecto que sea (Nawe, 27 nov).
// Fuera de CHF: inspector ITV (gta-juez-*, cinco poses) y etiqueta «ITV · <proyecto>»; en GTA, «Juez ITV»; en CHF, sus jueces del juego.
const fs = require('fs'), vm = require('vm'), assert = require('assert'), path = require('path');
const src = fs.readFileSync(path.join(__dirname, '../web/oficina.js'), 'utf8');
const zone = src.match(/const ZONE = \{[\s\S]*?\};/)[0];
const block = src.slice(src.indexOf('/* CHF: solo actividad viva'), src.indexOf('function drawAgents(t, dt, now) {'));
const drawn = [], beams = []; let clock = 1000;
function Img() { this.complete = true; this.naturalWidth = 120; let s = ''; Object.defineProperty(this, 'src', { get: () => s, set: v => { s = v; } }); }
const X = new Proxy({}, { get: (t, k) => k === 'drawImage' ? (im => drawn.push(im.src)) : k in t ? t[k] : () => {}, set: (t, k, v) => { t[k] = v; return true; } });
const ctx = { X, Image: Img, S: { agents: [] }, wake() {}, beam: (...a) => beams.push(a), performance: { now: () => clock }, assert };
vm.createContext(ctx);
vm.runInContext(zone + '\n' + block + `
const auditor = { id: 'claude-auditoria-faro', name: 'Claude', project: 'faro', projectId: 'faro', zone: 'pensar', status: 'run',
  task: 'Auditoría del nuevo Faro, la nueva nave y el trabajo del bibliotecario', step: 'Juez: tres auditores en paralelo (servidor de Faro, la nave y el bibliotecario)' };
const chfJuez = { id: 'chf-juez', name: 'CHF', project: 'chf', projectId: 'chf', zone: 'pensar', status: 'run', task: 'Consulta', step: 'Juez: veredicto del guion' };
const gtaCrew = { id: 'gta-crew', name: 'Hermes', project: 'gta', projectId: 'gta', zone: 'gta', status: 'run', task: 'Insertos del clip', step: 'Montaje del clip radar-2611-0' };
assert.strictEqual(roleLabel(auditor), 'ITV');                       // el chip pinta «ITV · faro» y el nombre sigue en l1
assert.strictEqual(roleLabel(chfJuez), 'Juez');
assert.strictEqual(roleLabel(gtaCrew), 'Crew GTA');
assert.strictEqual(roleLabel({ ...gtaCrew, step: 'Juez ITV: revisar clip' }), 'Juez ITV');
assert.strictEqual(itvRol(chfJuez), null, 'CHF conserva sus jueces del juego');
assert.strictEqual(chfFase(chfJuez)[0], 'juez');
assert.strictEqual(itvRol({ ...auditor, step: 'Investigación: estado del Faro nuevo' }), null, 'con step que no juzga, figura de marca');
assert.strictEqual(roleLabel({ ...auditor, step: 'Investigación: estado del Faro nuevo' }), 'Pensar');
`, ctx);
// Dibujo: el auditor de Faro sale con el inspector ITV en cada pose.
const ac = { id: 'claude-auditoria-faro', ph: 'work', pt: 2, a: vm.runInContext('auditor', ctx) };
const draw = (o = {}) => { drawn.length = 0; const r = vm.runInContext('gtaDraw', ctx)(ac, 100, 200, 78, 1, !!o.send, !!o.think); return [r, drawn[0] || null]; };
let [r, im] = draw(); assert.ok(r && /gta-juez-escritorio\.webp/.test(im), 'juez trabajando en su escritorio: ' + im);
assert.ok(/gta-juez-pensar/.test(draw({ think: true })[1])); assert.ok(/gta-juez-entregar/.test(draw({ send: true })[1]));
ac.ph = 'enter'; ac.pt = .5; assert.ok(/gta-juez-andar/.test(draw()[1]));
ac.ph = 'exit'; ac.pt = .2; assert.ok(/gta-juez-andar/.test(draw()[1])); ac.pt = 1; assert.ok(/gta-juez-espaldas/.test(draw()[1]));
// Teletransporte al pasar de trabajo (figura de marca) a juez: haz, media vuelta con su figura y luego el inspector.
const b = { id: 'b', ph: 'work', pt: 5, a: { ...ac.a, step: 'Investigación: estado del Faro nuevo' } }, gd = vm.runInContext('gtaDraw', ctx);
assert.strictEqual(gd(b, 0, 0, 78, 1, false, false), false, 'sin juzgar: figura de marca');
b.a = { ...b.a, step: 'Juez: tres auditores en paralelo' }; beams.length = 0;
assert.strictEqual(gd(b, 0, 0, 78, 1, false, false), false, 'primera mitad del salto: aún su figura'); assert.strictEqual(beams.length, 1, 'haz de teletransporte');
clock += 500; drawn.length = 0; assert.ok(gd(b, 0, 0, 78, 1, false, false) && /gta-juez-/.test(drawn[0]), 'segunda mitad: inspector ITV');
clock += 400; beams.length = 0; gd(b, 0, 0, 78, 1, false, false); assert.strictEqual(beams.length, 0, 'acabado el salto, sin haz');
// GTA crew sigue igual (crew); un CHF juez no pasa por el inspector ITV.
const g = { id: 'g', ph: 'work', pt: 5, a: vm.runInContext('gtaCrew', ctx) }; drawn.length = 0; gd(g, 0, 0, 78, 1, false, false); assert.ok(/gta-crew-escritorio/.test(drawn[0]));
assert.strictEqual(gd({ id: 'c', ph: 'work', pt: 5, a: vm.runInContext('chfJuez', ctx) }, 0, 0, 78, 1, false, false), false);
assert.ok(/\$\{esc\(roleLabel\(a\)\)\}\$\{a\.project \? " · "/.test(src), 'la ficha pone «papel · proyecto» y el nombre sigue en l1');
console.log('PASS: auditorías y revisiones con el juez ITV fuera de CHF; CHF y GTA con los suyos');
