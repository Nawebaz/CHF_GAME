import datetime as dt, importlib.util, os, pathlib, shutil, sys, tempfile, time, unittest
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "tools"))
import vault_links as VL

def vault(files, mt=None):
    d = tempfile.mkdtemp()
    for rel, t in files.items():
        p = os.path.join(d, rel); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(t)
        if mt: os.utime(p, (mt, mt))
    return d

class Ficha(unittest.TestCase):
    def test_deduce_y_marca_sin_firma(self):
        VL.FICHA_DESDE = time.time() - 7200; mt = time.time() - 600
        d = vault({"00 Inicio.md": "[[_agentes/Índice de tareas]]", "_agentes/Índice de tareas.md": "# T", "10 Proyectos/CHF.md": "# CHF",
                   "_agentes/inbox/hermes/2026-11-15 1100 claude→hermes x.md": "Mira [[10 Proyectos/CHF|CHF]]",
                   "_agentes/outbox/2026-11-15 1100 claude→hermes x · RESPUESTA.md": "## Hermes · hecho\nlisto",
                   "_agentes/suelta.md": "sin nada"}, mt)
        r = VL.review(d, apply=True)
        enc = open(os.path.join(d, "_agentes/inbox/hermes/2026-11-15 1100 claude→hermes x.md")).read()
        self.assertIn("autor: claude (deducido)", enc); self.assertIn("proyecto: chf (deducido)", enc)
        self.assertIn("autor: hermes (deducido)", open(os.path.join(d, "_agentes/outbox/2026-11-15 1100 claude→hermes x · RESPUESTA.md")).read())
        self.assertEqual(r["unsigned"], ["_agentes/suelta.md"])
    def test_lo_viejo_no_se_toca(self):
        VL.FICHA_DESDE = time.time() - 7200; d = vault({"_agentes/vieja.md": "sin ficha"}, VL.FICHA_DESDE - 86400)
        VL.review(d, apply=True); self.assertEqual(open(os.path.join(d, "_agentes/vieja.md")).read(), "sin ficha")
    def test_informe(self):
        d = vault({"00 Inicio.md": "x", "10 Proyectos/Campaña de ingresos.md": "# C", "10 Proyectos/Campaña de ingreso.md": "# C", "70 Privado/secreto.md": "NO LEER", "suelta.md": "a"})
        rep = VL.library_report(d, "2026-11-16")
        self.assertIn("en 70 Privado, sin leer", rep); self.assertNotIn("secreto", rep); self.assertIn("suelta", rep); self.assertIn("≈", rep)

class Bibliotecario(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, self.d)
        dst = pathlib.Path(self.d) / "faro.py"; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / "faro.py", dst)
        shutil.copytree(pathlib.Path(__file__).resolve().parents[1] / "tools", pathlib.Path(self.d) / "tools")
        spec = importlib.util.spec_from_file_location("fb", dst); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); self.m = m
        self.v = os.path.join(self.d, "boveda"); os.makedirs(os.path.join(self.v, "10 Proyectos")); open(os.path.join(self.v, "10 Proyectos/CHF.md"), "w").write("# CHF")
        m.CFG = {"vault": {"path": self.v, "write": True}, "sources": {}, "projects": [], "executors": {}}
        os.makedirs(os.path.join(self.d, "data"), exist_ok=True); m.ROOT = self.d
    def at(self, h, mi):
        real = self.m.now; self.m.now = lambda: dt.datetime(2026, 11, 16, h, mi).astimezone(); r = self.m.c_bibliotecario(); self.m.now = real; return r
    def test_fuera_de_hora_no_hace_nada(self):
        self.assertFalse(self.at(14, 0)["ran"])
    def test_en_hora_y_en_calma(self):
        r = self.at(4, 40); self.assertTrue(r["ran"])
        self.assertTrue(os.path.exists(os.path.join(self.v, "Faro/Biblioteca/Informe 2026-11-16.md")))
        enc = os.listdir(os.path.join(self.v, "_agentes/inbox/hermes")); self.assertEqual(len(enc), 1); self.assertIn("bibliotecario nocturno", enc[0])
        self.assertFalse(self.at(5, 10)["ran"])   # una vez por noche
    def test_espera_si_hay_trafico(self):
        self.m.VLIVE["ev"].append({"s": 1, "t": time.time(), "p": "x", "k": "write", "who": "Hermes"})
        self.assertFalse(self.at(4, 40)["ran"])
    def test_te_toca_hasta_revisar(self):
        f = os.path.join(self.v, "Faro/Biblioteca"); os.makedirs(f); p = os.path.join(f, "Recomendaciones 2026-11-16.md")
        open(p, "w").write("---\nrevisado:\n---\nx"); self.assertEqual(self.at(14, 0)["pending"], "Recomendaciones 2026-11-16")
        open(p, "w").write("---\nrevisado: sí\n---\nx"); self.assertIsNone(self.at(14, 0)["pending"])
    def test_firma_manda(self):
        open(os.path.join(self.v, "n.md"), "w").write("---\nautor: codex\n---\nx"); self.m.vault_event("n", "write")
        self.assertEqual(self.m.VLIVE["ev"][-1]["who"], "Codex")
        open(os.path.join(self.v, "o.md"), "w").write("---\nautor: codex (deducido)\n---\nx"); self.m.vault_event("o", "write")
        self.assertNotEqual(self.m.VLIVE["ev"][-1].get("via"), "firma")

if __name__ == "__main__": unittest.main()
