// El plugin de Obsidian: lee las posiciones del grafo, solo envía si algo se movió y aguanta que no haya vista gráfica
const Module = require("module"), path = require("path"), assert = require("assert");
const sent = []; let status = 200;
const fake = { Plugin: class { constructor() { this.app = null; } async loadData() { return {}; } async saveData() {} addSettingTab() {} addCommand() {} registerInterval() {} },
  PluginSettingTab: class { constructor() {} }, Setting: class {}, requestUrl: async o => { sent.push(o); return { status }; } };
const orig = Module._load; Module._load = function (r, ...a) { return r === "obsidian" ? fake : orig.call(this, r, ...a); };
global.window = { setInterval: () => 0 };
const P = require(path.join(__dirname, "..", "extras", "obsidian-faro-grafo", "main.js"));
(async () => {
  const nodes = [{ id: "a/Uno.md", x: 10.04, y: -20 }, { id: "#radar", x: 300, y: 5 }, { id: "foto.png", x: NaN, y: 1 }];
  const p = new P(); p.app = { workspace: { getLeavesOfType: () => [{ view: { renderer: { nodes } } }] } }; await p.onload();
  await p.tic(false); assert.strictEqual(sent.length, 1); const b = JSON.parse(sent[0].body);
  assert.deepStrictEqual(b.nodes, [["a/Uno.md", 10, -20], ["#radar", 300, 5]]); assert.ok(sent[0].url.endsWith("/api/vault/layout"));
  await p.tic(false); assert.strictEqual(sent.length, 1, "quieto: no reenvía");
  nodes[0].x = 11; await p.tic(false); assert.strictEqual(sent.length, 1, "temblor pequeño: no reenvía");
  nodes[0].x = 80; await p.tic(false); assert.strictEqual(sent.length, 2, "se movió: reenvía");
  p.app.workspace.getLeavesOfType = () => []; await p.tic(true); assert.strictEqual(sent.length, 2, "sin vista gráfica: nada");
  console.log("ok");
})().catch(e => { console.error(e); process.exit(1); });
