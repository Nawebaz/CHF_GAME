"""Relay privado: lee reports.json de un repositorio git con token en archivo, sin poner el token en la URL."""
import importlib.util, json, os, subprocess, sys, tempfile, unittest
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load():
    spec = importlib.util.spec_from_file_location("faro_relay_t", os.path.join(ROOT, "faro.py"))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

class Relay(unittest.TestCase):
    def test_lee_relay_y_no_filtra_token(self):
        m = load()
        with tempfile.TemporaryDirectory() as t:
            src = os.path.join(t, "src"); os.makedirs(src)
            g = lambda *a: subprocess.run(["git", "-C", src, *a], capture_output=True, check=True)
            g("init", "-q", "-b", "faro-buzon"); g("config", "user.email", "t@t"); g("config", "user.name", "t")
            json.dump([{"id": "relay-test", "kind": "agent", "name": "Prueba relay", "state": "run", "at": "2026-11-17T12:00:00+01:00"}], open(os.path.join(src, "reports.json"), "w"))
            g("add", "."); g("commit", "-qm", "x")
            tok = os.path.join(t, "tok.txt"); open(tok, "w").write("SECRETO123\n")
            m.CFG.setdefault("sources", {})["github_relay"] = {"git": "file://" + src, "branch": "faro-buzon", "token_file": tok}
            m.ROOT = t; m.DATA = os.path.join(t, "data"); os.makedirs(m.DATA); m.REPORTS.clear()
            r = m.c_github_relay()
            self.assertEqual(r["imported"], 1)
            self.assertIn("relay-test", m.REPORTS)
            self.assertNotIn("SECRETO123", json.dumps(r))
            self.assertTrue(any("Authorization: Basic" in x for x in m._relay_auth(m.CFG["sources"]["github_relay"])))
            self.assertEqual(m.c_github_relay().get("changed"), False)   # sin cambios: no reimporta

if __name__ == "__main__": unittest.main()
