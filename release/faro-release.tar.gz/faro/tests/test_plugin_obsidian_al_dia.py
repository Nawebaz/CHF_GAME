"""Faro pone al día el plugin «Faro · grafo» de la bóveda si está instalado (sin tocar sus ajustes) y no lo instala si no está."""
import json, os, sys, tempfile, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import faro

class PluginAlDia(unittest.TestCase):
    def test_actualiza_solo_si_esta(self):
        with tempfile.TemporaryDirectory() as v:
            faro.CFG["vault"] = {"path": v}
            faro.obs_plugin_sync(); self.assertFalse(os.path.exists(os.path.join(v, ".obsidian", "plugins", "faro-grafo")))
            d = os.path.join(v, ".obsidian", "plugins", "faro-grafo"); os.makedirs(d)
            json.dump({"id": "faro-grafo", "version": "1.1.0"}, open(os.path.join(d, "manifest.json"), "w"))
            open(os.path.join(d, "main.js"), "w").write("viejo"); open(os.path.join(d, "data.json"), "w").write('{"cada":4}')
            faro.obs_plugin_sync()
            self.assertIn("1,5 s", open(os.path.join(d, "main.js"), encoding="utf-8").read())
            self.assertEqual(open(os.path.join(d, "data.json")).read(), '{"cada":4}')
            self.assertEqual(json.load(open(os.path.join(d, "manifest.json")))["version"], "1.2.0")

if __name__ == "__main__":
    unittest.main()
