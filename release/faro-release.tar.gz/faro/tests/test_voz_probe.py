import importlib.util, os, pathlib, shutil, subprocess, sys, tempfile, time, unittest

# Faro detecta por sí mismo si se está generando voz: proceso lanzado desde la carpeta de la voz + último audio
class VozProbe(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR')); self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / 'faro.py'
        shutil.copy(pathlib.Path(__file__).resolve().parents[1] / 'faro.py', dst)
        spec = importlib.util.spec_from_file_location('faro_test_voz', dst); self.m = importlib.util.module_from_spec(spec); spec.loader.exec_module(self.m)
        self.voz = pathlib.Path(self.tmp.name) / 'vozdir'; (self.voz / 'pruebas').mkdir(parents=True); (self.voz / 'venv').mkdir()
        self.m.CFG = {'voz': {'dir': str(self.voz)}}
    def probe(self):
        self.m._VZ.update(pt=0, ft=0); return self.m.voz_probe()
    def test_files_and_process(self):
        r = self.probe(); self.assertTrue(r['dir']); self.assertFalse(r['running']); self.assertIsNone(r['last'])
        (self.voz / 'venv' / 'ignorado.wav').write_bytes(b'x'); (self.voz / 'pruebas' / 'clip3_pt.wav').write_bytes(b'x')
        r = self.probe(); self.assertEqual(r['today'], 1); self.assertEqual(r['lang'], 'pt'); self.assertIsNotNone(r['last'])
        script = self.voz / 'genera.py'; script.write_text('import time\ntime.sleep(20)\n')
        p = subprocess.Popen([sys.executable, str(script)]); self.addCleanup(p.kill); time.sleep(.4)
        r = self.probe(); self.assertTrue(r['running']); self.assertIsNotNone(r['since'])
        p.kill(); p.wait(); r = self.probe(); self.assertFalse(r['running']); self.assertIsNone(r['since'])
    def test_missing_dir(self):
        self.m.CFG = {'voz': {'dir': str(self.voz / 'no-existe')}}
        r = self.probe(); self.assertFalse(r['dir']); self.assertFalse(r['running'])

if __name__ == '__main__':
    unittest.main()
