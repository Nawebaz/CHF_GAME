// La voz de la nave solo se enciende con voz de verdad (entreno, generación o ingesta en marcha).
// Casos sacados de /api/status del 27 nov (06:18 y 06:22): la síntesis de Mimo no puede encender nada de voz ni la máquina GTA.
const fs = require('fs'), vm = require('vm'), assert = require('assert'), path = require('path');
const web = f => path.join(__dirname, '../web', f);
const ctx = {}; vm.createContext(ctx); vm.runInContext(fs.readFileSync(web('voz-estado.js'), 'utf8'), ctx);
const faroVoz = ctx.faroVoz, NOW = Date.parse('2026-11-27T06:22:30+01:00'), at = s => new Date(NOW - s * 1000).toISOString();
const gtaQuieto = { at: at(30), last: '2026-11-26T07:53:57+01:00', voz_ocupada: false, clips: [{ n: 'launch-1811-h03', p: 'INSERTOS', u: '2026-11-18T15:44:31+01:00' }] };
const hermes = task => ({ id: 'live:hermes', name: 'Hermes · PC', live: true, state: 'run', presence: 'desk', action: 'code', project: 'agentes', task,
  tasks: [{ title: 'PC', name: 'Hermes · PC', state: 'run', at: at(30), project: 'sistema', closed: false },
          { title: 'Síntesis local', name: 'Hermes · Mimo GPU', state: 'run', at: at(40), project: 'agentes', closed: false },
          { title: 'Ingesta de voz', name: 'Hermes · ingesta voz', state: 'ok', at: at(50), project: 'agentes', pct: 100, closed: true }] });
const mimoGpu = step => ({ id: 'hermes-mimo-gpu', name: 'Hermes · Mimo GPU', task: 'Síntesis local', step, action: 'code', project: 'agentes', state: 'run', presence: 'desk', at: at(20), ttl: 300 });
const st = (agents, running = [], probe = { running: false }) => ({ agents, running, voz_probe: probe });
const off = (s, g = gtaQuieto, m = null) => assert.strictEqual(faroVoz(s, m, g, NOW), null, JSON.stringify(faroVoz(s, m, g, NOW)));

// 1. La síntesis de Mimo, tal cual a las 06:18 y a las 06:22: nada de voz.
off(st([hermes('Ingesta de voz · con «Mimo orden de síntesis, cannabis, compost y sustra»')], [mimoGpu('243/1999 fichas')]));
off(st([hermes('Síntesis local · con «Mimo orden de síntesis, cannabis, compost y sustra»')], [mimoGpu(null)]));
// 2. Vocabulario de plantas que antes casaba con lora/clon/tts: floración, flora, clonar esquejes, watts, exploración, valoración.
for (const step of ['ficha 243/1999 · cannabis: floración', 'clonar esquejes de cannabis', 'lámpara de 600 watts', 'exploración de sustratos', 'valoración del compost'])
  off(st([], [mimoGpu(step)]));
off(st([{ id: 'mimo-bibliotecario', name: 'Bibliotecario · flora', task: 'Radar de fuentes vegetales', state: 'run', presence: 'desk', at: at(10), ttl: 300 }]));
// 3. Informe de ingesta ya cerrado (latido «ok» cada pocos minutos) y cerrojo de voz sin clip en VOZ: nada.
off(st([{ id: 'hermes-ingesta-voz', name: 'Hermes · ingesta voz', task: 'Ingesta de voz', state: 'ok', presence: 'gone', at: at(20), pct: 100 }]));
off(st([]), { ...gtaQuieto, voz_ocupada: true });
off(st([{ id: 'claude-gta-voz', name: 'Claude · Voz narradora', task: 'Encargo dejado a Hermes; esperando sus 3 pruebas', project: 'voz', state: 'run', presence: 'desk', at: at(60), ttl: 3600 }]));
// 4. Voz de verdad: sí enciende, con lo que es.
const on = (s, kind, g = gtaQuieto, m = null) => { const v = faroVoz(s, m, g, NOW); assert.ok(v, 'debía encender: ' + kind); assert.strictEqual(v.kind, kind); return v; };
assert.ok(on(st([], [{ id: 'hv', name: 'Hermes · entrenar voz', task: 'Entrenar perfil de voz voz-mamut', step: 'época 3/20', action: 'voice', project: 'voz', state: 'run', presence: 'desk', at: at(30), ttl: 900 }]), 'entreno').gta);
on(st([], [{ id: 'hn', name: 'Hermes · Voz narradora', task: 'Generar audio del clip radar-2611-0', step: 'TTS 3/9', project: 'voz', state: 'run', presence: 'desk', at: at(30), ttl: 300 }]), 'generacion');
assert.ok(!on(st([], [{ id: 'hi', name: 'Hermes · ingesta voz', task: 'Ingesta de voz', step: 'grabación 2/7', project: 'agentes', state: 'run', presence: 'desk', at: at(30), ttl: 300 }]), 'ingesta').gta, 'la ingesta de agentes no trae la máquina GTA');
on(st([], [], { running: true }), 'generacion');
on(st([]), 'generacion', { ...gtaQuieto, voz_ocupada: true, clips: [{ n: 'radar-2611-0', p: 'VOZ', u: at(120) }] });
// 5. Un informe en marcha pero caducado no cuenta.
off(st([], [{ id: 'hv', name: 'Hermes · entrenar voz', task: 'Entrenar perfil de voz', state: 'run', presence: 'desk', at: at(4000), ttl: 900 }]));

// 6. Clasificador de zona de la nave: «flora» o «watts» ya no son la zona Voz.
const src = fs.readFileSync(web('oficina.js'), 'utf8'), zc = {};
vm.createContext(zc); vm.runInContext(src.match(/const ACT = \{[\s\S]*?\};/)[0].replace('const ACT', 'var ACT') + '\n' + src.match(/function zoneOf\(a\) \{[\s\S]*?\n\}/)[0], zc);
assert.notStrictEqual(zc.zoneOf({ name: 'Bibliotecario · flora', task: 'Radar de fuentes vegetales' }), 'voz');
assert.notStrictEqual(zc.zoneOf({ name: 'Hermes · Mimo GPU', task: 'Síntesis local', step: 'foco de 600 watts' }), 'voz');
assert.strictEqual(zc.zoneOf({ name: 'Hermes · Voz narradora', task: 'Generar audio del clip' }), 'voz');
// 7. Una sola regla: la nave y gta.html usan voz-estado.js y no leen el cerrojo en crudo.
const html = fs.readFileSync(web('oficina.html'), 'utf8');
assert.ok(html.indexOf('voz-estado.js') > -1 && html.indexOf('voz-estado.js') < html.indexOf('oficina.js'), 'oficina.html carga voz-estado.js antes que oficina.js');
assert.ok(!/voz_ocupada/.test(src), 'oficina.js no usa voz_ocupada en crudo');
assert.ok(/faroVoz/.test(fs.readFileSync(web('gta.html'), 'utf8')), 'gta.html usa la misma regla');
console.log('PASS: la voz solo se enciende con voz de verdad (Mimo no la enciende)');
