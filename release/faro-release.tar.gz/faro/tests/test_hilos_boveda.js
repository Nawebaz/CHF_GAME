// Los hilos de los satélites del orbe no pueden salir del octógono de la bóveda (v2.73).
const fs = require('fs'), assert = require('assert'); const src = fs.readFileSync('web/office.js', 'utf8');
const grab = (start, end) => { const a = src.indexOf(start), b = src.indexOf(end, a + 1); assert(a > 0 && b > a, 'no encuentro ' + start); return src.slice(a, b); };
const code = grab('  function oct(c, x, y, w, h, k)', '\n  }\n') + '\n  }\n' +
  (() => { const a = src.indexOf('  const VOCT = v =>'), b = src.indexOf('\n  }\n', src.indexOf('function vgInOct')); assert(a > 0 && b > a, 'no encuentro vgInOct'); return src.slice(a, b) + '\n  }\n'; })() +
  grab('  function drawDeposits(c, t)', '  function drawGravity');
let clip = 0, outside = 0, inside = 0, strokes = 0, path = [];
const c = { save() { this._s = (this._s || []); this._s.push(clip); }, restore() { clip = this._s.pop(); }, clip() { clip++; },
  beginPath() { path = []; }, moveTo(x, y) { path.push([x, y]); }, lineTo(x, y) { path.push([x, y]); }, arc() {}, closePath() {}, quadraticCurveTo(a, b, x, y) { path.push([x, y]); },
  stroke() { strokes++; if (!clip) outside++; else inside++; }, fill() {}, set lineCap(v) {}, set strokeStyle(v) {}, set lineWidth(v) {}, set fillStyle(v) {} };
const S = { L: { vault: { x: 100, y: 100, w: 300, h: 300 } }, orb: null };
const VG = { nodes: new Map() };
const node = (id, x, y) => (VG.nodes.set(id, { id, pj: [x, y] }), VG.nodes.get(id));
const A = node('a', 250, 250), B = node('b', 260, 300), F = node('f', 900, -400);   // F, muy fuera (cámara mal colocada)
S.orb = { drops: [{ t0: 0, fall: .5, fx: 250, fy: 50, a: A, b: B, u: .5, path: ['a', 'f', 'b'], rgb: [255, 200, 100], col: '#ffc864', side: 1 }] };
const clamp = (x, a, b) => Math.max(a, Math.min(b, x)), glow = () => {}, rgbA = () => 'x';
const run = new Function('c', 'S', 'VG', 'clamp', 'glow', 'rgbA', code + '\n return { drawDeposits, vgInOct };');
const f = run(c, S, VG, clamp, glow, rgbA);
assert(f.vgInOct(250, 250, 0) && !f.vgInOct(105, 105, 0) && !f.vgInOct(900, -400, 0), 'vgInOct');
for (let t = .6; t < 3; t += .05) f.drawDeposits(c, t);
assert(strokes > 0, 'debería dibujar el recorrido');
assert.equal(outside, 0, 'hay trazos del recorrido sin recorte al octógono');
console.log('PASS: los hilos de los satélites quedan recortados al octógono (' + inside + ' trazos)');
