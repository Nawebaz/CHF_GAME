// El bibliotecario de la descarga tiene figura propia (v2.77) y se reconoce por su nombre (su id es "a:" + nombre).
const fs = require('fs'), assert = require('assert'); const src = fs.readFileSync('web/office.js', 'utf8');
const a = src.indexOf('  const isBiblio = a =>'), b = src.indexOf('  // Pantalla de la mesa de quien descarga la biblioteca:'); assert(a > 0 && b > a);
assert(/if \(isBiblio\(a\)( && !spF\("biblio\.idle"\))?\) \{ drawLibrarian\(/.test(src) && src.includes('else if (isBiblio(a) && bibLive()) drawBiblioScreen('), 'no está enganchado');
assert(!src.includes('a.id === "live:biblio"'), 'el id en la oficina no es live:biblio');
let ops = 0, xs = [], ys = []; const pt = (x, y) => { xs.push(x); ys.push(y); };
const c = { beginPath() {}, closePath() {}, moveTo: pt, lineTo: pt, arc(x, y, r) { pt(x - r, y - r); pt(x + r, y + r); }, ellipse(x, y, rx, ry) { pt(x - rx, y - ry); pt(x + rx, y + ry); },
  fill() { ops++; }, stroke() { ops++; }, fillRect(x, y, w, h) { ops++; pt(x, y); pt(x + w, y + h); }, set fillStyle(v) {}, set strokeStyle(v) {}, set lineWidth(v) {}, set lineCap(v) {} };
const S = { reduce: false }, ZONES = { obsidian: { c: '#a78bfa' } }, hexA = () => 'x', glow = () => {};
const f = new Function('c', 'S', 'ZONES', 'hexA', 'glow', src.slice(a, b) + '\n return { isBiblio, drawLibrarian };')(c, S, ZONES, hexA, glow);
assert(f.isBiblio({ name: 'Bibliotecario · síntesis' }) && !f.isBiblio({ name: 'Bibliotecario nocturno' }));
assert(f.isBiblio({ id: 'a:Bibliotecario · descarga', name: 'Bibliotecario · descarga' }) && !f.isBiblio({ name: 'Hermes' }) && !f.isBiblio(null));
for (const reduce of [false, true]) for (const st of ['work', 'idle']) for (const seated of [true, false]) for (let t = 0; t < 4; t += .37) {
  S.reduce = reduce; xs = []; ys = []; ops = 0; f.drawLibrarian(c, { st, ph: 1.3, y: 300 }, t, 500, 299, 267, seated); assert(ops > 10);
  assert(xs.every(Number.isFinite) && ys.every(Number.isFinite), 'coordenadas no válidas');
  assert(Math.min(...xs) > 500 - 32 && Math.max(...xs) < 500 + 32 && Math.min(...ys) > 300 - 58 && Math.max(...ys) < 300 + 32, 'la figura se sale de su hueco');
}
console.log('PASS: bibliotecario con figura propia');
