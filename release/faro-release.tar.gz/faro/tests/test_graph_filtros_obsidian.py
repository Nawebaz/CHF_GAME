import importlib.util, json, os, pathlib, shutil, tempfile, time, unittest

# El grafo de la bóveda en Faro sigue los filtros de la vista gráfica de Obsidian (graph.json o lo que manda el plugin)
class GraphFiltrosObsidian(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR')); self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / 'faro.py'; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / 'faro.py', dst)
        spec = importlib.util.spec_from_file_location('faro_test_filtros', dst); self.m = importlib.util.module_from_spec(spec); spec.loader.exec_module(self.m)
        self.v = pathlib.Path(self.tmp.name) / 'v'; (self.v / 'a').mkdir(parents=True); (self.v / '.obsidian').mkdir()
        (self.v / 'a' / 'Uno.md').write_text('[[Dos]] ![[foto.png]] [[No existe]] [[Dos.md]] #radar\nunicornio\n', encoding='utf-8')
        (self.v / 'a' / 'Dos.md').write_text('[[Uno]]\n', encoding='utf-8'); (self.v / 'Sola.md').write_text('nada\n', encoding='utf-8')
        (self.v / 'foto.png').write_bytes(b'x'); (self.v / 'suelto.pdf').write_bytes(b'x')
        self.notes = [(1.0, 'a/Uno'), (1.0, 'a/Dos'), (1.0, 'Sola')]; self.atts = ['foto.png', 'suelto.pdf']
    def gj(self, **o):
        base = {"search": "", "showTags": True, "showAttachments": True, "hideUnresolved": True, "showOrphans": True}; base.update(o)
        (self.v / '.obsidian' / 'graph.json').write_text(json.dumps(base), encoding='utf-8')
    def graph(self):
        g = self.m.vault_graph(str(self.v), self.notes, atts=self.atts, opts=self.m.obs_graph_opts(str(self.v)))
        return g, {n['id']: n for n in g['nodes']}
    def test_sin_graph_json_lo_ensena_todo(self):
        self.assertIsNone(self.m.obs_graph_opts(str(self.v)))
        g = self.m.vault_graph(str(self.v), self.notes, atts=self.atts); N = {n['id']: n for n in g['nodes']}
        self.assertIn('foto.png', N); self.assertIn('suelto.pdf', N); self.assertIn('#radar', N); self.assertNotIn('No existe', N); self.assertIsNone(g['obs'])
    def test_sin_adjuntos_no_hay_anillo(self):
        self.gj(showAttachments=False); g, N = self.graph()
        self.assertFalse([n for n in N.values() if n['k'] == 2]); self.assertEqual(g['atts'], 0)
        self.assertNotIn('foto.png', N, 'un adjunto oculto no sale como enlace sin resolver'); self.assertEqual(g['obs']['att'], False)
    def test_sin_etiquetas_ni_huerfanas(self):
        self.gj(showTags=False, showOrphans=False); g, N = self.graph()
        self.assertNotIn('#radar', N); self.assertNotIn('Sola', N); self.assertNotIn('suelto.pdf', N); self.assertIn('foto.png', N)
        self.assertTrue(all(n['d'] > 0 for n in N.values()))
    def test_sin_resolver_en_gris(self):
        self.gj(hideUnresolved=False); g, N = self.graph()
        self.assertEqual(N['No existe']['k'], 3); self.assertEqual(N['No existe']['d'], 1); self.assertEqual(N['No existe']['o'], 0); self.assertEqual(g['unres'], 1)
        self.assertNotIn('Dos.md', N, '[[Dos.md]] es la nota Dos, no un enlace roto')
    def test_busqueda(self):
        self.gj(search='path:"a/" -file:Dos'); g, N = self.graph()
        self.assertIn('a/Uno', N); self.assertNotIn('a/Dos', N); self.assertNotIn('Sola', N); self.assertNotIn('suelto.pdf', N); self.assertEqual(g['total'], 1)
        self.gj(search='unicornio'); g, N = self.graph(); self.assertEqual([n for n in N if n.startswith('a/') or n == 'Sola'], ['a/Uno'])
        self.gj(search='tag:#radar'); g, N = self.graph(); self.assertIn('a/Uno', N); self.assertNotIn('a/Dos', N)
    def test_busqueda_que_no_entiende_no_filtra(self):
        self.gj(search='content:"hola" OR (path:a)'); g, N = self.graph()
        self.assertIn('Sola', N); self.assertFalse(g['obs']['q_ok'])
    def test_el_plugin_manda_si_es_mas_nuevo(self):
        self.gj(showAttachments=True); os.utime(self.v / '.obsidian' / 'graph.json', (time.time() - 60, time.time() - 60))
        r = self.m.obs_layout_set({"opts": {"showAttachments": False, "showTags": True, "showOrphans": True, "hideUnresolved": True, "search": ""}})
        self.assertTrue(r['ok']); o = self.m.obs_graph_opts(str(self.v)); self.assertEqual((o['att'], o['src']), (False, 'plugin'))
        g, N = self.graph(); self.assertFalse([n for n in N.values() if n['k'] == 2])
        self.gj(showAttachments=True); o = self.m.obs_graph_opts(str(self.v)); self.assertEqual((o['att'], o['src']), (True, 'graph.json'), 'cambiado después en el archivo: manda el archivo')

if __name__ == '__main__': unittest.main()
