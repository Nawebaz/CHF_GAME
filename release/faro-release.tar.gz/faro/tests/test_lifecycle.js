const vm=require('vm'),fs=require('fs'),assert=require('assert');
let next=0, callbacks=new Map(), listeners={}, calls=0;
const document={hidden:false,documentElement:{classList:{toggle(){}}},addEventListener:(name,fn)=>listeners[name]=fn};
const add=fn=>{callbacks.set(++next,fn);return next;},remove=id=>callbacks.delete(id);
const window={setTimeout:add,clearTimeout:remove,requestAnimationFrame:add,cancelAnimationFrame:remove};
vm.runInNewContext(fs.readFileSync('web/lifecycle.js','utf8'),{window,document});
window.setInterval(()=>calls++,1000);window.requestAnimationFrame(()=>calls++);
assert.equal(callbacks.size,2);
document.hidden=true;listeners.visibilitychange();assert.equal(callbacks.size,0);
window.setTimeout(()=>calls++,10);assert.equal(callbacks.size,0);assert.equal(calls,0);
document.hidden=false;listeners.visibilitychange();assert.equal(callbacks.size,3);
for(const [id,fn] of [...callbacks]){callbacks.delete(id);fn(0);}
assert.equal(calls,3);assert.equal(callbacks.size,1);
document.hidden=true;listeners.visibilitychange();assert.equal(callbacks.size,0);
console.log('PASS: hidden page has zero scheduled timers/frames; callbacks resume once');
