import importlib.util, os, pathlib, shutil, tempfile, time, unittest
def put(p, txt, age=60):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(txt); t = time.time() - age; os.utime(p, (t, t))
class Inbox(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, self.d)
        dst = pathlib.Path(self.d) / "faro.py"; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / "faro.py", dst)
        shutil.copytree(pathlib.Path(__file__).resolve().parents[1] / "tools", pathlib.Path(self.d) / "tools")
        spec = importlib.util.spec_from_file_location("fi", dst); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        self.m = m; self.v = os.path.join(self.d, "boveda"); self.a = os.path.join(self.v, "_agentes")
        m.CFG = {"vault": {"path": self.v}, "sources": {}, "projects": [], "executors": {"faro": {}, "hermes": {}, "codex": {}, "claude": {}}}
        m.STATE = {}; m.save_state = lambda: None; self.sent = []
        def fake(text, kind="orden", title=None, thread=None, executor=None):
            o = {"id": "o%d" % len(self.sent), "state": "queued", "executor": executor, "result": "ok"}; m.ORDERS.append(o)
            self.sent.append((executor, title)); return {"order": o}
        m.new_order = fake; m.ORDERS.clear()
    def test_every_agent_inbox_is_watched(self):
        put(f"{self.a}/inbox/hermes/2026-11-14 1000 claude→hermes tarea nueva.md", "---\npara: hermes\nestado: pendiente\n---\nhaz X")
        put(f"{self.a}/inbox/codex/2026-11-14 1001 claude→codex otra.md", "haz Y")
        r = self.m.c_vault_inbox()
        self.assertEqual(sorted(self.sent), [("codex", "otra"), ("hermes", "tarea nueva")]); self.assertEqual(r["pending"], 2)
        self.m.c_vault_inbox(); self.assertEqual(len(self.sent), 2)            # no se lanza dos veces
        for o in self.m.ORDERS: o["state"] = "done"
        self.m.c_vault_inbox()
        self.assertTrue(os.path.exists(f"{self.a}/archivo/2026-11-14 1000 claude→hermes tarea nueva.md"))
        self.assertTrue(os.path.exists(f"{self.a}/outbox/2026-11-14 1000 claude→hermes tarea nueva · RESPUESTA.md"))
        self.assertEqual(os.listdir(f"{self.a}/inbox/hermes"), [])
    def test_avisos_answered_cancelled_and_stale_are_not_launched(self):
        put(f"{self.a}/inbox/claude/2026-11-14 1140 claude→claude AVISO algo.md", "aviso")
        put(f"{self.a}/inbox/hermes/2026-11-12 1040 claude→hermes ya hecha.md", "x")
        put(f"{self.a}/outbox/2026-11-12 1040 claude→hermes ya hecha · RESPUESTA.md", "hecho")
        put(f"{self.a}/inbox/hermes/2026-11-14 0225 claude→hermes cancelada.md", "---\nestado: cancelada (no hacer)\n---\nx")
        put(f"{self.a}/inbox/hermes/2026-11-01 1248 faro→hermes vieja.md", "x", age=8 * 86400)
        put(f"{self.a}/inbox/nadie/tarea.md", "x")
        r = self.m.c_vault_inbox()
        self.assertEqual(self.sent, [])
        self.assertTrue(os.path.exists(f"{self.a}/avisos/2026-11-14 1140 claude→claude AVISO algo.md"))
        self.assertTrue(os.path.exists(f"{self.a}/archivo/2026-11-12 1040 claude→hermes ya hecha.md"))
        self.assertTrue(os.path.exists(f"{self.a}/archivo/2026-11-14 0225 claude→hermes cancelada.md"))
        self.assertTrue(os.path.exists(f"{self.a}/archivo/sin-respuesta/2026-11-01 1248 faro→hermes vieja.md"))
        self.assertEqual(r["unwatched"], ["nadie"])
    def test_old_reply_leaves_outbox(self):
        put(f"{self.a}/archivo/t.md", "x"); put(f"{self.a}/outbox/t · RESPUESTA.md", "r", age=4 * 86400)
        put(f"{self.a}/outbox/u · RESPUESTA.md", "r", age=4 * 86400)       # su tarea no está archivada: se queda
        self.m.c_vault_inbox()
        self.assertTrue(os.path.exists(f"{self.a}/archivo/t · RESPUESTA.md")); self.assertTrue(os.path.exists(f"{self.a}/outbox/u · RESPUESTA.md"))
    def test_old_state_keys_migrate(self):
        os.makedirs(self.a); self.m.STATE["vinbox"] = {"vieja.md": {"answered": True}}
        self.m.c_vault_inbox(); self.assertIn("faro/vieja.md", self.m.STATE["vinbox"])
if __name__ == "__main__": unittest.main()
