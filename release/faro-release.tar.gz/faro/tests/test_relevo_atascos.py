import importlib.util, os, pathlib, shutil, tempfile, time, unittest

# Atascos: si Hermes no puede trabajar (sin cupo) y tiene órdenes en cola, Faro pasa la primera a su relevo (Claude Code)
class RelevoAtascos(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR')); self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / 'faro.py'; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / 'faro.py', dst)
        spec = importlib.util.spec_from_file_location('faro_test_relevo', dst); m = self.m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        m.CFG['executors'] = {'hermes': {'type': 'cmd', 'label': 'Hermes', 'cmd': ['true']},
                              'claude': {'type': 'cmd', 'label': 'Claude Code', 'cmd': ['echo', '{prompt}']}}
        m.CFG.pop('relief', None); m.CFG['ollama'] = {'model': 'qwen3:14b'}
        m.EXEC_BLOCK.clear(); m.ORDERS[:] = []
        def o(i, prio, created, ex='hermes', st='queued'):
            return {'id': 'o:%d' % i, 'title': 'orden %d' % i, 'text': 'haz la %d' % i, 'executor': ex, 'priority': prio, 'state': st, 'created': created}
        m.ORDERS += [o(1, 'normal', '2026-11-17T10:00'), o(2, 'alta', '2026-11-17T15:15'), o(3, 'alta', '2026-11-17T15:00')]
        m.save_orders = lambda: None; m.say = lambda *a, **k: None
    def block(self, secs):
        self.m.EXEC_BLOCK['hermes'] = {'until': time.time() + secs, 'why': 'sin cuota hasta las 12:15'}
    def test_sin_atasco_no_mueve(self):
        self.assertEqual(self.m.relief_tick(), [])
        self.block(120); self.assertEqual(self.m.relief_tick(), [], 'un bloqueo corto no es atasco')
    def test_pasa_la_primera_y_de_una_en_una(self):
        self.block(7200); mv = self.m.relief_tick()
        self.assertEqual([o['id'] for o in mv], ['o:3'], 'la de más prioridad y más antigua')
        o3 = mv[0]; self.assertEqual((o3['executor'], o3['relief_from']), ('claude', 'hermes')); self.assertIn('Relevo', o3['reason'])
        self.assertEqual(self.m.relief_tick(), [], 'mientras el relevo tenga una, no coge otra')
        o3['state'] = 'done'; self.assertEqual([o['id'] for o in self.m.relief_tick()], ['o:2'])
    def test_lo_de_baja_no_gasta_relevo(self):
        for o in self.m.ORDERS: o['priority'] = 'baja'
        self.block(7200); self.assertEqual(self.m.relief_tick(), [])
    def test_relevo_no_disponible(self):
        self.block(7200); self.m.CFG['executors']['claude']['enabled'] = False
        self.assertEqual(self.m.relief_tick(), [])
        self.m.CFG['executors']['claude']['enabled'] = True; self.m.CFG['relief'] = {}
        self.assertEqual(self.m.relief_tick(), [], 'sin relevo configurado, esperan')
    def test_prompt_en_modo_ahorro(self):
        self.block(7200); o = self.m.relief_tick()[0]
        out = self.m.execute(o)
        self.assertIn('MODO RELEVO', out); self.assertIn('qwen3:14b', out); self.assertIn('haz la 3', out)
    def test_aviso_dice_la_verdad(self):
        self.block(7200); self.m.build_status()
        t = [x for x in self.m.STATUS.get('todo', []) if x['id'].startswith('exec:hermes')]
        self.assertTrue(t and 'Claude Code' in t[0]['text'], t)
        self.m.CFG['relief'] = {}; self.m.build_status()
        t = [x for x in self.m.STATUS.get('todo', []) if x['id'].startswith('exec:hermes')]
        self.assertIn('esperan', t[0]['text'])

if __name__ == '__main__': unittest.main()
