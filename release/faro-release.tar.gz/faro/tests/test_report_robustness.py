import datetime as dt
import json
import threading
import urllib.request
import unittest
import test_real_activity

class ReportRobustness(unittest.TestCase):
    setUp = test_real_activity.RealActivity.setUp
    def test_http_malformed_reports(self):
        m = self.m
        m.note_event = lambda *_: None
        server = m.ThreadingHTTPServer(('127.0.0.1', 0), m.H)
        self.addCleanup(server.server_close)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.shutdown)
        base = 'http://127.0.0.1:%s' % server.server_port
        for body in ({'id':'x','kind':'todo','state':'warn'}, {'id':'y','kind':'agent','pct':'abc'}):
            req = urllib.request.Request(base+'/api/report', data=json.dumps(body).encode(), headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(req) as r:
                self.assertTrue(json.load(r)['ok'])
            m.build_status()
            with urllib.request.urlopen(base+'/api/status') as r:
                self.assertGreater(len(r.read()), 1024)
        self.assertEqual(m.REPORTS['x']['title'], 'x')
        self.assertNotIn('pct', m.REPORTS['y'])
        from pathlib import Path
        self.assertNotIn('Traceback', (Path(m.DATA)/'faro.log').read_text() if (Path(m.DATA)/'faro.log').exists() else '')

    def test_validation_and_pruning(self):
        m = self.m
        for body in (None, [], {'id':[]}, {'id':'a'*81}, {'id':'x','kind':'wrong'}, {'id':'x','state':'wrong'}):
            self.assertFalse(m.report(body)['ok'])
        self.assertEqual(m.REPORTS, {})
        m.REPORTS = {'broken':None,'old':{'id':'old','state':'ok','at':m.iso(m.now()-dt.timedelta(days=8))},'fresh':{'id':'fresh'}}
        m.clean_reports()
        self.assertEqual(set(m.REPORTS), {'fresh'})
        self.assertEqual(m.jload('reports.json', {}), m.REPORTS)

    def test_section_failure_preserves_status(self):
        m = self.m
        m.machines = lambda: 1/0
        m.build_status()
        self.assertEqual(m.STATUS['machines'], [])
        self.assertEqual(m.STATUS['errors']['machines'], 'error')
        self.assertIn('projects', m.STATUS)
        self.assertIn('generated', m.STATUS)

    def test_startup_cleans_persisted_reports(self):
        import importlib.util
        from pathlib import Path
        data = Path(self.m.DATA)
        (data/'reports.json').write_text(json.dumps({'bad': None, 'good': {'id':'good','kind':'todo'}}))
        spec = importlib.util.spec_from_file_location('faro_restart', Path(self.m.ROOT)/'faro.py')
        restarted = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(restarted)
        self.assertEqual(set(restarted.REPORTS), {'good'})
        self.assertEqual(restarted.jload('reports.json', {}), restarted.REPORTS)
        self.assertTrue(restarted.STATUS)
