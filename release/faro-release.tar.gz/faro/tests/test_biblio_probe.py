import importlib.util, json, os, pathlib, shutil, tempfile, time, unittest

# Faro mira por sí mismo la biblioteca offline: progreso.json (descarga en marcha) y manifest.json (lo ya verificado)
class BiblioProbe(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR')); self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / 'faro.py'
        shutil.copy(pathlib.Path(__file__).resolve().parents[1] / 'faro.py', dst)
        spec = importlib.util.spec_from_file_location('faro_test_biblio', dst); self.m = importlib.util.module_from_spec(spec); spec.loader.exec_module(self.m)
        self.b = pathlib.Path(self.tmp.name) / 'Biblioteca'
        self.m.CFG = {'biblioteca': {'dir': str(self.b)}}
    def probe(self):
        self.m._BB.update(t=0, v=None); return self.m.biblio_probe()
    def test_missing_dir(self):
        r = self.probe(); self.assertFalse(r['dir']); self.assertFalse(r['running']); self.assertEqual(r['cols'], 0)
    def test_progress_and_manifest(self):
        self.b.mkdir(); r = self.probe(); self.assertTrue(r['dir']); self.assertFalse(r['running']); self.assertIsNone(r['last'])
        (self.b / 'progreso.json').write_text(json.dumps({'nivel': 1, 'hecho_bytes': 25, 'total_bytes': 100, 'actual': 'wikipedia_es'}))
        (self.b / 'manifest.json').write_text(json.dumps([
            {'id': 'a', 'disciplina': ['medicina', 'ciencias'], 'bytes': 10, 'estado': 'ok'},
            {'id': 'b', 'disciplina': 'derecho', 'bytes': 5, 'estado': 'verificado'},
            {'id': 'c', 'disciplina': ['derecho'], 'bytes': 99, 'estado': 'descargando'}, 'basura']))
        r = self.probe(); self.assertTrue(r['running']); self.assertEqual((r['done'], r['total'], r['nivel']), (25, 100, '1'))
        self.assertEqual((r['cols'], r['cols_all'], r['bytes'], r['disc']), (2, 3, 15, 3)); self.assertIsNotNone(r['last'])
    def test_agent_only_while_downloading(self):
        self.assertIsNone((self.probe(), self.m.biblio_agent())[1]); self.b.mkdir()
        (self.b / 'progreso.json').write_text(json.dumps({'nivel': 1, 'hecho_bytes': 25, 'total_bytes': 200, 'actual': 'wikipedia_es'}))
        self.probe(); a = self.m.biblio_agent(); self.assertEqual((a['id'], a['state'], a['pct'], a['action']), ('live:biblio', 'run', 12.5, 'obsidian'))
        self.assertIn('wikipedia_es', a['task']); self.assertIn('12,5 %', a['task'])
        (self.b / 'progreso.json').write_text(json.dumps({'nivel': 1, 'hecho_bytes': 200, 'total_bytes': 200})); self.probe(); self.assertIsNone(self.m.biblio_agent())
    def test_synthesis_agent_after_download(self):
        self.b.mkdir(); (self.b / 'sintesis.json').write_text(json.dumps({'fase': 'piloto', 'hechas': 2, 'total': 5, 'actual': 'Cálculo', 'motor': 'local'}))
        r = self.probe(); self.assertTrue(r['sint']['running']); a = self.m.biblio_agent()
        self.assertEqual((a['name'], a['pct'], a['state']), ('Bibliotecario · síntesis', 40.0, 'run')); self.assertIn('2 de 5 fichas', a['task']); self.assertIn('Cálculo', a['task'])
        (self.b / 'progreso.json').write_text(json.dumps({'nivel': 1, 'hecho_bytes': 1, 'total_bytes': 9})); self.probe()
        self.assertEqual(self.m.biblio_agent()['name'], 'Bibliotecario · descarga')   # si aún descarga, manda la descarga
        os.remove(self.b / 'progreso.json'); (self.b / 'sintesis.json').write_text(json.dumps({'hechas': 5, 'total': 5})); self.probe(); self.assertIsNone(self.m.biblio_agent())
        (self.b / 'sintesis.json').write_text(json.dumps({'hechas': 1, 'total': 5})); old = time.time() - 600; os.utime(self.b / 'sintesis.json', (old, old)); self.probe(); self.assertIsNone(self.m.biblio_agent())
    def test_finished_stale_and_broken(self):
        self.b.mkdir(); p = self.b / 'progreso.json'
        p.write_text(json.dumps({'nivel': 1, 'hecho_bytes': 100, 'total_bytes': 100})); self.assertFalse(self.probe()['running'])   # acabado
        p.write_text(json.dumps({'nivel': 1, 'hecho_bytes': 1, 'total_bytes': 100})); old = time.time() - 600; os.utime(p, (old, old))
        self.assertFalse(self.probe()['running'])   # parado: nadie lo toca desde hace 10 min
        p.write_text('{roto'); (self.b / 'manifest.json').write_text('[[['); r = self.probe()
        self.assertTrue(r['dir']); self.assertFalse(r['running']); self.assertEqual(r['cols'], 0)
        p.write_text(json.dumps({'hecho_bytes': -5, 'total_bytes': 'mucho', 'actual': 7})); r = self.probe(); self.assertEqual((r['done'], r['total']), (0, 0))

if __name__ == '__main__':
    unittest.main()
