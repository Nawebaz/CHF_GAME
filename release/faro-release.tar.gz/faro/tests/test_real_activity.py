import datetime as dt
import importlib.util
import pathlib
import shutil
import tempfile
import os
import unittest

class RealActivity(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR'))
        self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / 'faro.py'
        shutil.copy(pathlib.Path(__file__).resolve().parents[1] / 'faro.py', dst)
        spec = importlib.util.spec_from_file_location('faro_test', dst)
        self.m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.m)
        self.m.CFG = {'projects': [], 'sources': {}, 'scheduled': [], 'executors': {}}
        self.m.CACHE = {}
        self.m.REPORTS = {}
        self.m.ORDERS = []
    def report(self, **kw):
        d = dict(id='test', kind='run', name='Hermes · test', state='run', pct=25, ttl=60, at=self.m.iso(self.m.now()))
        d.update(kw)
        self.m.REPORTS['test'] = d
        self.m.build_status()
        return self.m.STATUS
    def test_fresh_report_has_percentage(self):
        s = self.report()
        self.assertEqual(s['running'][0]['pct'], 25)
    def test_expired_run_is_bad_not_working(self):
        s = self.report(at=self.m.iso(self.m.now() - dt.timedelta(seconds=90)))
        self.assertFalse(s['running'])
        self.assertEqual(s['agents'][0]['state'], 'bad')
    def test_bad_run_is_not_working(self):
        self.assertFalse(self.report(state='bad')['running'])
    def test_ok_run_is_not_working(self):
        self.assertFalse(self.report(state='ok')['running'])
    def test_dead_pid_is_not_working(self):
        s = self.report(pid=2147483647)
        self.assertFalse(s['running'])
        self.assertEqual(s['agents'][0]['state'], 'bad')
    def test_example_is_not_working(self):
        s = self.report(example=True)
        self.assertFalse(s['running'])
        self.assertFalse(s['agents'])
    def test_inferred_processes_are_not_agents(self):
        for key in ('procs', 'codex', 'github_activity'):
            self.m.CACHE[key] = {'agents': [{'name':key, 'state':'run'}]}
        self.m.build_status()
        self.assertFalse(self.m.STATUS['agents'])
    def test_live_poll_shows_every_local_agent(self):
        self.m.CACHE['live'] = {'agents': [
            {'id':'live:hermes','name':'Hermes · PC','brand':'hermes','state':'run','task':'trabajando · última acción hace 10 s','live':True},
            {'id':'live:codex','name':'Codex · PC','brand':'gpt','state':'ok','task':'descansando','live':True},
            {'id':'live:claude-code','name':'Claude Code · PC','brand':'claude','state':'off','task':'apagado','live':True}]}
        self.m.build_status()
        st = {a['name']: a['state'] for a in self.m.STATUS['agents']}
        self.assertEqual(st, {'Hermes · PC':'run','Codex · PC':'ok','Claude Code · PC':'off'})
        self.assertEqual(self.m.STATUS['agents'][0]['name'], 'Hermes · PC')
    def test_live_uses_fresh_report_task(self):
        self.m.CACHE['live'] = {'agents': [{'id':'live:hermes','name':'Hermes · PC','brand':'hermes','state':'run','task':'trabajando · última acción hace 5 s'}]}
        self.report(kind='agent', state='ok', brand='hermes', task='Revisar CHF 3D', project='chf')
        a = next(a for a in self.m.STATUS['agents'] if a['name'] == 'Hermes · PC')
        self.assertTrue(a['task'].startswith('Revisar CHF 3D')); self.assertEqual(a['project'], 'chf')
    def test_old_reports_are_history_and_duplicates_collapse(self):
        old = self.m.iso(self.m.now() - dt.timedelta(hours=13)); new = self.m.iso(self.m.now())
        self.m.REPORTS = {'a': dict(id='a', kind='agent', name='Hermes · chf-3d', state='ok', at=old, ttl=99999),
                          'b': dict(id='b', kind='agent', name='Hermes · chf-3d', state='ok', at=new, ttl=600, task='nuevo'),
                          'c': dict(id='c', kind='agent', name='Hermes · chf-3d', state='ok', at=self.m.iso(self.m.now() - dt.timedelta(minutes=5)), ttl=600, task='viejo')}
        self.m.build_status()
        ag = self.m.STATUS['agents']
        self.assertEqual(len(ag), 1); self.assertEqual(ag[0]['task'], 'nuevo')
    def test_buzon_imports_src_at_reports(self):
        import json as J
        self.m.CFG['sources'] = {'github_inbox': {'enabled': True, 'git': False, 'url': 'http://x'}}
        self.m.http = lambda *a, **k: J.dumps([{'id':'cloud1','kind':'run','name':'Claude · X','state':'run','src_at': self.m.iso(self.m.now()),'ttl':3600,'pct':10}]).encode()
        self.assertEqual(self.m.c_github_inbox()['imported'], 1)
        self.assertIn('cloud1', self.m.REPORTS)
        self.assertEqual(self.m.c_github_inbox()['imported'], 0)
    def test_schedule_does_not_invent_agent(self):
        self.m.CFG['scheduled'] = [{'id':'scheduled','project':'chf','name':'Test','cron':'* * * * *'}]
        self.m.build_status()
        self.assertFalse(self.m.STATUS['agents'])
    def test_expired_state_is_persisted(self):
        self.report(at=self.m.iso(self.m.now() - dt.timedelta(seconds=90)))
        self.assertEqual(self.m.REPORTS['test']['state'], 'bad')
    def test_local_policy_prevents_update_overwrite(self):
        (pathlib.Path(self.tmp.name) / 'REAL_ACTIVITY_LOCK').write_text('local audited patch')
        self.m.CFG['update'] = {'url': 'http://127.0.0.1:1/'}
        result = self.m.self_update(force=True)
        self.assertEqual(result.get('reason'), 'local-real-activity-policy')
    def test_expired_agent_is_bad(self):
        s = self.report(kind='agent', at=self.m.iso(self.m.now() - dt.timedelta(seconds=90)))
        self.assertEqual(s['agents'][0]['state'], 'bad')

if __name__ == '__main__': unittest.main()
