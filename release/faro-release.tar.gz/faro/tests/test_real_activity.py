import datetime as dt
import importlib.util
import pathlib
import shutil
import tempfile
import os
import unittest

class RealActivity(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR'))
        self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / 'faro.py'
        shutil.copy(pathlib.Path(__file__).resolve().parents[1] / 'faro.py', dst)
        spec = importlib.util.spec_from_file_location('faro_test', dst)
        self.m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.m)
        self.m.CFG = {'projects': [], 'sources': {}, 'scheduled': [], 'executors': {}}
        self.m.CACHE = {}
        self.m.REPORTS = {}
        self.m.ORDERS = []
    def report(self, **kw):
        d = dict(id='test', kind='run', name='Hermes · test', state='run', pct=25, ttl=60, at=self.m.iso(self.m.now()))
        d.update(kw)
        self.m.REPORTS['test'] = d
        self.m.build_status()
        return self.m.STATUS
    def test_fresh_report_has_percentage(self):
        s = self.report()
        self.assertEqual(s['running'][0]['pct'], 25)
    def test_expired_run_is_bad_not_working(self):
        s = self.report(at=self.m.iso(self.m.now() - dt.timedelta(seconds=90)))
        self.assertFalse(s['running'])
        self.assertEqual(s['agents'][0]['state'], 'bad')
    def test_bad_run_is_not_working(self):
        self.assertFalse(self.report(state='bad')['running'])
    def test_ok_run_is_not_working(self):
        self.assertFalse(self.report(state='ok')['running'])
    def test_dead_pid_is_not_working(self):
        s = self.report(pid=2147483647)
        self.assertFalse(s['running'])
        self.assertEqual(s['agents'][0]['state'], 'bad')
    def test_example_is_not_working(self):
        s = self.report(example=True)
        self.assertFalse(s['running'])
        self.assertFalse(s['agents'])
    def test_inferred_processes_are_not_agents(self):
        for key in ('procs', 'codex', 'github_activity'):
            self.m.CACHE[key] = {'agents': [{'name':key, 'state':'run'}]}
        self.m.build_status()
        self.assertFalse(self.m.STATUS['agents'])
    def test_schedule_does_not_invent_agent(self):
        self.m.CFG['scheduled'] = [{'id':'scheduled','project':'chf','name':'Test','cron':'* * * * *'}]
        self.m.build_status()
        self.assertFalse(self.m.STATUS['agents'])
    def test_expired_state_is_persisted(self):
        self.report(at=self.m.iso(self.m.now() - dt.timedelta(seconds=90)))
        self.assertEqual(self.m.REPORTS['test']['state'], 'bad')
    def test_local_policy_prevents_update_overwrite(self):
        (pathlib.Path(self.tmp.name) / 'REAL_ACTIVITY_LOCK').write_text('local audited patch')
        self.m.CFG['update'] = {'url': 'http://127.0.0.1:1/'}
        result = self.m.self_update(force=True)
        self.assertEqual(result.get('reason'), 'local-real-activity-policy')
    def test_expired_agent_is_bad(self):
        s = self.report(kind='agent', at=self.m.iso(self.m.now() - dt.timedelta(seconds=90)))
        self.assertEqual(s['agents'][0]['state'], 'bad')

if __name__ == '__main__': unittest.main()
