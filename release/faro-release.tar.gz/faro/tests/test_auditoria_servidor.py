"""Auditoría del servidor (27-nov-2026). Reproduce con datos reales lo que vio Nawe y fija los arreglos 01–06.
Datos: /api/status capturado a las 06:22 (vivo/aud-status.json); si no está, se usa una copia mínima equivalente."""
import datetime as dt, importlib.util, json, os, pathlib, shutil, tempfile, threading, time, unittest, urllib.request

HERE = pathlib.Path(__file__).resolve()
SNAP = pathlib.Path(os.environ.get("FARO_SNAP", "/home/claude/auditoria/vivo/aud-status.json"))
MIMO = "Mimo orden de síntesis, cannabis, compost y sustratos"

class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="faro-aud-"); self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / "faro.py"; shutil.copy(HERE.parents[1] / "faro.py", dst)
        spec = importlib.util.spec_from_file_location("faro_aud", dst); m = self.m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        m.CFG = {"projects": [], "sources": {}, "scheduled": [], "executors": {}}
        m.CACHE, m.REPORTS, m.ORDERS[:] = {}, {}, []
        m.save_orders = lambda: None
    def ago(self, s): return self.m.iso(self.m.now() - dt.timedelta(seconds=s))
    def order(self):
        return {"id": "o:26f00a7a", "kind": "orden", "title": MIMO, "project": "mimo", "action": "code", "executor": "hermes",
                "state": "running", "created": self.ago(900), "started": self.ago(450)}
    def live_hermes(self):
        """c_live de verdad (sin ps ni ~/.hermes del equipo): proceso vivo y registro escrito hace 5 s."""
        m = self.m; d = pathlib.Path(self.tmp.name) / "hermes-sessions"; d.mkdir(exist_ok=True); (d / "s.json").write_text("{}")
        m.LIVE_AGENTS = [("hermes", "Hermes · PC", "hermes", "hermes", [str(d)])]
        m.procs_alive = lambda: {"hermes": 1}; m.strata_url = lambda default=None: None; m.CFG["strata_urls"] = []
        m.http_json = lambda *a, **k: (_ for _ in ()).throw(OSError("sin red en la prueba"))
        m.CACHE["live"] = m.c_live()
    def hermes(self):
        return next(a for a in self.m.STATUS["agents"] if a.get("id") == "live:hermes")

class AgentesVivos(Base):
    def test_06_18_ingesta_cerrada_no_renombra_la_sintesis(self):
        """Contexto 06:18: la última noticia de Hermes es «Ingesta de voz» (ok, 100 %, cerrada), pero ejecuta la orden de Mimo."""
        m = self.m; m.ORDERS.append(self.order())
        m.REPORTS = {
            "hermes-ingesta-voz": dict(id="hermes-ingesta-voz", kind="agent", name="Hermes · ingesta voz", brand="hermes", state="ok",
                                       pct=100, task="Ingesta de voz", project="agentes", action="code", ttl=300, at=self.ago(2)),
            "hermes-mimo-gpu": dict(id="hermes-mimo-gpu", kind="run", name="Hermes · Mimo GPU", brand="hermes", state="run", pct=12,
                                    task="Síntesis local", step="243/1999 fichas", project="agentes", action="code", ttl=300, at=self.ago(40)),
            "hermes-mimo-sintesis": dict(id="hermes-mimo-sintesis", kind="run", name="Hermes · Mimo síntesis", brand="hermes", state="run",
                                         pct=70, task="Pruebas reales", project="agentes", action="code", ttl=300, at=self.ago(60))}
        self.live_hermes(); m.build_status(); h = self.hermes()
        self.assertNotIn("voz", h["task"].lower(), h["task"])
        self.assertTrue(h["task"].startswith("con «Mimo orden de síntesis"), h["task"])
        self.assertEqual(h["project"], "mimo"); self.assertEqual(h["action"], "code")

    def test_06_22_json_real(self):
        """Mismo caso con el /api/status real de las 06:22 (horas desplazadas a ahora)."""
        if not SNAP.exists(): self.skipTest("sin captura " + str(SNAP))
        s = json.loads(SNAP.read_text()); m = self.m; gen = m.parse_iso(s["generated"]); shift = m.now() - gen
        mv = lambda iso_: m.iso(m.parse_iso(iso_) + shift) if iso_ else None
        reps = {}
        for a in s["agents"]:
            if str(a.get("id", "")).startswith("live:"): continue
            reps[a["id"]] = {k: v for k, v in a.items() if k not in ("presence", "presence_why", "expect_s", "tasks", "done")} | {"at": mv(a.get("at"))}
        for t in self.hermes_tasks(s):
            if t["name"] == "Hermes · PC": continue
            rid = "f:" + t["name"]; reps[rid] = dict(id=rid, kind="agent", name=t["name"], brand="hermes", state=t["state"], pct=t.get("pct"),
                                                      task=t["title"], project=t["project"], action="code", ttl=300, at=mv(t["at"]))
        for r in s["running"]:
            reps[r["id"]] = {k: v for k, v in r.items() if k not in ("presence", "presence_why", "expect_s", "stale")} | {"at": mv(r.get("at"))}
        for v in reps.values(): v.pop("pct", None) if v.get("pct") is None else None
        m.REPORTS = reps
        o = next(o for o in s["orders"] if o["id"] == "o:26f00a7a"); m.ORDERS.append({**o, "started": mv(o["started"])})
        self.live_hermes(); m.build_status(); h = self.hermes()
        self.assertTrue(h["task"].startswith("con «Mimo orden de síntesis"), h["task"])
        self.assertEqual(h["project"], "mimo")
        self.assertNotIn("prueba-real-voz", [a["id"] for a in m.STATUS["agents"]], "terminado hace 8 h: fuera de la lista")
    @staticmethod
    def hermes_tasks(s): return next(a for a in s["agents"] if a["id"] == "live:hermes")["tasks"]

    def test_sin_orden_usa_informe_en_marcha_no_el_cerrado(self):
        m = self.m
        m.REPORTS = {"a": dict(id="a", kind="agent", name="Hermes · ingesta voz", brand="hermes", state="ok", pct=100, task="Ingesta de voz", ttl=300, at=self.ago(1), project="agentes"),
                     "b": dict(id="b", kind="run", name="Hermes · Mimo GPU", brand="hermes", state="run", pct=10, task="Síntesis local", ttl=300, at=self.ago(30), project="mimo")}
        self.live_hermes(); m.build_status(); h = self.hermes()
        self.assertTrue(h["task"].startswith("Síntesis local"), h["task"]); self.assertEqual(h["project"], "mimo")

    def test_tarea_plegada_conserva_el_motivo_del_fallo(self):
        m = self.m
        m.REPORTS = {"g": dict(id="g", kind="agent", name="Hermes · Mimo GPU", brand="hermes", state="bad", pct=0, task="Síntesis local",
                               step="la GPU la ocupa llama-server (9,2 GB)", ttl=300, at=self.ago(20)),
                     "i": dict(id="i", kind="agent", name="Hermes · ingesta voz", brand="hermes", state="ok", pct=100, task="Ingesta de voz", ttl=300, at=self.ago(2))}
        self.live_hermes(); m.build_status(); ts = self.hermes()["tasks"]
        t = next(t for t in ts if t["name"] == "Hermes · Mimo GPU")
        self.assertEqual(t["step"], "la GPU la ocupa llama-server (9,2 GB)")
        self.assertEqual(ts[0]["name"], "Hermes · Mimo GPU", "lo abierto va antes que lo cerrado aunque sea más viejo")

class Caducidad(Base):
    def test_prueba_real_ok_100_sale_de_la_lista(self):
        m = self.m
        m.REPORTS = {"prueba-real-chf-juez": dict(id="prueba-real-chf-juez", kind="agent", name="CHF · juez", state="ok", pct=100, ttl=150,
                                                  task="Consulta de estado", step="Lectura de estado", project="chf", at=self.ago(10 * 3600)),
                     "reciente": dict(id="reciente", kind="agent", name="CHF · guion", state="ok", pct=100, ttl=150, task="Consulta", at=self.ago(300))}
        m.build_status(); ids = [a["id"] for a in m.STATUS["agents"]]
        self.assertNotIn("prueba-real-chf-juez", ids); self.assertIn("reciente", ids, "lo recién terminado se ve un rato")

    def test_sin_actualizacion_dice_la_hora_real_y_guarda_la_tarea(self):
        m = self.m
        m.REPORTS = {"x": dict(id="x", kind="agent", name="Claude · Diseño", state="run", ttl=3600, task="Diseño Faro v2", at=self.ago(2 * 3600), cloud=True)}
        m.build_status(); a = next(a for a in m.STATUS["agents"] if a["id"] == "x")
        self.assertEqual(a["task"], "Sin actualización verificable · hace 2 h"); self.assertEqual(a.get("task_was"), "Diseño Faro v2")
        self.assertEqual(m.REPORTS["x"]["task"], "Diseño Faro v2", "el informe guardado no se reescribe")
        m.REPORTS["x"]["at"] = self.ago(10 * 3600); m.build_status()
        self.assertEqual(next(a for a in m.STATUS["agents"] if a["id"] == "x")["task"], "Sin actualización verificable · hace 10 h")
        m.report({"id": "x", "state": "run", "task": "Diseño Faro v2 · fase 2"})
        a = next(a for a in m.STATUS["agents"] if a["id"] == "x"); self.assertEqual(a["state"], "run"); self.assertFalse(a.get("stale"))

class InformeParcial(Base):
    def test_parcial_no_pisa_kind_state_ttl(self):
        m = self.m
        m.report({"id": "p", "kind": "agent", "name": "Hermes · CHF", "state": "run", "ttl": 3600, "task": "Montaje"})
        m.report({"id": "p", "pct": 40})
        r = m.REPORTS["p"]
        self.assertEqual((r["kind"], r["state"], r["ttl"]), ("agent", "run", 3600))

class Fichas(Base):
    def test_id_reutilizado_no_hereda(self):
        m = self.m
        m.report({"id": "claude-skills-repo", "kind": "agent", "name": "Claude · repo de skills", "state": "run", "step": "copiando skills", "pct": 60, "need": "elige"})
        m.report({"id": "claude-skills-repo", "kind": "agent", "name": "Claude · Diseño Faro v2", "state": "run", "task": "Diseño"})
        r = m.REPORTS["claude-skills-repo"]
        self.assertEqual(r["name"], "Claude · Diseño Faro v2"); self.assertNotIn("step", r); self.assertNotIn("pct", r); self.assertNotIn("need", r)

    def test_voz_last_viejo_no_manda(self):
        m = self.m
        m.REPORTS = {"claude-gta-voz": dict(id="claude-gta-voz", kind="agent", name="Claude · Voz narradora", state="bad", project="voz", at=self.ago(14 * 86400))}
        self.assertIsNone(m.voz_last_report())

    def test_biblio_last_cuenta_la_sintesis(self):
        m = self.m; b = pathlib.Path(self.tmp.name) / "Biblioteca"; b.mkdir()
        (b / "progreso.json").write_text('{"hecho_bytes": 10, "total_bytes": 10}'); os.utime(b / "progreso.json", (time.time() - 10 * 86400,) * 2)
        (b / "sintesis.json").write_text('{"hechas": 20, "total": 20}')
        m.CFG["biblioteca"] = {"dir": str(b)}; m._BB.update(t=0, v=None)
        self.assertGreater(m.parse_iso(m.biblio_probe()["last"]), m.now() - dt.timedelta(minutes=5))

class ObraYDecide(Base):
    def test_latido_run_ok_no_sube_la_obra(self):
        m = self.m; m.STATE["build"] = {}
        for _ in range(3):
            m.report({"id": "iv", "kind": "agent", "name": "Hermes · ingesta voz", "state": "run", "task": "Ingesta de voz", "project": "agentes"})
            m.report({"id": "iv", "kind": "agent", "name": "Hermes · ingesta voz", "state": "ok", "pct": 100, "task": "Ingesta de voz", "project": "agentes"})
        self.assertEqual(len(m.STATE["build"]["agentes"]["log"]), 1, "tres latidos en un minuto = una entrega")

    def test_decide_sin_archivadas_ni_fallidas_viejas(self):
        m = self.m; t = lambda h: self.ago(h * 3600)
        m.ORDERS[:] = [{"id": "o:viejo", "title": "CHF clips tanda 6", "text": "x", "state": "failed", "created": t(80), "finished": t(72)},
                       {"id": "o:arch", "title": "VOZ URGENTE", "text": "x", "state": "failed", "created": t(2), "finished": t(1), "archived": True},
                       {"id": "o:nuevo", "title": "fallo de hoy", "text": "x", "state": "failed", "created": t(2), "finished": t(1)},
                       {"id": "o:cola", "title": "en cola", "text": "x", "state": "queued", "created": t(100)}]
        ids = [d["id"] for d in m.build_decide([]) if d["kind"] == "orden"]
        self.assertEqual(sorted(ids), ["o:cola", "o:nuevo"])

class BibliotecarioYRespuesta(Base):
    def test_recomendaciones_en_agentes_biblioteca(self):
        m = self.m; v = pathlib.Path(self.tmp.name) / "boveda"
        (v / "Faro" / "Biblioteca").mkdir(parents=True); (v / "_agentes" / "Biblioteca").mkdir(parents=True)
        (v / "Faro/Biblioteca/Recomendaciones 2026-11-22.md").write_text("---\nrevisado:\n---\n")
        (v / "_agentes/Biblioteca/Recomendaciones 2026-11-27.md").write_text("---\nrevisado:\n---\n")
        m.CFG["vault"] = {"path": str(v), "write": True, "folder": "Faro"}; m.CFG["bibliotecario"] = {"hora": "00:00", "hasta": "00:00"}
        m.VL = type("VL", (), {"library_report": staticmethod(lambda root, day: "")}); m.BIB.clear(); m.BIB["last"] = None
        r = m.c_bibliotecario()
        self.assertEqual(r["pending"], "Recomendaciones 2026-11-27"); self.assertEqual(r["pending_path"], "_agentes/Biblioteca/Recomendaciones 2026-11-27")
        (v / "_agentes/Biblioteca/Recomendaciones 2026-11-27.md").write_text("---\nrevisado: sí\n---\n")
        self.assertEqual(m.c_bibliotecario()["pending"], "Recomendaciones 2026-11-22")

    def test_respuesta_usa_el_resumen_no_la_cola(self):
        m = self.m
        con = "Arranco.\n│ +3. **Qué:** subdividir…\n│ -viejo\n╭─ write_file ─╮\n## Resumen\n12 recomendaciones; la primera: índice de archivo.\n"
        self.assertEqual(m.resumen_resultado(con), "## Resumen\n12 recomendaciones; la primera: índice de archivo.")
        sin = "Primer párrafo con lo hecho.\n\n│ +diff\n" + ("relleno largo. " * 400)
        r = m.resumen_resultado(sin)
        self.assertTrue(r.startswith("Primer párrafo")); self.assertNotIn("│ +", r); self.assertLessEqual(len(r), 4010)
        self.assertIn("| a | b |", m.resumen_resultado("| a | b |\n|---|---|\n| 1 | 2 |"), "las tablas Markdown se quedan")

class OrigenPost(Base):
    def test_post_de_otra_web_rechazado(self):
        m = self.m; m.CFG["token"] = "t"
        srv = m.ThreadingHTTPServer(("127.0.0.1", 0), m.H); th = threading.Thread(target=srv.serve_forever, daemon=True); th.start()
        self.addCleanup(srv.shutdown); port = srv.server_address[1]
        def post(path, **h):
            rq = urllib.request.Request("http://127.0.0.1:%d%s" % (port, path), data=b'{"from":"x","to":"y","text":"z","id":"r1"}', headers=h, method="POST")
            try: return urllib.request.urlopen(rq, timeout=5).status
            except urllib.error.HTTPError as e: return e.code
        self.assertEqual(post("/api/message", Origin="https://evil.example"), 403)
        self.assertEqual(post("/api/message", Host="evil.example:8787"), 403, "DNS rebinding")
        self.assertEqual(post("/api/message", Origin="http://127.0.0.1:%d" % port), 200)
        self.assertEqual(post("/api/message"), 200, "curl y vigías sin Origin siguen igual")
        self.assertEqual(post("/api/report", Origin="https://chatgpt.com"), 200, "los informes admiten otras páginas")

if __name__ == "__main__": unittest.main()
