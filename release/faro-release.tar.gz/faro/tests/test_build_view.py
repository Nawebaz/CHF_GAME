import importlib.util, os, pathlib, shutil, tempfile, unittest, datetime

# La obra de cada proyecto: la oficina recibe entregas de 7 días y de hoy, total sin tope y solo las 12 últimas
class BuildView(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR')); self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / 'faro.py'; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / 'faro.py', dst)
        spec = importlib.util.spec_from_file_location('faro_test_bv', dst); self.m = importlib.util.module_from_spec(spec); spec.loader.exec_module(self.m)
    def test_view(self):
        m = self.m; t = m.now(); iso = m.iso
        log = [{"at": iso(t - datetime.timedelta(days=d)), "why": "x"} for d in (10, 8, 6, 3, 0.5, 0.1)] + [{"at": "roto", "why": "y"}]
        m.STATE["build"] = {"gta": {"floors": 40, "log": log, "last": iso(t)}, "vacio": {"floors": 1, "log": []}}
        v = m.build_view()
        self.assertEqual(v["gta"]["w7"], 4); self.assertEqual(v["gta"]["d1"], 2); self.assertEqual(v["gta"]["total"], 40)
        self.assertEqual(v["vacio"]["w7"], 0); self.assertLessEqual(len(v["gta"]["log"]), 12)
    def test_total_grows_past_cap(self):
        m = self.m; m.STATE["build"] = {"gta": {"floors": 40, "log": []}}; m.save_state = lambda: None
        m.build_add("gta", "entrega"); b = m.STATE["build"]["gta"]
        self.assertEqual(b["floors"], 40); self.assertEqual(b["total"], 41)

if __name__ == '__main__': unittest.main()
