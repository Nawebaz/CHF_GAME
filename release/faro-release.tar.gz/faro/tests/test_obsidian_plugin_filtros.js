// El plugin de Obsidian también manda los filtros de la vista gráfica (y los manda solos si el grafo está cerrado)
const Module = require("module"), path = require("path"), assert = require("assert");
const sent = [];
const fake = { Plugin: class { constructor() { this.app = null; } async loadData() { return {}; } async saveData() {} addSettingTab() {} addCommand() {} registerInterval() {} },
  PluginSettingTab: class { constructor() {} }, Setting: class {}, requestUrl: async o => { sent.push(o); return { status: 200 }; } };
const orig = Module._load; Module._load = function (r, ...a) { return r === "obsidian" ? fake : orig.call(this, r, ...a); };
global.window = { setInterval: () => 0 };
const P = require(path.join(__dirname, "..", "extras", "obsidian-faro-grafo", "main.js"));
(async () => {
  const nodes = [{ id: "a/Uno.md", x: 10, y: -20 }, { id: "#radar", x: 300, y: 5 }];
  let vivo = { showAttachments: true, showTags: true, showOrphans: true, hideUnresolved: true, search: "", scale: 1.3 };
  let archivo = JSON.stringify({ showAttachments: false, showTags: true, showOrphans: true, hideUnresolved: true, search: "", repelStrength: 8 });
  let hojas = [{ view: { renderer: { nodes }, dataEngine: { getOptions: () => vivo } } }];
  const p = new P(); p.app = { workspace: { getLeavesOfType: () => hojas }, vault: { configDir: ".obsidian", adapter: { exists: async f => f === ".obsidian/graph.json", read: async () => archivo } } };
  await p.onload();
  await p.tic(false); let b = JSON.parse(sent[0].body);
  assert.strictEqual(b.nodes.length, 2); assert.deepStrictEqual(b.opts, { showAttachments: true, showTags: true, showOrphans: true, hideUnresolved: true, search: "" }, "filtros de la vista abierta, sin lo que no son filtros");
  await p.tic(false); assert.strictEqual(sent.length, 1, "nada cambia: no reenvía");
  vivo = { ...vivo, showAttachments: false }; await p.tic(false); assert.strictEqual(sent.length, 2); b = JSON.parse(sent[1].body);
  assert.ok(!b.nodes, "solo cambian los filtros: no manda los puntos"); assert.strictEqual(b.opts.showAttachments, false);
  hojas = []; archivo = JSON.stringify({ showAttachments: true, hideUnresolved: false }); await p.tic(false); assert.strictEqual(sent.length, 3);
  b = JSON.parse(sent[2].body); assert.deepStrictEqual(b, { opts: { showAttachments: true, hideUnresolved: false } }, "grafo cerrado: los filtros del archivo");
  console.log("ok");
})().catch(e => { console.error(e); process.exit(1); });
