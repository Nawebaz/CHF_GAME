import os, sys, tempfile, time, unittest, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "tools"))
import vault_links as VL

class Semantica(unittest.TestCase):
    def test_mencion_ficha_agente_y_vuelta(self):
        d = tempfile.mkdtemp(); old = time.time() - 600
        files = {"00 Inicio.md": "[[_agentes/Índice de tareas]] [[10 Proyectos/Faro]]", "_agentes/Índice de tareas.md": "# T", "10 Proyectos/Faro.md": "# Faro",
                 "10 Proyectos/CHF.md": "# CHF", "20 Áreas/Agentes/Hermes.md": "---\naliases: [Hermes Agent]\n---\n# Hermes",
                 "20 Áreas/Expertos/Voz y audio.md": "# Voz",
                 "_agentes/archivo/2026-11-15 1000 claude→faro prueba.md": "---\nfrom: claude\nto: hermes\nproyecto: chf\n---\nRevisa la voz y audio del jefe en Faro.",
                 "70 Privado/X.md": "Hermes CHF"}
        for rel, t in files.items():
            p = os.path.join(d, rel); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(t); os.utime(p, (old, old))
        VL.review(d, apply=True)
        enc = open(os.path.join(d, "_agentes/archivo/2026-11-15 1000 claude→faro prueba.md")).read()
        self.assertIn("[[10 Proyectos/CHF|CHF]]", enc)                    # ficha
        self.assertIn("[[20 Áreas/Expertos/Voz y audio|Voz y audio]]", enc)  # mención
        self.assertIn("[[20 Áreas/Agentes/Hermes|Hermes]]", enc)           # destino de la cabecera
        self.assertNotIn("[[10 Proyectos/Faro|Faro]]", enc)                # Faro solo si no hay otro proyecto
        self.assertIn("faro:auto:historial", open(os.path.join(d, "20 Áreas/Agentes/Hermes.md")).read())
        self.assertIn("faro:auto:actividad", open(os.path.join(d, "10 Proyectos/CHF.md")).read())
        self.assertEqual(open(os.path.join(d, "70 Privado/X.md")).read(), "Hermes CHF")   # lo privado no se toca

if __name__ == "__main__": unittest.main()
