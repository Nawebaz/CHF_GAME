"""Faro no cuenta como enlace lo que va en código (igual que Obsidian): el JS pegado en una orden de CHF
con [[0,1,50,45]] no puede crear puntos falsos en la galaxia."""
import os, sys, tempfile, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import faro

class EnlacesEnCodigo(unittest.TestCase):
    def test_codigo_no_enlaza(self):
        with tempfile.TemporaryDirectory() as d:
            txt = ("---\ntags: [chf]\n---\nVer [[10 Proyectos/CHF|CHF]] y [[Faro]].\n\n"
                   "```js\nconst r = [[0,1,50,45]];\n```\n~~~\nm = [[2,3]]\n~~~\nEn línea `[[0,1,50,45]]` tampoco.\n")
            open(os.path.join(d, "Orden.md"), "w", encoding="utf-8").write(txt)
            faro.LINKS_CACHE.clear()
            ln, tags = faro._note_scan(d, "Orden")
            self.assertEqual(sorted(ln), ["10 Proyectos/CHF", "Faro"])

if __name__ == "__main__":
    unittest.main()
