import os, sys, tempfile, time, unittest, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "tools"))
import vault_links as VL

class VaultLinks(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.TemporaryDirectory(); self.addCleanup(self.d.cleanup); self.r = self.d.name
        for rel, t in {"00 Inicio.md": "[[Faro]] [[_agentes/Índice de tareas]]", "10 Proyectos/Faro.md": "# Faro\nmano", "_agentes/Índice de tareas.md": "# T",
                       "_agentes/inbox/hermes/x.md": "enc", "_agentes/outbox/x · RESPUESTA.md": "resp", "Faro/Órdenes/o.md": "orden",
                       "_agentes/outbox/x · RESPUESTA.sync-conflict-1.md": "c", "10 Proyectos/Nueva.md": "[[Falta]]"}.items():
            p = os.path.join(self.r, rel); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(t)
            os.utime(p, (time.time() - 600,) * 2)
    def test_fixes_and_reports(self):
        r = VL.review(self.r, apply=True)
        self.assertEqual(r["orphans"], []); self.assertEqual(r["broken"], [("10 Proyectos/Nueva.md", "Falta")])
        self.assertTrue(os.path.exists(os.path.join(self.r, "_to_delete", "x · RESPUESTA.sync-conflict-1.md")))
        faro = open(os.path.join(self.r, "10 Proyectos/Faro.md")).read()
        self.assertIn("mano", faro); self.assertIn("[[Faro/Órdenes/o|o]]", faro)
        self.assertIn("[[_agentes/inbox/hermes/x|encargo]]", open(os.path.join(self.r, "_agentes/outbox/x · RESPUESTA.md")).read())
    def test_idempotent(self):
        VL.review(self.r, apply=True)
        for dp, _, fns in os.walk(self.r):
            for f in fns: os.utime(os.path.join(dp, f), (time.time() - 600,) * 2)
        self.assertEqual(VL.review(self.r, apply=True)["changed"], [])
    def test_fresh_note_untouched(self):
        p = os.path.join(self.r, "10 Proyectos/Faro.md"); os.utime(p, None)
        r = VL.review(self.r, apply=True)
        self.assertIn("10 Proyectos/Faro.md", r["skipped"]); self.assertEqual(open(p).read(), "# Faro\nmano")

    def test_order_linked_to_project(self):
        os.makedirs(os.path.join(self.r, "10 Proyectos"), exist_ok=True)
        p = os.path.join(self.r, "10 Proyectos/CHF.md"); open(p, "w").write("# CHF"); os.utime(p, (time.time() - 600,) * 2)
        o = os.path.join(self.r, "Faro/Órdenes/o.md"); open(o, "w").write("# o\n- Proyecto: chf\n"); os.utime(o, (time.time() - 600,) * 2)
        VL.review(self.r, apply=True)
        self.assertIn("[[10 Proyectos/CHF|CHF]]", open(o).read())
if __name__ == "__main__": unittest.main()
