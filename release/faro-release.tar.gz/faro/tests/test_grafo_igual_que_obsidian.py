"""Con la vista gráfica de Obsidian a mano, la oficina pinta exactamente lo que pinta Obsidian: ni un punto más
(lo que Obsidian no enseña no sale) ni de menos por los topes; lo recién creado sale aunque Obsidian aún no lo haya pintado."""
import os, sys, tempfile, time, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import faro

class IgualQueObsidian(unittest.TestCase):
    def test_solo_lo_de_obsidian(self):
        with tempfile.TemporaryDirectory() as d:
            for n, txt in (("A", "[[B]] #chf"), ("B", "[[C]]"), ("C", "x"), ("D", "[[A]]")):
                open(os.path.join(d, n + ".md"), "w", encoding="utf-8").write(txt)
            old = time.time() - 3600
            for n in "ABCD": os.utime(os.path.join(d, n + ".md"), (old, old))
            faro.LINKS_CACHE.clear(); faro.NOTE_BORN.clear()
            faro.OBS_LAYOUT.update(at=time.time(), pos={"A": (0, 0), "B": (10, 0), "C": (0, 10), "#chf": (5, 5)})
            notes = [(old, n) for n in "ABCD"]
            g = faro.vault_graph(d, notes, opts={"att": False, "tags": True, "orph": True, "unres": False, "q": "", "src": "plugin", "at": 0})
            ids = sorted(n["id"] for n in g["nodes"])
            self.assertEqual(ids, ["#chf", "A", "B", "C"])                 # D no está en Obsidian: no sale
            self.assertEqual(g["diff"]["extra"], 1); self.assertEqual(g["diff"]["ex"], ["D"])
            open(os.path.join(d, "E.md"), "w").write("nueva")              # recién creada: sale aunque Obsidian aún no la tenga
            g = faro.vault_graph(d, notes + [(time.time(), "E")], opts={"att": False, "tags": True, "orph": True, "unres": False, "q": "", "src": "plugin", "at": 0})
            self.assertIn("E", [n["id"] for n in g["nodes"]])
            faro.OBS_LAYOUT.update(at=0.0, pos={})

if __name__ == "__main__":
    unittest.main()
