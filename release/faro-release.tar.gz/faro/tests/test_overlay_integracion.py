"""Regresiones de la capa local incorporada a la candidata firmable."""
import threading
import unittest

from test_auditoria_servidor import Base


class CapaLocal(Base):
    def test_grafo_y_eventos_privados_salen_opacos_sin_mutar_cache(self):
        m = self.m
        private = "70 Privado/Nota sensible.md"
        graph = {"nodes": [{"id": private, "t": "Nota sensible"}],
                 "edges": [[private, "Público"]], "orphans": [private]}
        m.CACHE["vault"] = {"graph": graph}
        m.VLIVE.update({"seq": 1, "gv": 2, "mode": "test", "ev": [{"s": 1, "t": 0, "p": private}]})
        result = m.vault_live(0, 0)
        opaque = m._priv_id(private)
        self.assertEqual(result["ev"][0]["p"], opaque)
        self.assertEqual(result["graph"]["nodes"][0], {"id": opaque, "t": ""})
        self.assertEqual(result["graph"]["edges"][0][0], opaque)
        self.assertEqual(result["graph"]["orphans"], [opaque])
        self.assertEqual(graph["nodes"][0]["id"], private)
        self.assertEqual(m._priv_id("Público"), "Público")

    def test_cierre_con_id_distinto_cierra_original_sin_perder_informe_parcial(self):
        m = self.m
        m.report({"id": "tarea", "kind": "run", "name": "Hermes · prueba", "state": "run", "pct": 45})
        m.report({"id": "tarea-cierre", "state": "ok"})
        self.assertEqual(m.REPORTS["tarea"]["state"], "ok")
        self.assertEqual(m.REPORTS["tarea"]["closed_by"], "tarea-cierre")
        self.assertEqual(m.REPORTS["tarea"]["pct"], 45)
        self.assertEqual(m.REPORTS["tarea-cierre"]["state"], "ok")

    def test_news_no_bloquea_otros_recolectores(self):
        m = self.m
        gate = threading.Event()
        entered = threading.Event()
        self.addCleanup(gate.set)
        def slow():
            entered.set()
            gate.wait(3)
            return {"done": True}
        m.COLLECTORS.clear()
        m.COLLECTORS.update({"news": {"fn": slow, "last": 0, "every": 10},
                             "fast": {"fn": lambda: {"done": True}, "last": 0, "every": 10}})
        m.run_collectors()
        self.assertTrue(entered.wait(1))
        self.assertEqual(m.CACHE["fast"], {"done": True})
        self.assertTrue(m.COLLECTORS["news"]["running"])
        gate.set()
        for _ in range(100):
            if not m.COLLECTORS["news"]["running"]: break
            threading.Event().wait(.01)
        self.assertEqual(m.CACHE["news"], {"done": True})
        self.assertFalse(m.COLLECTORS["news"]["running"])


if __name__ == "__main__":
    unittest.main()
