import importlib.util, os, pathlib, shutil, tempfile, unittest
class GraphTable(unittest.TestCase):
    def test_table_alias_and_accents(self):
        d = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, d)
        os.makedirs(os.path.join(d, "20 Áreas"))
        open(os.path.join(d, "A.md"), "w").write("| x |\n|---|\n| [[20 Áreas/Conectores\\|Conectores]] |\n")
        open(os.path.join(d, "20 Áreas", "Conectores.md"), "w").write("c")
        dst = pathlib.Path(d) / "faro.py"; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / "faro.py", dst)
        spec = importlib.util.spec_from_file_location("fg", dst); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        notes = [(1.0, "A"), (1.0, "20 Áreas/Conectores")]
        g = m.vault_graph(d, notes)
        self.assertTrue(g.get("edges") or g.get("links"), g)
if __name__ == "__main__": unittest.main()
