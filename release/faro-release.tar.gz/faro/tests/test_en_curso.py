"""«En curso» (auditoría 27-nov): Faro escribe en la bóveda quién trabaja en qué, solo cuando cambia, para que los agentes no dupliquen trabajo."""
import datetime as dt, importlib.util, pathlib, shutil, tempfile, unittest

HERE = pathlib.Path(__file__).resolve()

class EnCurso(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="faro-encurso-"); self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / "faro.py"; shutil.copy(HERE.parents[1] / "faro.py", dst)
        spec = importlib.util.spec_from_file_location("faro_ec", dst); m = self.m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        self.v = pathlib.Path(self.tmp.name) / "boveda"; (self.v / "_agentes").mkdir(parents=True)
        m.CFG = {"vault": {"path": str(self.v)}}; m.EN_CURSO.update(sig=None, at=0.0, pend=False)
        self.f = self.v / "_agentes" / "En curso.md"
    def ago(self, s): return self.m.iso(self.m.now() - dt.timedelta(seconds=s))
    def st(self, pct="745/1999"):
        return {"agents": [
            {"id": "claude-auditoria-faro", "name": "Claude · Auditoría Faro y nave", "state": "run", "project": "faro", "task": "Auditoría", "at": self.ago(30)},
            {"id": "claude-auditoria", "name": "Claude · Auditoría Faro y bibliotecario", "state": "run", "project": "faro", "task": "Auditoría", "at": self.ago(60)},
            {"id": "viejo", "name": "Codex · algo", "state": "run", "project": "x", "task": "y", "at": self.ago(3 * 3600)},
            {"id": "hecho", "name": "Hermes · radar", "state": "ok", "project": "agentes", "task": "z", "at": self.ago(10)}],
            "running": [{"id": "hermes-mimo-gpu", "name": "Hermes · Mimo GPU", "state": "run", "project": "mimo", "task": pct + " fichas", "at": self.ago(5)}]}
    def test_escribe_solo_lo_vivo(self):
        self.assertTrue(self.m.write_en_curso(self.st()))
        t = self.f.read_text(encoding="utf-8")
        self.assertIn("autor: faro", t); self.assertIn("| Claude · Auditoría Faro y nave | faro | Auditoría |", t)
        self.assertIn("Claude · Auditoría Faro y bibliotecario", t)   # se ven las dos auditorías: la duplicación salta a la vista
        self.assertIn("Hermes · Mimo GPU", t)
        self.assertNotIn("Codex · algo", t); self.assertNotIn("Hermes · radar", t)
    def test_no_reescribe_por_cifras_de_avance(self):
        self.m.write_en_curso(self.st("745/1999")); self.m.EN_CURSO["at"] = 0
        self.assertFalse(self.m.write_en_curso(self.st("900/1999")))
    def test_limita_frecuencia_y_luego_escribe(self):
        self.m.write_en_curso(self.st()); s = self.st(); s["agents"].pop(1)
        self.assertFalse(self.m.write_en_curso(s)); self.assertTrue(self.m.EN_CURSO["pend"])
        self.m.EN_CURSO["at"] -= self.m.EN_CURSO_MIN_S + 1
        self.assertTrue(self.m.write_en_curso(s)); self.assertNotIn("bibliotecario", self.f.read_text(encoding="utf-8"))
    def test_sin_boveda_no_hace_nada(self):
        self.m.CFG = {}; self.assertFalse(self.m.write_en_curso(self.st()))

if __name__ == "__main__": unittest.main()
