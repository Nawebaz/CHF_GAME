import importlib.util, os, pathlib, shutil, tempfile, unittest

# Con el dibujo que manda Obsidian, cada nodo va donde está allí; si no cubre la bóveda, Faro usa el suyo
class ObsLayout(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='faro-test-', dir=os.environ.get('TMPDIR')); self.addCleanup(self.tmp.cleanup)
        dst = pathlib.Path(self.tmp.name) / 'faro.py'; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / 'faro.py', dst)
        spec = importlib.util.spec_from_file_location('faro_test_ol', dst); self.m = importlib.util.module_from_spec(spec); spec.loader.exec_module(self.m)
        self.v = pathlib.Path(self.tmp.name) / 'v'; (self.v / 'a').mkdir(parents=True)
        (self.v / 'a' / 'Uno.md').write_text('[[Dos]] [[Tres]] #Radar\n', encoding='utf-8'); (self.v / 'a' / 'Dos.md').write_text('[[Uno]]\n', encoding='utf-8')
        (self.v / 'Tres.md').write_text('x\n', encoding='utf-8'); (self.v / 'Sola.md').write_text('x\n', encoding='utf-8')
        self.notes = [(1.0, 'a/Uno'), (1.0, 'a/Dos'), (1.0, 'Tres'), (1.0, 'Sola')]
    def test_uses_obsidian_positions(self):
        m = self.m; g0 = m.vault_graph(str(self.v), self.notes, atts=[]); self.assertEqual(g0['src'], 'faro')
        r = m.obs_layout_set({"nodes": [["a/Uno.md", 0, 0], ["a/Dos.md", 100, 0], ["#Radar", 0, 100], ["Sola.md", -400, 0], ["x", "malo", 1]]}); self.assertTrue(r["ok"]); self.assertEqual(r["n"], 4)
        g = m.vault_graph(str(self.v), self.notes, atts=[]); N = {n['id']: n for n in g['nodes']}; self.assertEqual(g['src'], 'obsidian')
        self.assertGreater(N['a/Dos']['x'], N['a/Uno']['x']); self.assertAlmostEqual(N['a/Dos']['y'], N['a/Uno']['y'], places=3)
        self.assertGreater(N['#radar']['y'], N['a/Uno']['y']); self.assertLess(N['Sola']['x'], N['a/Uno']['x'])
        for n in g['nodes']: self.assertTrue(0 <= n['x'] <= 1 and 0 <= n['y'] <= 1)
        self.assertLess(abs(N['Tres']['x'] - N['a/Uno']['x']), .03)   # Obsidian no la mandó: junto a su vecina
        self.assertTrue(0 < g['rc'] < .5)
    def test_ignores_foreign_layout(self):
        m = self.m; m.obs_layout_set({"nodes": [["otra/A.md", 0, 0], ["otra/B.md", 5, 5], ["otra/C.md", 9, 1]]})
        self.assertEqual(m.vault_graph(str(self.v), self.notes, atts=[])['src'], 'faro')
        self.assertFalse(m.obs_layout_set({"nodes": []})["ok"])

if __name__ == '__main__': unittest.main()
