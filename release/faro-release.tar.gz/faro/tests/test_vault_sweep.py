import importlib.util, os, pathlib, shutil, tempfile, time, unittest
class Sweep(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, self.d)
        dst = pathlib.Path(self.d) / "faro.py"; shutil.copy(pathlib.Path(__file__).resolve().parents[1] / "faro.py", dst)
        shutil.copytree(pathlib.Path(__file__).resolve().parents[1] / "tools", pathlib.Path(self.d) / "tools")
        spec = importlib.util.spec_from_file_location("fs", dst); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        self.m = m; self.v = os.path.join(self.d, "boveda"); os.makedirs(self.v)
        m.CFG = {"vault": {"path": self.v, "write": True}, "sources": {}, "projects": [], "executors": {}}
        m.VLIVE["mode"] = "inotify"; m.build_status = lambda: None; m.c_vault = lambda: None
    def test_missed_write_shows_once(self):
        p = os.path.join(self.v, "A.md"); open(p, "w").write("a")
        self.m.c_vault_sweep()                       # primera foto
        time.sleep(1.1); open(p, "w").write("b")     # inotify «se lo pierde»
        self.m.c_vault_sweep()
        ev = [e for e in self.m.VLIVE["ev"] if e["p"] == "A"]
        self.assertEqual([(e["k"], e["via"]) for e in ev], [("write", "sondeo")])
        self.m.c_vault_sweep(); self.assertEqual(len([e for e in self.m.VLIVE["ev"] if e["p"] == "A"]), 1)
    def test_seen_by_inotify_not_repeated(self):
        p = os.path.join(self.v, "B.md"); open(p, "w").write("a"); self.m.c_vault_sweep()
        time.sleep(1.1); open(p, "w").write("b"); self.m.vault_event("B", "write")
        self.m.c_vault_sweep()
        self.assertEqual(len([e for e in self.m.VLIVE["ev"] if e["p"] == "B"]), 1)
    def test_write_kicks_link_review(self):
        self.m.COLLECTORS["vault_links"]["last"] = time.time()
        self.m.vault_event("C", "write", who="Hermes")
        self.assertEqual(self.m.COLLECTORS["vault_links"]["last"], 0)
if __name__ == "__main__": unittest.main()
