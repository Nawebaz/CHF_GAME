"""Revisión de conexiones de la bóveda de Obsidian (Faro).

Detecta huérfanas, enlaces rotos, duplicados y encargos viejos; arregla solo lo seguro:
- une encargo ↔ respuesta (notas de _agentes),
- mantiene bloques automáticos en las notas índice (entre marcadores, sin tocar lo escrito a mano),
- aparta las copias de conflicto de Syncthing a _to_delete/.
Nunca borra, nunca toca una nota editada hace menos de 90 s y nunca reescribe texto fuera de sus bloques.
Uso suelto:  python3 vault_links.py RUTA_BOVEDA [--apply]
"""
import hashlib, os, re, shutil, sys, time, unicodedata

NFC = lambda s: unicodedata.normalize("NFC", s)
KEY = lambda s: NFC(s).strip().lower()
LINK = re.compile(r"!?\[\[([^\]|#^]+)(?:#[^\]|]*)?(?:\|[^\]]*)?\]\]")
CODE = re.compile(r"```.*?```|`[^`\n]*`", re.S)
RESP = " · RESPUESTA"
FRESH = 90
SKIP_DIRS = {".obsidian", ".trash", ".git", "_to_delete"}
# Notas que pueden quedar solas a propósito
LONE_OK = re.compile(r"(^|/)(prueba-[^/]*|Bienvenido|LEEME)\.md$|^99 Plantillas/|^01 Bandeja/|^_adjuntos/")
AUTO_A, AUTO_B = "<!-- faro:auto:%s -->", "<!-- /faro:auto:%s -->"

def scan(root):
    notes = {}
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in SKIP_DIRS and not d.startswith(".")]
        for fn in fns:
            if not fn.endswith(".md"): continue
            fp = os.path.join(dp, fn); rel = NFC(os.path.relpath(fp, root)).replace(os.sep, "/")
            try:
                with open(fp, encoding="utf-8", errors="replace") as f: txt = f.read()
                notes[rel] = {"fp": fp, "txt": txt, "mtime": os.path.getmtime(fp)}
            except OSError: pass
    return notes

def aliases(txt):
    m = re.match(r"---\n(.*?)\n---", txt, re.S)
    if not m: return []
    a = re.search(r"^aliases:\s*\[(.*?)\]", m.group(1), re.M)
    return [x.strip(" '\"") for x in a.group(1).split(",")] if a else []

def graph(notes, root=None):
    idx, base_count, basenames = {}, {}, {}
    for rel, n in notes.items():
        b = KEY(os.path.basename(rel)[:-3]); base_count[b] = base_count.get(b, 0) + 1
        basenames.setdefault(b, []).append(rel); idx[KEY(rel[:-3])] = rel
        for a in aliases(n["txt"]): idx.setdefault(KEY(a), rel)
    for b, matches in basenames.items():
        if len(matches) == 1: idx.setdefault(b, matches[0])
    attachments = set()
    if root:
        for dp, dns, fns in os.walk(root):
            dns[:] = [d for d in dns if d not in SKIP_DIRS and not d.startswith(".")]
            for fn in fns:
                attachments.add(KEY(os.path.relpath(os.path.join(dp, fn), root).replace(os.sep, "/")))
    out = {r: set() for r in notes}; inc = {r: set() for r in notes}; broken = []
    for rel, n in notes.items():
        for t in LINK.findall(CODE.sub("", n["txt"])):
            t = t.strip().rstrip("\\").strip()  # en tablas el alias va con \|
            if not t: continue
            path = t.lstrip("/")
            # Una ruta explícita no debe resolverse por homónimo en otra carpeta.
            q = idx.get(KEY(path[:-3] if path.lower().endswith(".md") else path))
            if q is None and root and KEY(path) in attachments: continue
            here = os.path.dirname(rel)   # capa-nave: rutas relativas a la carpeta de la nota (adjuntos y notas vecinas)
            if q is None and here:
                relp = here + "/" + path
                if root and KEY(relp) in attachments: continue
                q = idx.get(KEY(relp[:-3] if relp.lower().endswith(".md") else relp))
            if q is None and path.lower().endswith(".md"):
                q = idx.get(KEY(path.rsplit("/", 1)[-1][:-3]))
            if q is None and not re.search(r"\.[A-Za-z0-9]{1,5}$", path):   # capa-nave: «v2.61 …» o «(gta.py) …» no son extensiones
                q = idx.get(KEY(path.rsplit("/", 1)[-1]))
            if q is None and "/" not in path and root:
                matches = [a for a in attachments if a.rsplit("/", 1)[-1] == KEY(path)]
                if len(matches) == 1: continue
            if q is None and not root and re.search(r"\.(png|jpe?g|webp|gif|pdf|mp4|mov|svg)$", t, re.I): continue
            if q is None:
                if not rel.startswith("01 Bandeja/"): broken.append((rel, t))
            elif q != rel: out[rel].add(q); inc[q].add(rel)
    ambiguous = sorted(b for b, c in base_count.items() if c > 1)
    return out, inc, broken, ambiguous

def wikilink(rel, alias=None):
    t = rel[:-3]
    return "[[%s|%s]]" % (t, alias) if alias else "[[%s]]" % t

def title(rel):
    return os.path.basename(rel)[:-3]

def set_block(txt, name, lines, heading):
    a, b = AUTO_A % name, AUTO_B % name
    block = "%s\n%s\n%s" % (a, "\n".join(lines) if lines else "- (nada)", b)
    if a in txt and b in txt:
        return re.sub(re.escape(a) + r".*?" + re.escape(b), lambda m: block, txt, flags=re.S)
    return txt.rstrip() + "\n\n## %s\n%s\n" % (heading, block)

class Writer:
    def __init__(self, notes, apply, hook=None):
        self.notes, self.apply, self.changed, self.skipped, self.hook = notes, apply, [], [], hook
    def write(self, rel, new):
        n = self.notes[rel]
        if new == n["txt"]: return False
        if time.time() - n["mtime"] < FRESH and rel not in self.changed: self.skipped.append(rel); return False   # lo que escribe esta pasada no cuenta como edición de otro
        if self.apply:
            if self.hook: self.hook(n["fp"])  # avisa antes de escribir: el vigía lo atribuye a quien llama
            with open(n["fp"], "w", encoding="utf-8") as f: f.write(new)
            n["txt"], n["mtime"] = new, time.time()
        self.changed.append(rel); return True

def related(txt, links):
    new = [l for l in links if l.split("|")[0].rstrip("]") not in txt]
    if not new: return txt
    if "\n## Relacionado\n" in txt: return txt.rstrip() + "\n" + "\n".join("- " + l for l in new) + "\n"
    return txt.rstrip() + "\n\n## Relacionado\n" + "\n".join("- " + l for l in new) + "\n"

FICHA_DESDE = 1794734400   # 15 nov 2026 10:20 (Madrid): desde aquí, toda nota de agentes lleva ficha
AGENTES = ("claude", "hermes", "codex", "chatgpt", "strata", "faro", "nawe")

def ficha_de(txt):
    m = re.match(r"---\n(.*?)\n---\n?", txt, re.S); fm = m.group(1) if m else ""
    get = lambda k: (re.search(r"^%s:\s*(.*)$" % k, fm, re.M | re.I) or [None, ""])[1].strip()
    return m, fm, {k: get(k) for k in ("autor", "proyecto", "experto", "decision")}

def con_ficha(txt, add):
    """Añade a la cabecera los campos que faltan (sin tocar los que hay); si no hay cabecera, la crea."""
    m, fm, _ = ficha_de(txt); extra = "\n".join("%s: %s" % kv for kv in add.items())
    return ("---\n" + fm.rstrip("\n") + "\n" + extra + "\n---\n" + txt[m.end():]) if m else ("---\n" + extra + "\n---\n" + txt)

def review(root, apply=False, extra_blocks=None, hook=None):
    notes = scan(root); W = Writer(notes, apply, hook); moved = []
    # 1) copias de conflicto de Syncthing → _to_delete (nunca se borran)
    for rel in [r for r in notes if ".sync-conflict-" in r]:
        if apply:
            if hook: hook(notes[rel]["fp"])
            dst = os.path.join(root, "_to_delete"); os.makedirs(dst, exist_ok=True)
            shutil.move(notes[rel]["fp"], os.path.join(dst, os.path.basename(notes[rel]["fp"])))
        moved.append(rel); notes.pop(rel)
    # 2) encargo ↔ respuesta
    by_title = {}
    for rel in notes: by_title.setdefault(KEY(title(rel)), []).append(rel)
    for rel in list(notes):
        if not rel.startswith("_agentes/") or RESP not in title(rel): continue
        for enc in by_title.get(KEY(title(rel).replace(RESP, "")), []):
            if not enc.startswith("_agentes/"): continue
            W.write(rel, related(notes[rel]["txt"], [wikilink(enc, "encargo")]))
            W.write(enc, related(notes[enc]["txt"], [wikilink(rel, "respuesta")]))
    def find(rel):   # una ruta conocida o, si se movió, la nota con el mismo nombre
        if not rel: return None
        if rel in notes: return rel
        hit = by_title.get(KEY(title(rel))); return hit[0] if hit else None
    # 2b) cada orden de Faro, enlazada con su proyecto (si no, queda colgando solo del índice de Faro)
    PROJ = {"chf": "10 Proyectos/CHF.md", "gta": "10 Proyectos/GTA VI.md", "ingresos": "10 Proyectos/Campaña de ingresos.md",
            "trading": "10 Proyectos/Laboratorio trading.md", "agentes": "20 Áreas/Sistema/Sistema y máquinas.md", "faro": "10 Proyectos/Faro.md"}
    for rel in list(notes):
        if not rel.startswith("Faro/Órdenes/"): continue
        m = re.search(r"^- Proyecto:\s*([\w-]+)", notes[rel]["txt"], re.M)
        tgt = find(PROJ.get((m.group(1) if m else "").lower()))
        if tgt: W.write(rel, related(notes[rel]["txt"], [wikilink(tgt, title(tgt))]))
    # 2c) significado: cada nota de agentes o de Faro se enlaza con el proyecto, el experto y el agente de los que habla
    ents = []   # (nota, [nombres por los que se la reconoce])
    for rel in notes:
        if rel.startswith("10 Proyectos/") or (rel.startswith("20 Áreas/Expertos/") and title(rel) != "Expertos") or (rel.startswith("20 Áreas/Agentes/") and title(rel) != "Agentes"):
            names = [title(rel)] + [a for a in aliases(notes[rel]["txt"]) if len(a) >= 4]
            ents.append((rel, sorted({n for n in names if len(n) >= 3}, key=len, reverse=True)))
    pats = [(rel, re.compile(r"(?<![\w/])(" + "|".join(re.escape(n) for n in names) + r")(?![\w])", re.I)) for rel, names in ents]
    AG = {e[0].split("/")[-1][:-3].lower(): e[0] for e in ents if e[0].startswith("20 Áreas/Agentes/")}
    AG.update({"local": AG.get("strata"), "claude code": AG.get("claude")})
    def body(t):   # sin cabecera, sin código, sin enlaces ya puestos y sin la sección Relacionado
        t = re.sub(r"\A---\n.*?\n---\n", "", t, flags=re.S); t = CODE.sub(" ", t); t = t.split("\n## Relacionado\n")[0]
        return re.sub(r"\[\[[^\]]*\]\]", " ", t)
    hist = {}   # agente → encargos en los que aparece como origen, destino o quien lo hizo
    for rel in list(notes):
        if not (rel.startswith("_agentes/") or rel.startswith("Faro/")) or rel.startswith("70 Privado/"): continue
        if title(rel) in ("Índice de tareas", "README", "Cómo escribir en la bóveda") or rel.startswith("Faro/Conexiones"): continue
        txt = notes[rel]["txt"]; b = body(txt); links = []
        fm = re.match(r"---\n(.*?)\n---", txt, re.S); fm = fm.group(1) if fm else ""
        for key in ("proyecto", "project", "experto", "decision", "decisión"):   # ficha del encargo
            m = re.search(r"^%s:\s*(.+)$" % key, fm, re.M | re.I)
            if m:
                for v in re.split(r"[,;]", m.group(1)):
                    v = v.strip(" []\"'"); tgt = find(PROJ.get(v.lower())) or next((e for e, ns in ents if v.lower() in [n.lower() for n in ns]), None)
                    if tgt and tgt != rel: links.append(tgt)
        for tgt, rx in pats:
            if tgt != rel and rx.search(b): links.append(tgt)
        who = set()   # agentes: por el nombre del archivo (origen→destino) y por «## X · hecho» / «Hecha por: x»
        m = re.search(r"(\w[\w ]*?)→(\w+)", title(rel))
        if m: who.add(m.group(2).lower())   # quien hace el trabajo, no quien lo encarga
        for mm in re.finditer(r"^(?:to|para):\s*(\w+)", fm, re.M | re.I): who.add(mm.group(1).lower())   # destino de la cabecera
        who |= {w.lower() for w in re.findall(r"^## (\w+) · hecho", txt, re.M)} | {w.lower() for w in re.findall(r"^- Hecha por:\s*(\w+)", txt, re.M)}
        for w in who:
            if AG.get(w): links.append(AG[w]); hist.setdefault(AG[w], []).append(rel)
        proj = [l for l in links if l.startswith("10 Proyectos/")]
        if any(title(l) != "Faro" for l in proj): links = [l for l in links if title(l) != "Faro"]   # Faro solo si no hay otro proyecto
        seen, out = set(), []
        for l in links:
            if l not in seen and l != rel and l[:-3] not in txt: seen.add(l); out.append(l)
        if out: W.write(rel, related(notes[rel]["txt"], [wikilink(l, title(l)) for l in out[:8]]))
    for ag, rels in hist.items():   # cada agente, con su historial (más reciente primero)
        lines = ["- " + wikilink(r, title(r)) for r in sorted(set(rels), key=lambda r: title(r), reverse=True)[:30]]
        if ag in notes: W.write(ag, set_block(notes[ag]["txt"], "historial", lines, "Historial de encargos (automático)"))
    # 2e) ficha obligatoria (autor y proyecto) en lo que escriben los agentes desde FICHA_DESDE; lo deducible se rellena marcado
    unsigned = []
    PR_INV = {v: k for k, v in PROJ.items()}
    for rel in list(notes):
        if not (rel.startswith("_agentes/") or rel.startswith("Faro/Órdenes/")) or "/adjuntos/" in rel or title(rel) in ("Índice de tareas", "README", "Cómo escribir en la bóveda"): continue
        if notes[rel]["mtime"] < FICHA_DESDE: continue
        txt = notes[rel]["txt"]; _m, _fm, f = ficha_de(txt); add = {}
        if not f["autor"]:
            a = None
            if rel.startswith("Faro/Órdenes/"): a = "faro"
            elif RESP in title(rel):
                h = re.findall(r"^## (\w+) · hecho", txt, re.M); mm = re.search(r"→(\w+)", title(rel))
                a = (h[0] if h else (mm.group(1) if mm else "")).lower() or None
            else:
                mm = re.search(r"(\w+)→\w+", title(rel)); fr = re.search(r"^(?:from|de):\s*(\w+)", _fm, re.M | re.I)
                a = (fr.group(1) if fr else (mm.group(1) if mm else "")).lower() or None
            if a in AGENTES: add["autor"] = a + " (deducido)"
            else: unsigned.append(rel)
        if not f["proyecto"]:
            pl = [l for l in re.findall(r"\[\[(10 Proyectos/[^\]|]+)", txt)]
            # Un enlace sin equivalencia explícita no identifica un proyecto.
            key = next((PR_INV.get(l + ".md") for l in pl if PR_INV.get(l + ".md")), None)
            if key: add["proyecto"] = key + " (deducido)"
        if add: W.write(rel, con_ficha(txt, add))
    # 2d) camino de vuelta: cada proyecto y cada experto, con los encargos y entregas que le afectan (los más recientes primero)
    _o, _inc, _b, _a = graph(notes, root)
    for tgt, _names in ents:
        if tgt.startswith("20 Áreas/Agentes/"): continue   # los agentes ya llevan su historial
        src = [r for r in _inc.get(tgt, ()) if r.startswith(("_agentes/", "Faro/")) and not r.startswith("Faro/Conexiones") and title(r) not in ("Índice de tareas", "README")]
        if not src: continue
        src = sorted(set(src), key=lambda r: -notes[r]["mtime"])[:60]
        line = " · ".join(wikilink(r, title(r)[:48]) for r in src)
        W.write(tgt, set_block(notes[tgt]["txt"], "actividad", ["- " + line], "Encargos y entregas (automático)"))
    # 3) bloques automáticos en las notas índice
    hub = lambda *c: next((r for r in c if r in notes), None)
    faro, idx_t, inicio = hub("10 Proyectos/Faro.md"), hub("_agentes/Índice de tareas.md"), hub("00 Inicio.md")
    if faro:
        fl = sorted([r for r in notes if r.startswith("Faro/") and not title(r).startswith("Estado ")], key=lambda r: -notes[r]["mtime"])[:40]
        est = sorted([r for r in notes if r.startswith("Faro/Estado ")], reverse=True)[:7]
        lines = ["- " + wikilink(r, title(r)) for r in fl]
        if est: lines.append("- Partes diarios: " + " · ".join(wikilink(r, title(r).replace("Estado ", "")) for r in est))
        W.write(faro, set_block(notes[faro]["txt"], "faro", lines, "Órdenes, auditorías y partes (automático)"))
    if idx_t:
        txt = notes[idx_t]["txt"]; head = txt.split(AUTO_A % "agentes")[0]
        ag = sorted([r for r in notes if r.startswith("_agentes/") and r != idx_t and r != "_agentes/README.md"
                     and RESP not in title(r) and r[:-3] not in head], key=lambda r: -notes[r]["mtime"])[:40]
        lines = []
        for r in ag:
            resp = [x for x in by_title.get(KEY(title(r) + RESP), []) if x in notes]
            st = "respondido" if resp else ("pendiente" if "/inbox/" in r else "archivo")
            lines.append("- " + wikilink(r, title(r)) + (" · " + wikilink(resp[0], "respuesta") if resp else "") + " · " + st)
        W.write(idx_t, set_block(txt, "agentes", lines, "Movimientos del buzón (automático)"))
    for name, rel, lines, heading in (extra_blocks or []):
        if rel in notes: W.write(rel, set_block(notes[rel]["txt"], name, lines, heading))
    # 4) huérfanas de primer nivel (proyectos, áreas, recursos) → bloque en Inicio
    out, inc, broken, ambiguous = graph(notes, root)
    if inicio:
        top = [r for r in notes if re.match(r"(10 Proyectos|20 Áreas|30 Recursos)/[^/]+\.md$", r) and not (inc[r] - {inicio})]
        top = [r for r in top if r[:-3] not in notes[inicio]["txt"].split(AUTO_A % "inicio")[0] and title(r) not in notes[inicio]["txt"].split(AUTO_A % "inicio")[0]]
        W.write(inicio, set_block(notes[inicio]["txt"], "inicio", ["- " + wikilink(r, title(r)) for r in sorted(top)], "Sin colocar todavía (automático)"))
        out, inc, broken, ambiguous = graph(notes, root)
    # 5) diagnóstico final
    orphans = sorted(r for r in notes if not inc[r] and r != inicio and not LONE_OK.search(r) and not r.endswith("/Conexiones de la bóveda.md"))
    dup = {}
    for r, n in notes.items():
        body = re.sub(r"\s+", " ", re.sub(r"<!-- faro:auto.*?/faro:auto:\w+ -->", "", n["txt"], flags=re.S)).strip()
        if len(body) > 40: dup.setdefault(hashlib.sha1(body.encode()).hexdigest(), []).append(r)
    dups = [v for v in dup.values() if len(v) > 1]
    stale = []
    for r in notes:
        if "/inbox/" in r and any(x for x in by_title.get(KEY(title(r) + RESP), []) if "done" in notes.get(x, {}).get("txt", "")[:300]):
            if time.time() - notes[r]["mtime"] > 86400: stale.append(r)
    return {"notes": len(notes), "unsigned": sorted(unsigned), "orphans": orphans, "broken": sorted(set(broken)), "ambiguous": ambiguous,
            "duplicates": dups, "stale": sorted(stale), "conflicts_moved": moved,
            "changed": sorted(set(W.changed)), "skipped": sorted(set(W.skipped))}

def library_report(root, when, inbox_days=3, quiet_days=7):
    """Informe del bibliotecario: datos objetivos de la estructura para proponer la siguiente reorganización.
    No mira dentro de 70 Privado (solo cuenta sus notas). No cambia nada."""
    import difflib
    notes = scan(root); t = time.time(); priv = [r for r in notes if r.startswith("70 Privado/")]
    pub = {r: n for r, n in notes.items() if not r.startswith("70 Privado/")}
    out, inc, broken, ambiguous = graph(pub, root); deg = {r: len(out[r] | inc[r]) for r in pub}
    folders = {}
    for r in pub: folders.setdefault("/".join(r.split("/")[:-1]) or "(raíz)", []).append(r)
    body = lambda r: re.sub(r"\A---\n.*?\n---\n", "", pub[r]["txt"], flags=re.S).strip()
    L = ["---", "tipo: informe", "autor: faro", "proyecto: agentes", "experto: Bibliotecario", "---",
         "# Informe del bibliotecario · %s" % when, "", "Datos objetivos de la bóveda para la siguiente reorganización. Faro no cambia nada; las recomendaciones las escribe el [[20 Áreas/Expertos/Bibliotecario|Bibliotecario]].", "",
         "**%d notas** (%d en 70 Privado, sin leer) · **%d carpetas** · **%d enlaces**" % (len(notes), len(priv), len(folders), sum(deg.values()) // 2), ""]
    def sec(h, items):
        L.append("## %s (%d)" % (h, len(items))); L.extend(items[:25] if items else ["- Nada."]); L.append("")
    sec("Carpetas por tamaño", ["- `%s` · %d notas" % (f, len(v)) for f, v in sorted(folders.items(), key=lambda kv: -len(kv[1]))[:12]])
    sec("Carpetas de más de 40 notas sin subcarpetas (candidatas a dividir)", ["- `%s` · %d" % (f, len(v)) for f, v in folders.items() if len(v) > 40 and not any(g.startswith(f + "/") for g in folders)])
    sec("Notas centrales de más de 80 enlaces (candidatas a partir en notas por tema)", ["- %s · %d" % (wikilink(r, title(r)), d) for r, d in sorted(deg.items(), key=lambda kv: -kv[1]) if d > 80])
    sec("Notas casi vacías (menos de 120 caracteres)", ["- " + wikilink(r, title(r)) for r in pub if len(body(r)) < 120 and not r.startswith("99 Plantillas/")])
    sec("Notas grandes (más de 60 KB)", ["- %s · %d KB" % (wikilink(r, title(r)), len(pub[r]["txt"].encode()) // 1024) for r in pub if len(pub[r]["txt"].encode()) > 60000])
    ts = sorted(pub, key=title); sim = []
    for i, a in enumerate(ts):
        for b in ts[i + 1:i + 6]:
            if a.split("/")[0] != "_agentes" and difflib.SequenceMatcher(None, title(a).lower(), title(b).lower()).ratio() >= .9: sim.append("- %s ≈ %s" % (wikilink(a, title(a)), wikilink(b, title(b))))
    sec("Títulos casi iguales (posibles duplicados o fusiones)", sim)
    sec("Notas sueltas en la raíz de la bóveda", ["- " + wikilink(r, title(r)) for r in pub if "/" not in r and title(r) not in ("00 Inicio", "Diario de decisiones")])
    sec("Encargos en inbox de más de %d días" % inbox_days, ["- %s · %d días" % (wikilink(r, title(r)), (t - pub[r]["mtime"]) // 86400) for r in pub if "/inbox/" in r and t - pub[r]["mtime"] > inbox_days * 86400])
    sec("Proyectos sin tocar en %d días" % quiet_days, ["- %s · %d días" % (wikilink(r, title(r)), (t - pub[r]["mtime"]) // 86400) for r in pub if re.match(r"10 Proyectos/[^/]+$", r) and t - pub[r]["mtime"] > quiet_days * 86400])
    sec("Enlaces rotos", ["- %s → `%s`" % (wikilink(a, title(a)), b) for a, b in broken])
    L += ["", "[[Faro/Conexiones de la bóveda|Conexiones de la bóveda]] · [[10 Proyectos/Faro|Faro]]"]
    return "\n".join(L) + "\n"

def report_md(r, when):
    L = ["# Conexiones de la bóveda", "", "Revisión automática de Faro: %s. %d notas." % (when, r["notes"]), "",
         "Se arregla solo: encargo ↔ respuesta, bloques automáticos de los índices y copias de conflicto. Lo de abajo necesita criterio.", ""]
    def sec(h, items, fmt):
        L.append("## %s (%d)" % (h, len(items))); L.extend(fmt(x) for x in items) if items else L.append("- Nada."); L.append("")
    sec("Enlaces rotos", r["broken"], lambda x: "- %s → `%s`" % (wikilink(x[0], title(x[0])), x[1]))
    sec("Huérfanas", r["orphans"], lambda x: "- " + wikilink(x, title(x)))
    sec("Notas de agentes sin firma (no se pudo deducir el autor)", r.get("unsigned", []), lambda x: "- " + wikilink(x, title(x)))
    sec("Posibles duplicados (mismo texto)", r["duplicates"], lambda v: "- " + " = ".join(wikilink(x, title(x)) for x in v))
    sec("Mismo nombre en varias carpetas (enlace ambiguo)", r["ambiguous"], lambda x: "- " + x)
    sec("Encargos ya respondidos que siguen en inbox (>24 h)", r["stale"], lambda x: "- " + wikilink(x, title(x)))
    sec("Copias de conflicto apartadas a _to_delete", r["conflicts_moved"], lambda x: "- " + x)
    L += ["", "[[10 Proyectos/Faro|Faro]] · [[_agentes/Índice de tareas|Tareas de agentes]]"]
    return "\n".join(L) + "\n"

if __name__ == "__main__":
    root = sys.argv[1]; apply = "--apply" in sys.argv
    r = review(root, apply)
    for k in ("changed", "skipped", "conflicts_moved", "broken", "orphans", "duplicates", "ambiguous", "stale"):
        print("%s (%d):" % (k, len(r[k])), *(["  %s" % (x,) for x in r[k]] or ["  -"]), sep="\n")
    if apply:
        p = os.path.join(root, "Faro", "Conexiones de la bóveda.md"); os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f: f.write(report_md(r, time.strftime("%d/%m/%Y %H:%M")))
