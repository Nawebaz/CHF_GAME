#!/usr/bin/env python3
"""Recorta una hoja de sprites generada sobre fondo magenta (#FF00FF) en sprites sueltos con transparencia.

Uso:  python3 recortar-sprites.py hoja.png carpeta_salida [--nombre prueba-a] [--alto 96]
- Quita el magenta (con margen) y el «halo» rosa de los bordes (despill).
- Separa por filas (proyección horizontal) y, dentro de cada fila, por piezas (proyección vertical).
- Guarda fila<R>_<C>.png recortados con 2 px de margen y un manifest.json con tamaños, para que la oficina
  los escale todos igual. Alfa binaria: bordes limpios y baratos de pintar (el PC dibuja sin gráfica).
"""
import argparse, json, os
import numpy as np
from PIL import Image


def mascara(rgb):
    r, g, b = (rgb[..., i].astype(np.int32) for i in range(3))
    # magenta y sus variantes de compresión: rojo y azul altos, verde bajo
    fondo = (r > 150) & (b > 150) & (g < 110) & (np.abs(r - b) < 90)
    return ~fondo


def despill(rgb, alfa):
    out = rgb.copy().astype(np.int32)
    r, g, b = out[..., 0], out[..., 1], out[..., 2]
    tinte = np.minimum(r, b) - g                     # cuánto «rosa magenta» lleva el píxel
    borde = alfa & (tinte > 40)
    lim = g + 40
    out[..., 0] = np.where(borde, np.minimum(r, lim + (r - b).clip(0)), r)
    out[..., 2] = np.where(borde, np.minimum(b, lim + (b - r).clip(0)), b)
    return out.clip(0, 255).astype(np.uint8)


def tramos(v, minimo, hueco):
    """Tramos ocupados de un perfil 1D, uniendo huecos pequeños."""
    on = v > 0; res = []; i = 0; n = len(v)
    while i < n:
        if not on[i]: i += 1; continue
        j = i
        while j < n and (on[j] or (j + hueco < n and on[j:j + hueco].any())): j += 1
        if j - i >= minimo: res.append((i, j))
        i = j
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("hoja"); ap.add_argument("salida")
    ap.add_argument("--nombre", default="hoja"); ap.add_argument("--alto", type=int, default=0, help="alto final de cada sprite (0 = original)")
    a = ap.parse_args()
    img = Image.open(a.hoja).convert("RGB"); rgb = np.array(img)
    alfa = mascara(rgb)
    # limpiar motas sueltas
    try:
        from scipy import ndimage
        alfa = ndimage.binary_opening(alfa, iterations=1)
        lab, n = ndimage.label(alfa)
        if n:
            tam = ndimage.sum(alfa, lab, range(1, n + 1))
            alfa = np.isin(lab, [i + 1 for i, s in enumerate(tam) if s >= 60])
    except ImportError:
        pass
    rgb = despill(rgb, alfa)
    os.makedirs(a.salida, exist_ok=True)
    H, W = alfa.shape; man = {"hoja": os.path.basename(a.hoja), "nombre": a.nombre, "sprites": []}
    cajas = []
    try:   # piezas = manchas independientes (une lo que está a pocos píxeles: vapor, conos de luz, cordones)
        from scipy import ndimage
        lab, n = ndimage.label(ndimage.binary_dilation(alfa, iterations=max(3, W // 300)))
        for sl in ndimage.find_objects(lab):
            ys, xs = sl; sub = alfa[ys, xs]
            if sub.sum() < (W * H) / 4000: continue
            cajas.append((xs.start, ys.start, xs.stop, ys.stop))
    except ImportError:   # sin scipy: por filas y columnas
        for y0, y1 in tramos(alfa.sum(1), max(8, H // 60), max(4, H // 120)):
            for x0, x1 in tramos(alfa[y0:y1].sum(0), max(8, W // 80), max(3, W // 200)): cajas.append((x0, y0, x1, y1))
    # ordenar por filas (centros verticales parecidos) y, dentro, de izquierda a derecha
    cajas.sort(key=lambda c: (c[1] + c[3]) / 2); filas = []
    for c in cajas:
        cy = (c[1] + c[3]) / 2
        if filas and abs(cy - filas[-1][0]) < H * .12: filas[-1][1].append(c)
        else: filas.append([cy, [c]])
    for ri, (_, fila) in enumerate(filas):
        for ci, (x0, y0, x1, y1) in enumerate(sorted(fila)):
            px0, py0, px1, py1 = max(0, x0 - 2), max(0, y0 - 2), min(W, x1 + 2), min(H, y1 + 2)
            rgba = np.dstack([rgb[py0:py1, px0:px1], (alfa[py0:py1, px0:px1] * 255).astype(np.uint8)])
            im = Image.fromarray(rgba, "RGBA")
            if a.alto and im.height != a.alto:
                im = im.resize((max(1, round(im.width * a.alto / im.height)), a.alto), Image.LANCZOS)
            fn = "%s_f%d_%d.png" % (a.nombre, ri + 1, ci + 1); im.save(os.path.join(a.salida, fn), optimize=True)
            man["sprites"].append({"archivo": fn, "fila": ri + 1, "col": ci + 1, "w": im.width, "h": im.height,
                                   "origen": [int(px0), int(py0), int(px1 - px0), int(py1 - py0)]})
    with open(os.path.join(a.salida, a.nombre + ".json"), "w", encoding="utf-8") as f: json.dump(man, f, ensure_ascii=False, indent=1)
    filas = {}
    for s in man["sprites"]: filas[s["fila"]] = filas.get(s["fila"], 0) + 1
    print("sprites: %d · por fila: %s" % (len(man["sprites"]), filas))


if __name__ == "__main__":
    main()
