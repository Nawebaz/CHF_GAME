#!/usr/bin/env bash
# Informe a Faro desde cualquier script o agente (Mac/Linux).
# Uso: faro-report.sh ID KIND STATE [PCT] [PASO] [PROYECTO] [NOMBRE] [MARCA] [ROL]
#   MARCA: claude|gpt|hermes|local  ROL: writing|research|code|video|audio|system|summary|email|thinking (para la oficina)
#   KIND: job (tarea con resultado), run (trabajo con barra), agent (estado de un agente), todo (algo que te toca)
# Ej.:  faro-report.sh backtest-1 run run 35 "Par 3 de 8" trading "Backtest scalping"
FARO_URL="${FARO_URL:-http://127.0.0.1:8787}"
id="$1"; kind="${2:-job}"; state="${3:-ok}"; pct="${4:-}"; step="${5:-}"; project="${6:-}"; name="${7:-$1}"; brand="${8:-}"; role="${9:-}"
json=$(python3 - "$id" "$kind" "$state" "$pct" "$step" "$project" "$name" "$brand" "$role" <<'PY'
import json,sys
i,k,s,p,st,pr,n,b,r=sys.argv[1:10]
d={"id":i,"kind":k,"state":s,"name":n}
if p: d["pct"]=float(p)
if st: d["step"]=st
if pr: d["project"]=pr
if b: d["brand"]=b
if r: d["role"]=r
print(json.dumps(d,ensure_ascii=False))
PY
)
curl -s -m 5 -X POST "$FARO_URL/api/report" -H "Content-Type: application/json" -H "X-Faro-Token: ${FARO_TOKEN:-}" -d "$json" || true
