// node shots.mjs etiqueta [query]  (ejecutar desde ~/lemo-opuscar para resolver playwright)
import { chromium } from "playwright-core";
const T = process.argv[2] || "x", Q = process.argv[3] || "demo=8";
const SZ = [[390,844,3,1],[393,852,3,1],[430,932,3,1],[600,900,2,1],[768,1024,2,1],[900,900,1,0],[1024,768,2,1],[1280,720,1,0],[1440,900,2,0],[1512,982,2,0],[1920,1080,1,0],[2560,1080,1,0],[844,390,3,1]];
const b = await chromium.launch({ executablePath: process.env.CHROME || "/usr/bin/google-chrome", args: ["--no-sandbox"] });
for (const [w,h,d,m] of SZ) { const c = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: Math.min(d,2), isMobile: !!m, hasTouch: !!m });
  const p = await c.newPage(); const errs = []; p.on("console", x => { if (x.type() === "error") errs.push(x.text()); }); p.on("pageerror", e => errs.push(String(e)));
  await p.goto(`http://localhost:8787/hibrida.html?${Q}&dbg=1`); await p.waitForTimeout(4500);
  await p.screenshot({ path: `/tmp/exp/${T}-${w}x${h}.png`, scale: "css" }); console.log(w+"x"+h, await p.title(), errs.slice(0,3).join(" | ")); await c.close(); }
await b.close();
