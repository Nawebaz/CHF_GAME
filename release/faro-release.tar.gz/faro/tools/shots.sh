#!/bin/bash
# uso: shots.sh etiqueta [query]  → /tmp/exp/<etiqueta>-hoja.jpg
G=$(which google-chrome chromium 2>/dev/null | head -1); T=$1; Q=${2:-demo=8}; F=~/.local/bin/ffmpeg
SZ="390x844 393x852 430x932 600x900 768x1024 900x900 1024x768 1280x720 1440x900 1512x982 1920x1080 2560x1080"
cd /tmp/exp; rm -f $T-*.png; ins=""; n=0
for s in $SZ; do w=${s%x*}; h=${s#*x}
  timeout 40 $G --headless=new --no-sandbox --hide-scrollbars --window-size=$w,$h --virtual-time-budget=5000 --screenshot=/tmp/exp/$T-$s.png "http://localhost:8787/hibrida.html?$Q&t=$RANDOM" >/dev/null 2>&1
  $F -v error -y -i $T-$s.png -vf "scale=-2:420,drawtext=text=$s:x=6:y=6:fontsize=20:fontcolor=yellow:box=1:boxcolor=black@0.7" $T-$s.t.png && ins="$ins -i $T-$s.t.png" && n=$((n+1))
done
$F -v error -y $ins -filter_complex "hstack=inputs=$n" -q:v 4 $T-hoja.jpg; ls -l $T-hoja.jpg
