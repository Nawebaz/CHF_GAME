# Informe a Faro desde Windows (agentes, tareas programadas, scripts).
# Uso: .\faro-report.ps1 -Id backtest-1 -Kind run -State run -Pct 35 -Step "Par 3 de 8" -Project trading -Name "Backtest scalping"
param([Parameter(Mandatory=$true)][string]$Id,[string]$Kind="job",[string]$State="ok",[double]$Pct=-1,
      [string]$Step="",[string]$Project="",[string]$Name="",[string]$Url=$(if($env:FARO_URL){$env:FARO_URL}else{"http://127.0.0.1:8787"}))
$b=@{id=$Id;kind=$Kind;state=$State;name=$(if($Name){$Name}else{$Id})}
if($Pct -ge 0){$b.pct=$Pct}; if($Step){$b.step=$Step}; if($Project){$b.project=$Project}
try{Invoke-RestMethod -Uri "$Url/api/report" -Method Post -ContentType "application/json; charset=utf-8" `
  -Headers @{"X-Faro-Token"=$env:FARO_TOKEN} -Body ([Text.Encoding]::UTF8.GetBytes(($b|ConvertTo-Json))) -TimeoutSec 5 | Out-Null}catch{}
