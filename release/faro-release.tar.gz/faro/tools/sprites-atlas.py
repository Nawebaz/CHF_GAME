#!/usr/bin/env python3
"""Junta los sprites recortados (tools/recortar-sprites.py) en un único atlas para la oficina.

Uso:  python3 -I sprites-atlas.py CARPETA_RECORTES web/   [--office web/office.js]
- CARPETA_RECORTES contiene agentes-1/, agentes-2/, gpt-a/, gpt-b/ y zonas/ (salida del recorte).
- Escribe web/office-sprites.webp (un solo archivo: una petición, caché del navegador) y, si se da --office,
  sustituye en office.js el bloque entre /*SPRITES:BEGIN*/ y /*SPRITES:END*/ por el índice del atlas.
- Cada pieza se guarda a la resolución que necesita (≈2× su tamaño en la oficina), no a la original.
- Mide lo que el código necesita para encajar sus dibujos en vivo encima: centro de la cabeza de cada pose
  (para que no bailen al andar), pantalla de la mesa y de cada puesto de zona, ojo y anillos del faro, cabeza del flexo.
Las medidas van en píxeles de la pieza original; «k» = píxeles del atlas por píxel original.
"""
import argparse, hashlib, io, json, os, re, sys
import numpy as np
from PIL import Image
from scipy import ndimage

# nombre → (carpeta, archivo, k)
AG = .76
PIECES = {}
def add(name, folder, f, k): PIECES[name] = (folder, f, k)
POSES = ["idle", "walkA", "walkB", "type1", "type2", "coffee"]
for brand, (sheet, row, talk) in {"claude": ("agentes-1", 1, 1), "gpt": ("agentes-1", 2, 2), "hermes": ("agentes-1", 3, 3),
                                   "codex": ("agentes-2", 1, 4), "local": ("agentes-2", 2, 5)}.items():
    for i, p in enumerate(POSES): add(f"{brand}.{p}", sheet, f"{sheet}_f{row}_{i + 1}.png", AG)
    add(f"{brand}.talk", "agentes-2", f"agentes-2_f3_{talk}.png", AG)
add("claude.lounge", "agentes-2", "agentes-2_f3_6.png", AG)
add("desk", "gpt-a", "gpt-a_f2_1.png", .8)
add("lamp", "gpt-a", "gpt-a_f2_4.png", .45)
add("tower", "gpt-b", "gpt-b_f2_1.png", 1)
add("sofa", "gpt-b", "gpt-b_f1_2.png", .9)
add("plant", "gpt-b", "gpt-b_f1_3.png", .6)
add("espresso", "gpt-b", "gpt-b_f1_4.png", .55)
add("box", "gpt-b", "gpt-b_f3_2.png", .7)
add("boxOpen", "gpt-b", "gpt-b_f3_3.png", .7)
for z, f in {"web": "f1_1", "write": "f1_2", "mail": "f1_3", "code": "f1_4", "edit": "f2_1", "skills": "f2_2", "system": "f2_3"}.items():
    add("zone." + z, "zonas", f"zonas_{f}.png", .6)


def biggest(mask, minfrac=0.0):
    lab, n = ndimage.label(mask)
    if not n: return None
    sz = ndimage.sum(mask, lab, range(1, n + 1)); big = sz.max(); sls = ndimage.find_objects(lab)
    boxes = [sls[i] for i in range(n) if sz[i] >= big * minfrac] if minfrac else [sls[int(np.argmax(sz))]]
    x0 = min(b[1].start for b in boxes); y0 = min(b[0].start for b in boxes); x1 = max(b[1].stop for b in boxes); y1 = max(b[0].stop for b in boxes)
    return [int(x0), int(y0), int(x1 - x0), int(y1 - y0)]


def measure(name, im):
    a = np.array(im).astype(int); r, g, b, al = (a[..., i] for i in range(4)); on = al > 0
    H, W = on.shape; m = {}
    ys, xs = np.where(on); m["bottom"] = int(ys.max()) + 1
    if "." in name and not name.startswith("zone."):        # personaje: x del centro de la cabeza (40 % de arriba)
        top = ys.min(); head = on[top: top + int((ys.max() - top) * .4)]
        hx = np.where(head)[1]; m["ax"] = round(float(np.median(hx)), 1); m["top"] = int(top)
    if name == "desk": m["screen"] = biggest(on & (r < 45) & (g < 55) & (b < 90) & (b > r + 5)); m["topY"] = 130
    if name == "lamp": m["head"] = [60, 90]; m["base"] = [115, 262]
    if name == "tower":
        orange = on & (r > 200) & (g > 120) & (g < 200) & (b < 90)
        lens = biggest(orange[100:165]); lens[1] += 100
        m["lens"] = [round(lens[0] + lens[2] / 2, 1), round(lens[1] + lens[3] / 2, 1), round(max(lens[2], lens[3]) / 2, 1)]
        rows = orange.sum(1); rings = []
        for y in range(240, H):
            if rows[y] > 35 and (not rings or y - rings[-1][1] > 6): rings.append([y, y])
            elif rows[y] > 35: rings[-1][1] = y
        m["rings"] = [[int(a0) - 8, int(a1) + 8] for a0, a1 in rings]
        wid = lambda y: int(on[y].sum())
        m["w"] = {str(y): wid(y) for y in range(0, H, 1) if 280 <= y <= 600 and y % 4 == 0}
        m["cx"] = round(float(np.median([(np.where(on[y])[0].min() + np.where(on[y])[0].max()) / 2 for y in range(300, 560)])), 1)
    if name.startswith("zone."):
        mx = np.maximum(np.maximum(r, g), b); mn = np.minimum(np.minimum(r, g), b)
        bright = on & (mx > 150) & ((mx - mn > 70) | (mx > 175))
        bright = ndimage.binary_opening(bright, iterations=2)
        m["screen"] = biggest(bright, .45)
        # medidas a ojo donde la detección no sirve: el marco de Escritura es un hueco (el magenta se fue con el fondo)
        # y la pantalla del armario de Servidores es gris claro, sin color
        m["screen"] = {"zone.write": [88, 24, 132, 98], "zone.system": [34, 50, 103, 80]}.get(name, m["screen"])
        m["hole"] = name == "zone.write"
    if name in ("box", "boxOpen"): m["slot"] = [int(xs.min()), int(ys.min()), int(xs.max() - xs.min()), int(ys.max() - ys.min())]
    return m


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("cut"); ap.add_argument("web"); ap.add_argument("--office")
    ap.add_argument("--q", type=int, default=90)
    A = ap.parse_args()
    items = []
    for name, (folder, f, k) in PIECES.items():
        p = os.path.join(A.cut, folder, f)
        if not os.path.exists(p): sys.exit("falta " + p)
        im = Image.open(p).convert("RGBA"); meta = measure(name, im); meta["W"], meta["H"] = im.size
        arr = np.array(im); arr[arr[..., 3] == 0, :3] = 0; im = Image.fromarray(arr, "RGBA")
        w, h = max(1, round(im.width * k)), max(1, round(im.height * k))
        if (w, h) != im.size: im = im.convert("RGBa").resize((w, h), Image.LANCZOS).convert("RGBA")
        a2 = np.array(im); a2[..., 3] = np.where(a2[..., 3] > 110, 255, 0); a2[a2[..., 3] == 0, :3] = 0   # alfa limpia
        items.append((name, Image.fromarray(a2, "RGBA"), k, meta))
    # estantes: de más alto a más bajo, ancho máximo 2048
    items.sort(key=lambda it: -it[1].height); MAXW, pad = 2048, 2
    x = y = shelf = 0; pos = {}
    for name, im, k, meta in items:
        if x + im.width + pad > MAXW: x = 0; y += shelf + pad; shelf = 0
        pos[name] = (x, y); x += im.width + pad; shelf = max(shelf, im.height)
    H = y + shelf; atlas = Image.new("RGBA", (MAXW, H), (0, 0, 0, 0))
    for name, im, k, meta in items: atlas.paste(im, pos[name])
    used = atlas.getbbox(); atlas = atlas.crop((0, 0, used[2], used[3]))
    buf = io.BytesIO(); atlas.save(buf, "WEBP", quality=A.q, alpha_quality=100, method=6); data = buf.getvalue()
    os.makedirs(A.web, exist_ok=True)
    with open(os.path.join(A.web, "office-sprites.webp"), "wb") as f: f.write(data)
    v = hashlib.sha256(data).hexdigest()[:10]
    idx = {"v": v, "f": {}}
    for name, im, k, meta in items:
        idx["f"][name] = {"r": [pos[name][0], pos[name][1], im.width, im.height], "k": k, **meta}
    js = json.dumps(idx, ensure_ascii=False, separators=(",", ":"))
    print("atlas %dx%d · %d piezas · %.0f KB · v=%s" % (atlas.width, atlas.height, len(items), len(data) / 1024, v))
    if A.office:
        src = open(A.office, encoding="utf-8").read()
        new, n = re.subn(r"/\*SPRITES:BEGIN\*/.*?/\*SPRITES:END\*/", lambda _: "/*SPRITES:BEGIN*/" + js + "/*SPRITES:END*/", src, flags=re.S)
        if n != 1: sys.exit("office.js sin bloque /*SPRITES:BEGIN*/…/*SPRITES:END*/")
        open(A.office, "w", encoding="utf-8").write(new); print("office.js: índice actualizado")


if __name__ == "__main__":
    main()
