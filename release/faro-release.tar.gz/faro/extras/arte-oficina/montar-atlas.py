import sys, os, io, json, hashlib, importlib.util
import numpy as np
from PIL import Image
from scipy import ndimage
S = os.path.dirname(os.path.abspath(__file__)); REL = sys.argv[1]
spec = importlib.util.spec_from_file_location("sa", REL + "/tools/sprites-atlas.py"); sa = importlib.util.module_from_spec(spec); spec.loader.exec_module(sa)

def key(path):
    """Quita el magenta con alfa suave (bordes limpios en ilustración) y el halo rosa."""
    a = np.asarray(Image.open(path).convert("RGB")).astype(np.float32); r, g, b = a[..., 0], a[..., 1], a[..., 2]
    mag = np.minimum(r, b) - g                      # cuánto magenta tiene el píxel
    alpha = np.clip((150 - mag) / 70, 0, 1)         # magenta puro ≈ 255 → 0; colores normales → 1
    sp = np.clip(mag, 0, None) * (alpha < 1)        # despill solo en el borde
    r2 = r - sp * .9; b2 = b - sp * .9
    out = np.dstack([r2, g, b2, alpha * 255]).clip(0, 255).astype(np.uint8); return Image.fromarray(out, "RGBA")

def cells(im, rows, cols=None):
    A = np.asarray(im)[..., 3] > 40; A = ndimage.binary_opening(A, iterations=1)
    ys = np.where(A.sum(1) > 3)[0]; bands = np.split(ys, np.where(np.diff(ys) > 6)[0] + 1); bands = [b for b in bands if len(b) > 30]
    assert len(bands) == rows, (len(bands), rows); out = []
    for b in bands:
        sub = A[b[0]:b[-1] + 1]; xs = np.where(sub.sum(0) > 1)[0]; segs = np.split(xs, np.where(np.diff(xs) > 9)[0] + 1); segs = [s for s in segs if len(s) > 14]
        row = []
        for s in segs:
            box = A[b[0]:b[-1] + 1, s[0]:s[-1] + 1]; yy = np.where(box.sum(1) > 0)[0]
            row.append(im.crop((max(0, s[0] - 2), max(0, b[0] + yy[0] - 2), s[-1] + 3, b[0] + yy[-1] + 3)))
        out.append(row)
    return out

pieces = {}   # nombre → (imagen en «píxeles originales», k)
POSES = ["idle", "walkA", "walkB", "coffee", "talk", "type1", "type2", "lounge"]
for sheet, brands in (("faro-hoja1-personajes.png", ["claude", "codex", "gpt"]), ("faro-hoja2-personajes.png", ["hermes", "local", "biblio"])):
    rows = cells(key(S + "/" + sheet), 3)
    for brand, row in zip(brands, rows):
        assert len(row) == 8, (sheet, brand, len(row)); f = 208 / row[0].height   # de pie = 208 px «originales», como los de antes
        for pose, im in zip(POSES, row): pieces[f"{brand}.{pose}"] = (im.resize((round(im.width * f), round(im.height * f)), Image.LANCZOS), .66)
rows = cells(key(S + "/faro-hoja3-orbe.png"), 3)
print("hoja3:", [len(r) for r in rows])
for n, im in zip(["calm", "right", "left", "focus", "sleepy", "empty"], rows[0]): pieces["orb." + n] = (im, .8)
for n, im in zip(["tv", "voz", "server", "deskscreen", "pad"], rows[1]): pieces["scr." + n] = (im, .72)
for n, im in zip(["plant", "lamp", "mug", "box", "boxOpen", "shelf"], rows[2]): pieces["deco." + n] = (im, .5)

idx = {"f": {}}; packed = []
for name, (im, k) in pieces.items():
    meta = {}
    if name.split(".")[0] in ("claude", "codex", "gpt", "hermes", "local", "biblio"):
        try: meta = sa.measure(name, im)
        except Exception as e: meta = {}
        A = np.asarray(im)[..., 3] > 40; ys, xs = np.where(A)
        meta.setdefault("bottom", int(ys.max()) + 1); meta.setdefault("ax", round(float(np.median(xs)), 1)); meta.setdefault("top", int(ys.min()))
    elif name.startswith("orb."):
        a = np.asarray(im).astype(int); dark = (a[..., 3] > 200) & (a[..., :3].sum(2) < 230) if name == "orb.empty" else None
        if dark is not None:
            lab, n = ndimage.label(dark); big = np.argmax(ndimage.sum(dark, lab, range(1, n + 1))) + 1; ys, xs = np.where(lab == big)
            ORBG = [round(float(xs.mean()), 1), round(float(ys.mean()), 1), round(float((xs.max() - xs.min() + ys.max() - ys.min()) / 4), 1)]
    elif name.startswith("scr."):
        a = np.asarray(im).astype(int); dark = (a[..., 3] > 200) & (a[..., :3].sum(2) < 200)
        lab, n = ndimage.label(dark)
        if n: big = np.argmax(ndimage.sum(dark, lab, range(1, n + 1))) + 1; ys, xs = np.where(lab == big); meta["screen"] = [int(xs.min()), int(ys.min()), int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1)]
    meta["W"], meta["H"] = im.size
    small = im.resize((max(1, round(im.width * k)), max(1, round(im.height * k))), Image.LANCZOS); packed.append((name, small, k, meta))
for name, small, k, meta in packed:
    if name.startswith("orb."): meta["g"] = ORBG
# empaquetado por estantes
packed.sort(key=lambda p: -p[1].height); AW = 1500; x = y = rowh = 0; pos = {}
for name, im, k, meta in packed:
    if x + im.width + 2 > AW: x = 0; y += rowh + 2; rowh = 0
    pos[name] = (x, y); x += im.width + 2; rowh = max(rowh, im.height)
atlas = Image.new("RGBA", (AW, y + rowh), (0, 0, 0, 0))
for name, im, k, meta in packed: atlas.paste(im, pos[name]); idx["f"][name] = {"r": [pos[name][0], pos[name][1], im.width, im.height], "k": k, **meta}
buf = io.BytesIO(); atlas.save(buf, "WEBP", quality=int(sys.argv[2]) if len(sys.argv) > 2 else 86, alpha_quality=92, method=6); data = buf.getvalue()
open(REL + "/web/office-sprites.webp", "wb").write(data); idx["v"] = hashlib.sha1(data).hexdigest()[:10]
import re
p = REL + "/web/office.js"; s = open(p, encoding="utf-8").read()
new, n = re.subn(r"/\*SPRITES:BEGIN\*/.*?/\*SPRITES:END\*/", lambda _: "/*SPRITES:BEGIN*/" + json.dumps(idx, separators=(",", ":")) + "/*SPRITES:END*/", s, flags=re.S); assert n == 1
open(p, "w", encoding="utf-8").write(new)
bg = Image.open(S + "/faro-hoja4-fondo.png").convert("RGB").resize((1280, 716), Image.LANCZOS); bb = io.BytesIO(); bg.save(bb, "WEBP", quality=62, method=6); open(REL + "/web/office-room.webp", "wb").write(bb.getvalue())
atlas.convert("RGB").resize((atlas.width // 2, atlas.height // 2)).save(S + "/atlas_prev.jpg", quality=75)
print("atlas", atlas.size, len(data), "bg", len(bb.getvalue()), "orb g", ORBG, "claude.idle", idx["f"]["claude.idle"], "tv", idx["f"]["scr.tv"])
