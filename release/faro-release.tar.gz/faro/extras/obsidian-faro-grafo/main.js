/* Faro · grafo — manda a Faro (tu propio servidor) dónde está cada punto de la vista gráfica de Obsidian.
   Gasto: cada 4 s mira las posiciones (unos cientos de números); solo envía si algo se ha movido. Con el grafo quieto o cerrado, no envía nada.
   Qué sale del equipo: ids de nodo (rutas de nota, etiquetas, adjuntos) y sus coordenadas x, y. Nada del contenido de las notas. */
const { Plugin, PluginSettingTab, Setting, requestUrl } = require("obsidian");
const DEF = { url: "http://127.0.0.1:8787", cada: 4 };

function leerGrafo(app) {
  const hojas = app.workspace.getLeavesOfType("graph");
  for (const h of hojas) {
    const r = h.view && h.view.renderer, ns = r && r.nodes;
    if (!ns || !ns.length) continue;
    const out = [];
    for (const n of ns) { if (n && typeof n.id === "string" && isFinite(n.x) && isFinite(n.y)) out.push([n.id, Math.round(n.x * 10) / 10, Math.round(n.y * 10) / 10]); }
    if (out.length) return out;
  }
  return null;
}
// huella barata: cambia si entra o sale un nodo o si alguno se mueve más de ~6 unidades del grafo
function huella(nodos) { let h = nodos.length; for (const n of nodos) h = (h * 31 + n[0].length * 7 + Math.round(n[1] / 6) * 13 + Math.round(n[2] / 6) * 17) | 0; return h; }

class FaroGrafo extends Plugin {
  async onload() {
    this.cfg = Object.assign({}, DEF, await this.loadData()); this.ultima = null; this.estado = "sin enviar todavía"; this.ocupado = false;
    this.addSettingTab(new Ajustes(this.app, this));
    this.addCommand({ id: "enviar-ahora", name: "Enviar el grafo a Faro ahora", callback: () => this.tic(true) });
    this.registerInterval(window.setInterval(() => this.tic(false), Math.max(2, Number(this.cfg.cada) || 4) * 1000));
  }
  async tic(forzar) {
    if (this.ocupado) return;
    const nodos = leerGrafo(this.app);
    if (!nodos) { this.estado = "abre la vista gráfica para que haya algo que enviar"; return; }
    const h = huella(nodos); if (!forzar && h === this.ultima) return;
    this.ocupado = true;
    try {
      const r = await requestUrl({ url: String(this.cfg.url).replace(/\/+$/, "") + "/api/vault/layout", method: "POST", contentType: "application/json", body: JSON.stringify({ nodes: nodos }), throw: false });
      if (r.status === 200) { this.ultima = h; this.estado = "enviados " + nodos.length + " puntos a las " + new Date().toLocaleTimeString(); }
      else this.estado = "Faro respondió " + r.status;
    } catch (e) { this.estado = "no llego a Faro (" + String(e && e.message || e).slice(0, 60) + ")"; }
    this.ocupado = false;
  }
}
class Ajustes extends PluginSettingTab {
  constructor(app, plugin) { super(app, plugin); this.plugin = plugin; }
  display() {
    const el = this.containerEl; el.empty();
    new Setting(el).setName("Dirección de Faro").setDesc("En el PC donde corre Faro: http://127.0.0.1:8787. Desde otro equipo: http://iceland:8787")
      .addText(t => t.setValue(this.plugin.cfg.url).onChange(async v => { this.plugin.cfg.url = v.trim() || DEF.url; this.plugin.ultima = null; await this.plugin.saveData(this.plugin.cfg); }));
    new Setting(el).setName("Estado").setDesc(this.plugin.estado).addButton(b => b.setButtonText("Enviar ahora").onClick(async () => { await this.plugin.tic(true); this.display(); }));
  }
}
module.exports = FaroGrafo;
module.exports._prueba = { leerGrafo, huella };
