/* Faro · grafo — manda a Faro (tu propio servidor) dónde está cada punto de la vista gráfica de Obsidian y qué filtros tiene puestos
   (adjuntos, etiquetas, huérfanas, sin resolver, búsqueda), para que la oficina enseñe lo mismo que ves aquí.
   Gasto: cada 0,4 s mira en memoria las posiciones (unos cientos de números) y los filtros; solo envía si algo ha cambiado, así lo que ves
   aquí llega a la oficina en 1,5 s como mucho. Con todo quieto, no envía nada. Si Faro le trae una versión nueva, se recarga solo.
   Qué sale del equipo: ids de nodo (rutas de nota, etiquetas, adjuntos), sus coordenadas x, y y esos filtros. Nada del contenido de las notas. */
const { Plugin, PluginSettingTab, Setting, requestUrl } = require("obsidian");
const DEF = { url: "http://127.0.0.1:8787", cada: 0.4, v: 2 };

function leerGrafo(app) {
  const hojas = app.workspace.getLeavesOfType("graph");
  for (const h of hojas) {
    const r = h.view && h.view.renderer, ns = r && r.nodes;
    if (!ns || !ns.length) continue;
    const out = [];
    for (const n of ns) { if (n && typeof n.id === "string" && isFinite(n.x) && isFinite(n.y)) out.push([n.id, Math.round(n.x * 10) / 10, Math.round(n.y * 10) / 10]); }
    if (out.length) return out;
  }
  return null;
}
const CLAVES = ["showAttachments", "showTags", "showOrphans", "hideUnresolved", "search"];
function recorta(o) { if (!o || typeof o !== "object") return null; const r = {}; for (const k of CLAVES) if (k in o) r[k] = o[k]; return Object.keys(r).length ? r : null; }
// filtros: los de la vista gráfica abierta (al instante) o, si está cerrada, los guardados en .obsidian/graph.json
async function leerFiltros(app) {
  for (const h of app.workspace.getLeavesOfType("graph")) {
    const de = h.view && h.view.dataEngine;
    if (de && typeof de.getOptions === "function") { try { const r = recorta(de.getOptions()); if (r) return r; } catch (e) {} }
  }
  try {
    const a = app.vault && app.vault.adapter, f = ((app.vault && app.vault.configDir) || ".obsidian") + "/graph.json";
    if (a && await a.exists(f)) return recorta(JSON.parse(await a.read(f)));
  } catch (e) {}
  return null;
}
// huella barata: cambia si entra o sale un nodo o si alguno se mueve más de ~6 unidades del grafo
function huella(nodos) { let h = nodos.length; for (const n of nodos) h = (h * 31 + n[0].length * 7 + Math.round(n[1] / 6) * 13 + Math.round(n[2] / 6) * 17) | 0; return h; }

class FaroGrafo extends Plugin {
  async onload() {
    this.cfg = Object.assign({}, DEF, await this.loadData()); this.ultima = null; this.ultimosF = null; this.estado = "sin enviar todavía"; this.ocupado = false;
    this.addSettingTab(new Ajustes(this.app, this));
    this.addCommand({ id: "enviar-ahora", name: "Enviar el grafo a Faro ahora", callback: () => this.tic(true) });
    if (!(this.cfg.v >= 2)) { this.cfg.cada = DEF.cada; this.cfg.v = 2; await this.saveData(this.cfg); }   // antes iba cada 4 s
    this.registerInterval(window.setInterval(() => this.tic(false), Math.max(0.25, Math.min(2, Number(this.cfg.cada) || DEF.cada)) * 1000));
    this.codigo = await this.huellaCodigo(); this.registerInterval(window.setInterval(() => this.alDia(), 5000));
  }
  async huellaCodigo() { try { const st = await this.app.vault.adapter.stat(this.manifest.dir + "/main.js"); return st ? st.mtime + ":" + st.size : null; } catch (e) { return null; } }
  async alDia() {   // Faro ha dejado una versión nueva del plugin: se recarga solo, sin reiniciar Obsidian
    const h = await this.huellaCodigo(); if (!h || !this.codigo || h === this.codigo || this.recargando) return;
    this.recargando = true; const id = this.manifest.id, pl = this.app.plugins;
    window.setTimeout(async () => { try { await pl.disablePlugin(id); await pl.enablePlugin(id); } catch (e) {} }, 300);
  }
  async tic(forzar) {
    if (this.ocupado) return;
    this.ocupado = true;
    try {
      const nodos = leerGrafo(this.app), filtros = await leerFiltros(this.app), fh = filtros ? JSON.stringify(filtros) : null;
      if (!nodos && !filtros) { this.estado = "abre la vista gráfica para que haya algo que enviar"; return; }
      const h = nodos ? huella(nodos) : null, body = {};
      if (nodos && (forzar || h !== this.ultima)) body.nodes = nodos;
      if (filtros && (forzar || fh !== this.ultimosF || body.nodes)) body.opts = filtros;
      if (!body.nodes && !body.opts) return;
      const r = await requestUrl({ url: String(this.cfg.url).replace(/\/+$/, "") + "/api/vault/layout", method: "POST", contentType: "application/json", body: JSON.stringify(body), throw: false });
      if (r.status === 200) { if (body.nodes) this.ultima = h; if (body.opts) this.ultimosF = fh; this.estado = (body.nodes ? "enviados " + nodos.length + " puntos" : "enviados los filtros") + " a las " + new Date().toLocaleTimeString(); }
      else this.estado = "Faro respondió " + r.status;
    } catch (e) { this.estado = "no llego a Faro (" + String(e && e.message || e).slice(0, 60) + ")"; }
    finally { this.ocupado = false; }
  }
}
class Ajustes extends PluginSettingTab {
  constructor(app, plugin) { super(app, plugin); this.plugin = plugin; }
  display() {
    const el = this.containerEl; el.empty();
    new Setting(el).setName("Dirección de Faro").setDesc("En el PC donde corre Faro: http://127.0.0.1:8787. Desde otro equipo: http://iceland:8787")
      .addText(t => t.setValue(this.plugin.cfg.url).onChange(async v => { this.plugin.cfg.url = v.trim() || DEF.url; this.plugin.ultima = null; await this.plugin.saveData(this.plugin.cfg); }));
    new Setting(el).setName("Estado").setDesc(this.plugin.estado).addButton(b => b.setButtonText("Enviar ahora").onClick(async () => { await this.plugin.tic(true); this.display(); }));
  }
}
module.exports = FaroGrafo;
module.exports._prueba = { leerGrafo, huella, leerFiltros };
