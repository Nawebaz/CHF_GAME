#!/usr/bin/env bash
# Actualiza Faro con el faro-linux.zip más reciente que encuentre (normalmente en Descargas). Conserva tu config y tus datos.
Z="$(find ~ -name 'faro-linux*.zip' -not -path '*/.*' -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -1 | cut -d' ' -f2-)"
[ -n "$Z" ] || { echo "No encuentro ningún faro-linux.zip"; exit 1; }
echo "Instalando desde: $Z"
rm -rf /tmp/faro-new && mkdir /tmp/faro-new && unzip -oq "$Z" -d /tmp/faro-new && bash /tmp/faro-new/faro/linux/install.sh
