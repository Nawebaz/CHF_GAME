/* Faro · La oficina (estilo consola acogedora)
   API: window.FaroOffice = { open(D), update(D), close(), isOpen() }  ·  window.FaroOfficeSample */
(function () {
  "use strict";
  const iso = m => new Date(Date.now() - m * 60000).toISOString();
  const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const LITE = !!(window.matchMedia && matchMedia("(pointer: coarse)").matches);   // móvil/tableta: sondeos más lentos
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const ease = k => k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;

  /* ───────── vocabulario ───────── */
  const BRANDS = {
    claude: { label: "Claude", c: "#f2a35e" }, gpt: { label: "GPT", c: "#9cc4ee" }, codex: { label: "Codex", c: "#9cc4ee" },
    hermes: { label: "Hermes", c: "#aa9de8" }, local: { label: "Strata", c: "#8fdcae" }, faro: { label: "Faro", c: "#efe2a4" }, agent: { label: "Agente", c: "#c9d3ea" }
  };
  const ZONES = {
    obsidian: { label: "Obsidian", c: "#aa9de8", doing: "consulta la bóveda" },
    web: { label: "Web", c: "#60a5fa", doing: "busca en la web" },
    write: { label: "Escritura", c: "#f29b9d", doing: "escribe" },
    voice: { label: "Voz y audio", c: "#f29b7d", doing: "trabaja la voz" },
    code: { label: "Código", c: "#7fd3a6", doing: "programa" },
    edit: { label: "Edición", c: "#fb923c", doing: "edita" },
    image: { label: "Imagen", c: "#f2c078", doing: "crea imágenes" },
    system: { label: "Servidores", c: "#94a3b8", doing: "trabaja en el sistema" }
  };
  const SCRIPTS = {
    code: ["obsidian", "code", "web", "code"], writing: ["obsidian", "write", "write"], research: ["web", "obsidian", "write"],
    video: ["edit", "voice", "edit"], audio: ["voice", "edit"], image: ["image", "edit"], thinking: ["obsidian", "write"], email: ["write"], system: ["system"],
    summary: ["obsidian", "write"], question: ["obsidian"]
  };
  const ACTION_ZONE = { codigo: "code", "código": "code", editar: "edit", pensar: "write", buscar: "web", escribir: "write", correo: "write", voz: "voice", audio: "voice", imagen: "image", sistema: "system", obsidian: "obsidian", "bóveda": "obsidian", web: "web", code: "code", edit: "edit", write: "write", skills: "code", mail: "write", voice: "voice", image: "image", system: "system", think: "write", cards: "write" };
  function brandOf(s) { s = (s || "").toLowerCase(); if (/codex/.test(s)) return "codex"; if (/claude/.test(s)) return "claude"; if (/gpt|openai|chatgpt/.test(s)) return "gpt"; if (/hermes/.test(s)) return "hermes"; if (/strata|ollama|local|qwen/.test(s)) return "local"; if (/faro/.test(s)) return "faro"; return "agent"; }   // sin representación propia: personaje genérico (antes salía como Hermes)
  function roleOf(t, brand) {
    t = (t || "").toLowerCase();
    if (/\bvoz\b|voces|audio|narra|locuci|chatterbox|tts|transcrib/.test(t)) return "audio";
    if (/sprite|imagen|im[aá]genes|ilustra|higgsfield|logo|icono|cartel|miniatura/.test(t)) return "image";
    if (/render|v[ií]deo|clip|reel|ffmpeg|montaje|davinci|premiere|blender/.test(t)) return "video";
    if (/c[oó]digo|script|bug|\bprogram(a|ar)\b|repositorio|github|api|deploy|backtest|freqtrade|build/.test(t)) return "code";
    if (/correo|email|gmail|responde|contesta|\bdm/.test(t)) return "email";
    if (/instala|actualiza|configura|copia|mueve|backup|reinicia|carpeta|archivo|descarga/.test(t)) return "system";
    if (/resume|resumen|traduce|clasifica|corrige/.test(t)) return "summary";
    if (/busca|investiga|noticias|compara|precio|mercado/.test(t)) return "research";
    if (/escribe|redacta|propuesta|guion|texto|post|plan|estrategia|dise[ñn]a/.test(t)) return "writing";
    return brand === "faro" ? "question" : "thinking";
  }
  const fitText = (c, s, w) => { if (c.measureText(s).width <= w) return s; while (s.length > 2 && c.measureText(s + "…").width > w) s = s.slice(0, -1); return s + "…"; };
  const shortName = n => { n = String(n || ""); return n.length > 14 ? n.slice(0, 13) + "…" : n; };

  /* ───────── estado ───────── */
  const S = {
    open: false, D: null, root: null, cv: null, ctx: null, raf: 0, t0: performance.now(), lastT: 0,
    L: null, evq: [], nextEv: 0, scale: 1, mv: {}, M: null, Mat: 0, gpuUse: {}, ox: 0, oy: 0, bg: null, bgKey: "",
    ag: new Map(), deskOf: new Map(), packets: [], flashes: [], bonus: {}, seenDone: new Set(), lastSugg: null,
    nextDemoDelivery: 0, nextSocial: 0, mailFlash: 0, sel: null, bokeh: [], reduce: false, sprite: {}
  };

  /* ───────── layouts ───────── */
  // Distribución (14 nov): la bóveda es el objeto central, al que todos acuden; las mesas, a sus lados; las zonas, en los
  // extremos (en el móvil, fichas arriba). Ya no hay torre: el ojo de Faro es un orbe que flota y sobrevuela la oficina.
  // Abajo, el descanso, la entrada con sus tres canales reales (tú, la nube y los vigías del PC/Mac) y los proyectos.
  function makeLayout(wide) {
    if (wide) {
      const W = 1400, H = 900, L = { W, H, wide: true, zones: {}, desks: [] };
      L.vault = { x: 430, y: 96, w: 540, h: 524 };
      ["web", "write", "voice", "system"].forEach((k, i) => L.zones[k] = { x: 20, y: 96 + i * 150, w: 160, h: 132 });
      ["code", "edit", "image"].forEach((k, i) => L.zones[k] = { x: W - 180, y: 96 + i * 150, w: 160, h: 132 });
      L.zones.obsidian = L.vault;
      for (let r = 0; r < 4; r++) for (const x of [225, 985]) L.desks.push({ x, y: 104 + r * 130, w: 190, h: 120 });
      L.door = { x: 215, y: 640, w: 300, h: 250 };
      L.proj = { x: 527, y: 640, w: 658, h: 250 };
      L.meter = { x: W / 2 - 310, y: 14, w: 620, h: 66 };   // más ancho: caben los termómetros con su cifra
      return finishLayout(L);
    }
    const W = 620, H = 1108, L = { W, H, wide: false, zones: {}, desks: [] };
    const order = ["web", "write", "voice", "code", "edit", "image", "system"];
    order.forEach((k, i) => L.zones[k] = { x: 10 + (i % 4) * 152, y: 92 + Math.floor(i / 4) * 60, w: 144, h: 52, chip: true });
    L.vault = { x: 200, y: 216, w: 220, h: 500 };   // en el centro, entre las dos columnas de mesas
    L.zones.obsidian = L.vault;
    for (let r = 0; r < 4; r++) for (const x of [10, W - 10 - 185]) L.desks.push({ x, y: 216 + r * 128, w: 185, h: 120 });
    L.proj = { x: 10, y: 732, w: W - 20, h: 230 };
    L.door = { x: 10, y: 972, w: W - 20, h: 126 };
    L.meter = { x: 30, y: 14, w: W - 60, h: 66 };
    return finishLayout(L);
  }
  // Las mesas más cercanas a la bóveda son las de más prioridad
  function finishLayout(L) {
    const tc = [L.vault.x + L.vault.w / 2, L.vault.y + L.vault.h / 2];
    L.orbHome = tc;
    L.deskRank = L.desks.map((d, i) => [i, Math.hypot(d.x + d.w / 2 - tc[0], d.y + d.h / 2 - tc[1])]).sort((a, b) => a[1] - b[1]).map(x => x[0]);
    const d = L.door;
    if (L.wide) {   // entrada estrecha entre la sala y los proyectos: canales en filas
      L.chan = ["you", "cloud", "local"].map((k, i) => ({ k, x: d.x + 14, y: d.y + 14 + i * 36, w: d.w - 28, h: 30 }));
      L.bench = { x: d.x + 14, y: d.y + 126, w: d.w - 100, h: 44 };
    } else {
      L.chan = ["you", "cloud", "local"].map((k, i) => ({ k, x: d.x + 14 + i * ((d.w - 28) / 3), y: d.y + 12, w: (d.w - 28) / 3 - 10, h: 50 }));
      L.bench = { x: d.x + 14, y: d.y + 72, w: d.w - 100, h: 44 };
    }
    return L;
  }
  function pickLayout(w, h) {
    const a = makeLayout(true), b = makeLayout(false);
    const sa = Math.min(w / a.W, h / a.H), sb = Math.min(w / b.W, h / b.H);
    return sb > sa * 1.1 ? b : a;
  }

  /* ───────── utilidades de dibujo ───────── */
  function rr(c, x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function hexA(hex, a) { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`; }
  function glowSprite(col) {
    // Los colores del calor llegan como rgb(); antes se leían como hex (salían negros) y cada tono nuevo creaba otra
    // textura. Ahora se aceptan y se redondean a pasos de 8, con la caché acotada.
    const m = /rgb\((\d+),\s*(\d+),\s*(\d+)\)/.exec(col);
    const key = m ? "q" + [m[1], m[2], m[3]].map(v => Math.min(255, Math.round(v / 8) * 8)).join(",") : col;
    if (S.sprite[key]) return S.sprite[key];
    if (Object.keys(S.sprite).length > 400) S.sprite = {};
    const rgb = m ? key.slice(1).split(",") : null, A = a => rgb ? `rgba(${rgb[0]},${rgb[1]},${rgb[2]},${a})` : hexA(col, a);
    const s = document.createElement("canvas"); s.width = s.height = 128; const c = s.getContext("2d");
    const g = c.createRadialGradient(64, 64, 0, 64, 64, 64); g.addColorStop(0, A(.9)); g.addColorStop(.35, A(.35)); g.addColorStop(1, A(0));
    c.fillStyle = g; c.fillRect(0, 0, 128, 128); S.sprite[key] = s; return s;
  }
  // Borde difuminado (orgánico): lo dibujado en (x, y, w, h) se funde con lo de debajo en «f» píxeles, sin cortes rectos.
  // Se aplica sobre una capa propia (destination-in multiplica la transparencia: vertical × horizontal).
  function feather(c, x, y, w, h, f) {
    const fy = Math.min(.45, f / h), fx = Math.min(.45, f / w), st = (g, k) => { g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(k * .35, "rgba(0,0,0,.2)"); g.addColorStop(k * .7, "rgba(0,0,0,.7)"); g.addColorStop(k, "#000"); g.addColorStop(1 - k, "#000"); g.addColorStop(1 - k * .7, "rgba(0,0,0,.7)"); g.addColorStop(1 - k * .35, "rgba(0,0,0,.2)"); g.addColorStop(1, "rgba(0,0,0,0)"); return g; };
    c.save(); c.globalCompositeOperation = "destination-in";
    c.fillStyle = st(c.createLinearGradient(0, y, 0, y + h), fy); c.fillRect(x, y, w, h);
    c.fillStyle = st(c.createLinearGradient(x, 0, x + w, 0), fx); c.fillRect(x, y, w, h);
    c.restore();
  }
  function glow(c, x, y, r, col, a) { c.globalAlpha = Math.min(1, a * .75); c.drawImage(glowSprite(col), x - r, y - r, r * 2, r * 2); c.globalAlpha = 1; }
  function center(b) { return [b.x + b.w / 2, b.y + b.h / 2]; }

  /* ───────── sprites «Plató nocturno» (un solo atlas; si no carga o con ?vector, todo se dibuja como antes) ─────────
     El índice lo escribe tools/sprites-atlas.py. Medidas en píxeles de la pieza original; k = píxeles del atlas por píxel
     original. Lo que cambia en vivo (pantallas, luces, ojo del faro, cifras) se sigue pintando con código encima. */
  const SPR = /*SPRITES:BEGIN*/{"f":{"scr.deskscreen":{"r":[0,0,193,155],"k":0.72,"screen":[69,17,108,87],"W":268,"H":215},"scr.tv":{"r":[195,0,216,145],"k":0.72,"screen":[22,21,256,126],"W":300,"H":202},"scr.voz":{"r":[413,0,193,141],"k":0.72,"screen":[75,17,169,99],"W":268,"H":196},"scr.server":{"r":[608,0,102,138],"k":0.72,"screen":[24,19,95,118],"W":142,"H":192},"biblio.talk":{"r":[712,0,80,126],"k":0.6,"bottom":209,"ax":54.0,"top":1,"W":133,"H":210},"claude.idle":{"r":[794,0,70,125],"k":0.6,"bottom":207,"ax":53.0,"top":1,"W":117,"H":208},"codex.idle":{"r":[866,0,68,125],"k":0.6,"bottom":206,"ax":53.0,"top":2,"W":113,"H":208},"gpt.idle":{"r":[936,0,65,125],"k":0.6,"bottom":206,"ax":49.0,"top":1,"W":109,"H":208},"gpt.walkB":{"r":[1003,0,70,125],"k":0.6,"bottom":207,"ax":49.0,"top":1,"W":117,"H":208},"gpt.talk":{"r":[1075,0,78,125],"k":0.6,"bottom":207,"ax":49.0,"top":1,"W":130,"H":208},"hermes.idle":{"r":[1155,0,80,125],"k":0.6,"bottom":208,"ax":66.0,"top":0,"W":133,"H":208},"hermes.walkA":{"r":[1237,0,77,125],"k":0.6,"bottom":208,"ax":63.0,"top":0,"W":128,"H":208},"hermes.talk":{"r":[1316,0,88,125],"k":0.6,"bottom":208,"ax":63.0,"top":0,"W":146,"H":208},"local.idle":{"r":[1406,0,71,125],"k":0.6,"bottom":208,"ax":61.0,"top":0,"W":119,"H":208},"local.walkA":{"r":[0,157,71,125],"k":0.6,"bottom":208,"ax":59.0,"top":0,"W":119,"H":208},"local.coffee":{"r":[73,157,77,125],"k":0.6,"bottom":208,"ax":59.0,"top":0,"W":128,"H":208},"local.talk":{"r":[152,157,84,125],"k":0.6,"bottom":208,"ax":60.0,"top":0,"W":140,"H":208},"biblio.idle":{"r":[238,157,68,125],"k":0.6,"bottom":207,"ax":53.0,"top":1,"W":114,"H":208},"biblio.walkB":{"r":[308,157,68,125],"k":0.6,"bottom":208,"ax":52.0,"top":1,"W":114,"H":209},"biblio.coffee":{"r":[378,157,68,125],"k":0.6,"bottom":208,"ax":53.5,"top":1,"W":113,"H":209},"claude.coffee":{"r":[448,157,68,124],"k":0.6,"bottom":205,"ax":51.0,"top":1,"W":113,"H":206},"claude.talk":{"r":[518,157,79,124],"k":0.6,"bottom":205,"ax":54.0,"top":1,"W":131,"H":206},"codex.walkA":{"r":[599,157,67,124],"k":0.6,"bottom":204,"ax":52.0,"top":2,"W":111,"H":206},"codex.walkB":{"r":[668,157,67,124],"k":0.6,"bottom":204,"ax":52.0,"top":2,"W":112,"H":206},"codex.coffee":{"r":[737,157,66,124],"k":0.6,"bottom":205,"ax":51.0,"top":2,"W":110,"H":207},"codex.talk":{"r":[805,157,80,124],"k":0.6,"bottom":205,"ax":52.0,"top":2,"W":133,"H":206},"gpt.walkA":{"r":[887,157,68,124],"k":0.6,"bottom":206,"ax":48.0,"top":1,"W":114,"H":207},"gpt.coffee":{"r":[957,157,68,124],"k":0.6,"bottom":206,"ax":48.0,"top":1,"W":113,"H":207},"hermes.walkB":{"r":[1027,157,73,124],"k":0.6,"bottom":205,"ax":58.5,"top":0,"W":121,"H":206},"hermes.coffee":{"r":[1102,157,79,124],"k":0.6,"bottom":207,"ax":62.0,"top":0,"W":131,"H":207},"local.walkB":{"r":[1183,157,74,124],"k":0.6,"bottom":207,"ax":58.0,"top":0,"W":124,"H":207},"claude.walkA":{"r":[1259,157,68,123],"k":0.6,"bottom":204,"ax":53.0,"top":1,"W":114,"H":205},"claude.walkB":{"r":[1329,157,70,123],"k":0.6,"bottom":204,"ax":54.0,"top":1,"W":117,"H":205},"biblio.walkA":{"r":[1401,157,70,123],"k":0.6,"bottom":203,"ax":53.0,"top":1,"W":116,"H":205},"hermes.type1":{"r":[0,284,85,121],"k":0.6,"bottom":200,"ax":58.0,"top":0,"W":141,"H":201},"local.type1":{"r":[87,284,85,121],"k":0.6,"bottom":201,"ax":56.0,"top":0,"W":142,"H":202},"local.type2":{"r":[174,284,85,119],"k":0.6,"bottom":198,"ax":59.0,"top":0,"W":141,"H":198},"biblio.type1":{"r":[261,284,79,119],"k":0.6,"bottom":197,"ax":51.0,"top":1,"W":132,"H":198},"biblio.type2":{"r":[342,284,79,118],"k":0.6,"bottom":195,"ax":51.0,"top":2,"W":132,"H":196},"hermes.type2":{"r":[423,284,82,117],"k":0.6,"bottom":195,"ax":57.0,"top":0,"W":137,"H":195},"claude.type1":{"r":[507,284,71,116],"k":0.6,"bottom":193,"ax":52.0,"top":1,"W":119,"H":194},"claude.type2":{"r":[580,284,74,116],"k":0.6,"bottom":192,"ax":54.0,"top":1,"W":123,"H":193},"codex.type1":{"r":[656,284,71,115],"k":0.6,"bottom":189,"ax":54.0,"top":2,"W":118,"H":191},"gpt.type1":{"r":[729,284,71,115],"k":0.6,"bottom":191,"ax":49.0,"top":1,"W":119,"H":192},"codex.type2":{"r":[802,284,71,113],"k":0.6,"bottom":186,"ax":53.5,"top":2,"W":119,"H":188},"gpt.type2":{"r":[875,284,72,113],"k":0.6,"bottom":188,"ax":50.0,"top":1,"W":120,"H":189},"gen0.coffee":{"r":[949,284,58,109],"k":0.52,"bottom":209,"ax":54.0,"top":0,"W":111,"H":209},"gen0.idle":{"r":[1009,284,58,108],"k":0.52,"bottom":208,"ax":56.0,"top":0,"W":111,"H":208},"gen0.walkA":{"r":[1069,284,56,108],"k":0.52,"bottom":207,"ax":53.0,"top":0,"W":108,"H":207},"gen0.walkB":{"r":[1127,284,57,108],"k":0.52,"bottom":208,"ax":55.0,"top":0,"W":109,"H":208},"gen0.talk":{"r":[1186,284,66,108],"k":0.52,"bottom":207,"ax":52.0,"top":0,"W":126,"H":207},"gen1.idle":{"r":[1254,284,67,108],"k":0.52,"bottom":208,"ax":62.0,"top":0,"W":128,"H":208},"gen1.walkA":{"r":[1323,284,69,108],"k":0.52,"bottom":207,"ax":63.0,"top":0,"W":132,"H":207},"gen2.idle":{"r":[1394,284,56,108],"k":0.52,"bottom":208,"ax":55.0,"top":0,"W":107,"H":208},"gen2.walkA":{"r":[0,407,57,108],"k":0.52,"bottom":208,"ax":54.0,"top":0,"W":110,"H":208},"gen1.walkB":{"r":[59,407,69,107],"k":0.52,"bottom":206,"ax":60.0,"top":0,"W":132,"H":206},"gen2.coffee":{"r":[130,407,58,107],"k":0.52,"bottom":206,"ax":52.0,"top":0,"W":112,"H":206},"gen2.talk":{"r":[190,407,68,107],"k":0.52,"bottom":205,"ax":53.0,"top":0,"W":130,"H":205},"gen1.coffee":{"r":[260,407,68,106],"k":0.52,"bottom":204,"ax":59.0,"top":0,"W":131,"H":204},"gen2.walkB":{"r":[330,407,57,106],"k":0.52,"bottom":204,"ax":54.0,"top":0,"W":109,"H":204},"hermes.lounge":{"r":[389,407,92,105],"k":0.6,"bottom":175,"ax":57.0,"top":0,"W":154,"H":175},"local.lounge":{"r":[483,407,101,105],"k":0.6,"bottom":175,"ax":59.0,"top":0,"W":168,"H":175},"gen1.talk":{"r":[586,407,76,105],"k":0.52,"bottom":202,"ax":60.0,"top":0,"W":146,"H":202},"gen2.type1":{"r":[664,407,75,101],"k":0.52,"bottom":193,"ax":52.0,"top":0,"W":145,"H":194},"gen0.type1":{"r":[741,407,75,100],"k":0.52,"bottom":192,"ax":53.0,"top":0,"W":144,"H":193},"gen0.type2":{"r":[818,407,70,100],"k":0.52,"bottom":192,"ax":53.0,"top":0,"W":135,"H":193},"biblio.lounge":{"r":[890,407,95,99],"k":0.6,"bottom":164,"ax":53.0,"top":1,"W":158,"H":165},"gen2.type2":{"r":[987,407,71,99],"k":0.52,"bottom":190,"ax":52.0,"top":0,"W":136,"H":191},"gen1.type1":{"r":[1060,407,83,98],"k":0.52,"bottom":188,"ax":55.0,"top":0,"W":159,"H":188},"gen1.type2":{"r":[1145,407,85,96],"k":0.52,"bottom":185,"ax":56.0,"top":0,"W":164,"H":185},"claude.lounge":{"r":[1232,407,83,89],"k":0.6,"bottom":148,"ax":49.0,"top":2,"W":139,"H":149},"gpt.lounge":{"r":[1317,407,79,88],"k":0.6,"bottom":146,"ax":42.0,"top":1,"W":132,"H":147},"gen0.lounge":{"r":[1398,407,79,88],"k":0.52,"bottom":168,"ax":53.0,"top":0,"W":152,"H":169},"gen2.lounge":{"r":[0,517,80,86],"k":0.52,"bottom":166,"ax":52.0,"top":0,"W":153,"H":166},"scr.pad":{"r":[82,517,159,86],"k":0.72,"screen":[44,105,92,13],"W":221,"H":120},"codex.lounge":{"r":[243,517,79,85],"k":0.6,"bottom":139,"ax":48.0,"top":2,"W":132,"H":141},"gen1.lounge":{"r":[324,517,80,83],"k":0.52,"bottom":159,"ax":47.0,"top":0,"W":153,"H":159}},"v":"f27c9397e1"}/*SPRITES:END*/;
  const SP = { img: null, ok: false };
  function spLoad() {
    if (SP.img || SP.fail || !SPR.f || /[?&]vector/.test(location.search)) return;
    const im = new Image(); im.decoding = "async";
    im.onload = () => { SP.ok = true; S.bg = null; if (S.L) { S.L.desks.forEach(d => d._g = null); if (S.D) sync(S.D); } };
    im.onerror = () => { SP.fail = true; };
    im.src = "office-sprites.webp?v=" + SPR.v; SP.img = im; roomLoad();
  }
  const spF = n => SP.ok ? SPR.f[n] : null;
  const ROOM = { img: null, ok: false };   // fondo de la sala (un WebP de ~20 KB): se carga aparte y, al llegar, se rehace el fondo
  function roomLoad() { if (ROOM.img || /[?&]vector/.test(location.search)) return; const im = new Image(); im.decoding = "async"; im.onload = () => { ROOM.ok = true; S.bg = null; }; im.src = "office-room.webp?v=" + SPR.v; ROOM.img = im; }
  // Partículas de energía gravitatoria (14 nov): sprites del juego CHF de Nawe, teñidos del color de cada nota.
  // Remolino (fx_viento) = la partícula; imán (fx_iman) = su estela de atracción; chispa (fx_chispa) = al llegar al orbe.
  const CHF = { v: "89d58f59e3", f: { swirl: [0, 0, 48, 48], pull: [50, 0, 48, 48], spark: [100, 0, 48, 48] }, img: null, ok: false, tint: new Map() };
  function chfLoad() {
    if (CHF.img || CHF.fail) return; const im = new Image(); im.decoding = "async";
    im.onload = () => { CHF.ok = true; }; im.onerror = () => { CHF.fail = true; }; im.src = "office-chf.webp?v=" + CHF.v; CHF.img = im;
  }
  function chfTinted(k, col) {   // copia teñida, una vez por color (8 niveles por canal)
    const [r, g, b] = hexRgb(col).map(v => Math.min(255, Math.round(v / 32) * 32)), key = k + ":" + r + "," + g + "," + b;
    let cv = CHF.tint.get(key); if (cv) return cv;
    const R = CHF.f[k]; cv = document.createElement("canvas"); cv.width = R[2]; cv.height = R[3]; const x = cv.getContext("2d");
    x.drawImage(CHF.img, R[0], R[1], R[2], R[3], 0, 0, R[2], R[3]); x.globalCompositeOperation = "source-atop"; x.fillStyle = `rgba(${r},${g},${b},.6)`; x.fillRect(0, 0, R[2], R[3]);
    if (CHF.tint.size > 240) CHF.tint.clear(); CHF.tint.set(key, cv); return cv;
  }
  function spImg(c, f, x0, y0, s) { const r = f.r; c.drawImage(SP.img, r[0], r[1], r[2], r[3], x0, y0, r[2] / f.k * s, r[3] / f.k * s); }
  // pieza centrada en x con el pie (su fila más baja) en y
  function spFoot(c, f, x, y, s) { spImg(c, f, x - f.W * s / 2, y - f.bottom * s, s); }
  const AG_S = () => S.L.wide ? .38 : .4;   // personajes: ~80 px de alto en la oficina
  // Mesa: el dibujo de la mesa manda dónde va la pantalla (ahí se pinta en vivo lo que hace el agente) y el asiento
  // Mesa flotante de cristal («500 años después»): tablero sobre una columna de luz y, encima del emisor, la pantalla
  // holográfica (ahí se pinta en vivo lo que hace el agente). El asiento queda a su izquierda, mirando al panel.
  function DG(dk) {
    if (dk._g) return dk._g;
    const dw = 146, x0 = dk.x + dk.w - dw - (S.L.wide ? 4 : 14), st = dk.y + dk.h - 50, sw = 74, sh = 42, sx = x0 + 80, sy = st - 36;
    return dk._g = { x0, dw, st, sx, sy, sw, sh, top: sy - sh / 2, seat: [x0 - 4, dk.y + dk.h - 44] };
  }
  // Puesto holográfico de cada zona (vista ancha; en el móvil siguen las fichas): plataforma, haz y panel flotante
  function ZG(k, z) {
    if (z._g) return z._g;
    if (z.chip) return (z._g = {});
    const cx = z.x + z.w / 2, qw = Math.min(z.w - 70, 86), qh = Math.round(qw * .6);
    return (z._g = { pad: { x: cx, y: z.y + z.h - 38, rx: z.w * .3, ry: 7 }, scr: { x: cx - qw / 2, y: z.y + 22, w: qw, h: qh } });
  }
  // Antes octógono (14 nov); Nawe pidió redondearlo el 17 nov. Se conserva el nombre «oct» para no tocar 36 llamadas.
  function oct(c, x, y, w, h, k) {   // desde la v2.89 es un rectángulo de esquinas redondeadas (radio «k»): las formas del rediseño son blandas
    k = Math.max(0, Math.min(k * 1.15, w / 2 - 1, h / 2 - 1)); c.beginPath();
    const q = (a, b, d, e) => c.arcTo ? c.arcTo(a, b, d, e, k) : c.lineTo(a, b);   /* sin arcTo (lienzos de prueba): esquinas rectas */
    c.moveTo(x + k, y); q(x + w, y, x + w, y + h); q(x + w, y + h, x, y + h); q(x, y + h, x, y); q(x, y, x + w, y); c.closePath();
  }
  const OCT = r => r * 1.25;   // de radio de esquina redondeada a corte de octógono
  function brFrame(c, x, y, w, h, r, col, a) {   // marco-membrana octogonal: borde luminoso y blando, como el de la bóveda
    const A = a == null ? .55 : a, k = OCT(r); c.lineJoin = "round";
    oct(c, x, y, w, h, k); c.strokeStyle = hexA(col, A * .16); c.lineWidth = 8; c.stroke();
    oct(c, x, y, w, h, k); c.strokeStyle = hexA(col, A * .45); c.lineWidth = 3; c.stroke();
    oct(c, x + 1.5, y + 1.5, w - 3, h - 3, Math.max(2, k - 1)); c.strokeStyle = `rgba(255,255,255,${A * .16})`; c.lineWidth = 1; c.stroke();
  }
  // Máscara de borde fundido con forma de octógono (se calcula una vez por tamaño): sumando octógonos cada vez más adentro
  function octMask(w, h, k, f) {
    const key = [w, h, k, f].map(Math.round).join("x"); S.octMasks = S.octMasks || {}; if (S.octMasks[key]) return S.octMasks[key];
    const m = document.createElement("canvas"); m.width = Math.max(1, Math.round(w)); m.height = Math.max(1, Math.round(h)); const c = m.getContext("2d");
    const N = 14; c.globalCompositeOperation = "lighter"; c.fillStyle = `rgba(0,0,0,${1 / N})`;
    for (let i = 0; i < N; i++) { const d = f * (i + .5) / N; oct(c, d, d, w - 2 * d, h - 2 * d, Math.max(0, k - d * .41)); c.fill(); }
    if (Object.keys(S.octMasks).length > 12) S.octMasks = {}; S.octMasks[key] = m; return m;
  }
  /* ───────── «500 años después» (14 nov): cristal oscuro, filos de neón y hologramas ─────────
     El mismo concepto de oficina (mesas, puestos, canales, espera, buzón, edificios), dibujado en código: sin créditos. */
  const TX = { text: "#f0ebe0", dim: "rgba(190,210,255,.66)", cyan: "#66d9ce" };
  function txGlass(c, x, y, w, h, k, col, a) {   // panel de cristal octogonal con filo de neón
    a = a == null ? 1 : a; oct(c, x, y, w, h, k);
    const g = c.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, `rgba(34,48,98,${.5 * a})`); g.addColorStop(1, `rgba(9,13,32,${.72 * a})`);
    c.fillStyle = g; c.fill(); c.lineJoin = "round";
    c.strokeStyle = hexA(col, .16 * a); c.lineWidth = 6; c.stroke();
    oct(c, x, y, w, h, k); c.strokeStyle = hexA(col, .7 * a); c.lineWidth = 1.3; c.stroke();
    c.strokeStyle = `rgba(255,255,255,${.14 * a})`; c.lineWidth = 1; c.beginPath(); c.moveTo(x + k + 3, y + 2.5); c.lineTo(x + w - k - 3, y + 2.5); c.stroke();
  }
  function txText(c, txt, x, y, size, col, align, ls) {   // rótulo de interfaz: espaciado, como un panel de mando
    c.font = `800 ${size}px Nunito, system-ui`; c.textAlign = align || "left"; c.fillStyle = col;
    const L = ls == null ? size * .12 : ls;
    if ("letterSpacing" in c) { c.letterSpacing = L.toFixed(1) + "px"; c.fillText(txt, x, y); c.letterSpacing = "0px"; } else c.fillText(txt, x, y);
  }
  function txSeg(c, x, y, w, h, v, col, n) {   // barra segmentada (0–100)
    const N = n || 12, gap = 2, sw = (w - gap * (N - 1)) / N, on = Math.round(clamp(v, 0, 100) / 100 * N);
    for (let i = 0; i < N; i++) { c.fillStyle = i < on ? col : "rgba(255,255,255,.08)"; c.fillRect(x + i * (sw + gap), y, sw, h); }
  }
  function txBeam(c, x, y, r, q, col, a) {   // haz de un emisor a su panel holográfico
    const g = c.createLinearGradient(0, y, 0, q.y + q.h); g.addColorStop(0, hexA(col, a)); g.addColorStop(1, hexA(col, a * .2));
    c.fillStyle = g; c.beginPath(); c.moveTo(x - r, y); c.lineTo(q.x + 4, q.y + q.h); c.lineTo(q.x + q.w - 4, q.y + q.h); c.lineTo(x + r, y); c.closePath(); c.fill();
  }
  function txBubble(c, cx, y, w, h, col, tx) {   // bocadillo holográfico: cristal oscuro con el filo del color de quien habla
    const x = cx - w / 2, f = "rgba(10,15,38,.93)";
    oct(c, x, y, w, h, 7); c.fillStyle = f; c.fill(); c.strokeStyle = hexA(col, .2); c.lineWidth = 5; c.stroke();
    c.beginPath(); c.moveTo(tx - 6, y + h - .5); c.lineTo(tx - 1, y + h + 9); c.lineTo(tx + 6, y + h - .5); c.fillStyle = f; c.fill(); c.strokeStyle = hexA(col, .85); c.lineWidth = 1.3; c.stroke();
    oct(c, x, y, w, h, 7); c.stroke(); c.fillStyle = f; c.fillRect(tx - 5, y + h - 2.5, 10, 3.2);
  }
  const PNEON = ["#66d9ce", "#aa9de8", "#7fd3a6", "#f2b77a", "#ff6fb5", "#efe2a4"];
  const SEGC = { base: "#f0ebe0", done: "#66d9ce", arts: "#c084fc", proud: "#f2c078", saved: "#8aa0d6" };   // segmentos de las agujas
  const PFH = () => Math.min(13, (S.L.proj.h - 130) / 12);   // alto de un segmento (12 como mucho: la aguja no pisa el rótulo)
  // Personaje genérico: ropa gris en el dibujo, teñida aquí del color que toque (una vez por pose y color; luego es una imagen más)
  const GENC = ["#66d9ce", "#f29b7d", "#aa9de8", "#ffd27a", "#9cc4ee", "#9be38a"], GEN = new Map();
  function genTint(f, col) {
    const key = f.r.join(",") + col; let cv = GEN.get(key); if (cv) return cv;
    const [x, y, w, h] = f.r; cv = document.createElement("canvas"); cv.width = w; cv.height = h; const g = cv.getContext("2d", { willReadFrequently: true }); g.drawImage(SP.img, x, y, w, h, 0, 0, w, h);
    try { const d = g.getImageData(0, 0, w, h), p = d.data, T = hexRgb(col);
      for (let i = 0; i < p.length; i += 4) { if (p[i + 3] < 30) continue; const mx = Math.max(p[i], p[i + 1], p[i + 2]), mn = Math.min(p[i], p[i + 1], p[i + 2]);
        if (mx > 105 && mx - mn < 26) { const l = Math.min(1.12, mx / 205); p[i] = Math.min(255, T[0] * l); p[i + 1] = Math.min(255, T[1] * l); p[i + 2] = Math.min(255, T[2] * l); } }   // gris claro = ropa; piel, pelo, silla y contorno no se tocan
      g.putImageData(d, 0, 0); } catch (e) { /* sin acceso a píxeles: se queda en gris */ }
    GEN.set(key, cv); return cv;
  }
  // Cabeza de un agente (recorte de su dibujo de pie), para enseñar quién está en cada proyecto
  function agHead(c, a, x, y, sz) {
    if (!SP.ok) return false; let B = isBiblio(a) ? "biblio" : a.brand, tint = null;
    if (!SPR.f[B + ".idle"] && SPR.f["gen0.idle"]) { let h = 0; for (const ch of String(a.name || a.id)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; tint = B !== "agent" && BRANDS[B] ? BRANDS[B].c : GENC[h % GENC.length]; B = "gen" + (h >> 3) % 3; }
    const f = SPR.f[B + ".idle"]; if (!f) return false; const r = f.r, hh = r[3] * .5, k = sz / r[2];
    if (tint) c.drawImage(genTint(f, tint), 0, 0, r[2], hh, x - sz / 2, y - hh * k, sz, hh * k); else c.drawImage(SP.img, r[0], r[1], r[2], hh, x - sz / 2, y - hh * k, sz, hh * k);
    return true;
  }
  function spAgent(c, a, t, x, foot, seated, bob) {
    let B = isBiblio(a) ? "biblio" : a.brand, tint = null;
    if (SP.ok && !SPR.f[B + ".idle"] && SPR.f["gen0.idle"]) {   // sin dibujo propio: personaje genérico, con una de tres cabezas y la ropa del color de su marca
      let h = 0; for (const ch of String(a.name || a.id)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
      tint = B !== "agent" && BRANDS[B] ? BRANDS[B].c : GENC[h % GENC.length]; B = "gen" + (h >> 3) % 3; }
    const base = SP.ok && SPR.f[B + ".idle"]; if (!base) return false;
    const s = AG_S(), chat = a.task && a.task.mode === "chat" && a.chatWith && dist(a) < 2;
    let pose = "idle", flip = false;
    if (a.walking) { pose = ["walkA", "idle", "walkB", "idle"][Math.floor(t * 6 + a.ph * 3) % 4]; flip = a.tx < a.x; }
    else if (chat) { pose = "talk"; flip = a.chatWith.x < a.x; }
    else if (seated && a.st === "work") { const bt = a.beat != null ? Math.max(0, 1 - (t - a.beat) / 3) : 0; pose = S.reduce || Math.sin(t * (6 + 10 * bt) + a.ph) > 0 ? "type1" : "type2"; }
    const f = SPR.f[B + "." + pose] || base;
    if (seated && a.st === "work") {   // la silla viene en el dibujo: solo su luz en el suelo, del color de la marca
      const col = tint || (BRANDS[B] || BRANDS.hermes).c; c.fillStyle = hexA(col, .2); c.beginPath(); c.ellipse(x, foot - 1, 19, 4.5, 0, 0, 7); c.fill();
    }
    if (pose === "lounge") foot -= 6;
    c.save(); c.translate(x, foot - bob); if (flip) c.scale(-1, 1);
    if (tint) { const cv = genTint(f, tint); c.drawImage(cv, -f.ax * s, -f.bottom * s, f.r[2] / f.k * s, f.r[3] / f.k * s); } else spImg(c, f, -f.ax * s, -f.bottom * s, s);
    c.restore();
    return true;
  }

  /* ───────── iconos de zona ───────── */
  function icon(c, k, x, y, s, col) {
    c.save(); c.translate(x, y); c.scale(s, s); c.strokeStyle = col; c.fillStyle = col; c.lineWidth = 2.6; c.lineCap = "round"; c.lineJoin = "round";
    switch (k) {
      case "obsidian": for (let i = 0; i < 3; i++) { rr(c, -14 + i * 9, -14 + (i === 1 ? -3 : 0), 7, 28 - (i === 1 ? -3 : 0), 2); c.stroke(); } c.beginPath(); c.moveTo(-17, 16); c.lineTo(17, 16); c.stroke(); break;
      case "web": c.beginPath(); c.arc(0, 0, 15, 0, 7); c.stroke(); c.beginPath(); c.ellipse(0, 0, 6, 15, 0, 0, 7); c.stroke(); c.beginPath(); c.moveTo(-15, 0); c.lineTo(15, 0); c.stroke(); break;
      case "write": c.beginPath(); c.moveTo(-12, 14); c.lineTo(-14, 6); c.lineTo(8, -16); c.lineTo(14, -10); c.lineTo(-8, 12); c.closePath(); c.stroke(); break;
      case "mail": rr(c, -16, -11, 32, 22, 3); c.stroke(); c.beginPath(); c.moveTo(-16, -9); c.lineTo(0, 3); c.lineTo(16, -9); c.stroke(); break;
      case "code": c.beginPath(); c.moveTo(-8, -10); c.lineTo(-16, 0); c.lineTo(-8, 10); c.moveTo(8, -10); c.lineTo(16, 0); c.lineTo(8, 10); c.moveTo(3, -13); c.lineTo(-3, 13); c.stroke(); break;
      case "edit": rr(c, -16, -11, 32, 22, 3); c.stroke(); c.beginPath(); c.moveTo(-4, -6); c.lineTo(6, 0); c.lineTo(-4, 6); c.closePath(); c.fill(); break;
      case "skills": c.beginPath(); c.moveTo(-12, 12); c.lineTo(4, -4); c.stroke(); c.beginPath(); c.arc(8, -8, 7, Math.PI * .9, Math.PI * 2.6); c.stroke(); break;
      case "voice": for (let i = 0; i < 5; i++) { const hh = [6, 13, 9, 15, 5][i]; c.beginPath(); c.moveTo(-14 + i * 7, -hh); c.lineTo(-14 + i * 7, hh); c.stroke(); } break;
      case "image": rr(c, -15, -12, 30, 24, 3); c.stroke(); c.beginPath(); c.arc(-6, -4, 3, 0, 7); c.fill(); c.beginPath(); c.moveTo(-13, 9); c.lineTo(-2, 0); c.lineTo(4, 5); c.lineTo(9, 1); c.lineTo(14, 8); c.stroke(); break;
      case "system": for (let i = 0; i < 3; i++) { rr(c, -13, -14 + i * 10, 26, 7, 2); c.stroke(); c.fillRect(6, -12 + i * 10, 3, 3); } break;
      case "queue": rr(c, -14, -9, 28, 18, 3); c.stroke(); c.beginPath(); c.moveTo(-4, -9); c.lineTo(-4, 9); c.stroke(); break;
      case "rest": rr(c, -12, -6, 20, 18, 4); c.stroke(); c.beginPath(); c.arc(10, 2, 5, -1.4, 1.4); c.stroke(); c.beginPath(); c.moveTo(-6, -10); c.quadraticCurveTo(-2, -15, -6, -20); c.moveTo(2, -10); c.quadraticCurveTo(6, -15, 2, -20); c.stroke(); break;
      case "work": rr(c, -15, -12, 30, 20, 3); c.stroke(); c.beginPath(); c.moveTo(-6, 14); c.lineTo(6, 14); c.moveTo(0, 8); c.lineTo(0, 14); c.stroke(); break;
      case "box": rr(c, -15, -8, 30, 20, 3); c.stroke(); c.beginPath(); c.moveTo(-8, -8); c.lineTo(-8, -14); c.lineTo(8, -14); c.lineTo(8, -8); c.stroke(); break;
      case "bulb": c.beginPath(); c.arc(0, -4, 9, Math.PI * .8, Math.PI * 2.2); c.stroke(); c.beginPath(); c.moveTo(-4, 6); c.lineTo(4, 6); c.moveTo(-3, 10); c.lineTo(3, 10); c.stroke(); break;
    }
    c.restore();
  }

  /* ───────── fondo estático (cacheado) ───────── */
  function buildBg() {
    const L = S.L, cv = document.createElement("canvas"), Rz = S.bgR || 1; cv.width = Math.round(L.W * Rz); cv.height = Math.round(L.H * Rz);
    const c = cv.getContext("2d"); c.scale(Rz, Rz); c.imageSmoothingQuality = "high";
    const g = c.createLinearGradient(0, 0, 0, L.H); g.addColorStop(0, "#141a24"); g.addColorStop(1, "#1c2532"); c.fillStyle = g; c.fillRect(0, 0, L.W, L.H);
    const room = ROOM.ok && ROOM.img;
    if (room) { const k = Math.max(L.W / room.width, L.H / room.height), w = room.width * k, h = room.height * k; c.drawImage(room, (L.W - w) / 2, (L.H - h) * .35, w, h);
      c.fillStyle = "rgba(12,16,30,.32)"; c.fillRect(0, 0, L.W, L.H); }   // sala ilustrada (escenografía): velo oscuro para que no compita con los datos
    // suelo de cristal oscuro con rejilla fina y anillo interior («500 años después»)
    const fl = { x: L.wide ? 200 : 4, y: L.wide ? 92 : 208, w: L.wide ? L.W - 400 : L.W - 8, h: L.wide ? 536 : 516 };
    const fg = c.createLinearGradient(0, fl.y, 0, fl.y + fl.h); fg.addColorStop(0, "#222c3a"); fg.addColorStop(1, "#1a2230");
    c.globalAlpha = room ? .5 : 1; c.fillStyle = fg; oct(c, fl.x, fl.y, fl.w, fl.h, 44); c.fill(); c.globalAlpha = room ? .35 : 1;   // con la sala, el suelo deja verla y la rejilla casi desaparece
    c.save(); oct(c, fl.x, fl.y, fl.w, fl.h, 44); c.clip(); c.strokeStyle = "rgba(102,217,206,.04)"; c.lineWidth = 1; c.beginPath();
    for (let x = fl.x + 20; x < fl.x + fl.w; x += 40) { c.moveTo(x, fl.y); c.lineTo(x, fl.y + fl.h); }
    for (let y = fl.y + 20; y < fl.y + fl.h; y += 40) { c.moveTo(fl.x, y); c.lineTo(fl.x + fl.w, y); }
    c.stroke(); c.fillStyle = "rgba(102,217,206,.13)";
    for (let x = fl.x + 20; x < fl.x + fl.w; x += 40) for (let y = fl.y + 20; y < fl.y + fl.h; y += 40) c.fillRect(x - 1, y - 1, 2, 2);
    c.restore(); c.globalAlpha = 1;
    oct(c, fl.x, fl.y, fl.w, fl.h, 44); c.strokeStyle = "rgba(102,217,206,.16)"; c.lineWidth = 1.5; c.stroke();
    oct(c, fl.x + 10, fl.y + 10, fl.w - 20, fl.h - 20, 38); c.strokeStyle = "rgba(102,217,206,.06)"; c.lineWidth = 1; c.stroke();
    glow(c, L.W / 2, fl.y + fl.h * .5, fl.w * .55, "#7c8cff", .07);
    // puestos de zona (apagados): plataforma, haz tenue y panel holográfico con su símbolo (se encienden en vivo)
    for (const [k, z] of Object.entries(L.zones)) {
      if (k === "obsidian") continue;
      const zc = ZONES[k].c; txGlass(c, z.x, z.y, z.w, z.h, OCT(z.chip ? 12 : 22), zc, .75);
      if (z.chip) { icon(c, k, z.x + 25, z.y + z.h / 2, .72, hexA(zc, .8)); txText(c, ZONES[k].label, z.x + 46, z.y + z.h / 2 + 6, 15, "rgba(230,240,255,.86)", "left", .3); continue; }
      const zg = ZG(k, z), q = zg.scr, P = zg.pad;
      c.fillStyle = "rgba(4,7,20,.9)"; c.beginPath(); c.ellipse(P.x, P.y, P.rx, P.ry, 0, 0, 7); c.fill(); c.strokeStyle = hexA(zc, .5); c.lineWidth = 1.5; c.stroke();
      c.strokeStyle = hexA(zc, .22); c.lineWidth = 1; c.beginPath(); c.ellipse(P.x, P.y, P.rx * .6, P.ry * .6, 0, 0, 7); c.stroke();
      txBeam(c, P.x, P.y, P.rx * .5, q, zc, .1);
      oct(c, q.x, q.y, q.w, q.h, 7); c.fillStyle = hexA(zc, .07); c.fill(); c.strokeStyle = hexA(zc, .42); c.lineWidth = 1.2; c.stroke();
      icon(c, k, q.x + q.w / 2, q.y + q.h / 2, Math.min(1, q.h / 40), hexA(zc, .62));
      txText(c, ZONES[k].label.toUpperCase(), z.x + z.w / 2, z.y + z.h - 12, L.wide ? 13 : 12, "rgba(230,240,255,.84)", "center", 1.6);
    }
    // bóveda: marco del grafo (los nodos se dibujan en vivo)
    const v = L.vault, vc = ZONES.obsidian.c, vr = VOCT(v) / 1.25;   // octógono regular sobre el lado corto
    glow(c, v.x + v.w / 2, v.y + v.h / 2, Math.max(v.w, v.h) * .75, vc, .16);   // luz que la bóveda echa a la sala
    { const g = c.createRadialGradient(v.x + v.w / 2, v.y + v.h * .45, 10, v.x + v.w / 2, v.y + v.h / 2, Math.max(v.w, v.h) * .6);
      g.addColorStop(0, "#1f1846"); g.addColorStop(1, "#0d0a20"); c.fillStyle = g; oct(c, v.x, v.y, v.w, v.h, VOCT(v)); c.fill(); }
    brFrame(c, v.x, v.y, v.w, v.h, vr, vc, .7);
    icon(c, "obsidian", v.x + v.w / 2 - 34, v.y + 22, .6, hexA(vc, .85));
    txText(c, "BÓVEDA", v.x + v.w / 2 - 18, v.y + 28, L.wide ? 15 : 13, "rgba(230,235,255,.9)", "left", 2);
    // proyectos: ciudad holográfica de noche, horizonte de neón y suelo con rejilla en perspectiva
    const p = L.proj; txGlass(c, p.x, p.y, p.w, p.h, OCT(24), "#66d9ce", .8);
    { c.save(); oct(c, p.x + 5, p.y + 5, p.w - 10, p.h - 10, OCT(20)); c.clip();
      const hz = p.y + p.h - 66, sky = c.createLinearGradient(0, p.y, 0, hz); sky.addColorStop(0, "#0a1030"); sky.addColorStop(1, "#1c1652");
      c.fillStyle = sky; c.fillRect(p.x, p.y, p.w, hz - p.y);
      for (let i = 0; i < 16; i++) { c.fillStyle = `rgba(200,220,255,${.22 + (i % 3) * .14})`; c.fillRect(p.x + 24 + (i * 47) % (p.w - 48), p.y + 14 + (i * 23) % 52, 1.5, 1.5); }
      let sx = p.x, seed = 7; const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
      while (sx < p.x + p.w) {   // siluetas lejanas
        const w = 12 + rnd() * 24, h = 10 + rnd() * 44; c.fillStyle = "rgba(110,120,255,.09)"; c.fillRect(sx, hz - h, w - 3, h);
        c.fillStyle = "rgba(102,217,206,.18)"; c.fillRect(sx, hz - h, w - 3, 1); if (rnd() < .4) { c.fillStyle = "rgba(255,120,210,.35)"; c.fillRect(sx + (w - 3) / 2 - .5, hz - h - 5, 1, 5); }
        sx += w; }
      const hg = c.createLinearGradient(0, hz - 16, 0, hz + 2); hg.addColorStop(0, "rgba(255,110,200,0)"); hg.addColorStop(1, "rgba(255,110,200,.24)"); c.fillStyle = hg; c.fillRect(p.x, hz - 16, p.w, 18);
      c.fillStyle = "#070b1e"; c.fillRect(p.x, hz, p.w, p.y + p.h - hz);
      c.strokeStyle = "rgba(102,217,206,.15)"; c.lineWidth = 1; c.beginPath(); const vx = p.x + p.w / 2, depth = p.y + p.h - hz;
      for (let i = -16; i <= 16; i++) { c.moveTo(vx + i * 16, hz); c.lineTo(vx + i * 80, p.y + p.h); }
      for (let j = 1; j < 7; j++) { const y = hz + depth * Math.pow(j / 7, 1.7); c.moveTo(p.x, y); c.lineTo(p.x + p.w, y); }
      c.stroke(); c.fillStyle = "rgba(255,150,230,.45)"; c.fillRect(p.x, hz, p.w, 1);
      c.restore(); }
    txText(c, "PROYECTOS", p.x + 22, p.y + 30, L.wide ? 14 : 13, TX.text, "left", 2.4);
    { let lx = p.x + 22; const ly = p.y + 47; c.font = "700 11px Nunito, system-ui";   // leyenda: qué es cada segmento
      for (const [lab, k] of [["entregas", "done"], ["artefactos", "arts"], ["orgullo ×2", "proud"]]) {
        oct(c, lx, ly - 8, 9, 9, 2.5); c.fillStyle = hexA(SEGC[k], .3); c.fill(); c.strokeStyle = SEGC[k]; c.lineWidth = 1; c.stroke();
        c.fillStyle = TX.dim; c.textAlign = "left"; c.font = "700 11px Nunito, system-ui"; c.fillText(lab, lx + 13, ly); lx += 13 + c.measureText(lab).width + 14; } }
    // entrada: canales y espera
    const d = L.door; txGlass(c, d.x, d.y, d.w, d.h, OCT(22), "#efe2a4", .6);
    const bx = BOX(); if (L.wide) txText(c, "BUZÓN", bx.x, bx.y + 72, 10.5, TX.dim, "center", 1.6);

    // mesas (vacías)
    L.desks.forEach(dk => drawDeskBase(c, dk));
    S.bg = cv;
  }
  function BOX() { const d = S.L.door; return S.L.wide ? { x: d.x + d.w - 52, y: d.y + d.h - 74 } : { x: d.x + d.w - 40, y: d.y + d.h - 62 }; }
  function SOFA_W() { return S.L.wide ? 180 : 160; }
  function drawDeskBase(c, dk) {
    const G = DG(dk), y1 = dk.y + dk.h - 8, x1 = G.x0 + 12, x2 = G.x0 + G.dw - 6, mx = (x1 + x2) / 2;
    const dsp = spF("scr.deskscreen");
    if (dsp) { const k = .53, sc = dsp.screen, ox = G.sx - (sc[0] + sc[2] / 2) * k, oy = G.sy - (sc[1] + sc[3] / 2) * k + 3;
      c.fillStyle = "rgba(8,10,18,.32)"; c.beginPath(); c.ellipse(ox + dsp.W * k * .5, oy + dsp.H * k - 3, dsp.W * k * .46, 6, 0, 0, 7); c.fill(); spImg(c, dsp, ox, oy, k); return; }
    // sombra y anillo en el suelo; columna de luz que la sostiene
    c.fillStyle = "rgba(0,0,0,.3)"; c.beginPath(); c.ellipse(mx, y1, (x2 - x1) * .45, 6, 0, 0, 7); c.fill();
    c.strokeStyle = "rgba(102,217,206,.16)"; c.lineWidth = 1; c.beginPath(); c.ellipse(mx, y1, (x2 - x1) * .28, 4, 0, 0, 7); c.stroke();
    const pg = c.createLinearGradient(0, G.st + 8, 0, y1); pg.addColorStop(0, "rgba(102,217,206,.34)"); pg.addColorStop(1, "rgba(102,217,206,0)");
    c.fillStyle = pg; c.fillRect(mx - 2, G.st + 8, 4, y1 - G.st - 8);
    // tablero de cristal
    const tg = c.createLinearGradient(0, G.st, 0, G.st + 9); tg.addColorStop(0, "rgba(96,128,220,.6)"); tg.addColorStop(1, "rgba(18,26,62,.92)");
    c.fillStyle = tg; c.beginPath(); c.moveTo(x1 + 6, G.st); c.lineTo(x2, G.st); c.lineTo(x2 - 6, G.st + 9); c.lineTo(x1, G.st + 9); c.closePath(); c.fill();
    c.strokeStyle = "rgba(102,217,206,.62)"; c.lineWidth = 1.2; c.beginPath(); c.moveTo(x1 + 6, G.st); c.lineTo(x2, G.st); c.stroke();
    c.strokeStyle = "rgba(102,217,206,.2)"; c.beginPath(); c.moveTo(x1, G.st + 9); c.lineTo(x2 - 6, G.st + 9); c.stroke();
    // teclado de luz y emisor del panel
    c.fillStyle = "rgba(102,217,206,.2)"; c.fillRect(x1 + 14, G.st + 3, 32, 2);
    c.fillStyle = "#121a3a"; c.beginPath(); c.ellipse(G.sx, G.st - 1, 9, 3, 0, 0, 7); c.fill(); c.strokeStyle = "rgba(102,217,206,.5)"; c.lineWidth = 1; c.stroke();
    // panel apagado
    oct(c, G.sx - G.sw / 2, G.sy - G.sh / 2, G.sw, G.sh, 6); c.fillStyle = "rgba(102,217,206,.04)"; c.fill(); c.strokeStyle = "rgba(102,217,206,.22)"; c.stroke();
  }
  /* ───────── datos → agentes ───────── */
  function buildAgents(D) {
    const out = [], used = new Set(), nowT = Date.now(), counter = {};
    const exLabel = k => (D.executors && D.executors[k] && D.executors[k].label) || k;
    const named = (D.agents || []).map(a => ({ ...a, brand: a.brand || brandOf(a.name), busy: a.state === "run" }));
    (D.orders || []).forEach(o => {
      const b = brandOf(o.executor + " " + exLabel(o.executor));
      const age = o.finished ? (nowT - new Date(o.finished)) / 60000 : 1e9;
      if (o.state === "done" && age < 3 && !S.seenDone.has(o.id)) { S.seenDone.add(o.id); S.pendingDeliveries = (S.pendingDeliveries || []).concat([{ brand: b, project: o.project, title: o.title }]); }
      if (o.state !== "running" && o.state !== "queued") return;
      const host = o.state === "running" ? named.find(a => a.brand === b && a.busy && !used.has(a.name)) : null;
      counter[b] = (counter[b] || 0) + 1; if (host) used.add(host.name);
      out.push({ id: host ? "a:" + host.name : "o:" + o.id, name: host ? host.name : (BRANDS[b] || BRANDS.hermes).label + " " + counter[b], brand: b,
        role: o.role || roleOf(o.text, b), st: o.state === "running" ? "work" : "queue", label: o.title || o.text, project: o.project, reason: o.reason,
        action: o.action || (host && host.action), example: o.example, cloud: !!(host && host.cloud), prio: o.priority });
    });
    (D.running || []).forEach(r => {
      if (used.has(r.agent)) return; used.add(r.agent); const b = brandOf(r.agent || r.name);
      // si su agente no está escribiendo ahora, la tarea corre en segundo plano y él descansa
      const host = named.find(a => a.name === r.agent), bgTask = host && !host.busy;
      out.push({ id: "r:" + r.id, name: r.agent || r.name, brand: b, role: r.role || roleOf(r.name + " " + (r.step || ""), b), st: bgTask ? "bg" : "work", label: r.name, pct: r.pct, project: r.project, action: r.action, step: r.step, example: r.example, expert: r.expert || (host && host.expert), cloud: !!(r.cloud || (host && host.cloud)) });
    });
    named.forEach(a => {
      if (used.has(a.name)) return;  // todos salen; dónde, según lo que hacen de verdad
      const off = a.state === "off" || a.state === "bad" || a.state === "warn";
      const bg = !a.busy && !off && (a.bg || (D.running || []).some(r => r.agent === a.name));
      const lbl = off ? (a.state === "off" ? "apagado" : "sin señal") + (a.task ? " · " + a.task : "") : a.done ? "hecho · " + (a.task || "") : a.task;
      out.push({ id: "a:" + a.name, name: a.name, brand: a.brand, role: a.role || roleOf(a.task, a.brand), st: a.busy ? "work" : bg ? "bg" : off ? "off" : a.done ? "done" : "idle",
        label: lbl, step: a.step, tasks: a.tasks, expert: a.expert, project: a.project || guessProject(a.task, D), action: a.action, example: a.example, cloud: !!a.cloud, live: !!a.live, pct: a.pct, seen: a.seen || a.at });
    });
    out.forEach(a => { if (!a.project) a.project = guessProject(a.label, D); });
    return out;
  }
  function guessProject(t, D) {
    t = (t || "").toLowerCase(); const ps = D.projects || [];
    for (const p of ps) if (t.includes(String(p.id).toLowerCase()) || t.includes(String(p.name).toLowerCase())) return p.id;
    if (/correo|productora|campaña|cliente|propuesta/.test(t)) return ps.find(p => p.id === "ingresos") ? "ingresos" : null;
    if (/juego|itch/.test(t)) return ps.find(p => p.id === "chf") ? "chf" : null;
    return null;
  }

  /* ───────── posiciones ───────── */
  function deskFor(id) {
    if (S.deskOf.has(id)) return S.deskOf.get(id);
    const taken = new Set(S.deskOf.values()); let i = 0; while (taken.has(i) && i < S.L.desks.length) i++;
    if (i >= S.L.desks.length) return null; S.deskOf.set(id, i); return i;
  }
  function seatPos(a) { const dk = a.desk == null ? null : S.L.desks[a.desk]; return dk ? DG(dk).seat : hostSpot(); }
  function restSpot(i) {
    const r = S.L.rest, sw = SOFA_W(), spots = [[r.x + 64, r.y + r.h - 96], [r.x + 34 + sw / 2, r.y + r.h - 96], [r.x + 4 + sw, r.y + r.h - 96], [r.x + sw + 40, r.y + r.h - 150], [r.x + 100, r.y + r.h - 170], [r.x + 160, r.y + r.h - 175], [r.x + 50, r.y + r.h - 160]];
    return spots[i % spots.length];
  }
  function queueSpot(i) { const d = S.L.door; return [d.x + d.w - 30 - (i % 6) * 40, d.y - 22]; }
  function agSrc(ag) {   // de dónde sale lo que hace un agente: su pantalla si está sentado; si no, su cabeza
    const dk = ag.desk != null ? S.L.desks[ag.desk] : null; if (!dk) return [ag.x, ag.y - 50];
    const sp = DG(dk).seat; return !ag.walking && Math.hypot(ag.x - sp[0], ag.y - sp[1]) < 6 ? [DG(dk).sx, DG(dk).top] : [ag.x, ag.y - 50];
  }
  function vaultSpot(ag) {   // delante de la bóveda, abajo, repartidos por su ancho (como quien mira un acuario)
    const v = S.L.vault, ids = [...S.ag.values()].filter(a => a.st === "work" && a.zone === "obsidian").map(a => a.id).sort();
    const i = Math.max(0, ids.indexOf(ag.id)), n = Math.max(1, ids.length), k = n === 1 ? .5 : .2 + .6 * i / (n - 1);
    return [v.x + v.w * k, v.y + v.h - 34];
  }
  function hostSpot() { const d = S.L.door; return [d.x + d.w / 2, d.y + d.h - 34]; }

  const PRANK = { alta: 0, normal: 1, baja: 2, noche: 3 };
  const CAT = { work: 0, bg: 1, idle: 2 };
  function sync(D) {
    S.D = D; const list = buildAgents(D), seen = new Set(); let ri = 0, qi = 0; const t = now(); gpuUsers();
    // prioridad: trabajando (por prioridad de la orden y avance) > tarea en segundo plano > libre; el resto, al banquillo
    const ranked = list.filter(a => a.st === "work").sort((a, b) => CAT[a.st] - CAT[b.st] || (PRANK[a.prio] ?? 1) - (PRANK[b.prio] ?? 1)
      || (b.pct || 0) - (a.pct || 0) || String(a.name).localeCompare(String(b.name)));
    // Mesas estables: quien ya tiene mesa la conserva; los nuevos ocupan la mejor libre. Solo se reordena si alguien que
    // trabaja se queda sin mesa (entonces cede la suya quien esté libre) o, como mucho cada 45 s, para acercar al faro a quien trabaja.
    const N = S.L.desks.length, keep = ranked.slice(0, N), prev = S.deskOf, deskOf = new Map(), used = new Set();
    keep.forEach(a => { const d = prev.get(a.id); if (d != null && !used.has(d)) { deskOf.set(a.id, d); used.add(d); } });
    keep.forEach(a => { if (deskOf.has(a.id)) return; const d = S.L.deskRank.find(x => !used.has(x)); if (d != null) { deskOf.set(a.id, d); used.add(d); } });
    const t0 = now(); if (!S.lastSwap || t0 - S.lastSwap > 45) {
      const rk = d => S.L.deskRank.indexOf(d);
      const w = keep.filter(a => a.st === "work").sort((a, b) => rk(deskOf.get(b.id)) - rk(deskOf.get(a.id)))[0];
      const i = keep.filter(a => a.st === "idle").sort((a, b) => rk(deskOf.get(a.id)) - rk(deskOf.get(b.id)))[0];
      if (w && i && rk(deskOf.get(i.id)) < rk(deskOf.get(w.id))) { const dw = deskOf.get(w.id); deskOf.set(w.id, deskOf.get(i.id)); deskOf.set(i.id, dw); S.lastSwap = t0; }
    }
    S.deskOf = deskOf;
    S.bench = list.filter(a => !(a.st in CAT && deskOf.has(a.id)) && a.st !== "queue").map(a => ({ name: a.name, brand: a.brand, off: a.st === "off", done: a.st === "done", cloud: a.cloud, label: a.label }));
    const prevSig = S.sig || {}; S.sig = {};
    list.forEach(a => {
      if (!deskOf.has(a.id)) return;
      const cur = S.ag.get(a.id);
      const ag = cur || { ...a, x: 0, y: 0, tx: 0, ty: 0, ph: Math.random() * 6, zone: null, mode: "", bubble: null };
      const prevDesk = cur ? cur.desk : null;
      Object.assign(ag, a); ag.desk = deskOf.has(a.id) ? deskOf.get(a.id) : null; ag.leaving = 0; ag.tpOut = 0;
      let target;
      if (a.st === "work" || a.st === "bg") { const ak = String(a.action || "").toLowerCase(); ag.zone = ACTION_ZONE[ak] || (SCRIPTS[ag.role] || SCRIPTS.thinking).slice(-1)[0]; ag.real = !!ACTION_ZONE[ak]; }
      if (a.st === "work" || a.st === "idle") target = seatPos(ag);
      else if (a.st === "bg") target = restSpot(ri++);
      else target = queueSpot(qi++);
      // llegan teletransportados a su mesa (ya nadie entra andando); si le cambian de mesa, salta a la nueva igual
      const jump = !cur || (cur && prevDesk != null && ag.desk != null && prevDesk !== ag.desk);
      if (!ag.task || ag.task.mode === "home") { ag.home = target; if (jump) { ag.x = target[0]; ag.y = target[1]; ag.walking = false; if (S.primed && !S.reduce) ag.tpIn = now(); } goTo(ag, target); }
      else ag.home = target;
      if (a.st === "work" || a.st === "bg") { const ak = String(a.action || "").toLowerCase(); ag.zone = ACTION_ZONE[ak] || (SCRIPTS[ag.role] || SCRIPTS.thinking).slice(-1)[0]; ag.real = !!ACTION_ZONE[ak]; }
      else ag.zone = null;
      // la información sube por el faro: cada cambio real de un agente (estado, tarea, avance) es una chispa hacia la torre
      const sig = [a.st, a.label, Math.round(a.pct || 0), a.action].join("|"); S.sig[a.id] = sig;
      if (prevSig[a.id] !== undefined && prevSig[a.id] !== sig) emitSpark(ag, a);
      if (!cur) chanFlash(a);
      S.ag.set(a.id, ag); seen.add(a.id);
    });
    // quien deja de trabajar se va: deja libre su mesa y sale andando por la entrada (luego aparece en el banquillo)
    for (const k of [...S.ag.keys()]) if (!seen.has(k)) { const g = S.ag.get(k);
      if (!S.primed || S.reduce) { S.ag.delete(k); continue; }
      if (!g.leaving) { g.leaving = g.tpOut = now(); g.zone = null; g.st = "leave"; g.task = null; g.chatWith = null; g.tx = g.x; g.ty = g.y; g.walking = false; } }   // se desmaterializa donde está
    S.primed = true;
    // entregas reales
    (S.pendingDeliveries || []).forEach(dl => {
      const who = [...S.ag.values()].find(a => a.brand === dl.brand && a.st === "work") || [...S.ag.values()].find(a => a.brand === dl.brand);
      if (who && dl.project) sendPacket(who, dl.project, true);
    });
    S.pendingDeliveries = [];
    // buzón: el número baja al instante (descartes, respuestas); sube cuando el agente llega con la carta
    const open = (D.suggestions || []).filter(s => s.state === "open").length;
    if (S.boxShown == null || open < S.boxShown) S.boxShown = open;
    S.lastSugg = open;
    // mensajes reales → escenas
    const chat = D.chat || []; S.seenMsg = S.seenMsg || new Set();
    if (!S.chatPrimed) { S.chatPrimed = true; const recent = Date.now() - 2 * 60000;
      chat.forEach(m => { if (new Date(m.at) < recent) S.seenMsg.add(m.id); }); S.boxShown = Math.max(0, open - chat.filter(m => m.kind === "buzon" && !S.seenMsg.has(m.id)).length); }
    chat.forEach(m => { if (!S.seenMsg.has(m.id)) { S.seenMsg.add(m.id); S.evq.push(m); } });
    if (S.boxShown < open && !S.evq.some(m => m.kind === "buzon") && ![...S.ag.values()].some(a => a.task && a.task.mode === "post")) S.boxShown = open;
    renderCard();
  }
  function goTo(ag, p) { ag.tx = p[0]; ag.ty = p[1]; }
  function now() { return (performance.now() - S.t0) / 1000; }

  /* ───────── acciones visibles ───────── */
  function projectBuildings() {
    const D = S.D || {}, ps = (D.projects || []).filter(p => !p.quiet).slice(0, 6), p0 = S.L.proj, tvw = TVR().w + 24;
    const p = { x: p0.x, y: p0.y, w: p0.w - tvw, h: p0.h }, n = Math.max(1, ps.length), bw = Math.min(64, (p.w - 40) / n - 14);   // con la tele de GTA, los edificios a su izquierda
    const wmax = Math.max(0, ...ps.map(pr => { const bd = (D.build || {})[pr.id] || {}; return (bd.w7 || 0) + (S.bonus[pr.id] || 0); })), wk = wmax > 11 ? 11 / wmax : 1;
    return ps.map((pr, i) => {
      const done = (D.orders || []).filter(o => o.project === pr.id && o.state === "done").length;
      const arts = (D.artifacts || []).filter(a => a.project === pr.id).length, proud = (D.proud || []).filter(a => a.project === pr.id).length;
      const bd = (D.build || {})[pr.id] || {}, saved = bd.floors || 0;  // la obra guardada en el servidor
      // altura fiel: entregas reales de los últimos 7 días (bd.w7), a la misma escala para todos; sin ese dato (servidor antiguo), como antes
      const raw = bd.w7 != null ? bd.w7 + (S.bonus[pr.id] || 0) : null;
      const floors = raw != null ? clamp(1 + Math.round(raw * wk), 1, 12) : clamp(Math.max(saved, 1 + done + arts + 2 * proud) + (S.bonus[pr.id] || 0), 1, 12);
      const active = [...S.ag.values()].some(a => a.st === "work" && a.project === pr.id);
      const x = p.x + 24 + i * ((p.w - 48) / n) + ((p.w - 48) / n - bw) / 2;
      return { hue: /^#[0-9a-f]{6}$/i.test(pr.hue || "") ? pr.hue : null, fin: !!(pr.done || pr.finished || pr.state === "done"), total: bd.total != null ? bd.total : 1 + done + arts + 2 * proud, w7: bd.w7, d1: bd.d1, lastAt: bd.last, id: pr.id, name: pr.name || pr.id, floors, active, x, w: bw, base: p.y + p.h - 44, done, arts, proud, slot: (p.w - 48) / n };
    });
  }
  function buildingTop(id) { const b = projectBuildings().find(b => b.id === id); if (!b) return null; return [b.x + b.w / 2, b.base - b.floors * PFH() - 14]; }
  function sendPacket(ag, project, real) {
    const to = buildingTop(project); if (!to) return;
    const from = [ag.x, ag.y - 40];
    S.packets.push({ from, to, t: 0, dur: 3.6, col: ZONES[ag.zone || "write"] ? ZONES[ag.zone || "write"].c : "#efe2a4", project, real });
    ag.bubble = { text: "entrega", until: now() + 2.5 };
  }
  const short = (t, n) => { t = String(t || "").replace(/\s+/g, " ").trim(); return t.length > n ? t.slice(0, n - 1) + "…" : t; };
  const isNawe = n => /^(nawe|nahuel|t[uú]|yo)$/i.test(String(n || "").trim());
  function agentFor(name, preferRest) {
    const all = [...S.ag.values()]; if (!name || isNawe(name)) return null;
    const exact = all.find(a => a.name === name); if (exact) return exact;
    const b = brandOf(name), same = all.filter(a => a.brand === b);
    return (preferRest && same.find(a => a.st !== "work" && !a.task)) || same.find(a => !a.task) || same[0] || null;
  }
  // Reproduce, uno a uno, los mensajes reales del sistema (D.chat). Nada inventado: si no hay mensajes, no hay escenas.
  function socialTick(t) {
    if (t < S.nextEv || !S.evq.length) return;
    const m = S.evq.shift(); S.nextEv = t + 5;
    const fromA = agentFor(m.from, true), toA = agentFor(m.to, true), bx = BOX();
    const free = a => a && a.st !== "work" && !a.task && !a.walking;   // quien trabaja no se levanta de su mesa
    if (m.kind === "buzon" && free(fromA)) {             // un agente deja una sugerencia en el buzón
      fromA.task = { mode: "post", stage: 0 }; fromA.bulb = true; fromA.say = { text: short(m.text, 34), until: t + 9 }; goTo(fromA, [bx.x - 34, bx.y + 18]); return;
    }
    if (m.kind === "buzon") { S.boxShown = Math.min((S.boxShown || 0) + 1, S.lastSugg || 0); S.mailFlash = t; if (fromA) fromA.say = { text: short(m.text, 34), until: t + 7 }; return; }
    if (m.kind === "orden") return;                // una orden no pasa por el buzón: el agente aparece en cola y luego en su mesa
    if (isNawe(m.from) && (m.kind === "respuesta" || m.kind === "encargo") && free(toA)) {                    // Nawe contesta o encarga: el agente recoge la carta
      toA.task = { mode: "fetch", stage: 0 }; toA.say = { text: "Nawe: " + short(m.text, 30), until: t + 10 }; goTo(toA, [bx.x - 34, bx.y + 18]); return;
    }
    if (free(fromA) && free(toA) && fromA !== toA) {   // conversación real entre dos agentes
      const cx = (fromA.x + toA.x) / 2, cy = (fromA.y + toA.y) / 2 + 30;   // se encuentran a medio camino entre sus mesas
      fromA.task = { mode: "chat", until: t + 10 }; toA.task = { mode: "chat", until: t + 10 }; fromA.chatWith = toA; toA.chatWith = fromA;
      goTo(fromA, [cx - 26, cy]); goTo(toA, [cx + 26, cy]); fromA.say = { text: short(m.text, 34), until: t + 10 }; return;
    }
    const sp = fromA || (isNawe(m.from) ? toA : null);
    if (sp) sp.say = { text: (isNawe(m.from) ? "Nawe: " : "") + short(m.text, 34), until: t + 7 };   // entrega, fallo, o mensaje con alguien ocupado
  }

  /* ───────── simulación ───────── */
  function stepAgents(dt, t) {
    S.ag.forEach(a => {
      if (false && a.st === "work" && !a.real && t > a.nextZone) {  // sin rotación inventada: sin «action» real, el agente se queda en la zona que encaja con su tarea
        const sc = SCRIPTS[a.role] || SCRIPTS.thinking; a.zi = (a.zi + 1) % sc.length; a.zone = sc[a.zi]; a.nextZone = t + 6 + Math.random() * 4;
        a.bubble = { text: ZONES[a.zone].doing, until: t + 2.4 };
      }
      if (a.task) {
        if (a.task.mode === "chat" && t > a.task.until) { a.task = null; a.chatWith = null; goTo(a, a.home); }
        if (a.task && (a.task.mode === "post" || a.task.mode === "fetch") && dist(a) < 2) {
          if (a.task.stage === 0) { a.task.stage = 1; a.task.until = t + 1.8; S.mailFlash = t; if (a.task.mode === "post") S.boxShown = Math.min((S.boxShown || 0) + 1, S.lastSugg || 0); }
          else if (t > a.task.until) { a.task = null; a.bulb = false; goTo(a, a.home); }
        }
      }
      // movimiento lento con aceleración suave
      const dx = a.tx - a.x, dy = a.ty - a.y, d = Math.hypot(dx, dy);
      if (S.reduce) { a.x = a.tx; a.y = a.ty; a.v = 0; return; }
      if (d > .5) { a.v = Math.min((a.v || 0) + 60 * dt, 52, d * 2.2 + 6); a.x += dx / d * a.v * dt; a.y += dy / d * a.v * dt; a.walking = true; }
      else { a.v = 0; a.walking = false; }
    });
    S.packets = S.packets.filter(p => {
      p.t += dt / p.dur; if (p.t >= 1) { if (p.project) { if (!p.real) S.bonus[p.project] = Math.min((S.bonus[p.project] || 0) + 1, 6); S.flashes.push({ project: p.project, t: 0 }); } return false; } return true;
    });
    S.flashes = S.flashes.filter(f => (f.t += dt) < 1.6);
  }
  const dist = a => Math.hypot(a.tx - a.x, a.ty - a.y);

  /* ───────── entrada, chispas y banquillo ───────── */
  const CHAN = { you: { label: "Tú · Faro", c: "#efe2a4" }, cloud: { label: "Nube", c: "#9cc4ee" }, local: { label: "PC · Mac", c: "#8fdcae" } };
  const chanOf = a => String(a.id || "").startsWith("o:") ? "you" : a.cloud ? "cloud" : "local";
  function chanSpot(a) { const ch = S.L.chan.find(c => c.k === chanOf(a)) || S.L.chan[0]; return [ch.x + ch.w / 2, ch.y + ch.h + 8]; }
  function chanFlash(a) { S.chanHit = S.chanHit || {}; S.chanHit[chanOf(a)] = now(); }
  function emitSpark(ag, a) {
    const from = agSrc(ag);
    const col = ag.zone && ZONES[ag.zone] ? ZONES[ag.zone].c : (BRANDS[a.brand] || BRANDS.hermes).c;
    (S.sparks = S.sparks || []).push({ from, t: 0, col }); if (S.sparks.length > 40) S.sparks.shift();
    chanFlash(a); ag.pulse = now();
  }
  // Cada dato (cambio real de un agente) vuela hasta donde esté el orbe y, al llegar, lo alimenta con un golpe de su color
  function stepSparks(dt) {
    (S.sparks || []).forEach(p => { p.t += dt / 2.4; if (p.t >= 1 && !p.fed) { p.fed = true; orbFeed(p.col, p.from); } });
    S.sparks = (S.sparks || []).filter(p => p.t < 1);
  }
  function drawSparks(c, t) {
    const O = orbState();
    (S.sparks || []).forEach(p => {
      const k = ease(p.t), mx = (p.from[0] + O.x) / 2 + Math.sin(p.t * 6 + p.from[0]) * 12, my = Math.min(p.from[1], O.y) - 90;   // arco que se mece
      const x = (1 - k) * (1 - k) * p.from[0] + 2 * (1 - k) * k * mx + k * k * O.x, y = (1 - k) * (1 - k) * p.from[1] + 2 * (1 - k) * k * my + k * k * O.y;
      for (let i = 1; i < 4; i++) { const kk = ease(Math.max(0, p.t - i * .035)), tx = (1 - kk) * (1 - kk) * p.from[0] + 2 * (1 - kk) * kk * mx + kk * kk * O.x, ty = (1 - kk) * (1 - kk) * p.from[1] + 2 * (1 - kk) * kk * my + kk * kk * O.y; glow(c, tx, ty, 9 - i * 2, p.col, .5 - i * .12); }
      glow(c, x, y, 14, p.col, .95); c.fillStyle = "#fff"; c.beginPath(); c.arc(x, y, 1.8, 0, 7); c.fill();
    });
  }
  function drawChannels(c, t) {
    const L = S.L; S.chanHit = S.chanHit || {};
    const n = { you: 0, cloud: 0, local: 0 }; [...S.ag.values()].forEach(a => n[chanOf(a)]++);
    n.you = ((S.D || {}).orders || []).filter(o => o.state === "queued" || o.state === "running").length;
    L.chan.forEach(ch => {   // compuertas de cristal con el filo de su color; se encienden y barren cuando entra algo
      const C = CHAN[ch.k], hot = Math.max(0, 1 - (t - (S.chanHit[ch.k] || -99)) / 2.5), k = Math.min(9, ch.h * .3);
      if (hot > 0) glow(c, ch.x + ch.w / 2, ch.y + ch.h / 2, ch.w * .6, C.c, .45 * hot);
      txGlass(c, ch.x, ch.y, ch.w, ch.h, k, C.c, .7 + .3 * hot);
      c.fillStyle = hexA(C.c, .75 + .25 * hot); c.fillRect(ch.x + 3, ch.y + k, 2.5, ch.h - 2 * k);
      if (hot > 0) { c.save(); oct(c, ch.x, ch.y, ch.w, ch.h, k); c.clip(); const sx = ch.x + ch.w * (1 - hot), g = c.createLinearGradient(sx - 60, 0, sx, 0);
        g.addColorStop(0, hexA(C.c, 0)); g.addColorStop(1, hexA(C.c, .35 * hot)); c.fillStyle = g; c.fillRect(sx - 60, ch.y, 60, ch.h); c.restore(); }
      const one = ch.h < 40, ix = ch.x + (one ? 20 : 28), iy = ch.y + ch.h / 2, sc = one ? .62 : .85;
      c.save(); c.translate(ix, iy); c.scale(sc, sc); c.translate(-ix, -iy); c.strokeStyle = C.c; c.fillStyle = C.c; c.lineWidth = 2.4;
      if (ch.k === "cloud") { c.beginPath(); c.arc(ix - 8, iy + 2, 6, 0, 7); c.arc(ix, iy - 3, 8, 0, 7); c.arc(ix + 9, iy + 2, 6, 0, 7); c.rect(ix - 8, iy + 2, 17, 6); c.fillStyle = hexA(C.c, .85); c.fill(); }
      else if (ch.k === "local") icon(c, "work", ix, iy, .7, C.c);
      else { rr(c, ix - 7, iy - 12, 14, 24, 4); c.stroke(); c.fillRect(ix - 2, iy + 6, 4, 2); }
      c.restore();
      const cnt = ch.k === "you" ? n.you + " en marcha" : n[ch.k] + " dentro";
      if (one) { txText(c, C.label.toUpperCase(), ix + 18, iy + 4.5, 12, TX.text, "left", 1.2); c.font = "800 14px Nunito, system-ui"; c.textAlign = "right"; c.fillStyle = C.c; c.fillText(cnt, ch.x + ch.w - 12, iy + 5); }
      else { txText(c, C.label.toUpperCase(), ix + 20, iy - 4, 11, TX.text, "left", 1.2); c.font = "800 14px Nunito, system-ui"; c.textAlign = "left"; c.fillStyle = C.c; c.fillText(cnt, ix + 20, iy + 14); }
    });
    // pulso del sondeo: Faro pregunta a los agentes cada 15 s
    const k = (t % 15) / 15, O0 = orbState(), E0 = [O0.x, O0.y]; if (!S.reduce && k < .25) { c.strokeStyle = hexA("#f2b77a", .45 * Math.sin(Math.PI * k / .25) * (1 - k / .25 * .5)); c.lineWidth = 3; c.beginPath(); c.arc(E0[0], E0[1], 30 + k / .25 * 260, 0, 7); c.stroke(); }
  }
  function drawBench(c, t) {
    const B = S.L.bench, list = S.bench || [], sz = S.L.wide ? 11 : 12, gap = sz * 2.6;
    c.font = "800 13px Nunito, system-ui"; c.textAlign = "left"; c.fillStyle = TX.dim;
    const nOff = list.filter(a => a.off).length, nDone = list.filter(a => a.done).length, nFree = list.length - nOff - nDone;
    const txt = list.length ? [nFree && nFree + (nFree === 1 ? " libre" : " libres"), nDone && nDone + (nDone === 1 ? " hecho" : " hechos"), nOff && nOff + " sin señal"].filter(Boolean).join(" · ") : "Todos en su mesa";
    const two = S.L.wide, tw = c.measureText(txt).width;
    c.fillText(txt, B.x + 10, two ? B.y + 13 : B.y + B.h / 2 + 4);
    const x0 = two ? B.x + 10 : B.x + 22 + tw, y0 = two ? B.y + 30 : B.y + B.h / 2 - 2, max = Math.max(1, Math.floor((B.x + B.w - x0 - 30) / gap));
    { // espera: un carril de luz; cada agente libre flota en su plaza
      const rx0 = x0 - 4, rx1 = B.x + B.w - 6, ry = y0 + sz + 6, g = c.createLinearGradient(rx0, 0, rx1, 0);
      g.addColorStop(0, "rgba(102,217,206,0)"); g.addColorStop(.12, "rgba(102,217,206,.45)"); g.addColorStop(.88, "rgba(102,217,206,.45)"); g.addColorStop(1, "rgba(102,217,206,0)");
      c.fillStyle = g; c.fillRect(rx0, ry, rx1 - rx0, 1.5);
    }
    list.slice(0, max).forEach((a, i) => {
      const x = x0 + i * gap + sz, y = y0 + (S.reduce ? 0 : Math.sin(t * 1.4 + i * 1.7) * 1.3), col = (BRANDS[a.brand] || BRANDS.hermes).c;
      c.globalAlpha = a.off ? .4 : a.done ? .7 : 1;
      c.fillStyle = hexA(col, .3); c.beginPath(); c.ellipse(x, y0 + sz + 6.7, sz * .8, 2.2, 0, 0, 7); c.fill();
      c.fillStyle = "#0e1430"; c.beginPath(); c.arc(x, y, sz, 0, 7); c.fill(); c.strokeStyle = col; c.lineWidth = 2; c.stroke();
      c.fillStyle = col; c.fillRect(x - sz * .42, y - 1.5, sz * .26, a.off ? 1.2 : 3); c.fillRect(x + sz * .16, y - 1.5, sz * .26, a.off ? 1.2 : 3);
      c.globalAlpha = 1;
      if (a.cloud) { c.fillStyle = "#e6f1ff"; c.beginPath(); c.arc(x + sz * .7, y - sz * .8, sz * .3, 0, 7); c.arc(x + sz, y - sz * .9, sz * .35, 0, 7); c.fill(); }
    });
    if (list.length > max) { c.fillStyle = "#d9d4ee"; c.textAlign = "left"; c.font = "800 13px Nunito, system-ui"; c.fillText("+" + (list.length - max), x0 + max * gap + 4, y0 + 5); }
  }
  /* ───────── la bóveda viva: el grafo se mueve como el de Obsidian ─────────
     Faro calcula dónde va cada nota; aquí cada nodo es un cuerpo con muelles (sus enlaces), un ancla (su sitio) y un
     poco de repulsión. Al abrir, el grafo florece desde el centro; una nota nueva nace junto a la que enlaza y empuja a
     las vecinas; cada lectura o escritura real (vigía del PC, al instante) ilumina la nota, sus enlaces y sus vecinas. */
  const VG = { nodes: new Map(), edges: [], adj: new Map(), gv: -1, seq: 0, log: [], beams: [], pend: {}, last: null, src: null, timer: 0, scanUntil: 0, mode: null };
  const KC = { read: "#66d9ce", write: "#efe2a4", new: "#8fdcae", del: "#f29b7d" };
  const VERB = { read: "lee", write: "escribe", new: "crea", del: "borra" };
  // Degradado de calor = masa: azul (poco visitada, ligera) → violeta → naranja → rojo (muy visitada, pesada, atrae)
  function rgbA(col, a) { const m = /rgb\((\d+),(\d+),(\d+)\)/.exec(col); return m ? `rgba(${m[1]},${m[2]},${m[3]},${a})` : hexA(col, a); }
  function mixRgb(col, rgb, k) { const m = /rgb\((\d+),(\d+),(\d+)\)/.exec(col) || [0, 160, 160, 200]; const a = [+m[1], +m[2], +m[3]].map((v, i) => Math.round(v + (rgb[i] - v) * k)); return `rgb(${a[0]},${a[1]},${a[2]})`; }
  function heatCol(h, leaf) {
    const st = [[0, [64, 120, 255]], [.35, [150, 110, 235]], [.7, [255, 140, 70]], [1, [255, 48, 60]]];   // azul (ligera) → rojo (pesada, atrae)
    let i = 0; while (i < st.length - 2 && h > st[i + 1][0]) i++;
    const [a, A] = st[i], [b, B] = st[i + 1], k = Math.min(1, Math.max(0, (h - a) / (b - a)));
    let rgb = A.map((v, j) => Math.round(v + (B[j] - v) * k));
    if (leaf && h < .2) rgb = [200, 196, 222];   // una sola conexión y fría: gris claro, se distingue de las bien conectadas
    return `rgb(${rgb[0]},${rgb[1]},${rgb[2]})`;
  }
  // Color = cuánto está conectada la nota (escala logarítmica sobre la más enlazada), no cuánto se visita:
  // gris lila (1 enlace) → azul → cian → violeta → magenta → naranja → rojo. Etiquetas, verde; adjuntos, amarillo; sin resolver, gris.
  // Qué sale lo decide la vista gráfica de Obsidian (adjuntos, etiquetas, huérfanas, sin resolver y búsqueda): lo filtra faro.py.
  const DEGC = [[0, [70, 120, 255]], [.2, [60, 200, 255]], [.42, [150, 110, 235]], [.6, [232, 90, 200]], [.8, [255, 140, 70]], [1, [255, 48, 60]]];
  function degCol(s) {
    if (s.k === 1) return "rgb(126,231,135)"; if (s.k === 2) return "rgb(242,227,90)"; if (s.k === 3) return "rgb(124,122,140)";   // enlace sin resolver: gris, como en Obsidian
    if (!(s.d > 0)) return s.o === 2 ? "rgb(110,104,138)" : "rgb(55,227,194)";   // nota suelta a propósito · huérfana de verdad
    if (s.d === 1) return "rgb(200,196,222)";
    const k = Math.min(1, Math.log1p(s.d) / Math.log1p(Math.max(3, VG.dmax || 3))); let i = 0; while (i < DEGC.length - 2 && k > DEGC[i + 1][0]) i++;
    const [a, A] = DEGC[i], [b, B] = DEGC[i + 1], f = Math.min(1, Math.max(0, (k - a) / (b - a))), c = A.map((v, j) => Math.round(v + (B[j] - v) * f));
    return `rgb(${c[0]},${c[1]},${c[2]})`;
  }
  function vgZ(s) {   // profundidad: la bóveda no da ese dato; se usa el calor (lo más visitado, delante) y un grosor fijo por nota
    if (s.zj == null) { let hsh = 0; for (const ch of String(s.id)) hsh = (hsh * 31 + ch.charCodeAt(0)) | 0; s.zj = ((hsh >>> 0) % 1000) / 1000 - .5; }
    if (s.ring) return s.zj * .05;   // cinturón de lo que no tiene enlaces: un anillo casi plano alrededor
    const hx = (isFinite(s.hx) ? s.hx : .5) - .5, hy = (isFinite(s.hy) ? s.hy : .5) - .5, RC = (VG.rc || .31) * 1.1;
    return s.zj * 1.7 * Math.sqrt(Math.max(.002, RC * RC - hx * hx - hy * hy));   // bola: de frente se ve igual que el grafo 2D de Obsidian; al girar, tiene volumen
  }
  VG.ui = { zoom: 1, spin: 0, drag: null, pan: null, sel: null, box: null, pts: new Map() };
  VG.cam = { p: [0, -.2, -4.2], v: [0, 0, 0], l: [0, 0, 0], tgt: null, since: 0, until: 0, orb: 0, wide: true };
  VG.sparks = [];
  function vgPick(px, py) {   // la nota bajo el dedo (la más cercana dentro de su radio + margen táctil)
    let best = null, bd = 1e9; VG.nodes.forEach(s => { const p = s.pb; if (!p || s.dead) return; const d = Math.hypot(p[0] - px, p[1] - py); if (d < bd) { bd = d; best = s; } });
    return bd < 22 ? best : null;
  }
  function vgBindUI(root) {   // vista grande de la bóveda: arrastrar notas, tocar, girar el sistema y zoom (ratón y táctil)
    const loc = (e, cv) => { const b = cv.getBoundingClientRect(); return [e.clientX - b.left, e.clientY - b.top]; };
    root.addEventListener("pointerdown", e => {
      const cv = e.target.closest && e.target.closest(".fo-vg"); if (!cv) return; e.preventDefault(); cv.setPointerCapture(e.pointerId);
      const UI = VG.ui, [x, y] = loc(e, cv); UI.pts.set(e.pointerId, [x, y]);
      if (UI.pts.size === 2) { const [a, b] = [...UI.pts.values()]; UI.pinch = { d: Math.hypot(a[0] - b[0], a[1] - b[1]), z: UI.zoom }; UI.drag = null; UI.pan = null; return; }
      const s = vgPick(x, y);
      if (s) { UI.drag = { s, px: x, py: y, x0: x, y0: y, moved: false }; UI.sel = s; s.hl = now(); s.kind = "read"; }
      else { UI.pan = { x, y, lx: x, lt: now() }; UI.sel = null; }
    });
    root.addEventListener("pointermove", e => {
      const UI = VG.ui; if (!UI.pts.has(e.pointerId)) return; const cv = e.target.closest && e.target.closest(".fo-vg") || root.querySelector(".fo-vg"); if (!cv) return;
      const [x, y] = loc(e, cv); UI.pts.set(e.pointerId, [x, y]);
      if (UI.pinch && UI.pts.size === 2) { const [a, b] = [...UI.pts.values()]; UI.zoom = Math.max(.6, Math.min(3, UI.pinch.z * Math.hypot(a[0] - b[0], a[1] - b[1]) / (UI.pinch.d || 1))); return; }
      if (UI.drag) { UI.drag.px = x; UI.drag.py = y; if (Math.hypot(x - UI.drag.x0, y - UI.drag.y0) > 5) UI.drag.moved = true; }
      else if (UI.pan) { const t = now(), dx = x - UI.pan.lx; UI.spin = Math.max(-3, Math.min(3, UI.spin + dx * .012)); UI.pan.lx = x; UI.pan.lt = t; }
    });
    const up = e => {
      const UI = VG.ui; UI.pts.delete(e.pointerId); if (UI.pts.size < 2) UI.pinch = null;
      if (UI.drag) { const s = UI.drag.s; if (!UI.drag.moved) vgKick(s, { k: "write", who: "Nawe" }); s.hl = now(); s.kind = UI.drag.moved ? "read" : "write"; UI.drag = null; }
      UI.pan = null;
    };
    root.addEventListener("pointerup", up); root.addEventListener("pointercancel", up);
    root.addEventListener("wheel", e => { if (!(e.target.closest && e.target.closest(".fo-vg"))) return; e.preventDefault();
      VG.ui.zoom = Math.max(.6, Math.min(3, VG.ui.zoom * Math.exp(-e.deltaY * .0015))); }, { passive: false });
  }
  function vgKickOff(s, t) {   // oscilación amortiguada de los golpes: A·e^(−3,5t)·sin(11t) en la dirección del golpe
    s.ko = null; if (!s.kq || !s.kq.length) { vgOrganic(s, t); return; }
    let ou = 0, ov = 0, ow = 0; s.kq = s.kq.filter(k => t - k.t0 < 2.2);
    for (const k of s.kq) { const dt = t - k.t0; if (dt < 0) continue; const f = k.a * Math.exp(-3.5 * dt) * Math.sin(11 * dt); ou += k.ux * f; ov += k.uy * f; ow += k.uz * f; }
    s.ko = [ou, ov, ow]; vgOrganic(s, t);
  }
  function vgOrganic(s, t) {   // medusa: todo respira con un pulso lento · alga: las ramas se mecen, más cuanto más lejos del núcleo
    if (S.reduce || s.u == null) return;
    if (s.ph == null) { let h = 7; for (const ch of String(s.id)) h = (h * 33 + ch.charCodeAt(0)) | 0; s.ph = ((h >>> 0) % 6283) / 1000; }
    const R = Math.hypot(s.u, s.v, s.zs || 0), pulse = .05 * Math.sin(t * .5) + .02 * Math.sin(t * 1.3 + 1), sway = .022 * (.4 + R) * (1 - (s.dn || 0) * .7);
    const o = s.ko || (s.ko = [0, 0, 0]);
    o[0] += s.u * pulse + Math.sin(t * .33 + s.ph) * sway; o[1] += s.v * pulse + Math.sin(t * .27 + s.ph * 1.7) * sway * .7; o[2] += (s.zs || 0) * pulse + Math.cos(t * .31 + s.ph * .6) * sway;
  }
  // Cámara dentro de la bóveda: posición C y mirada L; perspectiva con plano cercano. Lo que queda detrás no se dibuja.
  const VG_SP = 4;   // separación del mundo que ve la cámara (más distancia entre notas)
  // Historia de la bóveda, como «Animar» en la vista gráfica de Obsidian: las notas aparecen por orden de nacimiento y las conexiones, al llegar sus dos extremos.
  function vgHistory() {
    const t = now(), arr = [...VG.nodes.values()].filter(s => !s.dead);
    if (VG.hist) { arr.forEach(s => { if (s.born > t) s.born = t - 1; }); VG.hist = null; return; }   // segundo toque: la corta
    if (arr.length < 3) return;
    arr.sort((a, b) => (a.c || 0) - (b.c || 0)); const N = arr.length, dur = Math.max(12, Math.min(30, N * .03));
    arr.forEach((s, i) => { s.born = t + .8 + i / N * dur; });
    VG.hist = { t0: t + .8, dur, end: t + dur + 2.5, cs: arr.map(s => s.c || 0) };
    Object.assign(VG.cam, { wide: true, since: t, until: VG.hist.end });   // se ve entera mientras crece
  }
  function vgHistDraw(c, v, t) {
    const H = VG.hist; if (!H) return; if (t > H.end) { VG.hist = null; const b = S.root && S.root.querySelector(".fo-hist"); if (b) b.textContent = "▶ Historia de la bóveda"; return; }
    const k = Math.max(0, Math.min(1, (t - H.t0) / H.dur)), i = Math.min(H.cs.length - 1, Math.floor(k * H.cs.length)), d = new Date(H.cs[i] * 1000);
    const txt = d.toLocaleDateString("es-ES", { day: "numeric", month: "short", year: "numeric" }) + " · " + (i + 1) + " de " + H.cs.length, bw = Math.min(220, v.w * .5), bx = v.x + v.w / 2 - bw / 2, by = v.y + v.h - 26;
    c.save(); c.fillStyle = "rgba(9,12,24,.7)"; rr(c, bx - 10, by - 18, bw + 20, 30, 6); c.fill();
    c.fillStyle = "#fff3c4"; c.font = "800 10.5px Nunito, system-ui"; c.textAlign = "center"; c.fillText(txt, v.x + v.w / 2, by - 5);
    c.fillStyle = "rgba(255,255,255,.18)"; c.fillRect(bx, by + 2, bw, 3); c.fillStyle = "#ffd678"; c.fillRect(bx, by + 2, bw * k, 3); c.restore();
  }
  function vgCamBasis() {
    const C = VG.cam, f0 = C.fw || [C.l[0] - C.p[0], C.l[1] - C.p[1], C.l[2] - C.p[2]], n = Math.hypot(...f0) || 1, f = [f0[0] / n, f0[1] / n, f0[2] / n];
    let r = [f[2], 0, -f[0]]; const rn = Math.hypot(...r) || 1; r = r.map(x => x / rn);           // derecha (horizontal)
    const u = [f[1] * r[2] - f[2] * r[1], f[2] * r[0] - f[0] * r[2], f[0] * r[1] - f[1] * r[0]];   // arriba
    return { f, r, u };
  }
  function vgProj(X, Y, W, H) {   // devuelve s → [x, y, escala, profundidad] (x = NaN si queda detrás de la cámara)
    const C = VG.cam, B = vgCamBasis(), FOV = C.zm || .58, M = Math.min(W, H), SP = VG_SP;   // FOV menor = menos zoom
    return s => {
      const o = s.ko || [0, 0, 0], px = (s.x - .5 + o[0]) * SP, py = (s.y - .5 + o[1]) * SP, pz = ((s.zs != null ? s.zs : vgZ(s)) + o[2]) * SP;
      const dx = px - C.p[0], dy = py - C.p[1], dz = pz - C.p[2];
      const zc = dx * B.f[0] + dy * B.f[1] + dz * B.f[2]; if (zc < .035) return [NaN, NaN, 0, -9];
      const xc = dx * B.r[0] + dy * B.r[1] + dz * B.r[2], yc = dx * B.u[0] + dy * B.u[1] + dz * B.u[2];
      return [X + W / 2 + xc / zc * FOV * M * .5, Y + H / 2 + yc / zc * FOV * M * .5, Math.max(.25, Math.min(1.8, .75 / zc * (FOV / .58))), -zc];
    };
  }
  // Piloto «planetario»: se queda mucho en cada sitio, gira con inercia y muy despacio, y flota con una deriva lenta.
  // Topes medidos en simulación: giro ≤ 4,5°/s, aceleración de giro ≤ 2,5°/s², avance ≤ 0,07 u/s, ≤ 2-3 cambios de objetivo por minuto.
  function vgCam(dt) {
    const C = VG.cam, t = now(), arr = [...VG.nodes.values()].filter(s => !s.dead && s.u != null); if (!arr.length) return;
    const SP = VG_SP, pos = s => [(s.x - .5 + (s.ko ? s.ko[0] : 0)) * SP, (s.y - .5 + (s.ko ? s.ko[1] : 0)) * SP, ((s.zs || 0) + (s.ko ? s.ko[2] : 0)) * SP];
    const DWELL = 25;   // lo que se enciende solo roba la cámara si lleva ya un buen rato en lo anterior
    const recent = arr.filter(s => t - s.hl < 6).sort((a, b) => b.hl - a.hl)[0];
    if (recent && recent !== C.tgt && t - C.since > DWELL) { C.tgt = recent; C.since = t; C.until = t + 30; C.wide = false; }
    if (!C.tgt || !VG.nodes.has(C.tgt.id) || t > C.until) {
      C.wide = !C.since ? true : !C.wide && Math.random() < .5; C.since = t; C.until = t + (C.wide ? 40 : 26 + Math.random() * 14);   // abre con la vista completa (la que se parece al grafo de Obsidian) y vuelve a ella a menudo
      const core = arr.filter(s => (s.dn || 0) > .4), hot = arr.filter(s => (s.h || 0) > .3), r = Math.random();
      const pool = r < .4 && core.length ? core : r < .7 && hot.length ? hot : arr; C.tgt = pool[Math.floor(Math.random() * pool.length)];
      if (C.orb == null) C.orb = Math.random() * 6.283;   // la órbita sigue donde iba: no salta al cambiar de objetivo
    }
    const h = Math.min(dt, .1);
    if (C.wide) { let dA = (-Math.PI / 2 + .6 * Math.sin(t * .045)) - C.orb; dA = Math.atan2(Math.sin(dA), Math.cos(dA)); C.orb += dA * Math.min(1, h * .12); }   // vista completa: casi de frente (se reconoce el grafo 2D) y se mece ±35° para que se note el volumen
    else C.orb += h * .024;   // de cerca: una vuelta cada ~4 min, ritmo de planetario
    C.zm = (C.zm || .58) + ((C.wide ? 1.95 : .58) - (C.zm || .58)) * (1 - Math.exp(-h * .22));   // en la vista completa, teleobjetivo: el cinturón de sueltos llena el octógono
    const T = C.wide ? [0, 0, 0] : pos(C.tgt), D = C.wide ? 4.4 : 1.9 + .2 * Math.sin(t * .05);
    const fl = [.10 * Math.sin(t * .041 + 1), .07 * Math.sin(t * .029 + 2), .10 * Math.cos(t * .035)];   // deriva etérea, muy lenta
    const des = [T[0] + Math.cos(C.orb) * D + fl[0], T[1] - .09 * D + fl[1], T[2] + Math.sin(C.orb) * D + fl[2]];
    const w = .22;   // muelle críticamente amortiguado y blando: arranca y frena como si flotara
    for (let i = 0; i < 3; i++) { const a = w * w * (des[i] - C.p[i]) - 2 * w * C.v[i]; C.v[i] += a * h; }
    { const d0 = [C.p[0] - T[0], C.p[1] - T[1], C.p[2] - T[2]], dd = Math.hypot(...d0), keep = D * .75;   // no atravesar lo que mira: lo rodea, sin empujón brusco
      if (dd < keep) { const q = dd > 1e-4 ? d0.map(x => x / dd) : [Math.cos(C.orb), 0, Math.sin(C.orb)], push = (keep - dd) * .35; for (let i = 0; i < 3; i++) C.v[i] += q[i] * push * h; } }
    let VM = C.wide ? .07 : .05;
    if (C.fw) { const dl = [T[0] - C.p[0], T[1] - C.p[1], T[2] - C.p[2]], nl = Math.hypot(...dl) || 1, dot = (C.fw[0] * dl[0] + C.fw[1] * dl[1] + C.fw[2] * dl[2]) / nl;
      VM *= Math.max(.2, Math.min(1, (dot + .3) / 1.1)); }   // si aún no mira hacia allí, avanza menos (sin escalones)
    const sp = Math.hypot(...C.v); if (sp > VM) C.v = C.v.map(x => x * VM / sp);
    for (let i = 0; i < 3; i++) C.p[i] = Math.max(-4.4, Math.min(4.4, C.p[i] + C.v[i] * h));
    // punto de mira: muelle muy blando
    C.lv = C.lv || [0, 0, 0]; const wl = .25;
    for (let i = 0; i < 3; i++) C.lv[i] += (wl * wl * (T[i] - C.l[i]) - 2 * wl * C.lv[i]) * h;
    const dist = Math.hypot(C.l[0] - C.p[0], C.l[1] - C.p[1], C.l[2] - C.p[2]) || .3, lsp = Math.hypot(...C.lv), LM = dist * .07;
    if (lsp > LM) C.lv = C.lv.map(x => x * LM / lsp);
    for (let i = 0; i < 3; i++) C.l[i] += C.lv[i] * h;
    const dl = [C.l[0] - C.p[0], C.l[1] - C.p[1], C.l[2] - C.p[2]], nl = Math.hypot(...dl);
    if (nl < .6) { const f = C.fw || [0, 0, 1], q = nl > 1e-4 ? dl.map(x => x / nl) : f; for (let i = 0; i < 3; i++) C.l[i] = C.p[i] + q[i] * .6; }
    // dirección de la mirada con inercia de giro: velocidad angular que sube y baja con aceleración limitada
    const dn = [C.l[0] - C.p[0], C.l[1] - C.p[1], C.l[2] - C.p[2]], n2 = Math.hypot(...dn) || 1, want = dn.map(x => x / n2);
    if (!C.fw) { C.fw = want; C.aw = 0; return; }
    const dot = Math.max(-1, Math.min(1, C.fw[0] * want[0] + C.fw[1] * want[1] + C.fw[2] * want[2])), ang = Math.acos(dot);
    const AWMAX = .075, ACC = .04;   // 4,3°/s y 2,3°/s²
    const goal = Math.min(AWMAX, ang * .3, Math.sqrt(2 * ACC * ang));   // frena a tiempo de llegar sin pasarse
    C.aw = (C.aw || 0) + Math.max(-ACC * h, Math.min(ACC * h, goal - (C.aw || 0)));
    if (ang > 1e-6) { const k = Math.min(1, C.aw * h / ang), nf = C.fw.map((x, i) => x + (want[i] - x) * k), nn = Math.hypot(...nf) || 1; C.fw = nf.map(x => x / nn); }
  }
  // Energía cinética de cada entrada: la misma energía para todas, así que lo pesado se mueve menos (v = √(2E/m)).
  // Viene del lado de quien entra (agente, nube o sincronización) y se propaga a las notas enlazadas como una onda.
  const VG_E = { read: .0012, write: .0035, new: .006, del: .003 };
  function vgKick(s, e) {
    const E = VG_E[e.k] || .001, side = e.via === "sync" ? -1 : e.who === "Faro" ? 0 : 1;
    let du = -side * .7 + (Math.random() - .5) * .6, dv = (Math.random() - .5) * .6, dw = (Math.random() - .5) * .8;   // dirección: desde quien entra
    const nn = Math.hypot(du, dv, dw) || 1; du /= nn; dv /= nn; dw /= nn;
    const T0 = now();
    const kick = (q, en, ux, uy, uz, delay) => {   // empujón físico + oscilación visible (amplitud ∝ √(2E/m))
      const v = Math.sqrt(2 * en / (q.mass || 1)); q.vu += ux * v; q.vv += uy * v; q.vw += uz * v;
      (q.kq || (q.kq = [])).push({ t0: T0 + (delay || 0), a: v * .55, ux, uy, uz }); if (q.kq.length > 6) q.kq.shift();
    };
    if (e.k === "del") {   // borrar: las vecinas caen hacia el hueco
      (VG.adj.get(s.id) || []).forEach(k => { const q = VG.nodes.get(k); if (!q || q.u == null) return;
        const a = s.u - q.u, b = s.v - q.v, c = s.w - q.w, d = Math.hypot(a, b, c) || 1; kick(q, E * .6, a / d, b / d, c / d, .1); });
      return;
    }
    kick(s, E, du, dv, dw);
    (VG.adj.get(s.id) || []).forEach(k => { const q = VG.nodes.get(k); if (!q || q.u == null) return;   // onda: 35 % (crear: 60 %), hacia fuera
      const a = q.u - s.u, b = q.v - s.v, c = q.w - s.w, d = Math.hypot(a, b, c) || 1; kick(q, E * (e.k === "new" ? .6 : .35), a / d, b / d, c / d, .12); });   // la onda llega a las vecinas con retraso
    s.kick = now();   // destello del golpe
  }
  function vgHeat() {   // calor = log(visitas) / log(máximo): mismo cálculo que el servidor, al instante con cada lectura o escritura
    let mx = 0; VG.nodes.forEach(s => { if ((s.hr || 0) > mx) mx = s.hr; });
    const hs = []; VG.nodes.forEach(s => hs.push(s.hr || 0)); hs.sort((a, b) => a - b); const med = hs.length > 20 ? Math.log1p(hs[hs.length >> 1]) : 0;   // rojo = se toca más que la nota media (si algo lee toda la bóveda, no se pone toda roja)
    const L = Math.max(.2, Math.log1p(mx || 1) - med); VG.nodes.forEach(s => { s.h = (s.hr || 0) > .05 ? Math.max(0, Math.min(1, (Math.log1p(s.hr) - med) / L)) : 0; });
  }
  function vgSetGraph(g) {
    if (!g || !g.nodes) return;
    const t = now(), first = VG.nodes.size === 0, ids = new Set();
    g.nodes.forEach(n => {
      const id = n.id || n.t; ids.add(id); let s = VG.nodes.get(id);
      if (!s) {
        s = { id, x: n.x, y: n.y, vx: 0, vy: 0, born: t, hl: -99, kind: null, dead: 0, fresh: !first };
        if (first && !S.reduce) { s.x = .5 + (n.x - .5) * .3; s.y = .5 + (n.y - .5) * .3; }   // abre floreciendo, como Obsidian
        VG.nodes.set(id, s);
      }
      s.dc = null; Object.assign(s, { t: n.t, hx: isFinite(n.x) ? n.x : .5, hy: isFinite(n.y) ? n.y : .5, d: n.d || 0, o: n.o || 0, k: n.k || 0, c: n.c || n.m || 0, ring: !(n.d > 0), h: n.h || 0, hr: n.hr != null ? Math.max(n.hr, s.hr || 0) : (s.hr || 0), dir: n.dir || "", m: n.m || (Date.now() / 1000 - (n.age || 1e9)), dead: 0 });
    });
    VG.nodes.forEach((s, id) => { if (!ids.has(id) && !s.dead) s.dead = t; });
    VG.edges = g.edges.map(([i, j]) => [g.nodes[i].id || g.nodes[i].t, g.nodes[j].id || g.nodes[j].t]);
    VG.adj = new Map(); VG.edges.forEach(([a, b]) => { (VG.adj.get(a) || VG.adj.set(a, []).get(a)).push(b); (VG.adj.get(b) || VG.adj.set(b, []).get(b)).push(a); });
    VG.nodes.forEach(s => {
      if (!s.fresh) return; s.fresh = false;   // nota nueva: nace pegada a la que enlaza y sale disparada a su sitio
      const nb = (VG.adj.get(s.id) || []).map(k => VG.nodes.get(k)).find(q => q && !q.fresh);
      if (nb) { s.x = nb.x + (Math.random() - .5) * .03; s.y = nb.y + (Math.random() - .5) * .03; }
      const pe = VG.pend[s.id]; if (pe) { delete VG.pend[s.id]; vgHit(pe, t); }
    });
    vgHeat(); VG.dmax = Math.max(1, ...g.nodes.map(n => n.d || 0)); VG.total = g.total; VG.links = g.links; VG.orphans = g.orphans || 0; VG.leaves = g.leaves || 0; VG.rc = g.rc || .31; VG.src = g.src || "faro"; VG.srcAt = g.src_at || 0; VG.obs = g.obs || null;
  }
  function vgStep(dt, A) {
    // Física 3D: la cámara está quieta y es el sistema el que gira. Cada nota sigue su órbita (su sitio del grafo girando
    // alrededor del eje vertical) atada con un muelle poco amortiguado: la fuerza que la sostiene en la órbita sale de ese muelle,
    // así que lo que se retrasa se abre hacia fuera y vuelve con un rebote. Las notas chocan entre sí con pérdida de energía,
    // los enlaces son muelles y las rojas (calientes, pesadas) atraen al resto; lo pesado se mueve menos (inercia).
    if (!VG.nodes.size) return;
    const t = now();
    for (const s of [...VG.nodes.values()]) if (s.dead && t - s.dead > 1.1) VG.nodes.delete(s.id);
    const all = [...VG.nodes.values()], arr = all.filter(s => !s.ring), n = arr.length; if (!all.length) return;
    for (const s of all) if (s.ring) { s.x = isFinite(s.hx) ? s.hx : .5; s.y = isFinite(s.hy) ? s.hy : .5; s.zs = vgZ(s); s.dn = 0; s.mass = 1; s.rad = .05; s.fe = 0; s.fsp = false; }   // el cinturón no entra en la física: está en su sitio
    const UI = VG.ui; UI.spin *= Math.exp(-Math.min(dt, .1) * .7);   // el giro que das con el dedo se frena solo (inercia)
    const OM = 0;   // el sistema no gira: es la cámara la que navega por dentro
    VG.th = (VG.th || 0) + OM * Math.min(dt, .1);
    const th = VG.th, ct = Math.cos(th), st = Math.sin(th);
    const Kh = 2.2, Ch = .9, Ke = 1.4, G = .0003, E = .55, VMAX = .9;   // G bajo: la forma la da el grafo; antes lo pesado encogía la nube
    // pasos de la física: antes uno cada 8 ms (a 20 fotogramas/s eran 6 por fotograma, y a 10, 12: bajar los fotogramas no ahorraba);
    // ahora cada 16 ms en el PC y cada 30 ms en táctiles, que con estos muelles blandos sigue siendo estable
    // tope de 3 pasos: si un fotograma va lento NO se añaden más pasos (antes sí: más lento → más pasos → aún más lento); y si la física ya cuesta, uno solo
    const sub = VG.cost > 9 ? 1 : Math.min(3, Math.max(1, Math.ceil(Math.min(dt, .1) / (S.lite ? .03 : .016)))), h = Math.min(dt, .1) / sub, pc0 = performance.now();
    const RB = .25 * Math.cbrt(.125 / Math.max(60, n));
    for (const s of arr) {   // órbita objetivo: la posición del grafo girada, y su velocidad tangencial (ω × r)
      const hu = (isFinite(s.hx) ? s.hx : .5) - .5, hv = (isFinite(s.hy) ? s.hy : .5) - .5, hw = vgZ(s);
      s.ou = hu * ct + hw * st; s.ov = hv; s.ow = -hu * st + hw * ct; s.ovu = OM * s.ow; s.ovw = -OM * s.ou;
      if (s.u == null || !isFinite(s.u)) { s.u = s.ou; s.v = s.ov; s.w = s.ow; s.vu = s.ovu; s.vv = 0; s.vw = s.ovw;
        if (s.x != null && isFinite(s.x)) { s.u = s.x - .5; s.v = s.y - .5; } }
      s.dn = Math.min(1, (s.d || 0) / (VG.dmax || 1));
      s.mass = 1 + 2.5 * (s.h || 0) + 3 * s.dn;   // pesa lo caliente y lo muy enlazado
      s.rad = RB + Math.min(.01, Math.sqrt(s.d || 0) * .002);   // radio de choque a la medida de la bóveda: con el fijo de antes (0,08) 400 notas no cabían y la nube se hinchaba hasta borrar la forma del grafo
    }
    const hot = arr.filter(s => s.mass > 1.6 && !s.dead).sort((a, b) => b.mass - a.mass).slice(0, 14);   // solo los 14 más pesados atraen (con toda la bóveda caliente eran casi 400 × 400 por paso)   // los grandes (por calor o por enlaces) atraen a los pequeños
    // Ferrofluido: cuando el orbe pasa por encima, tira de las notas que tiene cerca en pantalla (más cuanto más cerca, y las
    // ligeras más que las pesadas); al irse, el muelle de su órbita las devuelve con un rebote.
    const OP = VG.orbPull, ferro = OP && OP.k > 0 && !S.reduce;
    if (ferro) { const B = vgCamBasis();
      for (const s of arr) { const p = s.pj; s.ffu = s.ffv = s.ffw = 0; if (!p || !isFinite(p[0])) { s.fe = 0; continue; }
        const dx = OP.x - p[0], dy = OP.y - p[1], d = Math.hypot(dx, dy), fe = d < OP.r ? Math.exp(-((d / (OP.r * .45)) ** 2)) : 0;   // caída suave (gaussiana)
        s.fe = Math.max(fe, (s.fe || 0) - Math.min(dt, .1) * 1.5); if (!fe) continue;
        const wx = B.r[0] * dx + B.u[0] * dy, wy = B.r[1] * dx + B.u[1] * dy, wz = B.r[2] * dx + B.u[2] * dy, wn = Math.hypot(wx, wy, wz) || 1, F = .2 * fe * OP.k;   // suave: la física propia de la bóveda manda
        s.ffu = wx / wn * F; s.ffv = wy / wn * F; s.ffw = wz / wn * F; } }
    else for (const s of arr) { s.fe = Math.max(0, (s.fe || 0) - Math.min(dt, .1) * 1.5); s.ffu = s.ffv = s.ffw = 0; }
    { const top = new Set(arr.filter(s => (s.fe || 0) > .08).sort((a, b) => b.fe - a.fe).slice(0, 8)); for (const s of arr) s.fsp = top.has(s); }   // púas: solo las 8 más cercanas
    for (let it = 0; it < sub; it++) {
      for (const s of arr) {   // muelle hacia la órbita + amortiguación relativa (sigue girando, no se frena)
        const M = s.mass;   // la fuerza que sostiene la órbita crece con la masa (como m·ω²·r): lo pesado no se queda atrás
        s.fu = M * (Kh * (s.ou - s.u) + Ch * (s.ovu - s.vu)); s.fv = M * (Kh * (s.ov - s.v) + Ch * (0 - s.vv)); s.fw = M * (Kh * (s.ow - s.w) + Ch * (s.ovw - s.vw));
      }
      for (const [a, b] of VG.edges) {   // enlaces: muelles con la longitud que tienen en el grafo
        const p = VG.nodes.get(a), q = VG.nodes.get(b); if (!p || !q || p.u == null || q.u == null) continue;
        const du = q.u - p.u, dv = (q.v - p.v) * A, dw = q.w - p.w, d = Math.hypot(du, dv, dw) + 1e-6;
        const L = Math.hypot(q.ou - p.ou, (q.ov - p.ov) * A, q.ow - p.ow), f = Ke * (d - L) / d;
        p.fu += du * f; p.fv += dv * f / A; p.fw += dw * f; q.fu -= du * f; q.fv -= dv * f / A; q.fw -= dw * f;
      }
      for (const g of hot) {   // gravedad de las calientes (suavizada)
        for (const s of arr) { if (s === g) continue;
          const du = g.u - s.u, dv = g.v - s.v, dw = g.w - s.w, d2 = du * du + dv * dv + dw * dw + .0064, f = G * (g.mass - 1) * .35 / (d2 * Math.sqrt(d2));   // Plummer: tope cerca, sin hondas
          s.fu += du * f * s.mass; s.fv += dv * f * s.mass; s.fw += dw * f * s.mass; }   // ×masa: la aceleración no depende de la masa propia
      }
      if (ferro) for (const s of arr) { s.fu += s.ffu; s.fv += s.ffv; s.fw += s.ffw; }
      for (const s of arr) {   // integración semi-implícita con inercia
        const im = 1 / s.mass;
        s.vu = Math.max(-VMAX, Math.min(VMAX, s.vu + s.fu * im * h)); s.vv = Math.max(-VMAX, Math.min(VMAX, s.vv + s.fv * im * h)); s.vw = Math.max(-VMAX, Math.min(VMAX, s.vw + s.fw * im * h));
        s.u += s.vu * h; s.v += s.vv * h; s.w += s.vw * h;
      }
      arr.sort((a, b) => a.u - b.u);   // barrido en u: cada nota solo se compara con las que tiene al lado
      for (let i = 0; i < n; i++) { const p = arr[i];   // choques: se separan y rebotan con pérdida de energía
        for (let j = i + 1; j < n; j++) { const q = arr[j], R = p.rad + q.rad, du = p.u - q.u; if (du < -.23) break; if (du > R || du < -R) continue;
          const dv = (p.v - q.v) * A; if (dv > R || dv < -R) continue; const dw = p.w - q.w, d = Math.hypot(du, dv, dw);
          if (d >= R || d < 1e-6) continue;
          const pm = p.mass * p.mass, qm = q.mass * q.mass;   // en el choque pesa el cuadrado: lo rojo no cede ante un enjambre de ligeras
          const nu = du / d, nv = dv / d, nw = dw / d, mi = 1 / pm + 1 / qm, push = (R - d) / mi;
          p.u += nu * push / pm; p.v += nv * push / pm / A; p.w += nw * push / pm;
          q.u -= nu * push / qm; q.v -= nv * push / qm / A; q.w -= nw * push / qm;
          const rv = (p.vu - q.vu) * nu + (p.vv - q.vv) * A * nv + (p.vw - q.vw) * nw;
          if (rv < 0) { const J = -(1 + E) * rv / mi; p.vu += J * nu / pm; p.vv += J * nv / pm / A; p.vw += J * nw / pm; q.vu -= J * nu / qm; q.vv -= J * nv / qm / A; q.vw -= J * nw / qm; }
        } }
    }
    VG.cost = (VG.cost || 0) * .9 + (performance.now() - pc0) * .1;   // coste medio de la física (ms)
    const D = UI.drag;   // la nota que llevas: sigue al dedo; sus enlaces arrastran a las vecinas; al soltar conserva la velocidad
    if (D && D.s && UI.box && D.s.u != null) {
      const b = UI.box, p = b.PJ(D.s), ex = D.px - p[0], ey = D.py - p[1], sc = .9 * (UI.zoom || 1) * p[2];
      const du = ex / (b.W * sc * Math.cos(.32)), dv = ey / (b.H * sc * Math.cos(.42)), g = Math.min(1, Math.min(dt, .1) * 14);
      D.s.u += du * g; D.s.v += dv * g; D.s.vu = du * g / Math.max(.016, Math.min(dt, .1)); D.s.vv = dv * g / Math.max(.016, Math.min(dt, .1)); D.s.vw *= .8;
      const seen = new Set([D.s.id]), ring = (ids, f) => { const nx = []; ids.forEach(id => (VG.adj.get(id) || []).forEach(k => { if (seen.has(k)) return; seen.add(k); nx.push(k);
        const q = VG.nodes.get(k); if (q && q.u != null) { const m = f / (q.mass || 1) ** .5; q.u += du * g * m; q.v += dv * g * m; q.vu += du * g * m * 6; q.vv += dv * g * m * 6; } })); return nx; };
      ring(ring([D.s.id], .45), .16);   // las enlazadas la siguen (las ligeras más), y las de segundo nivel algo menos
    }
    for (const s of arr) {
      if (![s.u, s.v, s.w, s.vu, s.vv, s.vw].every(isFinite) || Math.abs(s.u) > .9 || Math.abs(s.v) > .9 || Math.abs(s.w) > .9) {
        s.u = s.ou; s.v = s.ov; s.w = s.ow; s.vu = s.ovu; s.vv = 0; s.vw = s.ovw; }
      s.x = .5 + s.u; s.y = .5 + s.v; s.zs = s.w;
    }
    if (!S.reduce) vgCam(Math.min(dt, .1));
  }
  function vgAgent(e) {
    if (!e.who) return null; const ags = [...S.ag.values()], w = String(e.who).toLowerCase();
    return ags.find(a => String(a.name).toLowerCase() === w) || ags.find(a => brandOf(a.name) === brandOf(e.who) && !!a.cloud === (e.via === "sync" || e.via === "agente"));
  }
  function vgHit(e, t) {
    const s = VG.nodes.get(e.p); VG.last = { ...e, t, title: s ? s.t : String(e.p).split("/").pop() };
    if (!s) { if (e.k === "new" || e.k === "write") VG.pend[e.p] = { ...e, _t: t }; return; }
    s.hl = t; s.kind = e.k; s.who = e.who;
    if (e.who !== "Faro" && e.via !== "sistema" && (e.k === "read" || e.k === "write" || e.k === "new")) { s.hr = (s.hr || 0) + (e.k === "read" ? 1 : 2); vgHeat(); }   // calor en vivo
    if (!S.reduce && s.u != null) vgKick(s, e);
    const ag = vgAgent(e);
    const key = ag ? ag.id : e.via || e.who || "", prev = VG.beams.filter(b => b.key === key).reduce((m, b) => Math.max(m, b.t0), -1e9);
    VG.beams.push({ id: e.p, key, t0: Math.min(now() + 1.5, Math.max(now(), prev + .14)), col: KC[e.k] || KC.read, ag: ag ? ag.id : null, via: e.via, who: e.who }); if (VG.beams.length > 30) VG.beams.shift();
  }
  function vgPoll() {
    clearInterval(VG.timer);
    const go = () => fetch(`api/vault/live?since=${VG.seq}&gv=${VG.gv}`, { cache: "no-store" }).then(r => r.ok ? r.json() : null).then(j => {
      if (!j) return; VG.mode = j.mode; if ((j.seq || 0) < VG.seq) VG.seq = 0;
      if (j.graph) { VG.gv = j.gv; vgSetGraph(j.graph); }
      const t = now(), fresh = (j.ev || []).filter(e => e.s > VG.seq); VG.seq = Math.max(VG.seq, j.seq || 0);
      const reads = fresh.filter(e => e.k === "read" && e.ago < 6).length; if (reads >= 10) VG.scanUntil = t + 3.5;
      fresh.forEach(e => { VG.log.unshift({ ...e, at: Date.now() - e.ago * 1000 }); if (e.ago < 15) vgHit(e, t - Math.min(e.ago, 1.2)); });
      if (VG.log.length > 40) VG.log.length = 40;
      for (const k in VG.pend) if (t - VG.pend[k]._t > 20) delete VG.pend[k];
      if (fresh.length && S.sel && S.sel.type === "zone" && S.sel.id === "obsidian") vgCardUpdate();
    }).catch(() => {});
    if (location.protocol.startsWith("http")) { go(); VG.timer = setInterval(() => { if (!document.hidden) go(); }, LITE ? 3000 : 1200); }
  }
  // Dibuja el grafo en un rectángulo (la columna de la oficina o la ficha grande). Solo lo real se enciende.
  function vgDraw(c, X, Y, W, H, big) {
    const t = now(), UI = VG.ui, PJ = vgProj(X, Y, W, H), focus = new Set(), nb = new Set(), scan = VG.scanUntil > t, KEY = big ? "pb" : "pj";
    VG.nodes.forEach(s => { if (s.zs == null) s.zs = vgZ(s); vgKickOff(s, t); s[KEY] = PJ(s); });   // la Z la mueve la física (vgStep)
    const P = s => s[KEY] || PJ(s); if (big) UI.box = { X, Y, W, H, PJ }; else { VG.proj = { X, Y, W, H, P }; VG.grav = []; VG.gravT = t; }
    // márgenes: todo se desvanece al acercarse al borde; sin recorte rectangular (dejaba un corte recto arriba cuando la cámara
    // se acercaba): el borde lo funde feather() en la capa de la bóveda
    const MG = Math.max(10, Math.min(W, H) * .07), EF = (x, y) => Math.max(0, Math.min(1, Math.min(x - X, X + W - x, y - Y, Y + H - y) / (MG * 1.8) - .35));
    c.save();
    const LX = x => Math.max(X + MG + 30, Math.min(X + W - MG - 30, x));   // los nombres tampoco se salen
    if (big && UI.sel && VG.nodes.has(UI.sel.id)) focus.add(UI.sel.id);
    VG.nodes.forEach(s => { if (t - s.hl < 3.2) focus.add(s.id); });
    if (!scan) focus.forEach(id => (VG.adj.get(id) || []).forEach(k => nb.add(k)));
    const dim = focus.size > 0 && !scan, alive = s => (s.dead ? Math.max(0, 1 - (t - s.dead) / 1.1) : 1) * Math.min(1, (t - s.born) / .6);
    c.lineWidth = big ? 1.3 : 1; let ei = 0, np = 0; const EB = new Map();   // conexiones en reposo: agrupadas por color y grosor (un trazo por grupo)
    for (const [a, b] of VG.edges) {
      ei++; const p = VG.nodes.get(a), q = VG.nodes.get(b); if (!p || !q) continue;
      const fa = focus.has(a), fb = focus.has(b), hot = fa || fb, al = Math.min(alive(p), alive(q)), [x1, y1] = P(p), [x2, y2] = P(q);
      if (al <= 0 || !isFinite(x1) || !isFinite(x2)) continue;   // aún no ha nacido (animación del historial) o detrás de la cámara
      const ef = Math.min(EF(x1, y1), EF(x2, y2)); if (ef <= 0) continue;
      const kz = (P(p)[2] + P(q)[2]) / 2, dep = Math.min(1, Math.max(.45, (kz - .78) * 1.6));   // las del fondo, algo más apagadas
      if (hot) { c.strokeStyle = hexA(KC[(fa ? p : q).kind] || KC.read, .55 * al * ef); c.lineWidth = (big ? 1.1 : .8) * Math.min(1.4, kz); c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke(); }
      else {   // color de la nota más caliente de las dos (antes, un degradado por conexión y fotograma: lo más caro de la bóveda)
        const A0 = Math.round((dim ? .04 : .32) * al * dep * ef * 25) / 25; if (A0 > 0) {
          const m = (p.d || 0) >= (q.d || 0) ? p : q, ec = m.dc || (m.dc = degCol(m)), key = ec + "|" + A0 + "|" + (kz > 1 ? 1 : 0);   // la conexión toma el color de la nota más enlazada de las dos
          let g = EB.get(key); if (!g) { g = { path: new Path2D(), col: rgbA(ec, A0), lw: (big ? 1.1 : .8) * (kz > 1 ? 1.3 : .85) }; EB.set(key, g); }
          g.path.moveTo(x1, y1); g.path.lineTo(x2, y2); } }
      // «Vivo pero sereno»: cuando la cámara pasa cerca, por cada conexión corre de vez en cuando un grupo de partículas muy tenue
      // desde la nota más conectada de las dos hacia la otra (igual que las chispas del «cerebro»), del color de la nota a la que llega. Cada conexión con su
      // ritmo (cada 7–13 s, un pulso de 1,5–2,5 s) y su desfase; solo las que se ven largas (cámara cerca) y como mucho 40 a la vez. Las conexiones no guardan quién enlaza a quién.
      const eln = Math.hypot(x2 - x1, y2 - y1);   // «cerca» = la conexión se ve larga en pantalla
      if (!hot && !dim && !S.reduce && eln > 70 && np < (big ? 90 : 40)) {
        const k0 = (t / (7 + ei % 7) + ei * .618) % 1;
        if (k0 < .2) { np++; const k = k0 / .2, e2 = k * k * (3 - 2 * k), e1 = Math.max(0, e2 - .24), lo = (p.d || 0) >= (q.d || 0), ax = lo ? x1 : x2, ay = lo ? y1 : y2, bx = lo ? x2 : x1, by = lo ? y2 : y1, dst = lo ? q : p;
          const col = dst.dc || (dst.dc = degCol(dst)), aP = Math.sin(Math.PI * k) * .48 * Math.min(1, (eln - 70) / 60) * ef * al;
          // partículas, no rayas: tres motas blandas en fila (la primera con un halo mínimo) que ondulan un poco al avanzar
          const dx = bx - ax, dy = by - ay, nx = -dy / eln, ny = dx / eln;
          for (let j = 0; j < 3; j++) { const kk = Math.max(0, e2 - j * .055), w = Math.sin(kk * 9 + ei) * 2.2 * (1 - kk), px = ax + dx * kk + nx * w, py = ay + dy * kk + ny * w, aj = aP * (1 - j * .32);
            if (!j) glow(c, px, py, big ? 7 : 5.5, col, aj * .9);
            c.fillStyle = j ? rgbA(col, aj) : `rgba(255,255,255,${aj})`; c.beginPath(); c.arc(px, py, (big ? 1.3 : 1.05) - j * .22, 0, 7); c.fill(); }
        } }
      if (hot && !S.reduce) { const src = fa ? p : q, e = (t - src.hl) / 1.4; if (e < 1) { const [sx, sy] = P(src), [ex, ey] = fa ? [x2, y2] : [x1, y1]; glow(c, sx + (ex - sx) * e, sy + (ey - sy) * e, big ? 7 : 5, KC[src.kind] || KC.read, .9 * (1 - e)); } }
    }
    EB.forEach(g => { c.strokeStyle = g.col; c.lineWidth = g.lw; c.stroke(g.path); });
    const fresh15 = Date.now() / 1000 - 900; let lab = null;
    const named = big ? new Set([...VG.nodes.values()].filter(s => !s.dead).sort((a, b) => b.d - a.d).slice(0, 9).map(s => s.id)) : null;
    { const ctr = PJ({ x: .5, y: .5, zs: 0 }), pul = S.reduce ? 1 : .85 + .15 * Math.sin(t * 1.3);   // corazón del núcleo
      if (isFinite(ctr[0])) { glow(c, ctr[0], ctr[1], Math.min(W, H) * .2 * Math.min(2, ctr[2]), "#ffd678", .14 * pul); glow(c, ctr[0], ctr[1], Math.min(W, H) * .07 * Math.min(2, ctr[2]), "#fff1c2", .22 * pul); } }
    if (!big) {   // cerebro: chispas que viajan por las conexiones desde lo caliente o muy enlazado y encienden la nota al llegar
      if (!S.reduce && VG.edges.length && Math.random() < .18) {
        const e0 = VG.edges[Math.floor(Math.random() * VG.edges.length)], a0 = VG.nodes.get(e0[0]), b0 = VG.nodes.get(e0[1]);
        if (a0 && b0) { const fw = ((a0.h || 0) + (a0.dn || 0)) >= ((b0.h || 0) + (b0.dn || 0)); VG.sparks.push({ a: fw ? a0 : b0, b: fw ? b0 : a0, t0: t, d: 1.1 + Math.random() * .8 }); }
      }
      VG.sparks = VG.sparks.filter(sp => { if ((t - sp.t0) / sp.d >= 1) { sp.b.fire = t; return false; } return true; }).slice(-60);
    }
    for (const sp of VG.sparks) { const pa = P(sp.a), pb = P(sp.b); if (!isFinite(pa[0]) || !isFinite(pb[0])) continue;
      const e = (t - sp.t0) / sp.d, ee = e * e * (3 - 2 * e); glow(c, pa[0] + (pb[0] - pa[0]) * ee, pa[1] + (pb[1] - pa[1]) * ee, (big ? 6 : 4.5) * Math.min(2, (pa[2] + pb[2]) / 2), "#bfe9ff", .75 * Math.sin(e * Math.PI)); }
    [...VG.nodes.values()].sort((a, b) => P(a)[3] - P(b)[3]).forEach(s => {   // de atrás hacia delante
      const al0 = alive(s); if (al0 <= 0) return;
      const [x, y, kz] = P(s); if (!isFinite(x)) return;   // detrás de la cámara
      const ef = EF(x, y); if (ef <= 0) return;
      const al = al0 * ef * Math.min(1, Math.max(.3, (kz - .2) * 2.2)), f = focus.has(s.id), e = t - s.hl, pop = Math.min(1, (t - s.born) / .7);   // niebla: lo lejano, tenue
      const core = (s.dn || 0) > .4 ? (s.dn - .4) / .6 : 0;   // 0..1: cuánto es núcleo
      const r = kz * ((big ? 2.2 : 1.5) + Math.min(big ? 7 : 4.6, Math.sqrt(s.d) * (big ? 1.6 : 1.2))) * (1 + 1.3 * core) * (pop < 1 ? ease(pop) * (1 + .5 * Math.sin(pop * Math.PI)) : 1) * (f ? 1 + .7 * Math.max(0, 1 - e / 1.1) : 1);
      // Color: huérfana (verde agua) · suelta a propósito (gris) · una sola conexión (gris claro) · resto, degradado de calor por visitas
      const base = s.dc || (s.dc = degCol(s));
      const col = f ? (KC[s.kind] || KC.read) : nb.has(s.id) ? "#e9e4ff" : core > 0 ? mixRgb(base, [255, 214, 120], .2 + .45 * core) : base;
      c.globalAlpha = al * (dim && !f && !nb.has(s.id) ? .32 : 1);
      if (f) { glow(c, x, y, r * 5, col, .55 * Math.max(.35, 1 - e / 3.2)); if (e < 1.3) { c.strokeStyle = col; c.lineWidth = 2; c.globalAlpha = al * (1 - e / 1.3); c.beginPath(); c.arc(x, y, r + 3 + e * (big ? 22 : 14), 0, 7); c.stroke(); c.globalAlpha = al; } }
      else if (s.m > fresh15) glow(c, x, y, r * 3.2, "#efe2a4", .35);
      if (!big && (s.fe || 0) > .05 && VG.orbPull && VG.grav.length < 120) {   // nota atraída y visible (no tapada por el orbe): de ella salen partículas
        const d0 = Math.hypot(VG.orbPull.x - x, VG.orbPull.y - ORB_R() * .6 - y); if (d0 > ORB_R() * 1.35 && isFinite(d0)) VG.grav.push({ id: s.id, tx: x, ty: y, fe: s.fe, col }); }
      if (!big && s.fsp && (s.fe || 0) > .04 && VG.orbPull) {   // púa negra y brillante que se estira hacia el orbe (ferrofluido)
        const OP = VG.orbPull, dx = OP.x - x, dy = OP.y - y, dd = Math.hypot(dx, dy) || 1, ux = dx / dd, uy = dy / dd, Lp = Math.min(dd * .85, 6 + 36 * s.fe), wb = Math.max(2.6, r * 1.2) + 2 * s.fe;
        const gx = c.createLinearGradient(x, y, x + ux * Lp, y + uy * Lp); gx.addColorStop(0, col); gx.addColorStop(.3, "#2a2046"); gx.addColorStop(1, "rgba(6,4,14,.95)");
        c.fillStyle = gx; c.beginPath(); c.moveTo(x - uy * wb, y + ux * wb); c.quadraticCurveTo(x + ux * Lp * .45 - uy * wb * .35, y + uy * Lp * .45 + ux * wb * .35, x + ux * Lp, y + uy * Lp);
        c.quadraticCurveTo(x + ux * Lp * .45 + uy * wb * .35, y + uy * Lp * .45 - ux * wb * .35, x + uy * wb, y - ux * wb); c.closePath(); c.fill();
        c.strokeStyle = `rgba(225,215,255,${.35 + .45 * s.fe})`; c.lineWidth = 1; c.beginPath(); c.moveTo(x - uy * wb * .5, y + ux * wb * .5); c.quadraticCurveTo(x + ux * Lp * .45 - uy * wb * .2, y + uy * Lp * .45 + ux * wb * .2, x + ux * Lp * .95, y + uy * Lp * .95); c.stroke();
      }
      if (s.o === 2 && !f) c.globalAlpha *= .5;
      if (s.fire && t - s.fire < .7) glow(c, x, y, r * 4, "#bfe9ff", .45 * (1 - (t - s.fire) / .7));   // neurona que se enciende
      if (VG.cam.tgt === s && !VG.cam.wide && al > .3) { c.globalAlpha = Math.min(1, (t - VG.cam.since) / 1.5); c.fillStyle = "#fff"; c.font = `800 ${big ? 13 : 10.5}px Nunito, system-ui`; c.textAlign = "center"; c.fillText(fitText(c, s.t, big ? 220 : 120), LX(x), Math.max(Y + MG + 10, y - r - 7)); c.globalAlpha = 1; }
      if (s.kick && t - s.kick < .9) { const kk = 1 - (t - s.kick) / .9; c.strokeStyle = hexA("#ffffff", .7 * kk); c.lineWidth = 1.5; c.beginPath(); c.arc(x, y, r + 2 + (1 - kk) * 18, 0, 7); c.stroke(); }   // onda del golpe
      if (!f && core > 0) { glow(c, x, y, r * (3 + 4 * core), "#ffd678", .14 + .3 * core); c.strokeStyle = hexA("#fff3c4", .5 + .4 * core); c.lineWidth = 1.4; c.beginPath(); c.arc(x, y, r + 1.5, 0, 7); c.stroke(); }   // núcleo: dorado, con aro
      if (!f && !s.ring && (s.h || 0) > .5 && !S.reduce) { const pu = .5 + .5 * Math.sin(t * 2.2 + (s.zj || 0) * 20); c.strokeStyle = `rgba(255,255,255,${(.25 + .45 * (s.h - .5)) * pu})`; c.lineWidth = 1; c.beginPath(); c.arc(x, y, r + 2.5 + 2 * pu, 0, 7); c.stroke(); }   // tránsito (lo que más se toca): ya no da el color; solo un aro blanco que late
      if (s.ring && !f) { c.globalAlpha = Math.max(c.globalAlpha, .6 * al0 * ef); c.fillStyle = col; const rr2 = Math.max(big ? 1.6 : 1.25, r * .8); c.fillRect(x - rr2, y - rr2, rr2 * 2, rr2 * 2); c.globalAlpha = 1; return; }   // cinturón: puntos sencillos y baratos (son cientos)
      c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill();
      if (s.o === 1 && !f && big) { c.strokeStyle = "#37e3c2"; c.lineWidth = 1.2; c.setLineDash([2, 2]); c.beginPath(); c.arc(x, y, r + 3, 0, 7); c.stroke(); c.setLineDash([]); }   // nota huérfana de verdad: solo se marca en la vista grande
      c.globalAlpha = 1;
      if (f && (!lab || s.hl > lab.hl)) lab = s;
      if (!big && !f && core > .25 && al > .5) { c.globalAlpha = al * .9; c.fillStyle = "#fff3c4"; c.font = "800 9.5px Nunito, system-ui"; c.textAlign = "center"; c.fillText(fitText(c, s.t, 80), LX(x), Math.max(Y + MG + 10, y - r - 5)); c.globalAlpha = 1; }   // nombre del núcleo siempre a la vista
      if (big && UI.sel === s) { c.globalAlpha = 1; c.fillStyle = "#fff"; c.font = "800 13px Nunito, system-ui"; c.textAlign = "center";
        c.fillText(fitText(c, s.t, 200), x, y - r - 10); c.font = "600 10.5px Nunito, system-ui"; c.fillStyle = "#d9d4ee";
        c.fillText(`${s.d || 0} enlaces · tránsito ${Math.round((s.h || 0) * 100)} % · masa ${(s.mass || 1).toFixed(1)}`, x, y + r + 14); }
      else if (big && (f || named.has(s.id))) { c.globalAlpha = al * (f ? 1 : dim ? .2 : .55); c.fillStyle = f ? "#fff" : "#d9d4ee"; c.font = `${f ? 800 : 600} ${f ? 12 : 10.5}px Nunito, system-ui`; c.textAlign = "center"; c.fillText(fitText(c, s.t, 120), x, y + r + 12); c.globalAlpha = 1; }
    });
    c.restore();
    return lab ? { s: lab, p: P(lab) } : null;
  }
  function drawVault(c, t, usage) {
    const v = S.L.vault, using = (usage && usage.obsidian) || 0, col = ZONES.obsidian.c;
    if (VG.gv < 0) { const g0 = ((S.D || {}).vault || {}).graph; if (g0 && g0 !== VG.src) { VG.src = g0; vgSetGraph(g0); } }
    const pad = 12, gx = v.x + pad, gy = v.y + 40, gw = v.w - pad * 2, gh = v.h - 40 - 30;
    if (using) { glow(c, v.x + v.w / 2, v.y + v.h / 2, v.w * .9, col, .3 * (.7 + .3 * Math.sin(t * 2.4))); c.strokeStyle = col; c.lineWidth = 3; oct(c, v.x, v.y, v.w, v.h, VOCT(v)); c.stroke(); }
    if (!VG.nodes.size) {
      c.fillStyle = "rgba(200,190,255,.6)"; c.font = "600 13px Nunito, system-ui"; c.textAlign = "center";
      c.fillText(((S.D || {}).vault || {}).total ? (S.D.vault.total + " notas") : "sin datos", v.x + v.w / 2, v.y + v.h / 2); return;
    }
    // Capa propia del grafo a la resolución de la pantalla; su borde se funde con el panel (sin cortes) y se pega encima.
    const Rx = v.x + 2, Ry = v.y + 2, Rw = v.w - 4, Rh = v.h - 4, k = Math.max(1, Math.min(window.FARO_AHORRO ? 1 : S.lite ? 1.5 : 2.5, (S.scale || 1) * Math.min(2, devicePixelRatio || 1)));
    const lc = VG.layer || (VG.layer = document.createElement("canvas")), lw = Math.ceil(Rw * k), lh = Math.ceil(Rh * k);
    if (lc.width !== lw || lc.height !== lh) { lc.width = lw; lc.height = lh; }
    const lx = lc.getContext("2d"); lx.setTransform(1, 0, 0, 1, 0, 0); lx.clearRect(0, 0, lw, lh); lx.setTransform(k, 0, 0, k, -Rx * k, -Ry * k);
    const lab = vgDraw(lx, gx, gy, gw, gh, false);
    { const f = Math.min(30, Math.min(Rw, Rh) * .12), mk = octMask(Rw * k, Rh * k, (VOCT(v) - 3) * k, f * k);   // borde octogonal fundido
      lx.setTransform(1, 0, 0, 1, 0, 0); lx.globalCompositeOperation = "destination-in"; lx.drawImage(mk, 0, 0, lw, lh); lx.globalCompositeOperation = "source-over"; }
    c.drawImage(lc, Rx, Ry, Rw, Rh);
    // del agente (o del canal por el que llega) a la nota que toca
    // Llamadas a la bóveda. La oficina está arriba, sobre un suelo de cristal; la bóveda queda debajo y el octógono es la
    // barandilla. Cada llamada es un lanzamiento: sale del panel del agente en arco por encima de la barandilla, toca el
    // cristal (onda) y desde ahí cae, ya bajo el cristal (más fina, tenue y encogiendo), hasta su nota. Nada se dibuja
    // fuera del octógono: si la nota queda fuera de la vista, el hilo acaba en el borde interior. Con muchas llamadas a la
    // vez solo las 8 más nuevas dibujan hilo; el resto, solo su chispa, y las de un mismo agente salen escalonadas.
    const LIFE = 2.9; VG.beams = VG.beams.filter(b => t - b.t0 < LIFE);
    { const vk = VOCT(v), inO = (x, y, m) => x > v.x + m && x < v.x + v.w - m && y > v.y + m && y < v.y + v.h - m &&
        (x - v.x) + (y - v.y) > vk + m * 1.41 && (v.x + v.w - x) + (y - v.y) > vk + m * 1.41 && (x - v.x) + (v.y + v.h - y) > vk + m * 1.41 && (v.x + v.w - x) + (v.y + v.h - y) > vk + m * 1.41;
      const vcx = v.x + v.w / 2, vcy = v.y + v.h / 2;
      const pull = (x, y, tx, ty, m) => { if (inO(x, y, m)) return [x, y]; let lo = 0, hi = 1; for (let i = 0; i < 9; i++) { const md = (lo + hi) / 2; if (inO(x + (tx - x) * md, y + (ty - y) * md, m)) hi = md; else lo = md; } return [x + (tx - x) * hi, y + (ty - y) * hi]; };
      const live = VG.beams.filter(b => t >= b.t0), nLine = 8;
      live.forEach((b, bi) => {
        const s = VG.nodes.get(b.id); if (!s) return; const raw = s.pj ? s.pj : [gx + s.x * gw, gy + s.y * gh], e = (t - b.t0) / LIFE;
        const ag = b.ag && S.ag.get(b.ag);
        let from = ag ? agSrc(ag) : null;
        if (!from && b.via === "sync") { const ch = S.L.chan.find(x => x.k === "local"); from = [ch.x + ch.w / 2, ch.y]; }
        if (!from && b.who === "Faro") { const O0 = orbState(); from = [O0.x, O0.y]; }
        if (!from || ![from[0], from[1], raw[0], raw[1]].every(Number.isFinite)) return;
        const T = pull(raw[0], raw[1], vcx, vcy, 16);                       // la nota, o el borde interior si queda fuera de la vista
        const inside = inO(from[0], from[1], 4), E = inside ? from : pull(from[0], from[1], T[0], T[1], 20);   // donde toca el cristal
        const dA = Math.hypot(E[0] - from[0], E[1] - from[1]), cA = [(from[0] + E[0]) / 2, Math.min(from[1], E[1]) - 26 - dA * .16];
        const atA = k => { const u = 1 - k; return [u * u * from[0] + 2 * u * k * cA[0] + k * k * E[0], u * u * from[1] + 2 * u * k * cA[1] + k * k * E[1]]; };
        const sw = S.reduce ? 0 : Math.sin(t * .7 + b.t0 * 3.1) * 10, mB = [(E[0] + T[0]) / 2 - (T[1] - E[1]) * .12 + sw, (E[1] + T[1]) / 2 + (T[0] - E[0]) * .12];
        const cB = pull(mB[0], mB[1], vcx, vcy, 14);
        const atB = k => { const u = 1 - k; return [u * u * E[0] + 2 * u * k * cB[0] + k * k * T[0], u * u * E[1] + 2 * u * k * cB[1] + k * k * T[1]]; };
        const kA = inside ? 0 : .42, fade = Math.min(1, e / .1) * (e < .7 ? 1 : Math.max(0, (1 - e) / .3)), line = bi >= live.length - nLine, la = line ? 1 : 0;
        const qA = kA ? Math.min(1, e / kA) : 1, qB = clamp((e - kA) / (.8 - kA), 0, 1), eA = qA * qA * (3 - 2 * qA) * .6 + (1 - (1 - qA) * (1 - qA)) * .4, eB = qB * qB * (3 - 2 * qB) * .5 + qB * qB * .5;   // sale suave, sin tirón
        c.lineCap = "round";
        if (la && kA) {   // el arco del lanzamiento, por encima de la barandilla: se dibuja hasta donde va la chispa
          c.strokeStyle = hexA(b.col, .55 * fade); c.lineWidth = 1.6; c.beginPath(); c.moveTo(from[0], from[1]);
          for (let i = 1; i <= 10; i++) { const p = atA(eA * i / 10); c.lineTo(p[0], p[1]); } c.stroke(); }
        if (qA >= 1 && kA) { const r = clamp((e - kA) / .3, 0, 1); if (r < 1) { c.strokeStyle = hexA(b.col, .8 * (1 - r)); c.lineWidth = 1.3; c.beginPath(); c.ellipse(E[0], E[1], 4 + 13 * r, 1.6 + 5 * r, 0, 0, 7); c.stroke(); } }   // onda en el cristal
        if (la && qA >= 1 && eB > 0) {   // la caída, bajo el cristal
          // la misma línea que el lanzamiento, sin corte: continua, se adelgaza y se apaga al hundirse
          let q = E; for (let i = 1; i <= 12; i++) { const k = i / 12, p = atB(eB * k);
            c.strokeStyle = hexA(b.col, .55 * fade * (1 - .55 * k * eB)); c.lineWidth = 1.6 - .7 * k * eB;
            c.beginPath(); c.moveTo(q[0], q[1]); c.lineTo(p[0], p[1]); c.stroke(); q = p; } }
        if (!S.reduce && e < .8) { const up = qA < 1, p = up ? atA(eA) : atB(eB), z = up ? 1 : 1 - .5 * eB;   // la chispa: grande arriba, encoge al caer
          const sa = Math.min(1, e / .08) * Math.min(1, (.8 - e) / .1); glow(c, p[0], p[1], 12 * z, b.col, (up ? .9 : .7) * (line ? 1 : .6) * sa); c.fillStyle = `rgba(255,255,255,${sa})`; c.beginPath(); c.arc(p[0], p[1], 2 * z, 0, 7); c.fill(); }
      }); }
    vgHistDraw(c, v, t);
    // etiqueta de la nota que se está tocando, como al pasar el ratón en Obsidian
    if (lab) {
      c.font = `800 ${S.L.wide ? 12 : 12}px Nunito, system-ui`; const txt = fitText(c, lab.s.t, v.w - 30), tw = c.measureText(txt).width + 12;
      const lx = clamp(lab.p[0] - tw / 2, v.x + 6, v.x + v.w - 6 - tw), ly = clamp(lab.p[1] - 26, v.y + 58, v.y + v.h - 50);
      c.fillStyle = "rgba(10,8,28,.85)"; rr(c, lx, ly, tw, 18, 8); c.fill(); c.strokeStyle = hexA(KC[lab.s.kind] || KC.read, .8); c.lineWidth = 1; c.stroke();
      c.fillStyle = "#fff"; c.textAlign = "left"; c.fillText(txt, lx + 6, ly + 13);
    }
    const L0 = VG.last && t - VG.last.t < 12 ? VG.last : null;
    c.font = `${L0 ? 800 : 600} ${S.L.wide ? 12 : 12}px Nunito, system-ui`; c.textAlign = "left";
    c.fillStyle = L0 ? (KC[L0.k] || KC.read) : "rgba(200,190,255,.75)";
    const foot = L0 ? `${L0.who ? shortName(L0.who.split(" · ")[0]) + " " : L0.maybe ? "¿" + shortName(L0.maybe.split(" · ")[0]) + "? " : ""}${VERB[L0.k] || "toca"} «${L0.title}»` : `${VG.total ?? 0} notas · ${VG.links ?? 0} enlaces · ${VG.orphans ?? 0} huérfanas · ${VG.leaves ?? 0} con 1 enlace${VG.src === "obsidian" ? " · dibujo de Obsidian" : ""}${VG.obs ? " · filtros de Obsidian" + (VG.obs.att ? "" : ", sin adjuntos") : ""}`;
    c.textAlign = "center"; c.font = `${L0 ? 800 : 600} ${S.L.wide ? 12 : 11}px Nunito, system-ui`; c.fillText(fitText(c, foot, v.w - 40), v.x + v.w / 2, v.y + 48);
  }
  // Ficha grande de la bóveda: el grafo a tamaño de verdad, con nombres, y el registro de accesos reales
  function vgLogHTML() {
    const hh = ms => new Date(ms).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    const rows = VG.log.slice(0, 10).map(e => `<li><b style="color:${KC[e.k] || KC.read}">${esc(VERB[e.k] || e.k)}</b> ${esc(String(e.p).split("/").pop())}<span>${hh(e.at)}</span><p>${esc(e.who || (e.maybe ? "sin identificar (¿" + e.maybe + "?)" : e.via === "sync" ? "llega sincronizada (Mac u otro equipo)" : "sin identificar"))}</p></li>`);
    return rows.length ? rows.join("") : "<li>Aún no ha habido accesos desde que abriste la oficina.</li>";
  }
  function vgWho() { const w = [...S.ag.values()].filter(a => a.st === "work" && a.zone === "obsidian"); return w.length ? "En la bóveda: " + w.map(a => esc(shortName(a.name))).join(" · ") : "Nadie trabajando en la bóveda ahora mismo"; }
  function vgCardUpdate() { const el = S.root && S.root.querySelector(".fo-vlog"); if (el) el.innerHTML = vgLogHTML(); }
  function drawVaultCard() {
    const cv = S.root && !S.root.querySelector(".fo-card").hidden && S.root.querySelector(".fo-vg"); if (!cv) return;
    const dpr = Math.min(2, devicePixelRatio || 1), w = cv.clientWidth, h = cv.clientHeight; if (!w || !h) return;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    const c = cv.getContext("2d"); c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, w, h);
    vgDraw(c, 18, 18, w - 36, h - 40, true);
    feather(c, 0, 0, w, h, Math.min(40, h * .12));
    vgHistDraw(c, { x: 0, y: 0, w, h: h - 6 }, now());
    c.save(); c.globalCompositeOperation = "destination-over"; c.fillStyle = "#120f26"; c.fillRect(0, 0, w, h); c.restore();
  }

  /* ───────── dibujo dinámico ───────── */
  // Vector bóveda → orbe: energía gravitatoria en enjambres. Cada enjambre es UNA imagen ya pintada (13 motas: mini
  // remolinos y chispas de CHF y puntos, alargada en el sentido del vector) teñida una vez por color; así parecen cientos
  // de partículas con unas 40 pinturas por fotograma y sin halos. Salen del color de su nota y acaban del color del orbe.
  function chfSwarm(col) {
    const [r, g, b] = hexRgb(col).map(v => Math.min(255, Math.round(v / 48) * 48)), key = "sw:" + r + "," + g + "," + b;
    let cv = CHF.tint.get(key); if (cv) return cv;
    if (!CHF.swarm) { const m = CHF.swarm = document.createElement("canvas"); m.width = 96; m.height = 40; const x = m.getContext("2d"); let sd = 11;
      const rnd = () => (sd = (sd * 9301 + 49297) % 233280) / 233280;
      for (let i = 0; i < 13; i++) { const px = 6 + rnd() * 84, py = 20 + (rnd() - .5) * 30 * (1 - Math.abs(px - 48) / 60), k = i % 3;
        x.globalAlpha = .55 + rnd() * .45;
        if (k === 0) { const z = 9 + rnd() * 5, R = CHF.f.swirl; x.drawImage(CHF.img, R[0], R[1], R[2], R[3], px - z / 2, py - z / 2, z, z); }
        else if (k === 1) { const z = 7 + rnd() * 4, R = CHF.f.spark; x.drawImage(CHF.img, R[0], R[1], R[2], R[3], px - z / 2, py - z / 2, z, z); }
        else { x.fillStyle = "#fff"; x.fillRect(px, py, 2, 2); x.globalAlpha *= .4; x.fillRect(px - 5, py + .5, 5, 1); } } }
    cv = document.createElement("canvas"); cv.width = 96; cv.height = 40; const x = cv.getContext("2d");
    x.drawImage(CHF.swarm, 0, 0); x.globalCompositeOperation = "source-atop"; x.fillStyle = `rgba(${r},${g},${b},.62)`; x.fillRect(0, 0, 96, 40);
    if (CHF.tint.size > 240) CHF.tint.clear(); CHF.tint.set(key, cv); return cv;
  }
  function vgPath(a, b, max) {   // camino más corto por los enlaces de la bóveda (búsqueda en anchura, hasta «max» saltos)
    if (a === b) return [a]; const prev = new Map([[a, null]]); let fr = [a];
    for (let d = 0; d < max && fr.length; d++) { const nx = [];
      for (const id of fr) for (const k of VG.adj.get(id) || []) { if (prev.has(k) || !VG.nodes.has(k)) continue; prev.set(k, id);
        if (k === b) { const out = [b]; let q = id; while (q != null) { out.unshift(q); q = prev.get(q); } return out; } nx.push(k); }
      fr = nx; }
    return null;
  }
  // Satélites que el orbe suelta sobre la bóveda: caen atraídos a una conexión, entran, la encienden y siguen su camino por
  // el grafo dejando una estela que se desvanece; cada nota por la que pasan hace un guiño y la última, un latido.
  function drawDeposits(c, t) {
    const O = S.orb, L = O && O.drops; if (!L || !L.length) return;
    const HOP = .42, IN = .3, TR = 1.4, pj = id => { const n = typeof id === "string" || typeof id === "number" ? VG.nodes.get(id) : id; return n && n.pj && isFinite(n.pj[0]) ? n.pj : null; };
    O.drops = L.filter(d => t - d.t0 < d.fall + IN + (d.path.length - 1) * HOP + TR);
    c.lineCap = "round";
    O.drops.forEach(d => { const e = t - d.t0, pa = pj(d.a), pb = pj(d.b); if (!pa || !pb) return;
      const T = [pa[0] + (pb[0] - pa[0]) * d.u, pa[1] + (pb[1] - pa[1]) * d.u], rgbs = `rgb(${d.rgb.join(",")})`;
      if (e < d.fall) {   // atraído a la conexión: cae en arco, acelerando
        const q = e / d.fall, k = q * q, dx = T[0] - d.fx, dy = T[1] - d.fy, D = Math.hypot(dx, dy) || 1, off = Math.sin(Math.PI * k) * D * .2 * d.side;
        const x = d.fx + dx * k - dy / D * off, y = d.fy + dy * k + dx / D * off;
        glow(c, x, y, 10, d.col, .85 * Math.min(1, q * 4)); c.fillStyle = "#fff"; c.beginPath(); c.arc(x, y, 1.5, 0, 7); c.fill(); return; }
      // dentro: puntos del recorrido (toque → primera nota → siguientes) con el instante en que llega a cada uno
      const pts = [T], tm = [d.fall]; let ok = true;
      d.path.forEach((id, i) => { const p = pj(id); if (!p) ok = false; pts.push(p); tm.push(d.fall + IN + i * HOP); }); if (!ok) return;
      let head = null; const v = S.L.vault; c.save(); oct(c, v.x + 3, v.y + 3, v.w - 6, v.h - 6, VOCT(v) - 3); c.clip();   // dentro del grafo: nada sale del octógono
      for (let i = 0; i < pts.length - 1; i++) { if (e < tm[i]) break; if (!vgInOct(pts[i][0], pts[i][1], 0) && !vgInOct(pts[i + 1][0], pts[i + 1][1], 0)) continue; const k = clamp((e - tm[i]) / (tm[i + 1] - tm[i]), 0, 1), ke = k * k * (3 - 2 * k), age = e - tm[i + 1];
        const a = age > 0 ? Math.max(0, 1 - age / TR) : 1; if (a <= 0) continue;
        const x = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * ke, y = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * ke;
        c.strokeStyle = rgbA(rgbs, .22 * a); c.lineWidth = 4; c.beginPath(); c.moveTo(pts[i][0], pts[i][1]); c.lineTo(x, y); c.stroke();   // la conexión, encendida
        c.strokeStyle = rgbA(rgbs, .8 * a); c.lineWidth = 1.2; c.beginPath(); c.moveTo(pts[i][0], pts[i][1]); c.lineTo(x, y); c.stroke();
        if (k < 1) head = [x, y];
        else { const r = age / .7, last = i === pts.length - 2;   // guiño de la nota por la que pasa; la última late dos veces
          if (r < 1) { c.strokeStyle = rgbA(rgbs, .8 * (1 - r)); c.lineWidth = 1.2; c.beginPath(); c.arc(pts[i + 1][0], pts[i + 1][1], 3 + (last ? 16 : 8) * r, 0, 7); c.stroke(); }
          if (last) { const r2 = (age - .25) / .9; if (r2 > 0 && r2 < 1) { c.strokeStyle = rgbA(rgbs, .6 * (1 - r2)); c.beginPath(); c.arc(pts[i + 1][0], pts[i + 1][1], 3 + 24 * r2, 0, 7); c.stroke(); } glow(c, pts[i + 1][0], pts[i + 1][1], 18, d.col, .7 * Math.max(0, 1 - age / 1.1)); } } }
      if (head) { glow(c, head[0], head[1], 9, d.col, .9); c.fillStyle = "#fff"; c.beginPath(); c.arc(head[0], head[1], 1.5, 0, 7); c.fill(); }
      c.restore(); });
  }
  function drawGravity(c, t) {
    const G = VG.grav; if (!G || !G.length || t - (VG.gravT || 0) > .3 || S.reduce || !VG.orbPull || !VG.orbPull.k) return;
    chfLoad(); if (!CHF.ok) return;
    const O = orbState(), R = ORB_R(), oc = O.rgb || [255, 179, 71]; VG.gravN = 0;
    G.slice().sort((a, b) => b.fe - a.fe).slice(0, 7).forEach(g => {   // pocas y suaves: que se note la atracción sin llenar la bóveda
      let hs = 0; for (const ch of String(g.id)) hs = (hs * 31 + ch.charCodeAt(0)) % 997;
      const dx = O.x - g.tx, dy = O.y - g.ty, D = Math.hypot(dx, dy) || 1, ux = dx / D, uy = dy / D, n0 = hexRgb(g.col);
      for (let j = 0; j < 2; j++) {
        const q = (t * .3 + hs / 997 + j / 2) % 1, k = q * q, off = Math.sin(q * 6.3 + hs) * 4;   // acelera al caer; leve vaivén sobre el vector
        const x = g.tx + dx * k - uy * off, y = g.ty + dy * k + ux * off, d = D * (1 - k); if (d < R * .9) continue;
        const a = .6 * Math.min(1, .35 + g.fe * 1.3) * Math.min(1, q * 4) * Math.min(1, (d - R * .9) / (R * .8)); if (a < .04) continue; VG.gravN++;
        const kq = k < .34 ? 0 : k < .67 ? .5 : 1, col = `rgb(${n0.map((v, i) => Math.round(v + (oc[i] - v) * kq)).join(",")})`;
        const w = 26 * (1 - .45 * k), st = 1 + .8 * k;   // se estira y encoge al acercarse, como absorbido
        c.globalAlpha = a; c.setTransform(S.tf[0] * ux * st, S.tf[0] * uy * st, -S.tf[0] * uy, S.tf[0] * ux, S.tf[1] + x * S.tf[0], S.tf[2] + y * S.tf[0]);
        c.drawImage(chfSwarm(col), -w / 2, -w * .21, w, w * .42);
      }
    });
    c.globalAlpha = 1; c.setTransform(S.tf[0], 0, 0, S.tf[0], S.tf[1], S.tf[2]);
  }
  function drawBokeh(c, t) {
    if (!S.bokeh.length) for (let i = 0; i < 26; i++) S.bokeh.push({ x: Math.random() * S.L.W, y: Math.random() * S.L.H, r: 20 + Math.random() * 60, v: 4 + Math.random() * 10, c: ["#3b82f6", "#aa9de8", "#22d3ee", "#f29b9d"][i % 4], a: .05 + Math.random() * .07 });
    S.bokeh.forEach(b => { if (!S.reduce) { b.y -= b.v / 60; if (b.y < -b.r) b.y = S.L.H + b.r; } glow(c, b.x + Math.sin(t * .2 + b.r) * 10, b.y, b.r, b.c, b.a); });
  }
  /* ───────── el ojo de Faro: un orbe que flota (14 nov; antes era la linterna de un faro) ─────────
     Mismas reglas que el ojo de siempre: recorre a quien trabaja por orden de mesa, se queda más y estrecha el haz cuanto
     menos le falta a la tarea, y sin trabajo se apaga y parpadea. Ahora además vuela: ilumina → enfoca → persigue → ilumina
     desde arriba → siguiente. Sin nadie trabajando sobrevuela la bóveda, y su gravedad tira de las notas como un imán de un
     ferrofluido. Cada dato que llega (cambio real de un agente) vuela hasta él y lo alimenta con un golpe de energía de su color.
     Diseño propio: esfera de cristal oscuro con un iris de luz dentro, dos anillos y su luz. */
  const VOCT = v => Math.min(v.w, v.h) * .293;   // corte del octógono regular de la bóveda
  function vgInOct(x, y, m) {   // ¿(x, y) dentro del octógono de la bóveda, con margen m?
    const v = S.L.vault, vk = VOCT(v), mm = (m || 0) * 1.41; m = m || 0;
    return x > v.x + m && x < v.x + v.w - m && y > v.y + m && y < v.y + v.h - m && (x - v.x) + (y - v.y) > vk + mm &&
      (v.x + v.w - x) + (y - v.y) > vk + mm && (x - v.x) + (v.y + v.h - y) > vk + mm && (v.x + v.w - x) + (v.y + v.h - y) > vk + mm;
  }
  const ORB_R = () => S.L.wide ? 31 : 29;
  function orbState() {
    const O = S.orb || (S.orb = { x: S.L.orbHome[0], y: S.L.orbHome[1] - 40, vx: 0, vy: 0, ax: null, ay: null, feeds: [], look: [0, 1], lastFeed: null });
    if (O.L !== S.L) {   // al cambiar de formato no vuelve a casa: conserva su sitio relativo en la oficina
      if (O.L) { O.x = O.x / O.L.W * S.L.W; O.y = O.y / O.L.H * S.L.H; } else { O.x = S.L.orbHome[0]; O.y = S.L.orbHome[1] - 40; }
      O.L = S.L; O.vx = O.vy = 0; O.ax = O.ax == null ? null : O.x; O.ay = O.ay == null ? null : O.y; }
    return O;
  }
  function hexRgb(h) { const m = /rgb\((\d+),\s*(\d+),\s*(\d+)\)/.exec(h); if (m) return [+m[1], +m[2], +m[3]]; const n = parseInt(String(h).slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
  function orbMote(col, kind) {   // un punto de energía que se queda orbitándolo (los últimos 10)
    const O = orbState(); O.motes = O.motes || [];
    O.motes.push({ col, rgb: hexRgb(col), t0: now(), kind, r: 1.75 + Math.random() * .9, sp: (.18 + Math.random() * .22) * (Math.random() < .5 ? 1 : -1), ph: Math.random() * 6.28, tilt: .35 + Math.random() * .35, rot: (Math.random() - .5) * .9 });
    if (O.motes.length > 12) O.motes.shift();
  }
  function orbFeed(col, from) {
    const O = orbState(), t = now(); O.feeds.push({ col, t }); if (O.feeds.length > 8) O.feeds.shift(); O.lastFeed = { col, t };
    O.en = (O.en || 0) + 1; orbMote(col, "dato");
    if (from && !S.reduce) { const dx = O.x - from[0], dy = O.y - from[1], d = Math.hypot(dx, dy) || 1; O.vx += dx / d * 14; O.vy += dy / d * 14; }   // el golpe lo mece un poco
  }
  // a dónde mira el ojo en un agente: su pantalla si está sentado; si no (p. ej. consultando la bóveda), su cabeza
  function orbAim(a) {
    const dk = a.desk != null ? S.L.desks[a.desk] : null, sp = dk ? DG(dk).seat : null;
    if (dk && !a.walking && Math.hypot(a.x - sp[0], a.y - sp[1]) < 4) return { x: DG(dk).sx, y: DG(dk).sy, fx: a.x + 20, fy: a.y + 22, hx: a.x + 30, hy: a.y - 92 };
    return { x: a.x, y: a.y - 40, fx: a.x, fy: a.y + 24, hx: a.x, hy: a.y - 104 };
  }
  function orbStep(dt, t) {
    const O = orbState(), E = S.eye || (S.eye = { ang: Math.PI / 2, target: null, fresh: 0, open: 0, phase: 0 });
    // ruta: recorre a quien trabaja en orden de mesa (de la más cercana a la bóveda hacia fuera) y la mantiene.
    // Si alguien entra o sale, sigue por donde iba (no vuelve a empezar); si nadie trabaja, se queda donde está y
    // solo tras una espera larga va a la bóveda; en cuanto vuelve el trabajo, sale desde donde esté.
    const rank = a => S.L.deskRank.indexOf(a.desk);
    const workers = [...S.ag.values()].filter(a => (a.st === "work" || a.st === "bg") && a.desk != null && S.L.desks[a.desk]).sort((a, b) => rank(a) - rank(b));
    let k = 0;
    if (E.slotStart == null || t < E.slotStart) E.slotStart = t;
    const cur = E.target && S.ag.get(E.target), curOk = cur && workers.includes(cur);
    if (curOk) E.lost = null; else if (cur && E.lost == null) E.lost = t;
    if (workers.length) {
      E.idleSince = null;
      const slot = Math.max(7.5, 15 / workers.length);
      // el turno acaba por tiempo, o porque quien miraba dejó de trabajar (con 3 s de margen por si es un parpadeo del estado)
      const done = curOk ? t - E.slotStart >= slot : !cur || t - (E.lost || t) > 3 || !S.ag.has(E.target);
      if (done) {
        const lr = curOk ? rank(cur) : (E.lastRank == null ? -1 : E.lastRank);
        const nxt = workers.find(a => rank(a) > lr) || workers[0];
        const prev = E.target && S.ag.get(E.target); if (prev && prev.zone && ZONES[prev.zone]) orbMote(ZONES[prev.zone].c, "visita");   // se lleva un punto de energía de quien ha visitado
        E.target = nxt.id; E.fresh = t; E.slotStart = t; O.ax = O.x; O.ay = O.y; E.beatDone = false; E.lost = null; E.bk = 0;   // el haz vuelve a nacer, fundido
      }
      const tg = S.ag.get(E.target); if (tg && tg.desk != null) E.lastRank = rank(tg);
      k = clamp((t - E.slotStart) / slot, 0, 1);
    } else {
      if (E.idleSince == null) E.idleSince = t;
      if (E.target && (!cur || t - (E.lost || t) > 3)) { E.target = null; O.ax = O.x; O.ay = O.y; }
      if (cur && E.target) k = clamp((t - E.slotStart) / 7.5, 0, 1);
    }
    const tgt = E.target && S.ag.get(E.target);
    // Con un solo agente trabajando no se queda clavado encima: lo mira (ciclo normal) → lo orbita → se aburre y baja a
    // la bóveda (donde absorbe y deposita) → juega con sus satélites → vuelve a mirarlo. Duraciones con algo de azar.
    if (workers.length !== 1 || !tgt) E.mood = null;
    else { if (!E.mood) E.mood = { k: "mira", t0: t, until: t + 15 };
      if (t >= E.mood.until) { const seq = ["mira", "orbita", "boveda", "juega"], dur = { mira: 15, orbita: 11, boveda: 16, juega: 9 };
        let nx = seq[(seq.indexOf(E.mood.k) + 1) % 4]; if (nx === "juega" && (O.motes || []).length < 3) nx = "mira";
        E.mood = { k: nx, t0: t, until: t + dur[nx] * (.8 + Math.random() * .4) }; if (nx === "mira") { E.slotStart = t; E.beatDone = false; O.ax = O.x; O.ay = O.y; k = 0; } } }
    const mood = E.mood ? E.mood.k : "mira", away = mood === "boveda" || mood === "juega";
    E.open += ((tgt && !away ? 1 : 0) - E.open) * Math.min(1, dt * 1.6);
    E.phase = !tgt ? "libre" : mood === "orbita" ? "orbita" : mood === "boveda" ? "aburrido" : mood === "juega" ? "juega" : k < .18 ? "ilumina" : k < .35 ? "enfoca" : k < .6 ? "persigue" : "arriba";
    O.play = (O.play || 0) + ((mood === "juega" ? 1 : 0) - (O.play || 0)) * Math.min(1, dt * 1.5);
    // todo lo que rodea al orbe cambia sin saltos: ancho del haz, paso de haz a foco cenital, color y tamaño
    const sm = (cur, to, sp) => cur + (to - cur) * Math.min(1, dt * sp);
    E.nar = sm(E.nar == null ? 1 : E.nar, E.phase === "ilumina" ? 1 : .35, 1.6);
    E.up = sm(E.up || 0, E.phase === "arriba" ? 1 : 0, 2.2); E.bk = sm(E.bk == null ? 0 : E.bk, tgt && !away ? 1 : 0, 1.1);   // aparición del haz: ~1,5 s
    const toC = (() => {   // color: mezcla de los datos recientes (pesan más los nuevos); sin datos, ámbar
      let w0 = .6, c0 = [255 * w0, 179 * w0, 71 * w0]; (O.motes || []).forEach(m => { const w = Math.exp(-(t - m.t0) / 35) * (m.kind === "dato" ? 1 : .6); w0 += w; for (let i = 0; i < 3; i++) c0[i] += m.rgb[i] * w; });
      return c0.map(v => v / w0); })();
    O.rgb = O.rgb || toC.slice(); for (let i = 0; i < 3; i++) O.rgb[i] = sm(O.rgb[i], toC[i], 1.2);
    const bumpTo = O.feeds.reduce((m, f) => Math.max(m, Math.max(0, 1 - (t - f.t) / 1.2) * .1), 0); O.bump = sm(O.bump || 0, bumpTo, 6);
    if (tgt && !E.beatDone && k >= .18) { tgt.beat = t; E.beatDone = true; }   // cuando el haz se fija, ese agente «late»
    // a dónde vuela (con un vaivén lento propio: nunca está del todo quieto)
    let dx, dy, VM = S.L.wide ? 150 : 120, AM = S.L.wide ? 95 : 80;
    const sway = S.reduce ? [0, 0] : [Math.sin(t * .31) * 10 + Math.sin(t * .17 + 2) * 6, Math.cos(t * .27) * 6];
    if (!tgt) {   // sin trabajo: primero se queda flotando donde estaba; pasados 25 s va despacio a sobrevolar la bóveda
      const V = S.L.vault, idle = t - (E.idleSince == null ? t : E.idleSince);
      if (idle < 25 && O.ax != null) { dx = O.ax + sway[0] * 1.4; dy = O.ay + sway[1] * 1.4; VM = 30; AM = 22; }
      else { dx = V.x + V.w / 2 + Math.sin(t * .09) * V.w * .28; dy = V.y + V.h * .45 + Math.sin(t * .14 + 1) * V.h * .26; VM = 40; AM = 26; }
    } else {
      const A = orbAim(tgt), V = S.L.vault, vcx = V.x + V.w / 2, vcy = V.y + V.h / 2;
      if (mood === "orbita") { const an = (t - E.mood.t0) * .5 + 1; dx = tgt.x + 30 + Math.cos(an) * 104; dy = tgt.y - 52 + Math.sin(an) * 50; VM *= .75; }
      else if (mood === "boveda") { dx = vcx + Math.sin(t * .11) * V.w * .26; dy = V.y + V.h * .45 + Math.sin(t * .17 + 1) * V.h * .24; VM = 70; AM = 45; }
      else if (mood === "juega") { dx = vcx + (tgt.x - vcx) * .42 + sway[0] * 2; dy = vcy + (tgt.y - 70 - vcy) * .42 + sway[1] * 2; VM = 80; AM = 55; }
      else if (E.phase === "ilumina" || E.phase === "enfoca") { dx = O.ax + sway[0]; dy = O.ay + sway[1]; }
      else { dx = A.hx + sway[0] * .8; dy = A.hy + sway[1]; }
    }
    // Deja siempre libre lo que dicen los agentes: si su sitio pisa un bocadillo, se aparta al lado de la bóveda
    { const R2 = ORB_R() * 2.1, vcx = S.L.vault.x + S.L.vault.w / 2, tn = now();
      S.ag.forEach(a => { const b = a.bub; if (!b || tn - b.t > .4) return;
        if (Math.abs(dx - b.x) < b.w / 2 + R2 && Math.abs(dy - b.y) < 20 + R2 * .85) { dx = b.x + (vcx >= b.x ? 1 : -1) * (b.w / 2 + R2 + 8); VM = Math.max(VM, 170); AM = Math.max(AM, 120); } }); }
    if (S.reduce) { O.x = dx; O.y = dy; O.vx = O.vy = 0; }
    else {   // fuerzas: velocidad deseada con frenada de llegada; la aceleración tiene tope y una deriva lateral curva el camino
      const h = Math.min(dt, .08), ex = dx - O.x, ey = dy - O.y, dist = Math.hypot(ex, ey) || 1, slow = S.L.wide ? 170 : 140;
      const want = VM * Math.min(1, dist / slow), wx = ex / dist * want, wy = ey / dist * want;
      let ax = (wx - O.vx) * 1.1, ay = (wy - O.vy) * 1.1;
      const lat = Math.min(1, dist / 260) * Math.sin(t * .23 + (E.fresh || 0)) * AM * .35; ax += -ey / dist * lat; ay += ex / dist * lat;   // curva suave
      const am = Math.hypot(ax, ay); if (am > AM) { ax *= AM / am; ay *= AM / am; }
      O.vx += ax * h; O.vy += ay * h; const k = Math.exp(-h * .35); O.vx *= k; O.vy *= k;
      O.x += O.vx * h; O.y += O.vy * h;
    }
    // energía: lo que lo ha alimentado hace poco (se va apagando con calma) y su color, mezcla de esos datos
    O.en = (O.en || 0) * Math.exp(-dt / 25); O.motes = (O.motes || []).filter(m => t - m.t0 < 240);
    // Depósito: cuando lleva entre 7 y 12 satélites (umbral al azar cada vez) y pasa sobre la bóveda, se le van soltando
    // uno tras otro, atraídos por la conexión más cercana. Al tocarla se meten dentro, la encienden y recorren el grafo
    // por sus enlaces reales hasta una nota que se haya tocado DE VERDAD hace poco (del registro de la bóveda, por turno),
    // por el camino más corto. Así el dibujo dice algo cierto: qué notas han tenido actividad y cómo se llega a ellas
    // desde donde estaba el orbe. Sin actividad reciente, vagan unos saltos y se apagan. Se queda con dos.
    { const Dp = O.dep || (O.dep = { need: 7 + Math.floor(Math.random() * 6), on: false, next: 0, li: 0 }), inV = !!(VG.orbPull && VG.orbPull.k);
      if (!Dp.on && inV && O.motes.length >= Dp.need) { Dp.on = true; Dp.next = t + .8; }
      if (Dp.on && inV && t >= Dp.next && !S.reduce) {
        let best = null, bd = 1e9; const R1 = ORB_R(), busy = O.drops || (O.drops = []);
        for (const [ia, ib] of VG.edges) { const p = VG.nodes.get(ia), q = VG.nodes.get(ib); if (!p || !q || !p.pj || !q.pj || !isFinite(p.pj[0]) || !isFinite(q.pj[0])) continue;
          if (!vgInOct(p.pj[0], p.pj[1], 12) || !vgInOct(q.pj[0], q.pj[1], 12)) continue;   // nada de hilos que salgan del octógono
          const ex = q.pj[0] - p.pj[0], ey = q.pj[1] - p.pj[1], L2 = ex * ex + ey * ey; if (L2 < 144) continue;
          const u = clamp(((O.x - p.pj[0]) * ex + (O.y - p.pj[1]) * ey) / L2, .12, .88), d = Math.hypot(p.pj[0] + ex * u - O.x, p.pj[1] + ey * u - O.y);
          if (d < R1 * 1.3 || d > 230 || busy.some(dr => dr.a === p && dr.b === q)) continue;
          const sc = d + Math.random() * 50; if (sc < bd) { bd = sc; best = { p, q, u }; } }
        if (best) { const m = O.motes.shift(), start = best.u < .5 ? best.p : best.q;
          const logs = VG.log.filter(e => VG.nodes.has(e.p) && e.who !== "Faro").slice(0, 12), dest = logs.length ? VG.nodes.get(logs[Dp.li++ % logs.length].p) : null;
          let path = dest ? vgPath(start.id, dest.id, 9) : null; const real = !!(path && path.length >= 1 && dest);
          if (!path) { path = [start.id]; let cur = start.id, prev = null; for (let i = 0; i < 5; i++) { const nb = (VG.adj.get(cur) || []).filter(k => k !== prev && VG.nodes.has(k)); if (!nb.length) break; prev = cur; cur = nb[Math.floor(Math.random() * nb.length)]; path.push(cur); } }
          busy.push({ rgb: m.rgb, col: m.col, t0: t, fall: .9 + Math.random() * .5, fx: O.x, fy: O.y, a: best.p, b: best.q, u: best.u, path, real, side: Math.random() < .5 ? 1 : -1 }); }
        Dp.next = t + .5 + Math.random() * 1.1;
        if (O.motes.length <= 2) { Dp.on = false; Dp.need = 7 + Math.floor(Math.random() * 6); } } }
    O.x = clamp(O.x, 40, S.L.W - 40); O.y = clamp(O.y, 110, S.L.H - 60);
    // mirada
    const A2 = tgt && orbAim(tgt), want = !tgt ? [Math.sin(t * .4) * .5, .6] : E.phase === "arriba" ? [0, 1] : [A2.x - O.x, A2.y - O.y];
    const n = Math.hypot(want[0], want[1]) || 1; O.look[0] += (want[0] / n - O.look[0]) * Math.min(1, dt * 3); O.look[1] += (want[1] / n - O.look[1]) * Math.min(1, dt * 3);
    // gravedad sobre la bóveda: solo cuando el orbe está encima (ferrofluido)
    const V = S.L.vault, inside = O.x > V.x - 20 && O.x < V.x + V.w + 20 && O.y > V.y - 20 && O.y < V.y + V.h + 20;
    VG.orbPull = { x: O.x, y: O.y + ORB_R() * .6, r: S.L.wide ? 150 : 110, k: inside ? 1 : 0 };
  }
  // Haz (debajo de los agentes): ilumina y enfoca desde donde está; al llegar, foco cenital sobre quien trabaja
  // Haz de atención del orbe (rehecho el 15 nov). Antes eran trapecios planos y opacos que tapaban media oficina. Ahora es
  // luz: un cono volumétrico de bordes fundidos que se SUMA a lo que hay debajo (no lo tapa), con el color que tenga el
  // orbe, un hilo fino en el eje, motas de polvo que derivan dentro y, donde mira, una retícula que se cierra al enfocar.
  // El cono es una imagen ya calculada (una por color, en caché): pintarlo cuesta una sola copia por fotograma.
  const BEAMS = new Map();
  function beamSprite(rgb, rgb2) {   // del color del orbe (en su origen) al de la tarea que atiende (al llegar)
    const q = rgb.map(v => Math.min(255, Math.round(v / 40) * 40)), q2 = (rgb2 || rgb).map(v => Math.min(255, Math.round(v / 40) * 40)), key = q.join(",") + "|" + q2.join(","); let cv = BEAMS.get(key); if (cv) return cv;
    const W = 192, H = 96; cv = document.createElement("canvas"); cv.width = W; cv.height = H; const x = cv.getContext("2d"), im = x.createImageData(W, H), d = im.data;
    for (let i = 0; i < W; i++) { const u = i / (W - 1), w = (.045 + .955 * u) * (H / 2 - 2), along = Math.min(1, u / .05) * (1 - .5 * u) * (u > .9 ? (1 - u) / .1 : 1);
      const mk = Math.min(1, u * 1.35), cr = q[0] + (q2[0] - q[0]) * mk, cg = q[1] + (q2[1] - q[1]) * mk, cb = q[2] + (q2[2] - q[2]) * mk;   // se funde con el color de la tarea
      for (let j = 0; j < H; j++) { const dy = (j - (H - 1) / 2) / w, a = Math.exp(-dy * dy * 2.2) * along, k = (j * W + i) * 4;
        d[k] = cr; d[k + 1] = cg; d[k + 2] = cb; d[k + 3] = Math.min(255, a * 255); } }
    x.putImageData(im, 0, 0); if (BEAMS.size > 40) BEAMS.clear(); BEAMS.set(key, cv); return cv;
  }
  function beamCone(c, x0, y0, x1, y1, r0, hw, rgb, a, t, dust, rgb2) {   // cono de luz de (x0,y0) a (x1,y1); hw = medio ancho al llegar
    const ang = Math.atan2(y1 - y0, x1 - x0), len = Math.hypot(x1 - x0, y1 - y0) - r0; if (len < 8 || a < .01) return;
    c.save(); c.translate(x0, y0); c.rotate(ang); c.globalCompositeOperation = "lighter";
    c.globalAlpha = Math.min(1, a); c.drawImage(beamSprite(rgb, rgb2), r0, -hw * 1.05, len, hw * 2.1);   // solo el difuso: sin línea en el eje
    if (dust && !S.reduce) { c.fillStyle = "#ffffff";   // polvo en la luz
      for (let i = 0; i < 7; i++) { const u = (t * .11 + i / 7 + Math.sin(i * 9.1) * .07 + 1) % 1; c.globalAlpha = Math.sin(Math.PI * u) * .55 * a; c.fillRect(r0 + u * len, Math.sin(t * .8 + i * 2.4) * hw * u * .55, 1.4, 1.4); } }
    c.restore();
  }
  function orbBeam(c, t) {
    const O = orbState(), E = S.eye; if (!E) return; const tgt = E.target && S.ag.get(E.target); if (!tgt) return;
    const bk = E.bk == null ? 1 : E.bk, bke = bk * bk * (3 - 2 * bk);   // nace fundido y creciendo desde el orbe; nunca de golpe
    const A = orbAim(tgt), focus = tgt.pct != null ? tgt.pct / 100 : 0, R = ORB_R(), up = E.up || 0, op0 = E.open * bke; if (op0 < .01) return;
    const rgb = (O.rgb || [255, 179, 71]).map(v => Math.round(v)), rgb2 = tgt.zone && ZONES[tgt.zone] ? hexRgb(ZONES[tgt.zone].c) : rgb, col = `rgb(${rgb2.join(",")})`;
    if (up > .02) {   // desde arriba: cono suave hasta los pies y un charco de luz elíptico en el suelo, con su anillo
      const op = op0 * up, wb = 34 - 10 * focus, yb = A.fy;
      beamCone(c, O.x, O.y, A.fx, yb, R * .8, wb * 1.15, rgb, .5 * op, t, true, rgb2);
      c.save(); c.translate(A.fx, yb); c.scale(1, .34); c.globalCompositeOperation = "lighter"; glow(c, 0, 0, wb * 2.4, col, .34 * op); c.restore();
      c.strokeStyle = rgbA(col, .55 * op); c.lineWidth = 1.1; c.beginPath(); c.ellipse(A.fx, yb, wb * 1.25, wb * .42, 0, 0, 7); c.stroke();
      if (up > .98) return;
    }
    const op = op0 * (1 - up), ang = Math.atan2(A.y - O.y, A.x - O.x);
    E.ang = E.ang == null ? ang : E.ang; let d = ang - E.ang; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
    E.ang = S.reduce ? ang : E.ang + d * .12; const moving = Math.min(1, Math.abs(d) * 2);
    const narrow = E.nar == null ? 1 : E.nar, fk = clamp((1 - narrow) / .65, 0, 1);   // ilumina abierto (fk 0); enfoca y persigue, cerrado (fk 1)
    const len = Math.hypot(A.x - O.x, A.y - O.y) * (.35 + .65 * bke), hw = Math.max(13, (74 * narrow) * (1 - .35 * focus) + 22 * moving);
    beamCone(c, O.x, O.y, O.x + Math.cos(E.ang) * len, O.y + Math.sin(E.ang) * len, R * .85, hw, rgb, (.36 + .2 * fk) * op, t, fk > .5, rgb2);
    const ra = op * (1 - moving) * Math.max(0, (bk - .6) / .4); if (ra > .03) {   // la retícula llega cuando el haz ya ha llegado   // donde mira: luz sobre el panel y retícula que se cierra y gira despacio al enfocar
      c.save(); c.globalCompositeOperation = "lighter"; glow(c, A.x, A.y, 50 - 14 * fk, col, (.14 + .14 * fk) * ra); c.restore();
      const rr = 34 - 12 * fk - 4 * focus, rot = S.reduce ? 0 : t * .35;
      c.strokeStyle = rgbA(col, (.25 + .35 * fk) * ra); c.lineWidth = 1.1; c.lineCap = "round";
      for (let i = 0; i < 4; i++) { const a0 = rot + i * Math.PI / 2 + .25, a1 = a0 + Math.PI / 2 - .5; c.beginPath(); c.arc(A.x, A.y, rr, a0, a1); c.stroke();
        const am = rot + i * Math.PI / 2; c.beginPath(); c.moveTo(A.x + Math.cos(am) * (rr + 3), A.y + Math.sin(am) * (rr + 3)); c.lineTo(A.x + Math.cos(am) * (rr + 8), A.y + Math.sin(am) * (rr + 8)); c.stroke(); }
    }
  }
  // Cuerpo del orbe (encima de todo lo de la sala: flota)
  function orbBody(c, t) {
    const O = orbState(), E = S.eye || { open: 0 }, osp = null, RK = 1.14, R0 = ORB_R() * .9, bob = S.reduce ? 0 : Math.sin(t * 1.6) * 3, x = O.x, y = O.y + bob, op = E.open;   // con cuerpo de cerámica el cristal es más pequeño y los anillos y satélites se abren (RK) para que no quede enorme a su lado
    const tgt = E.target && S.ag.get(E.target), focus = tgt && tgt.pct != null ? tgt.pct / 100 : 0, blink = !tgt && (t % 9) < .35;
    // golpes de energía recientes: el orbe se hincha un poco y destella del color del dato
    O.feeds = O.feeds.filter(f => t - f.t < 1.2);
    O.feeds.forEach(f => { const e = (t - f.t) / 1.2, a = Math.min(1, e * 8) * (1 - e) * (1 - e);   // entra fundido y se apaga despacio
      c.strokeStyle = hexA(f.col, .8 * a); c.lineWidth = 3 * (1 - e) + 1; c.beginPath(); c.arc(x, y, R0 * (1.1 + ease(e) * 1.9), 0, 7); c.stroke();
      glow(c, x, y, R0 * (2.4 + e), f.col, .55 * a); });
    const R = R0 * (1 + (O.bump || 0)), rgb = O.rgb || [255, 179, 71], core = `rgb(${rgb.map(v => Math.round(v)).join(",")})`, lf = 0;
    // vida según lo que lo alimenta: más datos recientes → más luz y giro más vivo (siempre suave)
    const en = Math.min(1, (O.en || 0) / 5); O.spin = (O.spin || 0) + Math.min(.1, t - (O.lastT || t)) * (.35 + .9 * en); O.lastT = t; const sp = O.spin;
    // le orbitan los últimos puntos de energía (datos y visitas), cada uno con su color; los viejos se apagan despacio
    const pl = S.reduce ? 0 : O.play || 0, nM = (O.motes || []).length, toss = nM ? Math.floor(t / 1.5) % nM : -1, tk = (t / 1.5) % 1;   // jugando: los abre, los acelera y lanza uno al aire por turno
    const motes = (O.motes || []).map((m, i) => { const a = m.ph + sp * m.sp * 2.2 + pl * Math.sin(t * 1.3 + i * 1.7) * .9, age = t - m.t0, al = Math.min(1, age * 2) * Math.max(0, 1 - age / 240);
      const rf = 1 + pl * (.3 + .3 * Math.sin(t * 2.1 + i * 2.3) + (i === toss ? 1.5 * Math.sin(Math.PI * tk) : 0));
      const ex = Math.cos(a) * R * RK * m.r * rf, ey = Math.sin(a) * R * RK * m.r * m.tilt * rf, cr = Math.cos(m.rot), sr = Math.sin(m.rot);
      return { x: x + ex * cr - ey * sr, y: y + ex * sr + ey * cr, front: Math.sin(a) > 0, al, m }; });
    const drawMotes = front => motes.forEach(o => { if (o.front !== front || o.al <= 0) return;
      glow(c, o.x, o.y, (o.m.kind === "dato" ? 9 : 12) * (.7 + .3 * o.al), o.m.col, (.55 + .3 * en) * o.al); c.fillStyle = `rgba(255,255,255,${.8 * o.al})`; c.beginPath(); c.arc(o.x, o.y, 1.6, 0, 7); c.fill(); });
    drawMotes(false);
    // luz que echa alrededor y halo
    glow(c, x, y, R * (3.2 + 1.4 * op + 1.2 * en), core, .12 + .22 * op + .22 * en + 2.5 * (O.bump || 0));
    // anillos: mitad de atrás antes de la esfera, mitad de delante después (sensación de volumen)
    // anillos que precesan despacio (se inclinan y se abren como si giraran en 3D) con su chispa viajando
    const rq = S.reduce ? 0 : 1, rings = [[1.62, .34 + .07 * Math.sin(t * .45) * rq, sp * .9], [1.38, .26 + .06 * Math.sin(t * .37 + 2) * rq, -sp * 1.2 + 1.2]];
    const ring = (front) => rings.forEach(([rx, ry, rot], i) => {
      c.save(); c.translate(x, y); c.rotate((i ? -.35 : .22) + .18 * Math.sin(t * (i ? .23 : .19) + i) * rq); c.strokeStyle = i ? `rgba(160,220,255,${.35 + .3 * op})` : `rgba(255,200,120,${.3 + .35 * op})`; c.lineWidth = 1.4;
      c.beginPath(); c.ellipse(0, 0, R * RK * rx, R * RK * ry, 0, front ? 0 : Math.PI, front ? Math.PI : 2 * Math.PI); c.stroke();
      const a = rot % (2 * Math.PI), onFront = Math.sin(a) > 0; if (onFront === front) { c.fillStyle = i ? "#bfe9ff" : "#ffd27a"; c.beginPath(); c.arc(Math.cos(a) * R * RK * rx, Math.sin(a) * R * RK * ry, 2.2, 0, 7); c.fill(); }
      c.restore(); });
    ring(false);
    // esfera de cristal oscuro
    if (osp) { const k = R / osp.g[2] * 1.02; c.fillStyle = "rgba(8,10,20,.28)"; c.beginPath(); c.ellipse(x, y + R * 1.5, R * 1.1, R * .22, 0, 0, 7); c.fill(); spImg(c, osp, x - osp.g[0] * k, y - osp.g[1] * k, k); }
    else { const g = c.createRadialGradient(x - R * .35, y - R * .4, R * .1, x, y, R); g.addColorStop(0, "#3a2a5c"); g.addColorStop(.55, "#1a1030"); g.addColorStop(1, "#07040f");
    c.fillStyle = g; c.beginPath(); c.arc(x, y, R, 0, 7); c.fill(); }
    // dentro: nebulosa que gira y el iris (mira a quien vigila; la pupila se estrecha al concentrarse)
    c.save(); c.beginPath(); c.arc(x, y, R * .96, 0, 7); c.clip();
    for (let i = 0; i < 3; i++) { const a = sp * (.8 + i * .45) + i * 2.1; glow(c, x + Math.cos(a) * R * .35, y + Math.sin(a) * R * .3, R * .9, i === 1 ? "#ff6a2a" : core, (.18 + .25 * op) * (i === 1 ? .7 : 1)); }
    const lx = x + O.look[0] * R * .28 * (.4 + .6 * op), ly = y + O.look[1] * R * .24 * (.4 + .6 * op), ri = R * (.5 + .08 * op);
    const gi = c.createRadialGradient(lx, ly, 0, lx, ly, ri); gi.addColorStop(0, "#fff0c0"); gi.addColorStop(.35, core); gi.addColorStop(1, "rgba(226,97,26,0)");
    c.globalAlpha = .35 + .65 * op; c.fillStyle = gi; c.beginPath(); c.arc(lx, ly, ri, 0, 7); c.fill(); c.globalAlpha = 1;
    if (blink) { c.fillStyle = "#0b0716"; c.beginPath(); c.ellipse(lx, ly, ri, ri * .9, 0, 0, 7); c.fill(); c.strokeStyle = "rgba(255,179,71,.7)"; c.lineWidth = 1.2; c.beginPath(); c.moveTo(lx - ri * .8, ly); c.quadraticCurveTo(lx, ly + ri * .35, lx + ri * .8, ly); c.stroke(); }
    else { c.fillStyle = "#140600"; c.beginPath(); c.ellipse(lx + O.look[0] * ri * .15, ly + O.look[1] * ri * .1, Math.max(1, ri * (.24 - .16 * focus)), ri * .66 * (.6 + .4 * op), 0, 0, 7); c.fill(); }
    c.restore();
    // borde y brillo del cristal
    // Palantír: una piedra de cristal oscuro sujeta por un aro fino de metal gris y dos garras laterales afiladas (amable, pero piedra vidente)
    c.strokeStyle = "#141b26"; c.lineWidth = 4.2; c.beginPath(); c.arc(x, y, R + .6, 0, 7); c.stroke();
    c.strokeStyle = "#5d6877"; c.lineWidth = 2.4; c.beginPath(); c.arc(x, y, R + .6, 0, 7); c.stroke();
    c.strokeStyle = "rgba(196,206,220,.75)"; c.lineWidth = 1; c.beginPath(); c.arc(x, y, R + 1.1, Math.PI * 1.08, Math.PI * 1.55); c.stroke();
    for (const sg of [-1, 1]) {
      c.beginPath(); c.moveTo(x + sg * R * .9, y - R * .5); c.lineTo(x + sg * R * 1.36, y - R * .2); c.lineTo(x + sg * R * 1.2, y); c.lineTo(x + sg * R * 1.36, y + R * .2); c.lineTo(x + sg * R * .9, y + R * .5);
      c.lineTo(x + sg * R * 1.02, y + R * .18); c.lineTo(x + sg * R * 1.1, y); c.lineTo(x + sg * R * 1.02, y - R * .18); c.closePath();
      const cg = c.createLinearGradient(x, y - R * .5, x, y + R * .5); cg.addColorStop(0, "#6a7686"); cg.addColorStop(.5, "#394653"); cg.addColorStop(1, "#222b38"); c.fillStyle = cg; c.fill();
      c.strokeStyle = "#121923"; c.lineWidth = 1.2; c.stroke();
      c.strokeStyle = rgbA(core, .55 + .35 * op); c.lineWidth = 1.1; c.beginPath(); c.moveTo(x + sg * R * 1.31, y - R * .2); c.lineTo(x + sg * R * 1.17, y); c.lineTo(x + sg * R * 1.31, y + R * .2); c.stroke();   // filo que toma el color de lo que mira
    }
    c.strokeStyle = rgbA(core, .35 + .3 * op); c.lineWidth = 2; c.beginPath(); c.arc(x, y, R - 1, Math.PI * .1, Math.PI * .75); c.stroke();
    // Luz 3D sobre el plano 2D. El orbe es una esfera pulida vista de frente (cámara en +z). Cada luz tiene una dirección
    // L en 3D: la de sala, fija (arriba-izquierda, hacia quien mira); las del entorno (paneles encendidos, nodos cálidos
    // de la bóveda) están en el plano y algo hacia delante, y pierden fuerza con el cuadrado de la distancia. Por luz:
    //  · difusa: el lado que la mira se aclara con su color (degradado descentrado, recortado a la esfera);
    //  · especular: en la normal N = L + V normalizada, o sea a medio camino entre el centro y la luz, nunca en el borde
    //    salvo luz rasante; es una elipse aplastada en sentido radial (por Nz: el escorzo de la esfera), no un círculo;
    //  · contraluz: un filo tenue de su color en el borde de ese lado. El lado contrario a todas se oscurece un poco.
    if (!O.lts || t - O.reflT > .2) { O.reflT = t; O.lts = O.lts || new Map(); const seen = new Set();
      const add = (id, lx, ly, rgb, pw) => { const d = Math.hypot(lx - O.x, ly - O.y); if (d < R0 * 1.05) return; const it = pw / (1 + (d / 95) * (d / 95)); if (it < .06) return;
        seen.add(id); const e = O.lts.get(id) || { a: 0 }; e.x = lx; e.y = ly; e.rgb = rgb; e.to = Math.min(1, it * 1.5); O.lts.set(id, e); };
      S.ag.forEach(a => { if ((a.st === "work" || a.st === "bg") && a.zone && a.desk != null && S.L.desks[a.desk]) { const G = DG(S.L.desks[a.desk]); add("d" + a.desk, G.sx, G.sy, hexRgb(ZONES[a.zone].c), a.st === "work" ? 1 : .6); } });
      if (VG.orbPull && VG.orbPull.k) VG.nodes.forEach(n => { if ((n.dn || 0) > .4 && n.pj && isFinite(n.pj[0])) add("n" + n.id, n.pj[0], n.pj[1], [255, 214, 120], .35 + n.dn * .5); });
      O.lts.forEach((e, id) => { if (!seen.has(id)) e.to = 0; });
      const top = [...O.lts.entries()].sort((p, q) => q[1].to - p[1].to); top.slice(4).forEach(([, e]) => { e.to = 0; }); }
    c.save(); c.beginPath(); c.arc(x, y, R - .5, 0, 7); c.clip();
    { const g = c.createRadialGradient(x - R * .3, y - R * .35, R * .2, x, y, R * 1.05); g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, "rgba(0,0,8,.5)"); c.fillStyle = g; c.fillRect(x - R, y - R, 2 * R, 2 * R); }   // sombra propia: lado opuesto a la luz de sala
    const spec = (Lx, Ly, Lz, rgb, a, size) => {
      const ll = Math.hypot(Lx, Ly, Lz) || 1; Lx /= ll; Ly /= ll; Lz /= ll;
      const col = `${rgb[0] | 0},${rgb[1] | 0},${rgb[2] | 0}`;
      { const cx = x + Lx * R * .6, cy = y + Ly * R * .6, g = c.createRadialGradient(cx, cy, 0, cx, cy, R * 1.15); g.addColorStop(0, `rgba(${col},${.13 * a})`); g.addColorStop(1, `rgba(${col},0)`); c.fillStyle = g; c.fillRect(x - R, y - R, 2 * R, 2 * R); }   // difusa
      const pl = Math.hypot(Lx, Ly); if (pl > .25) glow(c, x + Lx / pl * R * 1.02, y + Ly / pl * R * 1.02, R * .36, `rgb(${col})`, .38 * a * pl);   // contraluz en el borde
      let Nx = Lx, Ny = Ly, Nz = Lz + 1; const nl = Math.hypot(Nx, Ny, Nz); Nx /= nl; Ny /= nl; Nz /= nl;
      const px = x + Nx * R * .96, py = y + Ny * R * .96, s = R * size, rot = Math.atan2(Ny, Nx);
      glow(c, px, py, s * 2.2, `rgb(${col})`, .4 * a);
      const w = rgb.map(v => Math.round(v + (255 - v) * .72)).join(",");
      c.fillStyle = `rgba(${w},${.92 * a})`; c.beginPath(); c.ellipse(px, py, Math.max(s * .25, s * Nz), s, rot, 0, 7); c.fill(); };
    O.lts.forEach((e, id) => { e.a += (e.to - e.a) * (S.reduce ? 1 : .1); if (e.a < .02) { if (!e.to) O.lts.delete(id); return; }
      spec(e.x - x, e.y - y, 55, e.rgb, e.a * .85, .05 + .04 * e.a); });
    spec(-.5, -.62, .6, [255, 255, 255], .8, .115);   // luz de sala: la ventana de siempre, ahora en su sitio físico
    c.restore();
    ring(true); drawMotes(true);
  }
  function drawZonesLit(c, t, usage) {
    for (const [k, z] of Object.entries(S.L.zones)) {
      const n = usage[k] || 0; if (!n || k === "obsidian") continue; const col = ZONES[k].c, pulse = .65 + .35 * Math.sin(t * 2.4);
      glow(c, z.x + z.w / 2, z.y + z.h / 2, z.w * .85, col, .35 * pulse);
      c.strokeStyle = col; c.lineWidth = 3; oct(c, z.x, z.y, z.w, z.h, OCT(z.chip ? 12 : 22)); c.stroke();
      const bx = z.chip ? z.x + z.w - 4 : z.x + z.w - 22, by = z.chip ? z.y + 4 : z.y + 22, zg = ZG(k, z);
      if (zg.scr) { const q = zg.scr, P = zg.pad;   // puesto encendido: haz, plataforma y holograma con barrido
        txBeam(c, P.x, P.y, P.rx * .5, q, col, .22 + .14 * pulse);
        c.strokeStyle = hexA(col, .9); c.lineWidth = 2; c.beginPath(); c.ellipse(P.x, P.y, P.rx, P.ry, 0, 0, 7); c.stroke();
        glow(c, q.x + q.w / 2, q.y + q.h / 2, q.w, col, .45 * pulse);
        oct(c, q.x, q.y, q.w, q.h, 7); c.fillStyle = hexA(col, .34); c.fill(); c.strokeStyle = col; c.lineWidth = 1.6; c.stroke();
        if (!S.reduce) { const sy = q.y + 2 + ((t * 26) % (q.h - 4)); c.fillStyle = "rgba(255,255,255,.25)"; c.fillRect(q.x + 4, sy, q.w - 8, 1.4); }
        icon(c, k, q.x + q.w / 2, q.y + q.h / 2, Math.min(1, q.h / 40), "#ffffff"); }
      else if (z.chip) icon(c, k, z.x + 25, z.y + z.h / 2, .72, "#ffffff"); else icon(c, k, z.x + z.w / 2, z.y + z.h / 2 - 12, 1.25, "#ffffff");
      { const r = z.chip ? 11 : 12; oct(c, bx - r, by - r, 2 * r, 2 * r, r * .55); c.fillStyle = col; c.fill(); }
      c.fillStyle = "#1a2230"; c.font = "800 15px Nunito, system-ui"; c.textAlign = "center"; c.fillText(n, bx, by + 5);
    }
  }
  // Curva orgánica entre dos puntos: dos puntos de control que se mecen despacio (como las ramas de la bóveda)
  function orgPath(ax, ay, bx, by, t, ph, lift) {
    const sw = S.reduce ? 0 : 1, top = Math.min(ay, by) - lift;
    const c1 = [ax + (bx - ax) * .28 + Math.sin(t * .5 + ph) * 16 * sw, top + Math.cos(t * .42 + ph) * 12 * sw];
    const c2 = [ax + (bx - ax) * .72 + Math.cos(t * .46 + ph * 1.7) * 16 * sw, top * .5 + Math.min(ay, by) * .5 + Math.sin(t * .55 + ph) * 12 * sw];
    const at = k => { const u = 1 - k; return [u * u * u * ax + 3 * u * u * k * c1[0] + 3 * u * k * k * c2[0] + k * k * k * bx, u * u * u * ay + 3 * u * u * k * c1[1] + 3 * u * k * k * c2[1] + k * k * k * by]; };
    return { c1, c2, at, trace: c => { c.beginPath(); c.moveTo(ax, ay); c.bezierCurveTo(c1[0], c1[1], c2[0], c2[1], bx, by); } };
  }
  function orgLink(c, P, ax, ay, bx, by, colA, colB, a, t, ph, nsp, big) {   // hebra luminosa con degradado y chispas
    const g = c.createLinearGradient(ax, ay, bx, by); g.addColorStop(0, hexA(colA, a)); g.addColorStop(1, hexA(colB, a));
    c.lineCap = "round"; c.strokeStyle = g;
    c.globalAlpha = .28; c.lineWidth = big ? 7 : 5; P.trace(c); c.stroke();
    c.globalAlpha = 1; c.lineWidth = big ? 1.8 : 1.4; P.trace(c); c.stroke();
    if (S.reduce) return;
    for (let i = 0; i < nsp; i++) {   // chispa: sale despacio, acelera y frena al llegar (como las de la bóveda)
      const k0 = (t * .32 + i / nsp + ph) % 1, k = k0 * k0 * (3 - 2 * k0), [x, y] = P.at(k);
      glow(c, x, y, big ? 11 : 8, colB, .85 * Math.sin(k0 * Math.PI)); c.fillStyle = "rgba(255,255,255," + (.9 * Math.sin(k0 * Math.PI)) + ")"; c.beginPath(); c.arc(x, y, 1.6, 0, 7); c.fill();
    }
  }
  function drawThreads(c, t) {
    S.ag.forEach(a => {
      if (a.st !== "work" || !a.zone || a.walking || a.desk == null) return; const z = S.L.zones[a.zone], col = ZONES[a.zone].c;
      { const sp = seatPos(a); if (Math.hypot(a.x - sp[0], a.y - sp[1]) > 6) return; }
      const [zx, zy] = center(z), dk = S.L.desks[a.desk], sx = DG(dk).sx, sy = DG(dk).top;
      const P = orgPath(sx, sy, zx, zy, t, a.ph * 6.3, 60), B = (BRANDS[a.brand] || BRANDS.hermes).c;
      orgLink(c, P, sx, sy, zx, zy, B, col, .55, t, a.ph, 2, false);
    });
  }
  function drawDeskLights(c, t) {
    S.ag.forEach(a => {
      const dk = a.desk == null ? null : S.L.desks[a.desk]; if (!dk) return;
      const on = (a.st === "work" || a.st === "bg") && a.zone, col = on ? ZONES[a.zone].c : null, B = BRANDS[a.brand] || BRANDS.hermes;
      const G = DG(dk), mx = G.sx, my = G.sy, hw = G.sw / 2, hh = G.sh / 2;
      const beat = a.beat != null ? Math.max(0, 1 - (t - a.beat) / 3) : 0, pulse = a.pulse != null ? Math.max(0, 1 - (t - a.pulse) / 2) : 0;
      const strata = a.brand === "local";
      if (on) {
        // emisor encendido: abanico de luz del disco de la mesa al panel holográfico
        { const g = c.createLinearGradient(0, G.st, 0, my + hh); g.addColorStop(0, hexA(col, .5 + .3 * beat)); g.addColorStop(1, hexA(col, .06));
          c.fillStyle = g; c.beginPath(); c.moveTo(mx - 7, G.st - 1); c.lineTo(mx - hw + 5, my + hh); c.lineTo(mx + hw - 5, my + hh); c.lineTo(mx + 7, G.st - 1); c.closePath(); c.fill();
          glow(c, mx, G.st - 1, 14, col, a.st === "work" ? .8 : .4); }
        glow(c, mx, my, 50, col, .35 + .4 * beat);
        // pantalla: color de la zona real; símbolo del trabajo; marca del agente; conexión y avance
        c.fillStyle = hexA(col, a.st === "work" ? .86 : .5); oct(c, mx - hw, my - hh, hw * 2, hh * 2, 6); c.fill();
        c.fillStyle = "rgba(255,255,255," + (.14 + .35 * beat) + ")"; oct(c, mx - hw, my - hh, hw * 2, hh * 2, 6); c.fill();
        { const G2 = gtaAgent(a) && gtaData(); if (strata) drawStrataScreen(c, mx, my, t, hw * 2, hh * 2); else if (isBiblio(a) && bibLive()) drawBiblioScreen(c, mx, my, t, hw * 2, hh * 2); else if (G2) drawGtaScreen(c, mx, my, t, G2, hw * 2, hh * 2); else icon(c, a.zone, mx, my - 1, .62 * Math.min(1, hh / 20), "#1a2230"); }
        c.fillStyle = B.c; c.fillRect(mx - hw + 6, my - hh, hw * 2 - 12, 3);
        oct(c, mx - hw, my - hh, hw * 2, hh * 2, 6); c.strokeStyle = hexA(col, 1); c.lineWidth = 1.3; c.stroke();   // filo del holograma
        if (!S.reduce) { const sy = my - hh + ((t * 22 + a.ph * 9) % (hh * 2)); c.fillStyle = "rgba(255,255,255,.18)"; c.fillRect(mx - hw + 3, sy, hw * 2 - 6, 1.2); }
        if (strata) {} else if (a.pct != null) { c.fillStyle = "rgba(0,0,0,.35)"; c.fillRect(mx - hw + 3, my + hh - 6, hw * 2 - 6, 3); c.fillStyle = "#ffffff"; c.fillRect(mx - hw + 3, my + hh - 6, (hw * 2 - 6) * clamp(a.pct, 0, 100) / 100, 3); }
        else if (a.st === "work" && !S.reduce) { const q = (t * .6 + a.ph) % 1; c.fillStyle = "rgba(255,255,255,.8)"; c.fillRect(mx - hw + 3 + q * (hw * 2 - 18), my + hh - 6, 12, 3); }
        // conexión: nube / PC (Strata ya ocupa su pantalla con su informe)
        const cx = mx + hw - 8, cy = my - hh + 8; c.fillStyle = "#1a2230";
        if (strata) {} else if (a.cloud) { c.beginPath(); c.arc(cx - 4, cy + 1, 3, 0, 7); c.arc(cx, cy - 1, 4, 0, 7); c.arc(cx + 4, cy + 1, 3, 0, 7); c.fill(); }
        else { c.fillRect(cx - 4, cy - 3, 8, 5); c.fillRect(cx - 1, cy + 2, 2, 2); }
        if (a.st === "bg" && !S.reduce && !strata) { c.strokeStyle = "#1a2230"; c.lineWidth = 2; c.beginPath(); c.arc(mx - hw + 11, my - hh + 12, 4, t * 4, t * 4 + 4.5); c.stroke(); }
        if (pulse > 0) glow(c, mx, my, 40, "#ffffff", .5 * pulse);
      } else {
        // libre: panel en espera (Strata sigue enseñando su informe)
        if (strata) drawStrataScreen(c, mx, my, t, hw * 2, hh * 2);
        else { c.fillStyle = "rgba(102,217,206,.1)"; oct(c, mx - hw, my - hh, hw * 2, hh * 2, 6); c.fill();
          c.fillStyle = hexA(B.c, .7 + .3 * Math.sin(t * 1.5 + a.ph)); c.beginPath(); c.arc(mx, my, 3, 0, 7); c.fill(); }
      }
      // chip GPU: este agente está usando la gráfica ahora mismo (según nvidia-smi)
      const gk = Object.keys(S.gpuUse || {}).find(k => String(a.name || "").toLowerCase().includes(k));
      if (gk) { const gx = dk.x + 18, gy = dk.y + dk.h - 72, pul = .6 + .4 * Math.sin(t * 4);
        glow(c, gx + 13, gy + 9, 26, "#66d9ce", .5 * pul); c.fillStyle = "#1a2230"; rr(c, gx, gy, 26, 18, 4); c.fill(); c.strokeStyle = "#66d9ce"; c.lineWidth = 1.5; c.stroke();
        c.fillStyle = "#66d9ce"; c.font = "800 9px Nunito, system-ui"; c.textAlign = "center"; c.fillText("GPU", gx + 13, gy + 12); }
      // nombre bajo la mesa
      c.font = `700 ${S.L.wide ? 14 : 18}px Nunito, system-ui`; c.textAlign = "center";
      const nm0 = a.brand === "local" && S.ST && S.ST.model ? "Strata · " + S.ST.model : String(a.name || "");
      // placa con el nombre: bajo la mesa dibujada (así no tapa a quien se sienta a su izquierda)
      const pw = G.dw ? dk.w - 16 : dk.w - (a.brand === "local" ? 24 : 70);
      if (c.measureText(nm0).width > pw) c.font = `700 ${S.L.wide ? 12 : 15}px Nunito, system-ui`;
      const nm = fitText(c, nm0, pw), nw = c.measureText(nm).width;
      const px = G.dw ? clamp(G.x0 + G.dw / 2, dk.x + nw / 2 + 8, dk.x + dk.w - nw / 2 - 8) : dk.x + dk.w / 2, ny = dk.y + dk.h - (G.dw ? 10 : 14);
      oct(c, px - nw / 2 - 9, ny - (S.L.wide ? 13 : 16), nw + 18, S.L.wide ? 19 : 23, 5); c.fillStyle = "rgba(9,13,34,.86)"; c.fill(); c.strokeStyle = on ? hexA(col, .7) : "rgba(102,217,206,.2)"; c.lineWidth = 1; c.stroke();
      c.fillStyle = on ? "#ffffff" : "rgba(200,210,240,.7)"; c.fillText(nm, px, ny + (S.L.wide ? 1 : 2));
    });
  }
  // Teletransporte: al llegar, cae una columna de luz del color del agente, se abren anillos en el suelo y la figura se
  // materializa de abajo arriba con un barrido; al irse, lo mismo al revés. 0,85 s.
  const EXC = ["#5eead4", "#fbbf24", "#aa9de8", "#f29b9d", "#60a5fa", "#a3e635", "#fb923c"];
  function expertCol(n) { let h = 0; for (const ch of String(n)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return EXC[h % EXC.length]; }
  function drawAgent(c, a, t) {
    const kin = a.tpIn ? (t - a.tpIn) / .85 : 1, kout = a.tpOut ? (t - a.tpOut) / .85 : 0;
    if (kin >= 1 && !a.tpOut) { a.tpIn = 0; return drawAgentBody(c, a, t); }
    const k = clamp(a.tpOut ? 1 - kout : kin, 0, 1), col = (BRANDS[a.brand] || BRANDS.hermes).c, fy = a.y + 26, top = a.y - 78, e = k * k * (3 - 2 * k), fl = Math.sin(Math.PI * k);
    const g = c.createLinearGradient(0, top - 60, 0, fy); g.addColorStop(0, hexA(col, 0)); g.addColorStop(.35, hexA(col, .55 * fl)); g.addColorStop(1, hexA(col, .9 * fl));
    c.fillStyle = g; c.fillRect(a.x - 15 - 8 * fl, top - 60, 30 + 16 * fl, fy - top + 60);
    c.fillStyle = `rgba(255,255,255,${.7 * fl})`; c.fillRect(a.x - 2, top - 60, 4, fy - top + 60);
    glow(c, a.x, fy, 50, col, .8 * fl);
    for (let i = 0; i < 2; i++) { const q = (k + i * .5) % 1; c.strokeStyle = hexA(col, (1 - q) * .9 * fl + .05); c.lineWidth = 1.6; c.beginPath(); c.ellipse(a.x, fy, 8 + 34 * q, 2.5 + 9 * q, 0, 0, 7); c.stroke(); }
    const cut = fy + 4 - (fy - top + 8) * e;   // frente del barrido: por debajo ya está materializado
    c.save(); c.beginPath(); c.rect(a.x - 70, cut, 140, fy + 12 - cut); c.clip(); c.globalAlpha = .35 + .65 * e; drawAgentBody(c, a, t); c.restore(); c.globalAlpha = 1;
    c.fillStyle = `rgba(255,255,255,${.9 * fl})`; c.fillRect(a.x - 24, cut - 1, 48, 2);
    for (let i = 0; i < 6; i++) { const q = (k * 1.3 + i / 6) % 1, px = a.x + Math.sin(i * 2.4 + a.ph) * 20; c.fillStyle = hexA(col, (1 - q) * fl); c.fillRect(px, fy - q * 110, 2, 5); }
  }
  function drawAgentBody(c, a, t) {
    const B = BRANDS[a.brand] || BRANDS.hermes, seated = (a.st === "work" || a.st === "idle") && !a.walking && Math.hypot(a.x - seatPos(a)[0], a.y - seatPos(a)[1]) < 3;
    const bob = a.walking ? Math.abs(Math.sin(t * 7 + a.ph)) * 3 : Math.sin(t * 1.6 + a.ph) * 1.2, x = a.x, y = a.y - bob;
    c.fillStyle = "rgba(0,0,0,.28)"; c.beginPath(); c.ellipse(x, a.y + 26, 18, 5, 0, 0, 7); c.fill();
    if (S.sel === a.id) { c.strokeStyle = "#ffffff"; c.lineWidth = 2.5; c.beginPath(); c.ellipse(x, a.y + 26, 26, 8, 0, 0, 7); c.stroke(); }
    const hy = y - 32;
    if (isBiblio(a) && !spF("biblio.idle")) { drawLibrarian(c, a, t, x, y, hy, seated); drawAgentExtras(c, a, t, x, y, hy - 12); return; }
    if (spAgent(c, a, t, x, a.y + 26, seated, a.walking ? bob * .5 : bob * .6)) { drawAgentExtras(c, a, t, x, y, hy - 10 - (seated && a.st === "work" ? 9 : 0)); return; }
    // piernas
    if (!seated) { const sw = a.walking ? Math.sin(t * 7 + a.ph) * 6 : 0; c.strokeStyle = "#2a3150"; c.lineWidth = 6; c.lineCap = "round"; c.beginPath(); c.moveTo(x - 6, y + 8); c.lineTo(x - 6 + sw, y + 24); c.moveTo(x + 6, y + 8); c.lineTo(x + 6 - sw, y + 24); c.stroke(); }
    // cuerpo
    c.fillStyle = B.c; rr(c, x - 15, y - 16, 30, 30, 11); c.fill(); c.fillStyle = "rgba(255,255,255,.18)"; rr(c, x - 11, y - 13, 10, 22, 5); c.fill();
    // brazos
    c.strokeStyle = B.c; c.lineWidth = 6; c.lineCap = "round"; const bt = a.beat != null ? Math.max(0, 1 - (t - a.beat) / 3) : 0;
    const k = seated && a.st === "work" && !S.reduce ? Math.sin(t * (6 + 10 * bt) + a.ph) * (1 + 3 * bt) : 0;
    c.beginPath(); c.moveTo(x - 14, y - 6); c.lineTo(x - 20, y + 6 + k); c.moveTo(x + 14, y - 6); c.lineTo(x + 20, y + 6 - k); c.stroke();
    // cabeza
    c.fillStyle = "#f6dcc3";
    if (a.brand === "gpt" || a.brand === "codex") { rr(c, x - 15, hy - 15, 30, 30, 8); c.fill(); }
    else if (a.brand === "local") { for (let i = 0; i < 3; i++) { c.fillStyle = ["#f6dcc3", "#e9c9ad", "#dcb798"][i]; rr(c, x - 15 + i * 1.5, hy - 15 + i * 10, 30 - i * 3, 10, 4); c.fill(); } }
    else { c.beginPath(); c.arc(x, hy, 15, 0, 7); c.fill(); }
    // ojos
    const blink = Math.sin(t * 1.1 + a.ph * 3) > .985, ey = hy - 1;
    c.fillStyle = "#252f3b"; if (a.st === "bg" && !a.task) { c.fillRect(x - 7, ey, 5, 2); c.fillRect(x + 2, ey, 5, 2); } else { c.fillRect(x - 6, ey - 2, 3, blink ? 1 : 5); c.fillRect(x + 3, ey - 2, 3, blink ? 1 : 5); }
    // rasgos de silueta
    c.fillStyle = B.c; c.strokeStyle = "#252f3b"; c.lineWidth = 2;
    switch (a.brand) {
      case "claude": c.save(); c.translate(x + 3, hy - 13); c.rotate(-.25); c.beginPath(); c.ellipse(0, 0, 17, 6, 0, 0, 7); c.fill(); c.fillRect(-1, -9, 3, 5); c.restore(); break;
      case "gpt": case "codex": c.beginPath(); c.arc(x - 5, ey + 1, 5, 0, 7); c.arc(x + 5, ey + 1, 5, 0, 7); c.stroke(); c.beginPath(); c.moveTo(x - 1, ey + 1); c.lineTo(x + 1, ey + 1); c.stroke();
        if (a.brand === "codex") { c.fillStyle = "#9cc4ee"; c.fillRect(x - 15, hy - 12, 30, 5); } break;
      case "hermes": c.beginPath(); c.arc(x, hy - 2, 16, Math.PI, 0); c.fill(); for (const s of [-1, 1]) { c.beginPath(); c.moveTo(x + s * 15, hy - 6); c.quadraticCurveTo(x + s * 30, hy - 18, x + s * 26, hy - 2); c.closePath(); c.fillStyle = "#ffffff"; c.fill(); } break;
      case "faro": for (let i = 0; i < 3; i++) { c.fillStyle = i % 2 ? "#ffffff" : "#f0736e"; c.fillRect(x - 10 + i * 1.5, hy - 20 - i * 7, 20 - i * 3, 7); } glow(c, x, hy - 44, 22, "#efe2a4", .8); c.fillStyle = "#efe2a4"; c.beginPath(); c.arc(x, hy - 42, 5, 0, 7); c.fill(); break;
    }
    drawAgentExtras(c, a, t, x, y, hy);
  }
  function drawAgentExtras(c, a, t, x, y, hy) {
    // experto: el papel con el que trabaja ahora (de su informe). Insignia de cristal bajo los pies, con su color propio.
    if (a.expert && (a.st === "work" || a.st === "bg")) {
      const ex = String(a.expert).toUpperCase(), col = expertCol(a.expert), fs = S.L.wide ? 8.5 : 8; c.font = `800 ${fs}px Nunito, system-ui`;
      const tx = fitText(c, ex, 150), w = c.measureText(tx).width + tx.length * .8 + 24, bx = x - w / 2, by = a.y + 41, pl = S.reduce ? 1 : .75 + .25 * Math.sin(t * 2.2 + a.ph);
      oct(c, bx, by, w, 15, 4); c.fillStyle = "rgba(9,12,24,.82)"; c.fill(); c.strokeStyle = hexA(col, .55 + .3 * pl); c.lineWidth = 1; c.stroke();
      c.fillStyle = col; c.globalAlpha = pl; c.beginPath(); c.moveTo(bx + 9, by + 3.5); c.lineTo(bx + 13, by + 7.5); c.lineTo(bx + 9, by + 11.5); c.lineTo(bx + 5, by + 7.5); c.closePath(); c.fill(); c.globalAlpha = 1;
      txText(c, tx, bx + 18, by + 10.8, fs, col, "left", .8);
    }
    // extras de estado
    if (a.st === "queue") { c.fillStyle = "#ffffff"; rr(c, x + 16, y - 50, 26, 18, 4); c.fill(); icon(c, "queue", x + 29, y - 41, .55, "#252f3b"); }
    if (a.bulb) { glow(c, x, hy - 32, 30, "#f2c078", .9); icon(c, "bulb", x, hy - 30, .9, "#fff7c2"); }
    if (a.task && a.task.mode === "chat" && a.chatWith && a.x < a.chatWith.x && dist(a) < 2) {
      const sp = a.say && now() < a.say.until ? a : a.chatWith, txt = sp.say && now() < sp.say.until ? sp.say.text : "";
      if (txt) { c.font = "700 15px Nunito, system-ui"; const w = Math.min(c.measureText(txt).width + 24, 300), bx = Math.max(w / 2 + 14, Math.min(S.L.W - w / 2 - 14, (a.x + a.chatWith.x) / 2)), by = Math.min(a.y, a.chatWith.y) - 80;
        a.bub = { x: bx, y: by, w, t: now() };
        txBubble(c, bx, by - 16, w, 30, (BRANDS[sp.brand] || BRANDS.hermes).c, sp.x);
        c.font = "700 15px Nunito, system-ui"; c.fillStyle = TX.text; c.textAlign = "center"; c.fillText(fitText(c, txt, w - 20), bx, by + 4); }
    }
    const said = a.say && now() < a.say.until && !(a.task && a.task.mode === "chat");
    if (said || (a.bubble && now() < a.bubble.until && !(a.task && a.task.mode === "chat"))) {
      const txt = said ? a.say.text : a.bubble.text; c.font = "700 15px Nunito, system-ui"; const w = c.measureText(txt).width + 22, bx = Math.max(w / 2 + 14, Math.min(S.L.W - w / 2 - 14, x)), by = hy - 40;   // sin salirse del lienzo
      const col = a.zone && ZONES[a.zone] ? ZONES[a.zone].c : "#ffffff";
      a.bub = { x: bx, y: by, w: w + 12, t: now() };   // el orbe lo esquiva (orbStep)
      txBubble(c, bx, by - 16, w + 12, 28, col, Math.max(bx - w / 2, Math.min(bx + w / 2, x)));
      glow(c, bx - w / 2 + 4, by - 2, 9, col, .6); c.fillStyle = col; c.beginPath(); c.arc(bx - w / 2 + 4, by - 2, 3.5, 0, 7); c.fill();
      c.font = "700 15px Nunito, system-ui"; c.fillStyle = TX.text; c.textAlign = "center"; c.fillText(txt, bx + 5, by + 3);
    }
    if (a.st === "bg" && !a.task && !a.walking && !S.reduce) { const kz = (t * .4 + a.ph) % 1; c.globalAlpha = 1 - kz; c.fillStyle = "#d9d4ee"; c.font = "800 14px Nunito"; c.textAlign = "center"; c.fillText("z", x + 16 + kz * 8, hy - 18 - kz * 16); c.globalAlpha = 1; }
  }
  function drawProjects(c, t) {
    // «500 años después»: cada proyecto es una aguja holográfica sobre una plataforma. Cada segmento es algo hecho, de
    // abajo arriba: la base (el proyecto), entregas (cian), artefactos (violeta) y orgullo (oro, cuenta doble); si la obra
    // guardada en el servidor es más alta, el resto va en gris azulado. En obra (alguien trabaja en él): un anillo de
    // escaneo recorre la aguja, suben chispas y pone «EN OBRA». Al entregar, el segmento de arriba destella.
    const bs = projectBuildings(), fh = PFH(), P = S.L.proj;
    c.save(); oct(c, P.x + 6, P.y + 6, P.w - 12, P.h - 12, OCT(20)); c.clip();
    bs.forEach((b, i) => {
      const top = b.base - b.floors * fh, fl = S.flashes.find(f => f.project === b.id), col = b.fin ? "#f2c078" : b.hue || PNEON[i % PNEON.length], cx = b.x + b.w / 2;
      const seq = ["base"]; for (let j = 0; j < b.done; j++) seq.push("done"); for (let j = 0; j < b.arts; j++) seq.push("arts"); for (let j = 0; j < b.proud; j++) seq.push("proud", "proud");
      // Diorama: cada proyecto es una pila de bloques redondeados sobre su peana (un bloque por entrega de la semana, a escala común).
      // Encima asoman las cabezas de los agentes que trabajan en él AHORA (se leen de la oficina en vivo, no del sondeo).
      const live = [...S.ag.values()].filter(a => (a.st === "work" || a.st === "bg") && a.project === b.id).slice(0, 4), on = live.length > 0 && !b.fin;
      const bh = Math.min(fh, 11), bwid = b.w * .8, topY = b.base - 3 - b.floors * bh;
      if (on) glow(c, cx, b.base, b.w * 1.15, col, .32 + (S.reduce ? 0 : .1 * Math.sin(t * 2 + i)));
      rr(c, cx - b.w * .56, b.base - 3, b.w * 1.12, 9, 4.5); c.fillStyle = "rgba(20,26,36,.92)"; c.fill(); c.strokeStyle = hexA(col, on ? .95 : .5); c.lineWidth = 1.3; c.stroke();
      for (let f = 0; f < b.floors; f++) {
        const sc = f ? SEGC[seq[f] || "saved"] : "#ece8dc", y = b.base - 3 - (f + 1) * bh, lit = f === b.floors - 1 && fl, fk = lit ? Math.max(0, 1 - fl.t / 1.6) : 0, w = bwid * (f % 2 ? .94 : 1);
        rr(c, cx - w / 2, y + 1, w, bh - 2, 3.5); c.fillStyle = hexA(sc, (on ? .46 : b.fin ? .4 : .24) + .5 * fk); c.fill(); c.strokeStyle = hexA(sc, on || b.fin ? .9 : .6); c.lineWidth = 1; c.stroke();
        c.fillStyle = "rgba(255,255,255,.2)"; c.fillRect(cx - w / 2 + 3, y + 2.6, w - 6, 1.1);
        if (fk > 0) glow(c, cx, y + bh / 2, b.w, sc, fk);
      }
      let stY = topY - 8;
      if (on) {
        live.forEach((a, k) => { const hx = cx + (k - (live.length - 1) / 2) * 17, hyy = topY - 2 + (S.reduce ? 0 : Math.sin(t * 2.4 + k * 1.7 + i) * 1.2);
          if (!agHead(c, a, hx, hyy, 19)) { c.fillStyle = (BRANDS[a.brand] || BRANDS.agent).c; c.beginPath(); c.arc(hx, hyy - 8, 6, 0, 7); c.fill(); } });
        stY = topY - 26; txText(c, live.length > 1 ? live.length + " TRABAJANDO" : "TRABAJANDO", cx, stY, 7.5, "#8fdcae", "center", .7);
      } else if (b.fin) { c.strokeStyle = "#f2c078"; c.lineWidth = 1.4; c.beginPath(); c.ellipse(cx, topY - 4, 9, 3, 0, 0, 7); c.stroke(); txText(c, "COMPLETO", cx, stY - 6, 8, "#f2c078", "center", 1); }
      else if (b.w7 != null) txText(c, b.w7 ? b.w7 + " ESTA SEMANA" : "PARADO", cx, stY, 7.5, hexA(col, b.w7 ? .85 : .45), "center", .6);
      else if (b.total > 12) txText(c, b.total + " HECHOS", cx, stY, 8, hexA(col, .8), "center", .8);
      // rótulo: si los nombres no caben en su hueco, van al tresbolillo (uno arriba, otro abajo) con el doble de sitio
      const fs = S.L.wide ? 12 : 11, crowd = bs.some(o => { c.font = `800 ${fs}px Nunito, system-ui`; return c.measureText(String(o.name).toUpperCase()).width + o.name.length * .8 > o.slot - 6; });
      c.font = `800 ${fs}px Nunito, system-ui`; const nm = fitText(c, String(b.name).toUpperCase(), (crowd ? 2 * b.slot : b.slot) - 10);
      txText(c, nm, cx, b.base + (crowd && i % 2 ? 35 : 23), fs, TX.text, "center", .8);
    });
    c.restore();
    S.packets.forEach(p => {
      const k = ease(p.t), x = p.from[0] + (p.to[0] - p.from[0]) * k, y = p.from[1] + (p.to[1] - p.from[1]) * k - Math.sin(k * Math.PI) * 160;
      glow(c, x, y, 26, p.col, .9); glow(c, x, y, 10, "#ffffff", .9); c.fillStyle = "#ffffff"; c.beginPath(); c.arc(x, y, 3.5, 0, 7); c.fill();
      for (let i = 1; i < 6; i++) { const kk = ease(Math.max(0, p.t - i * .03)), tx = p.from[0] + (p.to[0] - p.from[0]) * kk, ty = p.from[1] + (p.to[1] - p.from[1]) * kk - Math.sin(kk * Math.PI) * 160; glow(c, tx, ty, 12 - i, p.col, .5 - i * .08); }
    });
  }
  function drawMailbox(c, t) {
    const bx = BOX(), D = S.D || {}, n = S.boxShown == null ? (D.suggestions || []).filter(s => s.state === "open").length : S.boxShown;
    const fl = Math.max(0, 1 - (t - S.mailFlash) / 1.6);
    if (fl > 0) glow(c, bx.x, bx.y, 60, "#f2c078", fl);
    // baliza holográfica: pedestal, haz, sobre flotante y anillo; con sugerencias abiertas late en ámbar
    const w = S.L.wide, s = w ? 1 : .8, py = bx.y + (w ? 46 : 48), hy = bx.y + (w ? -4 : 18) + (S.reduce ? 0 : Math.sin(t * 1.6) * (w ? 3 : 2)), col = n > 0 ? "#f2c078" : "#66d9ce";
    const g = c.createLinearGradient(0, py, 0, hy); g.addColorStop(0, hexA(col, .34)); g.addColorStop(1, hexA(col, 0));
    c.fillStyle = g; c.beginPath(); c.moveTo(bx.x - 10 * s, py); c.lineTo(bx.x - 20 * s, hy); c.lineTo(bx.x + 20 * s, hy); c.lineTo(bx.x + 10 * s, py); c.closePath(); c.fill();
    c.fillStyle = "rgba(4,7,20,.92)"; c.beginPath(); c.ellipse(bx.x, py, 22 * s, 6 * s, 0, 0, 7); c.fill(); c.strokeStyle = hexA(col, .65); c.lineWidth = 1.5; c.stroke();
    glow(c, bx.x, hy, 34 * s, col, n > 0 ? .38 + .18 * Math.sin(t * 3) : .2);
    c.strokeStyle = hexA(col, .5); c.lineWidth = 1; c.beginPath(); c.ellipse(bx.x, hy, 26 * s, 8 * s, 0, 0, 7); c.stroke();
    icon(c, "mail", bx.x, hy, .9 * s, col);
    const qx = bx.x + (w ? 24 : 28), qy = hy - (w ? 20 : 6); oct(c, qx - 11, qy - 11, 22, 22, 6); c.fillStyle = n > 0 ? "#f2c078" : "#1b2547"; c.fill(); c.strokeStyle = hexA(col, .8); c.lineWidth = 1.2; c.stroke();
    c.fillStyle = n > 0 ? "#252f3b" : TX.text; c.font = "800 13px Nunito, system-ui"; c.textAlign = "center"; c.fillText(n, qx, qy + 4.5);
  }
  // Barra de arriba: a la izquierda quién trabaja / cola / fondo; a la derecha, cada máquina con su CPU y su gráfica en vivo
  function drawMeter(c, t, counts) {
    const m = S.L.meter, ms = machList(), split = ms.length ? .44 : 1, cw = m.w * split, k = m.h * .3;
    const items = [["work", counts.work, "#7fd3a6", "trabajan"], ["queue", counts.queue, "#f2c078", "en cola"], ["rest", counts.rest, "#aa9de8", "libres"]];
    const waste = counts.queue > 0 && counts.rest > 0, in0 = k * .75, w = (cw - in0) / 3, big = S.L.wide ? 27 : (ms.length ? 24 : 30);
    // panel de mando: cristal, filo cian y una pasada lenta de escáner
    txGlass(c, m.x, m.y, m.w, m.h, k, "#66d9ce", 1);
    if (!S.reduce) { const sx = m.x - 60 + ((t * 45) % (m.w + 120)); c.save(); oct(c, m.x, m.y, m.w, m.h, k); c.clip();
      const g = c.createLinearGradient(sx - 50, 0, sx + 50, 0); g.addColorStop(0, "rgba(102,217,206,0)"); g.addColorStop(.5, "rgba(102,217,206,.07)"); g.addColorStop(1, "rgba(102,217,206,0)");
      c.fillStyle = g; c.fillRect(sx - 50, m.y, 100, m.h); c.restore(); }
    if (ms.length) { c.fillStyle = "rgba(102,217,206,.22)"; c.fillRect(m.x + cw, m.y + 12, 1, m.h - 24); }
    items.forEach(([key, n, col, lab], i) => {
      let cc = col; if (key === "rest" && waste) cc = (Math.sin(t * 5) > 0 || S.reduce) ? "#f29b7d" : col;
      const cx = m.x + in0 + w * i + w / 2, cy = m.y + m.h * .4;
      if (key === "work" && n) glow(c, cx, cy, 30, col, .3);
      c.font = `800 ${big}px Nunito, system-ui`; const nw = c.measureText(String(n)).width, isz = ms.length ? .62 : .78, iw = 30 * isz, x1 = cx - (iw + 6 + nw) / 2;
      icon(c, key, x1 + iw / 2, cy, isz, cc); c.fillStyle = cc; c.textAlign = "left"; c.fillText(n, x1 + iw + 6, cy + big * .36);
      txText(c, lab.toUpperCase(), cx, m.y + m.h - 9, 9, hexA(cc.startsWith("#") ? cc : col, .78), "center", .9);
    });
    if (!ms.length) return;
    const x0 = m.x + cw + 12, aw = m.w - cw - 24, cell = aw / ms.length;
    ms.forEach((mc, i) => {
      const x = x0 + i * cell, y = m.y + 8, bw = cell - 12, S2 = S.mv[mc.name] || (S.mv[mc.name] = { cpu: 0, gpu: 0 });
      S2.cpu += ((mc.cpu || 0) - S2.cpu) * .12; S2.gpu += ((mc.gpu || 0) - S2.gpu) * .12;   // movimiento suave entre lecturas
      const nm = String(mc.name).toUpperCase(); txText(c, nm + (mc.age > 20 ? " · SIN DATOS" : ""), x, y + 10, 10.5, TX.text, "left", 1.2);
      { const pz = S.mpulse && S.mpulse[mc.name], a = pz == null ? .2 : Math.max(.2, 1 - (now() - pz) / 1.2); c.font = "800 10.5px Nunito, system-ui"; const nw = c.measureText(nm).width + 1.2 * nm.length;   // late con cada lectura nueva
        c.globalAlpha = a; c.fillStyle = "#8fdcae"; c.beginPath(); c.arc(x + nw + 6, y + 6, 3, 0, 7); c.fill(); c.globalAlpha = 1; }
      [["CPU", S2.cpu, mc.cpu], ["GPU", S2.gpu, mc.gpu]].forEach(([lab, v, raw], r) => {
        if (raw == null) return; const by = y + 19 + r * 17, hot = v > 85, warm = v > 60;
        const col = hot ? ((Math.sin(t * 6) > 0 || S.reduce) ? "#f0736e" : "#ff8a8d") : warm ? "#f2c078" : lab === "GPU" ? "#66d9ce" : "#7fd3a6";
        txText(c, lab, x, by + 7.5, 9, "rgba(200,210,240,.72)", "left", .8);
        const tv = lab === "CPU" ? mc.cpu_temp : mc.gpu_temp, TH = tv != null ? (bw > 118 ? 30 : 12) : 0;
        const bx = x + 25, bl = bw - 58 - TH; txSeg(c, bx, by, bl, 8, v, col, bl > 60 ? 12 : 6); if (hot) glow(c, bx + bl * clamp(v, 0, 100) / 100, by + 4, 14, col, .7);
        c.fillStyle = col; c.font = "800 12px Nunito, system-ui"; c.textAlign = "right"; c.fillText(Math.round(raw) + "%", x + bw - TH, by + 8.5); c.textAlign = "left";
        if (tv != null) {   // termómetro de esta fila: columna que sube y baja con la temperatura real (30–95 °C); turquesa, ámbar desde 70 y rojo que late desde 85
          const kk = "t" + lab; S2[kk] = S2[kk] == null ? tv : S2[kk] + (tv - S2[kk]) * .08; const k = clamp((S2[kk] - 30) / 65, 0, 1), tx = x + bw - 4, ty = by - 2.5, th = 8;
          const tc = S2[kk] >= 85 ? ((Math.sin(t * 6) > 0 || S.reduce) ? "#f0736e" : "#f5a19d") : S2[kk] >= 70 ? "#f2c078" : "#66d9ce";
          c.strokeStyle = "rgba(240,235,224,.6)"; c.lineWidth = 1; rr(c, tx - 2, ty, 4, th, 2); c.stroke(); c.beginPath(); c.arc(tx, ty + th + 1.4, 3.2, 0, 7); c.fillStyle = "#1a2230"; c.fill(); c.stroke();
          c.fillStyle = tc; c.beginPath(); c.arc(tx, ty + th + 1.4, 2.1, 0, 7); c.fill(); const fh2 = Math.max(1.5, (th - 1.5) * k); c.fillRect(tx - 1, ty + th - fh2, 2, fh2 + 1.5);
          if (S2[kk] >= 85) glow(c, tx, ty + th, 9, tc, .7);
          if (TH > 12) { c.fillStyle = tc; c.font = "800 9px Nunito, system-ui"; c.textAlign = "right"; c.fillText(Math.round(tv) + "°", tx - 5, by + 8); c.textAlign = "left"; }
        }
      });
    });
  }
  function machList() {
    const fresh = S.M && Date.now() - S.Mat < 15000 ? S.M : ((S.D || {}).machines || []);
    return fresh.filter(m => m.cpu != null || m.gpu != null).slice(0, 2);
  }
  // Sondeo propio cada 2 s (solo con la oficina abierta): CPU y gráfica van más rápido que el resto del panel
  function pollMachines() {
    clearInterval(S.mTimer); S.mv = S.mv || {};
    const go = () => fetch("api/machines", { cache: "no-store" }).then(r => r.ok ? r.json() : null).then(j => { if (j && j.machines) { if (j.build && S.D) S.D.build = j.build; if (j.gta) { S.gtaP = j.gta; S.gtaPat = Date.now(); } if (j.biblio) { S.bibP = j.biblio; S.bibPat = Date.now(); } if (j.voz) { S.vozP = j.voz; S.vozPat = Date.now(); if (S.sel && (S.sel.type === "gta" || S.sel.type === "voz")) renderCard(); } S.M = j.machines; S.Mat = Date.now(); gpuUsers(); machHist(j.machines); stHist(j.strata); if (S.sel && (S.sel.type === "mach" || (S.sel.type === "agent" && /local/.test(String((S.ag.get(S.sel.id) || {}).brand))))) renderCard(); } }).catch(() => {});
    if (location.protocol.startsWith("http")) { go(); S.mTimer = setInterval(() => { if (!document.hidden) go(); }, LITE ? 5000 : 2000); }
  }
  // Historial real de 2 min por máquina (una muestra por lectura nueva) y latido cuando llega una lectura distinta
  function machHist(ms) {
    S.mh = S.mh || {}; S.mpulse = S.mpulse || {};
    ms.forEach(m => { const h = S.mh[m.name] || (S.mh[m.name] = []), k = m.at + "|" + m.cpu + "|" + m.gpu;
      if (h.length && h[h.length - 1].k === k) return; h.push({ k, cpu: m.cpu, gpu: m.gpu }); if (h.length > 60) h.shift(); S.mpulse[m.name] = now(); });
  }
  function spark(h, key, col) {
    const pts = h.filter(x => x[key] != null); if (pts.length < 2) return "";
    return `<polyline fill="none" stroke="${col}" stroke-width="1.6" stroke-linejoin="round" points="${pts.map((x, i) => (i * 120 / (pts.length - 1)).toFixed(1) + "," + (30 - x[key] * .28).toFixed(1)).join(" ")}"/>`;
  }
  function gpuUsers() {
    S.gpuUse = {}; ((S.M && S.M.length) ? S.M : ((S.D || {}).machines || [])).forEach(m => (m.gpu_apps || []).forEach(a => { if (a.agent) S.gpuUse[a.agent.toLowerCase()] = Math.max(S.gpuUse[a.agent.toLowerCase()] || 0, a.vram_gb || 0); }));
  }

  /* ───────── bucle ───────── */
  function frame(ts) {
    if (!S.open) return;
    // 30 fotogramas por segundo bastan; en el propio PC (escritorio sin aceleración), 15
    // En pantallas táctiles (móvil, tableta) se calienta por píxeles pintados: 20 por segundo, y 10 si llevas 40 s sin tocar
    if (S.lite == null) { S.lite = !!(window.matchMedia && matchMedia("(pointer: coarse)").matches); S.touchAt = ts;
      addEventListener("pointerdown", () => { S.touchAt = performance.now(); }, { passive: true }); }
    const gapMs = window.FARO_AHORRO ? 64 : S.lite ? (ts - S.touchAt > 40000 ? 98 : 48) : 31;
    if (ts - (S.lastDraw || 0) < gapMs) { S.raf = requestAnimationFrame(frame); return; } S.lastDraw = ts;
    const t = now(), dt = Math.min(.11, (ts - (S.lastT || ts)) / 1000); S.lastT = ts;
    const st = S.cv.parentElement, w = st.clientWidth, h = st.clientHeight, dpr = Math.min(S.lite ? 1.5 : 2, devicePixelRatio || 1);
    const L = pickLayout(w, h);
    if (!S.L || S.L.wide !== L.wide) { S.L = L; S.bg = null; S.bokeh = []; S.ag.clear(); S.deskOf.clear(); S.primed = false; if (S.D) sync(S.D); }
    { const sc0 = Math.min(w / S.L.W, h / S.L.H), want = window.FARO_AHORRO ? 1 : Math.min(S.lite ? 1.5 : 2, Math.max(1, Math.ceil(sc0 * dpr * 2) / 2));
      if (S.bgR !== want) { S.bgR = want; S.bg = null; } }
    if (!S.bg) buildBg();
    if (S.cv.width !== Math.round(w * dpr) || S.cv.height !== Math.round(h * dpr)) { S.cv.width = Math.round(w * dpr); S.cv.height = Math.round(h * dpr); }
    const c = S.ctx; try { S.scale = Math.min(w / S.L.W, h / S.L.H); S.ox = (w - S.L.W * S.scale) / 2; S.oy = (h - S.L.H * S.scale) / 2;
    c.setTransform(dpr, 0, 0, dpr, 0, 0); c.fillStyle = "#141a24"; c.fillRect(0, 0, w, h);
    c.setTransform(dpr * S.scale, 0, 0, dpr * S.scale, dpr * S.ox, dpr * S.oy); S.tf = [dpr * S.scale, dpr * S.ox, dpr * S.oy];
    c.drawImage(S.bg, 0, 0, S.L.W, S.L.H);
    const PF = window.FARO_PROF ? (S.pf = S.pf || {}) : null, p0 = performance.now(); let pl = p0; const tm = k => { if (PF) { const n = performance.now(); PF[k] = (PF[k] || 0) * .95 + (n - pl) * .05; pl = n; } };
    tm("bg"); stepAgents(dt, t); stepSparks(dt);
    S.ag.forEach((g, k) => { if (g.leaving && t - g.leaving > .85) S.ag.delete(k); }); socialTick(t); { const vb = S.L.vault; vgStep(dt, (vb.h - 70) / (vb.w - 24)); } tm("fisica");
    const ags = [...S.ag.values()], usage = {}, counts = { work: 0, queue: 0, rest: 0 };
    ags.forEach(a => { if (a.st === "work") { counts.work++; if (a.zone && !a.walking) usage[a.zone] = (usage[a.zone] || 0) + 1; } else if (a.st === "queue") counts.queue++; else if (a.st === "bg") counts.rest++; });
    drawBokeh(c, t); drawZonesLit(c, t, usage); tm("zonas"); drawVault(c, t, usage); tm("boveda"); drawGravity(c, t); tm("grav"); orbStep(dt, t); drawDeposits(c, t); orbBeam(c, t); drawThreads(c, t); tm("haz+hilos"); drawDeskLights(c, t); tm("mesas");
    drawMailbox(c, t); drawGtaTV(c, t); drawVoz(c, t); drawBiblio(c, t); drawChannels(c, t); drawBench(c, t); tm("entrada+tv");
    ags.sort((a, b) => a.y - b.y).forEach(a => drawAgent(c, a, t)); tm("agentes");
    drawSparks(c, t); drawProjects(c, t); tm("proyectos"); orbBody(c, t); tm("orbe"); drawMeter(c, t, counts); drawVaultCard(); tm("barra");
    S.ms = (S.ms || 0) * .95 + (performance.now() - p0) * .05;
    } catch (err) {   // un fallo de dibujo no puede congelar la oficina: se apunta y el siguiente fotograma sigue
      S.errs = (S.errs || 0) + 1; S.lastErr = String(err && err.stack || err).slice(0, 300);
      if (!S.errAt || t - S.errAt > 10) { S.errAt = t; console.error("Oficina:", err); }
      try { c.globalAlpha = 1; c.setLineDash([]); } catch (_) {}
    }
    S.raf = requestAnimationFrame(frame);
  }

  /* ───────── Máquina GTA VI: la tele de la sala de descanso y las pantallas de quien trabaja en ella ─────────
     Lee el campo «gta» del informe más reciente (solo etapas y series, nada de contenido). */
  // Orden de la cadena desde el 15 nov: los jueces miran el guion ANTES de gastar voz y gráfica, y el montaje va después
  // de la voz (sus tiempos salen del audio real). Los códigos numéricos no cambian.
  const GTA_ST = [["FUENTES", 0], ["GUION", 1], ["ITV GUION", 5], ["VOZ", 3], ["CAPTURA", 2], ["RÓTULOS", 12], ["MONTAJE", 4], ["ITV VÍDEO", 7], ["TALLER", 6], ["EMPAQUE", 8], ["PEAJE", 9], ["PUBLICADO", 10]];
  const GTA_IDX = {}; GTA_ST.forEach((s, i) => GTA_IDX[s[1]] = i);
  const GTA_SER = { cuenta: "#ff9a3c", bolsa: "#8fdcae", mito: "#b56cff", mapa: "#25f4ee", reto: "#fe2c55", hito: "#ffe27a" };
  const GTA_SER_N = { cuenta: "Cuenta atrás", bolsa: "Bolsa", mito: "Mitos", mapa: "Leonida vs Florida", reto: "Reto del día", hito: "Hitos" };
  const GTA_J = { rev: "#f0b46a", ok: "#8fdcae", ko: "#ee6660" };
  function gtaData() {
    const D = S.D || {}; let b = null;
    for (const r of [...(D.running || []), ...(D.agents || []), D.gta_last, S.gtaP && Date.now() - S.gtaPat < 20000 ? S.gtaP : D.gta_probe]) if (r && r.gta && Array.isArray(r.gta.clips) && (!b || String(r.at || "") > String(b.at || ""))) b = r;
    return b ? b.gta : null;
  }
  function gtaAgent(a) { return a && (a.project === "gta" || /gta/i.test(String(a.label || "") + " " + String(a.name || ""))); }
  function TVR() { const p = S.L.proj; return S.L.wide ? { x: p.x + p.w - 312, y: p.y + 40, w: 292, h: 124 } : { x: p.x + p.w - 262, y: p.y + 36, w: 252, h: 98 };
  }
  function gtaRoad(x0, y0, w, h, rows) {
    const per = Math.ceil(GTA_ST.length / rows), P = [];
    for (let i = 0; i < GTA_ST.length; i++) { const r = Math.floor(i / per), k = i % per, xr = r % 2 ? per - 1 - k : k; P.push([x0 + w * xr / (per - 1), y0 + (rows > 1 ? h * r / (rows - 1) : h / 2)]); }
    return P;
  }
  function gtaAt(P, u) { u = clamp(u, 0, P.length - 1); const i = Math.min(P.length - 2, Math.floor(u)), f = u - i; return [P[i][0] + (P[i + 1][0] - P[i][0]) * f, P[i][1] + (P[i + 1][1] - P[i][1]) * f, Math.atan2(P[i + 1][1] - P[i][1], P[i + 1][0] - P[i][0])]; }
  function gtaDrawRoad(c, P, t, lw, labels, G, s) {
    c.lineCap = "round"; c.lineJoin = "round"; c.beginPath(); P.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]));
    c.strokeStyle = "rgba(255,62,165,.25)"; c.lineWidth = lw + 5; c.stroke(); c.strokeStyle = "#241031"; c.lineWidth = lw; c.stroke();
    if (!S.reduce) { c.setLineDash([3 * s, 4 * s]); c.lineDashOffset = -t * 12; } else c.setLineDash([3 * s, 4 * s]);
    c.strokeStyle = "rgba(255,225,77,.6)"; c.lineWidth = Math.max(1, lw / 9); c.stroke(); c.setLineDash([]);
    const blocked = G.clips.some(k => k.st === 9 && k.b);
    GTA_ST.forEach((st, i) => { const [px, py] = P[i]; c.fillStyle = st[1] === 9 && blocked ? "#ee6660" : st[1] === 10 ? "#8fdcae" : "#25f4ee"; c.beginPath(); c.arc(px, py, 2.4 * s, 0, 7); c.fill();
      if (labels) { c.font = `800 ${6.2 * s}px Nunito, system-ui`; c.textAlign = "center"; c.fillStyle = "rgba(255,236,250,.85)"; c.fillText(st[0], px, py + 10 * s); } });
  }
  function gtaDrawCars(c, P, t, G, s, key, dt) {
    S.gtaPos = S.gtaPos || {}; const groups = {};
    for (const k of G.clips) { if (!(k.st in GTA_IDX)) continue; (groups[GTA_IDX[k.st]] = groups[GTA_IDX[k.st]] || []).push(k); }
    for (const g in groups) groups[g].forEach((k, j) => {
      const id = key + String(k.n), tgt = +g - .22 * j; S.gtaPos[id] = S.gtaPos[id] == null ? tgt : S.gtaPos[id] + (tgt - S.gtaPos[id]) * Math.min(1, dt * 1.6);
      const [cx, cy, a] = gtaAt(P, S.gtaPos[id]), col = GTA_SER[k.s] || "#ffffff";
      c.save(); c.translate(cx, cy); c.rotate(a); glow(c, 0, 0, 9 * s, col, .5); c.fillStyle = col; rr(c, -5.5 * s, -3 * s, 11 * s, 6 * s, 2 * s); c.fill();
      c.fillStyle = "#1b0633"; c.fillRect(-1 * s, -2.2 * s, 3.5 * s, 4.4 * s); c.fillStyle = "#fff7c2"; c.fillRect(4.5 * s, -2.6 * s, 1.2 * s, 1.6 * s); c.fillRect(4.5 * s, 1 * s, 1.2 * s, 1.6 * s); c.restore();
      if (s >= 1.4) { c.font = `900 ${5.5 * s}px Nunito, system-ui`; c.textAlign = "center"; c.fillStyle = "#fff"; c.fillText(String(k.n), cx, cy - 5 * s); }
      if (Array.isArray(k.j)) k.j.slice(0, 3).forEach((js, q) => { if (js === "rev" && !S.reduce && Math.floor(t * 3 + q) % 2) return; c.fillStyle = GTA_J[js] || GTA_J.rev; c.beginPath(); c.arc(cx - 4 * s + q * 4 * s, cy - (s >= 1.4 ? 11 : 6) * s, 1.6 * s, 0, 7); c.fill(); });
      if (k.b) { c.strokeStyle = "#ee6660"; c.lineWidth = 1.5 * s; c.beginPath(); c.moveTo(cx + 7 * s, cy - 5 * s); c.lineTo(cx + 7 * s, cy + 5 * s); c.stroke(); }
      if (k.prio && Math.floor(t * 5) % 2) { c.fillStyle = "#2e7bff"; c.beginPath(); c.arc(cx, cy - 15 * s, 1.6 * s, 0, 7); c.fill(); }
    });
  }
  // Estado de la máquina de GTA VI, como el monitor de Strata: si trabaja ahora, en qué paso va, cuándo dio la última
  // señal y cuántos clips hay en cada tramo. Trabaja = algún agente de GTA está trabajando en la oficina, o el último
  // informe con datos de la máquina está «en marcha» y aún no ha caducado.
  function gtaLive() {
    const D = S.D || {}; let src = null;
    // el último informe con datos de la máquina; si ya no está entre los agentes por viejo, Faro lo guarda aparte (gta_last)
    for (const r of [...(D.running || []), ...(D.agents || []), D.gta_last, S.gtaP && Date.now() - S.gtaPat < 20000 ? S.gtaP : D.gta_probe]) if (r && r.gta && Array.isArray(r.gta.clips) && (!src || String(r.at || "") > String(src.at || ""))) src = r;
    if (!src) return null;
    const G = src.gta, at = Date.parse(src.at || src.src_at || ""), age = isFinite(at) ? Math.max(0, (Date.now() - at) / 1000) : null;
    const ags = [...S.ag.values()].filter(a => a.st === "work" && gtaAgent(a)), who = ags.length;
    const working = who > 0 || (src.state === "run" && age != null && age < (src.ttl || 3600));
    const fin = k => k.st === 10 || k.st === 11, old = age == null || age > 3600;
    // si los datos de la máquina son viejos pero alguien trabaja ahora en GTA VI, el paso es lo que hace esa persona
    const step = old && who ? String(ags[0].label || ags[0].step || "") : String(G.paso || src.step || src.task || "");
    return { G, at: src.at || "", age, old, working, who, live: G.clips.filter(k => !fin(k)).length, pub: G.clips.filter(k => k.st === 10).length,
      blk: G.clips.filter(k => k.b && !fin(k)).length, step };
  }
  const agoTxt = s => s == null ? "sin hora" : s < 90 ? "ahora" : s < 3600 ? "hace " + Math.round(s / 60) + " min" : s < 86400 ? "hace " + Math.round(s / 3600) + " h" : "hace " + Math.round(s / 86400) + " d";
  function drawGtaTV(c, t) {
    const M = gtaLive(); if (!M) return; const G = M.G, T = TVR(), W = S.L.wide, dt = Math.min(.1, t - (S.gtaT || t)); S.gtaT = t;
    // aviso: cada informe nuevo de la máquina (o cuando empieza o deja de trabajar) hace destellar la tele y manda un dato al orbe
    const sig = M.at + "|" + M.working;
    if (S.gtaSig !== sig) { if (S.gtaSig != null) { S.gtaPulse = t; (S.sparks = S.sparks || []).push({ from: [T.x + T.w / 2, T.y + T.h / 2], t: 0, col: "#f08aa6" }); } S.gtaSig = sig; }
    const pz = S.gtaPulse != null ? Math.max(0, 1 - (t - S.gtaPulse) / 2.2) : 0, on = M.working;
    glow(c, T.x + T.w / 2, T.y + T.h / 2, T.w * .7, "#f08aa6", on ? .24 + .08 * Math.sin(t * 2) : .08);
    if (pz > 0) glow(c, T.x + T.w / 2, T.y + T.h / 2, T.w * .8, "#ffffff", .35 * pz);
    const tvs = spF("scr.tv");
    if (tvs) { const sc = tvs.screen, kx = T.w / sc[2], ky = T.h / sc[3], cut = (sc[1] + sc[3] + 16) / tvs.H, r = tvs.r;   // el hueco de la pantalla del dibujo se ajusta a la tele; el pie se recorta para no pisar el panel de voz
      c.drawImage(SP.img, r[0], r[1], r[2], r[3] * cut, T.x - sc[0] * kx, T.y - sc[1] * ky, tvs.W * kx, tvs.H * cut * ky);
      if (pz > 0) { c.strokeStyle = `rgba(255,255,255,${.7 * pz})`; c.lineWidth = 2; rr(c, T.x - 2, T.y - 2, T.w + 4, T.h + 4, 7); c.stroke(); } }
    else { oct(c, T.x - 5, T.y - 5, T.w + 10, T.h + 10, 10); c.fillStyle = "#161c27"; c.fill(); c.strokeStyle = hexA("#f08aa6", .22 + .3 * pz); c.lineWidth = 5; c.stroke();
    oct(c, T.x - 5, T.y - 5, T.w + 10, T.h + 10, 10); c.strokeStyle = pz > 0 ? `rgba(255,255,255,${.5 + .5 * pz})` : hexA("#f08aa6", on ? .85 : .5); c.lineWidth = 1.3; c.stroke(); }
    const gr = c.createLinearGradient(0, T.y, 0, T.y + T.h); gr.addColorStop(0, "#1b0633"); gr.addColorStop(.65, "#3d0c55"); gr.addColorStop(1, "#7a1059");
    c.fillStyle = gr; rr(c, T.x, T.y, T.w, T.h, 5); c.fill();
    c.save(); rr(c, T.x, T.y, T.w, T.h, 5); c.clip();
    const s = W ? 1.55 : 1.35, top = W ? 37 : 30, foot = W ? 31 : 21;
    // cabecera: luz de estado (verde que late = trabajando; ámbar = en pausa con aviso de hoy; gris = sin aviso reciente)
    const sc = on ? "#8fdcae" : M.age != null && M.age < 86400 ? "#f0b46a" : "#8a8fa8", lp = on && !S.reduce ? .6 + .4 * Math.sin(t * 5) : 1;
    glow(c, T.x + 12, T.y + 11, 9, sc, on ? .7 * lp : .3); c.fillStyle = sc; c.beginPath(); c.arc(T.x + 12, T.y + 11, 3.2, 0, 7); c.fill();
    txText(c, "GTA VI", T.x + 21, T.y + 15, W ? 10.5 : 10, "#ffd23f", "left", 1.2);
    c.font = `800 ${W ? 10.5 : 10}px Nunito, system-ui`; const nx = T.x + 21 + c.measureText("GTA VI").width + 7 + 8;
    const stt = pz > 0 && Math.floor(t * 4) % 2 ? "NUEVO AVISO" : on ? "TRABAJANDO" : "EN PAUSA", ssz = W ? 9 : 8.5;
    txText(c, stt, nx, T.y + 15, ssz, sc, "left", 1); c.font = `800 ${ssz}px Nunito, system-ui`;
    const free = T.x + T.w - 8 - (nx + c.measureText(stt).width + stt.length + 10);   // lo que queda a la derecha para el recuento
    c.font = `700 ${W ? 9.5 : 9}px Nunito, system-ui`; c.textAlign = "right";
    const bq = M.blk ? " · " + M.blk + " bloq." : "", cnt = [`${M.live} en marcha · ${M.pub} publ.${bq}`, `${M.live} en marcha${bq}`, `${M.live} en marcha`, `${M.live}`].find(x => c.measureText(x).width <= free) || "";
    if (cnt) { const bw = bq && cnt.endsWith(bq) ? c.measureText(bq).width : 0; c.fillStyle = "#ffd8f0"; c.fillText(cnt.slice(0, cnt.length - (bw ? bq.length : 0)), T.x + T.w - 8 - bw, T.y + 15);
      if (bw) { c.fillStyle = "#f0807a"; c.fillText(bq, T.x + T.w - 8, T.y + 15); } }
    // carretera de tramos: con la máquina en pausa, quieta y atenuada; trabajando, la línea corre
    const P = gtaRoad(T.x + (W ? 30 : 14), T.y + top, T.w - (W ? 60 : 28), T.h - top - foot, 2);
    gtaDrawRoad(c, P, on ? t : 0, W ? 9 : 8, W, G, s * .9); gtaDrawCars(c, P, t, G, s, "tv", dt);
    if (!on) { c.fillStyle = "rgba(11,13,24,.32)"; c.fillRect(T.x, T.y + top - 12, T.w, T.h - top - foot + 26); }
    // pie: el paso en el que va y la última señal
    c.fillStyle = "rgba(11,6,24,.55)"; c.fillRect(T.x, T.y + T.h - 15, T.w, 15);
    c.font = `700 ${W ? 9.5 : 9}px Nunito, system-ui`; const ago = (M.old && M.age != null ? "datos " : "") + agoTxt(M.age), aw = c.measureText(ago).width;
    c.textAlign = "right"; c.fillStyle = on && !M.old ? "#8fdcae" : "rgba(255,216,240,.7)"; c.fillText(ago, T.x + T.w - 8, T.y + T.h - 4.5);
    c.textAlign = "left"; c.fillStyle = "#ffe8f6"; c.fillText(fitText(c, M.step || "sin paso", T.w - aw - 26), T.x + 8, T.y + T.h - 4.5);
    if (!S.reduce) { c.fillStyle = "rgba(255,255,255,.035)"; for (let y = T.y + ((t * 30) % 4); y < T.y + T.h; y += 4) c.fillRect(T.x, y, T.w, 1); }   // líneas de tele
    c.restore();
    c.fillStyle = hexA("#f08aa6", on ? .7 : .4); c.fillRect(T.x + T.w / 2 - 34, T.y + T.h + 8, 68, 1.5);
  }
  /* ───────── Voz narradora: monitor permanente bajo la tele de GTA VI (15 nov) ─────────
     Tarea aparte dentro de la cadena de GTA VI: aquí se ve cuándo se está generando voz. Trabaja = algún agente trabaja en el
     proyecto «voz» en la oficina, o el último informe de ese proyecto está «en marcha» y no ha caducado. Generando: la onda
     se mueve como una voz hablando; en espera: línea casi plana y atenuada. Cada informe nuevo destella y manda un dato al orbe.
     Bloque opcional del informe: {"voz": {"paso": "...", "idioma": "es|en|pt", "cola": n, "revisar": n}}. */
  function VZR() { const T = TVR(), W = S.L.wide; return { x: T.x, y: T.y + T.h + (W ? 16 : 14), w: T.w, h: W ? 54 : 47 }; }
  function vozLive() {
    const D = S.D || {}; let src = null;
    for (const r of [...(D.running || []), ...(D.agents || []), D.voz_last]) if (r && r.project === "voz" && (!src || String(r.at || "") > String(src.at || ""))) src = r;
    const ags = [...S.ag.values()].filter(a => a.st === "work" && a.project === "voz"), who = ags.length;
    const at = src ? Date.parse(src.at || "") : NaN, age = isFinite(at) ? Math.max(0, (Date.now() - at) / 1000) : null, V = (src && src.voz) || {};
    // Señal principal: Faro mira en el PC si hay un proceso de voz en marcha y cuál es el último audio (no depende de que
    // nadie informe). Llega cada 2–5 s con las máquinas; si es vieja, vale la del estado general.
    const P = S.vozP && Date.now() - S.vozPat < 15000 ? S.vozP : D.voz_probe, pl = P && P.last ? Date.parse(P.last) : NaN;
    const page = isFinite(pl) ? Math.max(0, (Date.now() - pl) / 1000) : null, age2 = P && P.running ? 0 : page != null && (age == null || page < age) ? page : age;
    const working = !!(P && P.running) || who > 0 || !!(src && src.state === "run" && age != null && age < (src.ttl || 3600));
    return { has: !!src || who > 0 || !!(P && P.dir), at: (P && P.running ? "run" : "") + (P && P.last || "") + (src ? src.at || "" : ""), age: age2, working, who, lang: String((P && P.running && P.lang) || V.idioma || (P && P.lang) || "").toLowerCase(), cola: V.cola, rev: V.revisar,
      step: String(P && P.running ? "Generando audio" + (P.today ? " · " + P.today + " hoy" : "") : V.paso || (who ? ags[0].label || ags[0].step : src && (src.step || src.task)) || (P && P.today ? P.today + " audios hoy" : "")) };
  }
  function drawVoz(c, t) {
    const M = vozLive(), R = VZR(), W = S.L.wide, on = M.working, col = "#f2b77a";
    const sig = M.at + "|" + on; if (S.vozSig !== sig) { if (S.vozSig != null) { S.vozPulse = t; (S.sparks = S.sparks || []).push({ from: [R.x + R.w / 2, R.y + R.h / 2], t: 0, col }); } S.vozSig = sig; }
    const pz = S.vozPulse != null ? Math.max(0, 1 - (t - S.vozPulse) / 2.2) : 0;
    // la onda no es decorado: su altura sigue la carga real de la gráfica del PC mientras se genera voz
    const gpuPc = (() => { const m = machList().find(x => /pc|iceland/i.test(x.name)) || machList()[0]; return m && m.gpu != null ? clamp(m.gpu / 100, 0, 1) : .6; })();
    S.vozAmp = (S.vozAmp || 0) + ((on ? .45 + .55 * gpuPc : .06) - (S.vozAmp || 0)) * .06;
    if (on || pz > 0) glow(c, R.x + R.w / 2, R.y + R.h / 2, R.w * .6, pz > 0 ? "#ffffff" : col, on ? .2 + .3 * pz : .3 * pz);
    rr(c, R.x - 7, R.y - 6, R.w + 14, R.h + 12, 11); c.fillStyle = "#e8ddc9"; c.fill(); c.strokeStyle = "#1f2a3a"; c.lineWidth = 1.4; c.stroke();
    rr(c, R.x - 2, R.y - 1.5, R.w + 4, R.h + 3, 7); c.fillStyle = "#161c27"; c.fill(); c.strokeStyle = pz > 0 ? `rgba(255,255,255,${.5 + .5 * pz})` : hexA(col, on ? .9 : .4); c.lineWidth = 1.2; c.stroke();
    c.fillStyle = "#aa9de8"; rr(c, R.x + R.w + 1.5, R.y + R.h / 2 - 8, 3.5, 16, 1.7); c.fill(); rr(c, R.x - 5, R.y + R.h / 2 - 8, 3.5, 16, 1.7); c.fill();
    // micrófono
    const mx = R.x + 13, my = R.y + R.h / 2 - 1, mc = on ? col : hexA(col, .55);
    c.strokeStyle = mc; c.fillStyle = mc; c.lineWidth = 1.5; rr(c, mx - 3.5, my - 9, 7, 12, 3.5); c.fill();
    c.beginPath(); c.arc(mx, my - 1, 6.5, .15 * Math.PI, .85 * Math.PI); c.stroke(); c.beginPath(); c.moveTo(mx, my + 5.5); c.lineTo(mx, my + 10); c.moveTo(mx - 4, my + 10); c.lineTo(mx + 4, my + 10); c.stroke();
    // cabecera
    const sc = on ? "#8fdcae" : M.age != null && M.age < 86400 ? "#f0b46a" : "#8a8fa8", hx = R.x + 28;
    glow(c, hx + 3, R.y + 9, 8, sc, on && !S.reduce ? .4 + .4 * Math.sin(t * 5) : .25); c.fillStyle = sc; c.beginPath(); c.arc(hx + 3, R.y + 9, 2.8, 0, 7); c.fill();
    txText(c, "VOZ", hx + 11, R.y + 12.5, W ? 10 : 9.5, col, "left", 1.2);
    txText(c, pz > 0 && Math.floor(t * 4) % 2 ? "NUEVO AVISO" : on ? "GENERANDO" : M.has ? "EN ESPERA" : "SIN AVISOS", hx + (W ? 44 : 42), R.y + 12.5, W ? 9 : 8.5, sc, "left", 1);
    { c.font = `700 ${W ? 9.5 : 9}px Nunito, system-ui`; c.textAlign = "right"; let rx = R.x + R.w - 6;   // idiomas (el activo, encendido) y lo que espera su OK
      for (const l of ["pt", "en", "es"]) { const act = on && M.lang === l; c.fillStyle = act ? "#161c27" : hexA(col, .5); if (act) { c.fillStyle = col; rr(c, rx - 17, R.y + 3.5, 18, 12, 3); c.fill(); c.fillStyle = "#161c27"; } c.fillText(l.toUpperCase(), rx - 2, R.y + 12.5); rx -= 21; }
}
    // onda de voz: barras con envolvente de habla (sílabas y pausas) cuando genera; casi plana en espera
    const x0 = R.x + 28, x1 = R.x + R.w - 8, cy = R.y + 17 + (R.h - 29) / 2, n = W ? 58 : 48, bw = (x1 - x0) / n, hmax = (R.h - 29) / 2, tt = S.reduce ? 0 : t;
    for (let i = 0; i < n; i++) { const u = i / n, syl = Math.max(0, Math.sin(tt * 3.1 - u * 9) * .6 + Math.sin(tt * 1.3 + u * 4) * .5), f = Math.abs(Math.sin(u * 37 + tt * 11) * .6 + Math.sin(u * 91 - tt * 17) * .4);
      const h = Math.max(.8, Math.min(hmax, hmax * S.vozAmp * (.12 + syl * f) * 1.5)); c.fillStyle = hexA(col, on ? .55 + .45 * f : .35); c.fillRect(x0 + i * bw, cy - h, Math.max(1, bw - 1.2), h * 2); }
    // pie: paso y última señal
    c.font = `700 ${W ? 9 : 8.5}px Nunito, system-ui`; const ago = (M.rev ? M.rev + " esperan OK · " : "") + (M.has ? agoTxt(M.age) : ""), aw = c.measureText(ago).width;
    c.textAlign = "right"; c.fillStyle = M.rev ? "#ffd23f" : on ? "#8fdcae" : "rgba(255,230,200,.6)"; c.fillText(ago, R.x + R.w - 6, R.y + R.h - 1);
    c.textAlign = "left"; c.fillStyle = "rgba(255,240,220,.85)"; c.fillText(fitText(c, M.step || (M.has ? "" : "aún no se ha generado voz"), R.w - aw - 44), R.x + 28, R.y + R.h - 1);
  }
  /* ───────── Biblioteca offline: franja al pie de la bóveda (16 nov) ─────────
     El conocimiento descargado (carreras y másters) vive en el PC, fuera de la bóveda; aquí se ve cuánto hay y si se está
     descargando. Dato real: Faro lee ~/Biblioteca/progreso.json y manifest.json (biblio_probe). Si la carpeta no existe,
     no se dibuja nada. Descargando: barra que avanza; lista: colecciones, GB y disciplinas. */
  function BBR() { const v = S.L.vault, W = S.L.wide, w = W ? 250 : 168, h = W ? 40 : 36; return { x: v.x + v.w / 2 - w / 2, y: v.y + v.h - h - (W ? 30 : 26), w, h }; }
  function bibLive() { const D = S.D || {}, P = S.bibP && Date.now() - S.bibPat < 20000 ? S.bibP : D.biblio_probe; return P && P.dir ? P : null; }
  const bibGB = b => { const g = (b || 0) / 1e9; return (g >= 100 ? Math.round(g) : g.toFixed(1).replace(".", ",")) + " GB"; };
  function drawBiblio(c, t) {
    const P = bibLive(); if (!P) return;
    const R = BBR(), W = S.L.wide, on = !!P.running, col = ZONES.obsidian.c, pct = P.total ? clamp(P.done / P.total, 0, 1) : 0;
    const sig = P.cols + "|" + on + "|" + P.nivel; if (S.bibSig !== sig) { if (S.bibSig != null) { S.bibPulse = t; (S.sparks = S.sparks || []).push({ from: [R.x + R.w / 2, R.y + R.h / 2], t: 0, col }); } S.bibSig = sig; }
    const pz = S.bibPulse != null ? Math.max(0, 1 - (t - S.bibPulse) / 2.2) : 0;
    c.save();
    if (on || pz > 0) glow(c, R.x + R.w / 2, R.y + R.h / 2, R.w * .55, pz > 0 ? "#ffffff" : col, on ? .16 + .3 * pz : .3 * pz);
    oct(c, R.x, R.y, R.w, R.h, 8); c.fillStyle = "rgba(8,10,20,.86)"; c.fill(); c.strokeStyle = pz > 0 ? `rgba(255,255,255,${.5 + .5 * pz})` : hexA(col, on ? .9 : .45); c.lineWidth = 1.2; c.stroke();
    // libros en el lomo
    const bx = R.x + 9, by = R.y + R.h / 2 + 6, bc = on ? col : hexA(col, .6); c.fillStyle = bc;
    [[0, 11], [4, 14], [8, 9]].forEach(([dx, hh]) => c.fillRect(bx + dx, by - hh, 3, hh));
    const sc = on ? "#8fdcae" : P.cols ? col : "#8a8fa8", fs = W ? 9 : 8.5;
    txText(c, "BIBLIOTECA", R.x + 26, R.y + 13, fs + .5, col, "left", 1.1);
    c.font = `700 ${fs}px Nunito, system-ui`; c.textAlign = "right"; c.fillStyle = sc;
    c.fillText(on ? "BAJANDO" + (P.nivel ? " N" + String(P.nivel).replace(/\D/g, "") : "") + " · " + Math.round(pct * 100) + " %" : P.cols ? "LISTA" : "VACÍA", R.x + R.w - 8, R.y + 13);
    const x0 = R.x + 26, x1 = R.x + R.w - 8, yb = R.y + 18;
    if (on) {   // barra real de bytes descargados; el brillo que la recorre solo indica que sigue viva
      c.fillStyle = hexA(col, .16); c.fillRect(x0, yb, x1 - x0, 3); c.fillStyle = "#8fdcae"; c.fillRect(x0, yb, (x1 - x0) * pct, 3);
      if (!S.reduce) { const sx = x0 + (x1 - x0) * pct * ((t * .5) % 1); c.fillStyle = "rgba(255,255,255,.8)"; c.fillRect(sx, yb, 5, 3); }
    }
    c.textAlign = "left"; c.fillStyle = "rgba(230,240,255,.85)";
    const foot = on ? (P.actual || "descargando") + " · " + bibGB(P.done) + " de " + bibGB(P.total)
      : P.cols ? P.cols + " colecciones · " + bibGB(P.bytes) + (P.disc ? " · " + P.disc + " disciplinas" : "") : "aún sin colecciones verificadas";
    c.fillText(fitText(c, foot, x1 - x0), x0, R.y + R.h - 6);
    c.restore();
  }
  // El bibliotecario que descarga la biblioteca: figura propia dibujada en código (16 nov). Túnica oscura con filo violeta
  // (el color de la bóveda), capucha, gafas redondas de neón y un libro-holograma abierto; al trabajar pasa páginas y le
  // orbitan tres hojas de datos. En buildAgents su id es "a:" + nombre, por eso se reconoce por el nombre.
  const isBiblio = a => !!a && /^Bibliotecario · (descarga|síntesis)$/.test(String(a.name));
  function drawLibrarian(c, a, t, x, y, hy, seated) {
    const col = ZONES.obsidian.c, dk = "#241a4d", cy = "#66d9ce", work = a.st === "work", tt = S.reduce ? 0 : t, hem = seated ? y + 14 : y + 24;
    if (seated) {   // disco flotante, como el resto de quienes trabajan
      const dy = a.y + 14 + Math.sin(tt * 1.3 + a.ph) * .8; c.fillStyle = hexA(col, .18); c.beginPath(); c.ellipse(x, a.y + 24, 15, 3.5, 0, 0, 7); c.fill();
      c.fillStyle = "#1c2532"; c.beginPath(); c.ellipse(x, dy + 2.5, 17, 5.5, 0, 0, 7); c.fill(); c.fillStyle = "#394653"; c.beginPath(); c.ellipse(x, dy, 17, 5, 0, 0, 7); c.fill();
      c.strokeStyle = hexA(col, .85); c.lineWidth = 1.4; c.beginPath(); c.ellipse(x, dy + 1, 17, 5.5, 0, 0, Math.PI); c.stroke();
    }
    // túnica
    c.fillStyle = dk; c.beginPath(); c.moveTo(x - 11, y - 16); c.lineTo(x + 11, y - 16); c.lineTo(x + 17, hem); c.lineTo(x - 17, hem); c.closePath(); c.fill();
    c.strokeStyle = hexA(col, .9); c.lineWidth = 1.4; c.lineCap = "round"; c.beginPath(); c.moveTo(x, y - 12); c.lineTo(x, hem - 3); c.moveTo(x - 16, hem - 1); c.lineTo(x + 16, hem - 1); c.stroke();
    // capucha y cara
    c.fillStyle = dk; c.beginPath(); c.arc(x, hy, 17, Math.PI, 0); c.lineTo(x + 14, hy + 13); c.lineTo(x - 14, hy + 13); c.closePath(); c.fill();
    c.strokeStyle = hexA(col, .8); c.lineWidth = 1.2; c.beginPath(); c.arc(x, hy, 17, Math.PI, 0); c.stroke();
    c.fillStyle = "#f6dcc3"; c.beginPath(); c.arc(x, hy + 2, 11, 0, 7); c.fill();
    // gafas redondas y ojos
    const blink = Math.sin(tt * 1.1 + a.ph * 3) > .985; c.fillStyle = "#252f3b"; c.fillRect(x - 6, hy + 1, 2.4, blink ? 1 : 3.4); c.fillRect(x + 3.6, hy + 1, 2.4, blink ? 1 : 3.4);
    c.strokeStyle = cy; c.lineWidth = 1.5; c.beginPath(); c.arc(x - 5, hy + 2.5, 4.4, 0, 7); c.moveTo(x + 9.4, hy + 2.5); c.arc(x + 5, hy + 2.5, 4.4, 0, 7); c.moveTo(x - .6, hy + 2.5); c.lineTo(x + .6, hy + 2.5); c.stroke();
    // brazos y libro-holograma abierto
    const by = y + 3 + (work ? Math.sin(tt * 2 + a.ph) * .6 : 0);
    c.strokeStyle = dk; c.lineWidth = 5; c.beginPath(); c.moveTo(x - 11, y - 8); c.lineTo(x - 9, by + 2); c.moveTo(x + 11, y - 8); c.lineTo(x + 9, by + 2); c.stroke();
    glow(c, x, by - 2, 16, col, work ? .55 : .25);
    c.fillStyle = hexA(cy, work ? .9 : .55);
    c.beginPath(); c.moveTo(x, by + 3); c.lineTo(x - 11, by); c.lineTo(x - 11, by - 7); c.lineTo(x, by - 4); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(x, by + 3); c.lineTo(x + 11, by); c.lineTo(x + 11, by - 7); c.lineTo(x, by - 4); c.closePath(); c.fill();
    c.strokeStyle = "#1a2230"; c.lineWidth = .8; for (const s of [-1, 1]) for (const k of [0, 1]) { c.beginPath(); c.moveTo(x + s * 2.5, by - 1.6 + k * 2.4); c.lineTo(x + s * 9, by - 3.6 + k * 2.4); c.stroke(); }
    if (work && tt) {   // página que pasa y tres hojas de datos en órbita
      const f = (tt * .9 + a.ph) % 1, px = x + 11 - 22 * f, ph = 7 * Math.sin(Math.PI * f);
      c.fillStyle = "rgba(255,255,255,.85)"; c.beginPath(); c.moveTo(x, by + 3); c.lineTo(px, by - ph * .3); c.lineTo(px, by - 7 - ph * .3); c.lineTo(x, by - 4); c.closePath(); c.fill();
      for (let i = 0; i < 3; i++) { const an = tt * 1.1 + a.ph + i * 2.094, ox = x + Math.cos(an) * 24, oy = hy - 4 + Math.sin(an) * 7, back = Math.sin(an) < 0;
        c.fillStyle = hexA(i === 1 ? cy : col, back ? .35 : .9); c.fillRect(ox - 2.5, oy - 3.5, 5, 7); }
    }
  }
  // Pantalla de la mesa de quien descarga la biblioteca: porcentaje real, barra y GB (mismos datos que la franja de la bóveda)
  function drawBiblioScreen(c, mx, my, t, w, h) {
    const P = bibLive() || {}, x0 = mx - w / 2, y0 = my - h / 2, pct = P.total ? clamp(P.done / P.total, 0, 1) : 0, col = ZONES.obsidian.c;
    c.save(); c.fillStyle = "#0d0a1c"; rr(c, x0, y0, w, h, 4); c.fill(); rr(c, x0, y0, w, h, 4); c.clip();
    c.fillStyle = col; c.fillRect(x0, y0, w, 3);
    const SI = !P.running && P.sint && P.sint.running ? P.sint : null;
    if (SI) {   // sintetizando: fichas hechas sobre el total, fase y barra
      const sp = SI.total ? clamp(SI.done / SI.total, 0, 1) : 0, bx = x0 + 4, bw = w - 8, by = y0 + h - 8;
      c.textAlign = "left"; c.font = `800 ${Math.max(6.5, h * .17)}px Nunito, system-ui`; c.fillStyle = col; c.fillText("SÍNTESIS", x0 + 4, y0 + 4 + h * .2);
      c.textAlign = "right"; c.font = `800 ${Math.max(9, h * .32)}px Nunito, system-ui`; c.fillStyle = "#66d9ce"; c.fillText(SI.total ? SI.done + "/" + SI.total : String(SI.done), x0 + w - 4, y0 + h * .62);
      c.textAlign = "left"; c.font = `700 ${Math.max(6, h * .16)}px Nunito, system-ui`; c.fillStyle = "rgba(230,240,255,.85)"; c.fillText(fitText(c, SI.fase || "fichas", w * .5), x0 + 4, y0 + h * .62);
      c.fillStyle = hexA(col, .25); c.fillRect(bx, by, bw, 4); c.fillStyle = "#66d9ce"; c.fillRect(bx, by, bw * sp, 4);
      if (!S.reduce) { c.fillStyle = "rgba(255,255,255,.85)"; c.fillRect(bx + (bw - 4) * ((t * .35) % 1), by, 4, 4); }
      c.restore(); return;
    }
    c.textAlign = "left"; c.font = `800 ${Math.max(6.5, h * .17)}px Nunito, system-ui`; c.fillStyle = col; c.fillText("BIBLIOTECA", x0 + 4, y0 + 4 + h * .2);
    c.textAlign = "right"; c.font = `800 ${Math.max(9, h * .32)}px Nunito, system-ui`; c.fillStyle = "#8fdcae"; c.fillText((pct * 100).toFixed(pct < .1 ? 1 : 0).replace(".", ",") + " %", x0 + w - 4, y0 + h * .62);
    c.textAlign = "left"; c.font = `700 ${Math.max(6, h * .16)}px Nunito, system-ui`; c.fillStyle = "rgba(230,240,255,.85)"; c.fillText(bibGB(P.done), x0 + 4, y0 + h * .62);
    const bx = x0 + 4, bw = w - 8, by = y0 + h - 8; c.fillStyle = hexA(col, .25); c.fillRect(bx, by, bw, 4); c.fillStyle = "#8fdcae"; c.fillRect(bx, by, bw * pct, 4);
    if (!S.reduce && P.running) { c.fillStyle = "rgba(255,255,255,.85)"; c.fillRect(bx + bw * pct * ((t * .5) % 1), by, 4, 4); }
    c.restore();
  }
  /* ───────── Strata: su pantalla es su propio monitor ─────────
     Barras: lo que lee (entrada, cian) y lo que escribe (salida, verde) por segundo ahora mismo; debajo, la salida de los
     últimos 2 min; a la derecha, la temperatura de la gráfica (o de la CPU si la gráfica no responde). El modelo cargado va
     en su placa de nombre y en su ficha. Datos de /api/machines (Faro pregunta a Strata en localhost cada 2 s). */
  function stHist(st) {
    S.ST = st || null; S.STh = S.STh || []; S.DKh = S.DKh || []; if (!st || !st.ok) return;
    S.STh.push(st.busy ? (st.write_tps || 0) : 0); if (S.STh.length > 60) S.STh.shift();
    const d = stDisk(); S.DKh.push((d.r || 0) + (d.w || 0)); if (S.DKh.length > 60) S.DKh.shift();
  }
  // disco: el de los procesos de Strata si Faro los encuentra; si no, el del PC entero
  function stDisk() { const ST = S.ST || {}, pc = machList().find(m => m.kind === "pc") || {};
    return ST.disk_r != null ? { r: ST.disk_r, w: ST.disk_w, k: "Strata" } : { r: pc.disk_r, w: pc.disk_w, k: "PC" }; }
  function pcTemp() { const pc = machList().find(m => m.kind === "pc") || ((S.D || {}).machines || []).find(m => m.kind === "pc") || {};
    return pc.gpu_temp != null ? { v: pc.gpu_temp, k: "GPU" } : pc.cpu_temp != null ? { v: pc.cpu_temp, k: "CPU" } : null; }
  const tCol = v => v >= 80 ? "#f0736e" : v >= 68 ? "#f2c078" : "#8fdcae";
  function drawStrataScreen(c, mx, my, t, w, h) {
    const ST = S.ST || {}, hw = w / 2, hh = h / 2, x0 = mx - hw, y0 = my - hh, T = pcTemp();
    c.save(); c.fillStyle = "#03140c"; rr(c, x0, y0, w, h, 4); c.fill(); rr(c, x0, y0, w, h, 4); c.clip();
    c.fillStyle = "#8fdcae"; c.fillRect(x0, y0, w, 3);
    const tw = T ? Math.max(18, w * .3) : 0, gx = x0 + 19, gw = w - 21 - tw;
    if (!ST.ok) { c.fillStyle = "rgba(57,255,136,.45)"; c.font = "800 8px Nunito, system-ui"; c.textAlign = "center"; c.fillText("sin señal", x0 + (w - tw) / 2, my + 3); }
    else {
      const lg = (v, top) => Math.min(1, Math.log10(1 + (v || 0)) / Math.log10(1 + top)), bh = h - 9;
      // texto: lo que lee (entrada) en vivo si Strata da métricas, si no el de la última orden (más tenue); lo que escribe, en vivo
      const rdLive = ST.read_tps != null, rd = rdLive ? ST.read_tps : (ST.last && ST.last.read_tps) || 0, wr = ST.busy ? (ST.write_tps || 0) : 0, dk = stDisk();
      const bar = (i, v, top, col, dim) => { const bx = x0 + 3 + i * 4.2; c.fillStyle = hexA(col, .15); c.fillRect(bx, y0 + 5, 3.2, bh); c.fillStyle = dim ? hexA(col, .45) : col; c.fillRect(bx, y0 + 5 + bh * (1 - lg(v, top)), 3.2, bh * lg(v, top)); };
      bar(0, rd, 2000, "#66d9ce", !rdLive); bar(1, wr, 120, "#8fdcae"); bar(2, dk.r, 2000, "#f2b77a"); bar(3, dk.w, 2000, "#f29b9d");
      // gráfica de 2 min: alterna cada 5 s entre lo que escribe la IA y el disco (lee + escribe)
      const dkPage = !S.reduce && Math.floor(t / 5) % 2 === 1, H2 = dkPage ? (S.DKh || []) : (S.STh || []), top = Math.max(dkPage ? 5 : 10, ...H2);
      if (H2.length > 1) { c.strokeStyle = dkPage ? "#f2b77a" : "#8fdcae"; c.lineWidth = 1.2; c.beginPath();
        H2.forEach((v, i) => { const x = gx + 3 + i * (gw - 3) / (H2.length - 1), y = y0 + h - 3 - (h - 10) * v / top; i ? c.lineTo(x, y) : c.moveTo(x, y); }); c.stroke(); }
      // cifra de la página, ajustada a su hueco (nunca pisa la temperatura)
      const n = v => v == null ? "—" : v >= 10 ? Math.round(v) : Math.round(v * 10) / 10;
      const opts = dkPage ? ["↓" + n(dk.r) + " ↑" + n(dk.w) + " MB/s", "↓" + n(dk.r) + " ↑" + n(dk.w), (dk.r || 0) >= (dk.w || 0) ? "↓" + n(dk.r) : "↑" + n(dk.w)]
        : [ST.busy ? Math.round(wr) + " t/s" : "listo", ST.busy ? String(Math.round(wr)) : "listo"];
      let txt = opts[opts.length - 1];
      for (const sz of [8, 7]) { c.font = `800 ${sz}px Nunito, system-ui`; const f0 = opts.find(o => c.measureText(o).width <= gw - 4); if (f0) { txt = f0; break; } }
      c.textAlign = "left"; c.fillStyle = dkPage ? "#f2b77a" : ST.busy ? "#8fdcae" : "rgba(57,255,136,.5)";
      c.save(); c.beginPath(); c.rect(gx, y0 + 3, gw, h - 3); c.clip(); c.fillText(txt, gx + 3, y0 + 12); c.restore();
      if (ST.busy && !S.reduce) glow(c, gx + gw, y0 + 9, 6, "#8fdcae", .6 + .4 * Math.sin(t * 8));
    }
    if (T) { const col = tCol(T.v); c.fillStyle = "rgba(255,255,255,.06)"; c.fillRect(x0 + w - tw, y0 + 3, tw, h - 3);
      c.fillStyle = col; c.font = `800 ${Math.round(Math.min(13, h * .42))}px Nunito, system-ui`; c.textAlign = "center"; c.fillText(T.v + "°", x0 + w - tw / 2, my + 3);
      c.fillStyle = "rgba(200,230,210,.6)"; c.font = "700 6px Nunito, system-ui"; c.fillText(T.k, x0 + w - tw / 2, y0 + h - 3); }
    c.restore();
  }
  function strataCardHTML() {
    const ST = S.ST || {}, T = pcTemp(), L = ST.last, f = v => v == null ? "—" : (v >= 100 ? Math.round(v) : v) + " t/s";
    if (!ST.ok) return `<p class="fo-meta">Strata no responde en este PC ahora mismo (o la ficha no tiene datos todavía).</p>`;
    const pc = machList().find(m => m.kind === "pc") || {};
    return `<div class="fo-st"><h4>En vivo</h4><ul class="fo-chat">
      <li><b>Modelo cargado</b><span>${esc(ST.model || "sin nombre")}</span></li>
      <li><b>Estado</b><span>${ST.busy ? "pensando" : "listo"}</span></li>
      <li><b style="color:#66d9ce">Lee (entrada)</b><span>${ST.read_tps != null ? f(ST.read_tps) : ST.read_avg != null ? f(ST.read_avg) + " de media" : L && L.read_tps ? f(L.read_tps) + " en la última orden" : "—"}</span></li>
      <li><b style="color:#8fdcae">Escribe (salida)</b><span>${ST.busy && ST.write_tps != null ? f(ST.write_tps) : ST.write_avg != null ? f(ST.write_avg) + " de media" : L && L.write_tps ? f(L.write_tps) + " en la última orden" : "—"}</span></li>
      ${ST.read_total != null ? `<li><b>Total</b><span>${ST.read_total.toLocaleString("es-ES")} leídos · ${ST.write_total.toLocaleString("es-ES")} escritos</span></li>` : ""}
      ${L && (L.read || L.write) ? `<li><b>Última orden de Faro</b><span>${L.read != null ? L.read.toLocaleString("es-ES") + " leídos" : ""}${L.read != null && L.write != null ? " · " : ""}${L.write != null ? L.write.toLocaleString("es-ES") + " escritos" : ""} · hace ${Math.max(1, Math.round(L.age / 60))} min</span></li>` : ""}
      <li><b style="color:#f2b77a">Disco de Strata</b><span>${ST.disk_r != null ? `lee ${ST.disk_r} MB/s · escribe ${ST.disk_w} MB/s` : ST.procs ? "sin datos todavía" : "no veo sus procesos"}</span></li>
      <li><b style="color:#f29b9d">Disco del PC</b><span>${pc.disk_r != null ? `lee ${pc.disk_r} MB/s · escribe ${pc.disk_w} MB/s` : "sin datos"}</span></li>
      ${ST.kv != null ? `<li><b>Memoria de contexto</b><span>${ST.kv} %</span></li>` : ""}
      <li><b>Temperatura</b><span>${pc.gpu_temp != null ? `GPU <b style="color:${tCol(pc.gpu_temp)}">${pc.gpu_temp} °C</b>` : ""}${pc.gpu_temp != null && pc.cpu_temp != null ? " · " : ""}${pc.cpu_temp != null ? `CPU <b style="color:${tCol(pc.cpu_temp)}">${pc.cpu_temp} °C</b>` : ""}${!T ? "sin sensor" : ""}</span></li>
      ${pc.vram_gb != null ? `<li><b>Memoria de la gráfica</b><span>${pc.vram_gb} / ${pc.vram_total_gb} GB</span></li>` : ""}
    </ul><p class="fo-meta">Pantalla: barras de lo que lee y escribe (texto en cian y verde, disco en ámbar y rosa) y gráfica de 2 min que alterna entre lo que escribe la IA y el disco. Faro lo pregunta en este PC cada 2 s mientras la oficina está abierta.</p></div>`;
  }
  function drawGtaScreen(c, mx, my, t, G, w, h) {   // pantalla (66×40 o la de la mesa dibujada) de un agente que trabaja en la máquina
    w = w || 66; h = h || 40; const hw = w / 2, hh = h / 2;
    const gr = c.createLinearGradient(0, my - hh, 0, my + hh); gr.addColorStop(0, "#2a0a44"); gr.addColorStop(1, "#7a1059");
    c.fillStyle = gr; rr(c, mx - hw, my - hh, w, h, 4); c.fill();
    c.save(); rr(c, mx - hw, my - hh, w, h, 4); c.clip();
    const P = gtaRoad(mx - hw + 6, my - hh * .45, w - 12, h * .45, 2); gtaDrawRoad(c, P, t, 4, false, G, .7); gtaDrawCars(c, P, t, G, .75, "pc" + Math.round(mx), 1 / 60);
    c.restore();
  }
  function gtaCardHTML() {
    const G = gtaData(); if (!G) return "<h3>Máquina GTA VI</h3><p>Sin clips en marcha.</p>";
    const name = st => (GTA_ST.find(s => s[1] === st) || [st === 11 ? "DESGUACE" : "?"])[0];
    const rows = G.clips.map(k => `<li><span class="fo-sw" style="background:${GTA_SER[k.s] || "#fff"}"></span><b>Clip ${esc(k.n)}</b> · ${esc(GTA_SER_N[k.s] || k.s)} · ${esc(name(k.st))}${k.b ? " · bloqueado" : ""}${Array.isArray(k.j) ? " · jueces " + k.j.map(j => ({ rev: "🟡", ok: "🟢", ko: "🔴" })[j] || "·").join("") : ""}</li>`).join("");
    const link = typeof G.url === "string" && /^https:\/\/claude\.ai\//.test(G.url) ? `<p><a class="fo-btn" href="${esc(G.url)}" target="_blank" rel="noopener">Abrir el panel de la máquina</a></p>` : "";
    const M = gtaLive(), est = M ? (M.working ? `<b style="color:#8fdcae">Trabajando ahora</b>${M.who ? " · " + M.who + (M.who > 1 ? " agentes" : " agente") + " en la oficina" : ""}` : `<b style="color:#f0b46a">En pausa</b>`) + ` · último dato de la máquina ${agoTxt(M.age)}` : "";
    return `<h3><span class="fo-sw" style="background:#f08aa6"></span>Máquina GTA VI</h3><p>${est}</p><p>${esc(G.paso || "")}</p><ul style="margin:6px 0 0;padding-left:0;list-style:none;display:grid;gap:4px">${rows}</ul>${link}`;
  }

  // Ficha completa de la máquina (GTA VI + voz): se abre al pulsar cualquiera de sus dos monitores. Estructura fija, de lo
  // urgente a lo detallado: estado en vivo → cifras → qué te toca → tramos → clips → voz → encargos. Se refresca sola con
  // cada lectura (2–5 s) sin perder el desplazamiento. Todo sale de datos reales; lo viejo se dice que es viejo.
  function machineSheetHTML(focus) {
    const D = S.D || {}, M = gtaLive(), V = vozLive(), G = M ? M.G : null, P = S.vozP && Date.now() - S.vozPat < 15000 ? S.vozP : D.voz_probe || {};
    const chip = (txt, col, fill) => `<span class="fo-chip" style="border-color:${col};color:${fill ? "#161c27" : col};${fill ? "background:" + col : ""}">${txt}</span>`;
    const kpi = (n, lab, col) => `<div class="fo-kpi"><b style="color:${col}">${n}</b><span>${lab}</span></div>`;
    const stale = M && M.age != null && M.age > 6 * 3600, hhmm = iso => { const d = new Date(iso); return isNaN(d) ? "" : d.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }); };
    let h = `<h3><span class="fo-sw" style="background:#f08aa6"></span>Máquina GTA VI</h3><div class="fo-chips">` +
      (M ? chip(M.working ? "● Trabajando ahora" : "En pausa", M.working ? "#8fdcae" : "#f0b46a", M.working) : chip("Sin datos de la máquina", "#8a8fa8")) +
      chip(V.working ? "● Voz: generando" : "Voz: en espera", V.working ? "#8fdcae" : "#f2b77a", V.working) +
      (M ? chip("Datos de clips: " + agoTxt(M.age), stale ? "#f0807a" : "#aab6cf") : "") + `</div>`;
    if (stale) h += `<p class="fo-warn">La lista de clips es de ${agoTxt(M.age)}: la máquina no ha vuelto a informar de sus clips. La voz sí va en directo (Faro la mira en el PC).</p>`;
    h += `<div class="fo-kpis">${kpi(M ? M.live : "–", "clips en marcha", "#66d9ce")}${kpi(M ? M.pub : "–", "publicados", "#8fdcae")}${kpi(M ? M.blk : "–", "bloqueados", M && M.blk ? "#f0807a" : "#aab6cf")}${kpi(P.today != null ? P.today : "–", "audios de voz hoy", "#f2b77a")}</div>`;
    // qué te toca
    const ords = (D.orders || []).filter(o => /^(gta|voz)$/.test(o.project || "") || /gta|voz narradora|clip/i.test(o.title || ""));
    const open = ords.filter(o => o.state === "queued" || o.state === "running" || o.state === "failed"), blocked = G ? G.clips.filter(k => k.b && k.st !== 10 && k.st !== 11) : [];
    const todo = [...blocked.map(k => `Clip ${esc(k.n)} bloqueado: ${esc(typeof k.b === "string" ? k.b : "sin motivo apuntado")}`), ...open.filter(o => o.state === "failed").map(o => `Encargo fallido: ${esc(o.title)}`), ...(V.rev ? [`${esc(V.rev)} clips esperan el OK de la voz`] : [])];
    h += `<h4>Qué te toca</h4>` + (todo.length ? `<ul class="fo-list">${todo.map(x => `<li>${x}</li>`).join("")}</ul>` : `<p class="fo-dim">Nada bloqueado que dependa de ti, según lo que la máquina ha informado.</p>`);
    // tramos y clips
    if (G) { const by = {}; G.clips.forEach(k => (by[k.st] = by[k.st] || []).push(k));
      h += `<h4>Tramos</h4><div class="fo-stages">` + GTA_ST.map(([nm, st]) => { const L = by[st] || []; return `<div class="fo-st${L.length ? " on" : ""}"><span>${nm}</span><b>${L.length || ""}</b><i>${L.map(k => `<em style="background:${GTA_SER[k.s] || "#fff"}" title="Clip ${esc(k.n)}">${esc(k.n)}</em>`).join("")}</i></div>`; }).join("") + `</div>`;
      const nmSt = st => (GTA_ST.find(x => x[1] === st) || [st === 11 ? "DESGUACE" : "?"])[0], jd = j => `<span class="fo-j" style="background:${({ rev: "#f2c078", ok: "#8fdcae", ko: "#f0736e" })[j] || "#55607f"}"></span>`;
      h += `<h4>Clips</h4><table class="fo-tb"><tr><th>Nº</th><th>Serie</th><th>Tramo</th><th>Jueces</th><th>Bloqueo</th></tr>` + G.clips.map(k => `<tr><td><b>${esc(k.n)}</b></td><td><span class="fo-sw" style="background:${GTA_SER[k.s] || "#fff"}"></span>${esc(GTA_SER_N[k.s] || k.s || "")}</td><td>${esc(nmSt(k.st))}</td><td>${Array.isArray(k.j) ? k.j.map(jd).join("") : "–"}</td><td>${k.b ? esc(typeof k.b === "string" ? k.b : "sí") : ""}</td></tr>`).join("") + `</table>` + (G.paso ? `<p class="fo-dim">Último paso informado: ${esc(G.paso)}</p>` : ""); }
    else h += `<h4>Clips</h4><p class="fo-dim">La máquina aún no ha informado de ningún clip.</p>`;
    // voz
    const hrs = Array.isArray(P.hours) ? P.hours : [], hm = Math.max(1, ...hrs), nowH = new Date().getHours(), lg = P.langs || {};
    h += `<h4 id="fo-voz">Voz narradora</h4><p>${V.working ? '<b style="color:#8fdcae">Generando ahora</b>' + (P.since ? " · desde las " + hhmm(P.since) : "") : P.dir ? "En espera" : "Faro no encuentra la carpeta de la voz en este equipo"}${P.last ? " · último audio a las " + hhmm(P.last) + " (" + agoTxt(Math.max(0, (Date.now() - Date.parse(P.last)) / 1000)) + ")" : ""}</p>` +
      (hrs.length ? `<div class="fo-hrs" title="Audios generados hoy, por horas">${hrs.map((n, i) => `<i style="height:${Math.round(4 + 30 * n / hm)}px;opacity:${n ? 1 : .25}${i === nowH ? ";outline:1px solid #fff" : ""}" title="${i} h: ${n}"></i>`).join("")}</div><p class="fo-dim">Audios de hoy por horas (0–23 h)${Object.keys(lg).length ? " · por idioma: " + Object.entries(lg).map(([k, n]) => `${esc(k.toUpperCase())} ${n}`).join(" · ") : ""}</p>` : "") +
      (Array.isArray(P.recent) && P.recent.length ? `<table class="fo-tb"><tr><th>Últimos audios</th><th>Idioma</th><th>Hora</th><th>Tamaño</th></tr>${P.recent.map(r => `<tr><td>${esc(r.name)}</td><td>${esc(String(r.lang || "").toUpperCase())}</td><td>${hhmm(r.at)}</td><td>${r.kb} KB</td></tr>`).join("")}</table>` : "") +
      `<p class="fo-dim">Clon local en el PC. Nada se publica sin el OK de la titular de la voz. Faro solo mira procesos, nombres y horas: no lee audios ni textos.</p>`;
    // encargos
    const stN = { queued: ["en cola", "#f2c078"], running: ["en marcha", "#8fdcae"], done: ["hecho", "#aab6cf"], failed: ["falló", "#f0807a"], cancelled: ["cancelado", "#8a8fa8"] };
    h += `<h4>Encargos de la máquina</h4>` + (ords.length ? `<table class="fo-tb"><tr><th>Encargo</th><th>Quién</th><th>Estado</th></tr>${ords.slice(-12).reverse().map(o => `<tr><td>${esc(o.title || "")}</td><td>${esc(o.executor || "")}</td><td style="color:${(stN[o.state] || [0, "#fff"])[1]}">${(stN[o.state] || [o.state])[0]}</td></tr>`).join("")}</table>` : `<p class="fo-dim">Sin encargos de GTA VI o de voz en la lista de Faro.</p>`);
    const link = G && typeof G.url === "string" && /^https:\/\/claude\.ai\//.test(G.url) ? `<a class="fo-btn" href="${esc(G.url)}" target="_blank" rel="noopener">Panel de la máquina</a>` : "";
    h += `<p style="margin-top:12px">${link}<a class="fo-btn" href="obsidian://open?vault=Nahuel&file=${encodeURIComponent("10 Proyectos/GTA VI")}">Nota del proyecto en Obsidian</a></p>`;
    return h;
  }

  /* ───────── fichas ───────── */
  function hit(x, y) {
    const L = S.L; let best = null, bd = 40;
    S.ag.forEach(a => { const d = Math.hypot(a.x - x, a.y - 20 - y); if (d < bd) { bd = d; best = { type: "agent", id: a.id }; } });
    if (best) return best;
    { const R = VZR(); if (x > R.x - 6 && x < R.x + R.w + 6 && y > R.y - 5 && y < R.y + R.h + 5) return { type: "voz" }; }
    if (gtaData()) { const T = TVR(); if (x > T.x - 6 && x < T.x + T.w + 6 && y > T.y - 6 && y < T.y + T.h + 6) return { type: "gta" }; }
    for (const [k, z] of Object.entries(L.zones)) if (x > z.x && x < z.x + z.w && y > z.y && y < z.y + z.h) return { type: "zone", id: k };
    for (const ch of L.chan) if (x > ch.x && x < ch.x + ch.w && y > ch.y && y < ch.y + ch.h) return { type: "chan", id: ch.k };
    const Bn = L.bench; if (x > Bn.x && x < Bn.x + Bn.w && y > Bn.y && y < Bn.y + Bn.h) return { type: "bench" };
    const Me = L.meter; if (machList().length && x > Me.x + Me.w * .40 && x < Me.x + Me.w + 10 && y > Me.y - 12 && y < Me.y + Me.h + 8) return { type: "mach" };
    const bx = BOX(); if (Math.hypot(x - bx.x, y - bx.y) < 50) return { type: "box" };
    for (const b of projectBuildings()) if (x > b.x - 10 && x < b.x + b.w + 10 && y > S.L.proj.y && y < b.base + 42) return { type: "proj", id: b.id };
    { const O = orbState(); if (Math.hypot(x - O.x, y - O.y) < ORB_R() * 1.8) return { type: "tower" }; }   // el orbe (antes, la torre)
    return null;
  }
  function renderCard() {
    const el = S.root && S.root.querySelector(".fo-card"); if (!el) return; const sel = S.sel, D = S.D || {};
    if (!sel) { el.hidden = true; return; } el.hidden = false; let h = "";
    const isV = sel.type === "zone" && sel.id === "obsidian", isM = sel.type === "gta" || sel.type === "voz"; el.classList.toggle("fo-wide", isV || isM);
    if (!isV && !isM) el.dataset.k = "";
    else if (el.dataset.k === "vault" && el.querySelector(".fo-vg")) { vgCardUpdate(); const w = el.querySelector(".fo-vwho"); if (w) w.innerHTML = vgWho(); return; }
    const ae = document.activeElement; if (ae && ae.tagName === "TEXTAREA" && el.contains(ae)) return;  // no borrar lo que estás escribiendo
    if (sel.type === "chat") {
      const ms = (D.chat || []).slice(-15).reverse(), when = iso => new Date(iso).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
      h = `<h3><span class="fo-sw" style="background:#ffb86b"></span>Conversaciones</h3>${ms.length ? `<ul class="fo-chat">${ms.map(m => `<li><b>${esc(m.from)}</b> → ${esc(m.to)} <span>${when(m.at)}</span><p>${esc(m.text)}</p></li>`).join("")}</ul>` : "<p>Aún no hay mensajes reales. Aparecen cuando un agente propone, entrega o te escribe, o cuando tú contestas.</p>"}`;
      el.innerHTML = `<button type="button" class="fo-x" aria-label="Cerrar">×</button>` + h; el.querySelector(".fo-x").onclick = () => { S.sel = null; renderCard(); }; return;
    }
    if (sel.type === "mach") {
      const ms = (S.M && S.M.length ? S.M : (D.machines || [])), f = (v, u) => v == null ? "—" : v + (u || "");
      h = `<h3><span class="fo-sw" style="background:#66d9ce"></span>Máquinas</h3>` + ms.map(m => `<div class="fo-mach"><b>${esc(m.name)}${m.gpu_name ? " · " + esc(m.gpu_name) : ""}</b>
        ${(S.mh && S.mh[m.name] || []).length > 1 ? `<svg class="fo-spark" viewBox="0 0 120 30" preserveAspectRatio="none" aria-label="CPU y GPU de los últimos 2 minutos">${spark(S.mh[m.name], "cpu", "#7fd3a6")}${spark(S.mh[m.name], "gpu", "#66d9ce")}</svg>` : ""}
        <div class="fo-meta">CPU ${f(m.cpu, " %")} · RAM ${f(m.ram, " %")} (${f(m.ram_gb)}/${f(m.ram_total_gb, " GB")})${m.gpu != null ? ` · GPU ${m.gpu} %` : ""}${m.disk_r != null ? ` · Disco lee ${m.disk_r} / escribe ${m.disk_w} MB/s` : ""}${m.vram_gb != null ? ` · VRAM ${m.vram_gb}${m.vram_total_gb ? "/" + m.vram_total_gb : ""} GB` : ""}${m.gpu_temp != null ? ` · ${m.gpu_temp} °C` : ""}${m.gpu_w != null ? ` · ${m.gpu_w} W` : ""}${m.age > 20 ? " · sin datos hace " + m.age + " s" : ""}</div>
        ${(m.gpu_apps || []).length ? `<p>Gráfica: ${m.gpu_apps.map(a => esc((a.agent ? a.agent + " (" + a.name + ")" : a.name) + " " + a.vram_gb + " GB")).join(" · ")}</p>` : ""}
        ${(m.top || []).length ? `<p>CPU: ${m.top.slice(0, 4).map(a => esc((a.agent ? a.agent + " · " : "") + a.name + " " + a.cpu + " %")).join(" · ")}</p>` : ""}</div>`).join("")
        + `<div class="fo-meta">Lectura real cada 2 s (verde CPU, azul GPU, últimos 2 min). El punto verde late con cada lectura nueva. Procesos: lo que usan ahora, no su media.</div>`;
      el.innerHTML = `<button type="button" class="fo-x" aria-label="Cerrar">×</button>` + h; el.querySelector(".fo-x").onclick = () => { S.sel = null; renderCard(); }; return;
    }
    if (sel.type === "bench") {
      const b = S.bench || [];
      h = `<h3><span class="fo-sw" style="background:#94a3b8"></span>Sin turno</h3>${b.length ? `<ul class="fo-chat">${b.map(a => `<li><b>${esc(a.name)}</b>${a.cloud ? " ☁" : ""}<p>${esc(a.label || (a.off ? "sin señal" : "libre"))}</p></li>`).join("")}</ul>` : "<p>Todos tienen mesa.</p>"}
        <div class="fo-meta">Las mesas van por prioridad: primero quien trabaja, luego quien tiene algo en segundo plano y después quien está libre.</div>`;
      el.innerHTML = `<button type="button" class="fo-x" aria-label="Cerrar">×</button>` + h; el.querySelector(".fo-x").onclick = () => { S.sel = null; renderCard(); }; return;
    }
    if (sel.type === "chan") {
      const k = sel.id, who = [...S.ag.values()].filter(a => chanOf(a) === k), C = CHAN[k];
      const how = { you: "Lo que pides desde Faro (órdenes y respuestas).", cloud: "Sesiones en la nube que informan por el buzón de GitHub; Faro lo lee cada 15 s.", local: "Agentes del PC y del Mac: Faro mira cada 15 s si están escribiendo, en marcha o apagados." }[k];
      h = `<h3><span class="fo-sw" style="background:${C.c}"></span>${esc(C.label)}</h3><p>${esc(how)}</p><p>${who.length ? who.map(a => esc(a.name)).join(" · ") : "Nadie ahora"}</p>`;
      el.innerHTML = `<button type="button" class="fo-x" aria-label="Cerrar">×</button>` + h; el.querySelector(".fo-x").onclick = () => { S.sel = null; renderCard(); }; return;
    }
    if (sel.type === "agent") {
      const a = S.ag.get(sel.id); if (!a) { el.hidden = true; return; } const z = a.zone && ZONES[a.zone];
      const st = { work: "trabajando", queue: "en cola", bg: "descansa: su tarea sigue en segundo plano", idle: "libre en su mesa" }[a.st];
      const pr = (D.projects || []).find(p => p.id === a.project);
      h = `<h3><span class="fo-sw" style="background:${(BRANDS[a.brand] || BRANDS.hermes).c}"></span>${esc(a.name)}</h3>
        <div class="fo-row"><b style="color:${z ? z.c : "#d9d4ee"}">${z ? esc(z.label) : esc(st)}</b>${z ? `<span>${esc(z.doing)}</span>` : ""}</div>
        ${a.label ? `<p>${esc(a.label)}</p>` : ""}${a.step ? `<p class="fo-meta">Paso: ${esc(a.step)}</p>` : ""}
        ${a.tasks && a.tasks.length ? `<ul class="fo-chat">${a.tasks.map(k => `<li><b>${esc(k.title || k.name)}</b><span>${k.closed ? "hecho" : k.state === "run" ? "en marcha" : "sin cierre"}</span></li>`).join("")}</ul>` : ""}
        <div class="fo-meta">${pr ? "Proyecto: " + esc(pr.name) + " · " : ""}${a.st === "work" ? (a.real ? "acción real" : "representación según el tipo de tarea") : st}${a.reason ? " · " + esc(a.reason) : ""}</div>
        ${a.brand === "local" ? strataCardHTML() : ""}`;
    } else if (sel.type === "zone") {
      const z = ZONES[sel.id], who = [...S.ag.values()].filter(a => a.st === "work" && a.zone === sel.id && !a.walking);
      h = `<h3><span class="fo-sw" style="background:${z.c}"></span>${esc(z.label)}</h3><p>${who.length ? who.map(a => esc(shortName(a.name))).join(" · ") : "Nadie ahora"}</p>`;
      if (sel.id === "obsidian") { const v = D.vault || {}, g = v.graph || {}; el.dataset.k = "vault";
        h = `<h3><span class="fo-sw" style="background:${z.c}"></span>Bóveda · en vivo</h3><canvas class="fo-vg" aria-label="Grafo de la bóveda: se enciende la nota que se lee o se escribe."></canvas><p class="fo-vhint" style="margin:0 0 4px;font-size:12px;opacity:.7">La cámara navega sola: va a lo que se enciende, al núcleo y a lo caliente</p>
          <div class="fo-vleg"><span style="--c:${KC.read}">lee</span><span style="--c:${KC.write}">escribe (y escrita hace &lt;15 min)</span><span style="--c:${KC.new}">nota nueva</span><span style="--c:${KC.del}">borrada</span><span style="--c:#a99fd8">en reposo</span></div>
          <p><button type="button" class="fo-hist" style="font:800 12px Nunito,system-ui;color:#fff3c4;background:rgba(255,214,120,.12);border:1px solid rgba(255,214,120,.55);border-radius:8px;padding:7px 12px;cursor:pointer">${VG.hist ? "■ Parar" : "▶ Historia de la bóveda"}</button></p><p class="fo-vwho">${vgWho()}</p><ul class="fo-chat fo-vlog">${vgLogHTML()}</ul>
          <div class="fo-meta">${VG.src === "obsidian" ? "Cada punto está donde lo tiene la vista gráfica de Obsidian (último envío " + agoTxt(Math.max(0, Date.now() / 1000 - VG.srcAt)) + "). " : "Dibujo calculado por Faro (Obsidian no ha mandado el suyo). "}${v.total || 0} notas · ${g.links ?? 0} enlaces · ${VG.mode === "inotify" ? "el PC avisa al instante de cada lectura y escritura" : VG.mode === "sondeo" ? "se comprueba cada 2 s (solo escrituras)" : "sin vigía en vivo"}. Quién lo hace se dice solo cuando no hay duda; lo que viene del Mac llega por Syncthing.</div>`; }
      if (sel.id === "skills") h += `<ul class="fo-list">${(D.skills || []).slice(0, 12).map(s => `<li>${esc(s.name)}</li>`).join("")}</ul>`;
    } else if (sel.type === "proj") {
      const b = projectBuildings().find(x => x.id === sel.id); if (!b) { el.hidden = true; return; }
      const arts = (D.artifacts || []).filter(a => a.project === b.id).slice(-4), pr = (D.proud || []).filter(a => a.project === b.id);
      h = `<h3><span class="fo-sw" style="background:#66d9ce"></span>${esc(b.name)}</h3><div class="fo-row"><b>${b.w7 != null ? b.w7 : b.floors}</b><span>${b.w7 != null ? "entregas en 7 días · " + (b.d1 || 0) + " hoy · " + b.total + " en total" : "segmentos"}${b.fin ? " · completo" : b.active ? " · en obra" : ""}</span></div>${b.w7 != null ? `<p class="fo-dim">La altura de la aguja son las entregas reales de los últimos 7 días, a la misma escala para todos los proyectos. Baja sola si el proyecto se para.</p>` : ""}<p>${b.done} entregas · ${b.arts} artefactos · ${b.proud} de orgullo (cuentan doble)${b.floors >= 12 ? " · tope de 12 alcanzado" : ""}</p>
        ${pr.length ? `<p>★ ${pr.map(p => esc(p.title)).join(" · ")}</p>` : ""}${arts.length ? `<ul class="fo-list">${arts.map(a => `<li>${esc(a.name)}</li>`).join("")}</ul>` : ""}`;
    } else if (isM) {   // los dos monitores abren la misma ficha completa; se refresca sin mover el desplazamiento
      const top = el.dataset.k === "maq" ? el.scrollTop : null; el.dataset.k = "maq";
      el.innerHTML = `<button type="button" class="fo-x" aria-label="Cerrar ficha">×</button>` + machineSheetHTML(sel.type);
      el.querySelector(".fo-x").onclick = () => { S.sel = null; renderCard(); };
      if (top != null) el.scrollTop = top; else if (sel.type === "voz") { const v = el.querySelector("#fo-voz"); if (v) el.scrollTop = v.offsetTop - 12; }
      return;
    } else if (sel.type === "tower") {
      const n = [...S.ag.values()].filter(a => a.st === "work").length;
      h = `<h3><span class="fo-sw" style="background:#efe2a4"></span>El ojo de Faro</h3><p>${n} trabajando. Recorre a quien trabaja: lo ilumina, enfoca, persigue y lo alumbra desde arriba, y pasa al siguiente. Cada dato que llega vuela hasta él y lo alimenta con su color. Mantiene su ruta: si alguien entra o sale, sigue por donde iba. Sin trabajo, se queda flotando donde estaba y, al rato, sobrevuela la bóveda.</p>`;
    } else if (sel.type === "box") {
      const list = (D.suggestions || []).filter(s => s.state === "open").sort((a, b) => (b.imp * b.ret / (b.cost || 1)) - (a.imp * a.ret / (a.cost || 1)));
      h = `<h3><span class="fo-sw" style="background:#f2c078"></span>Buzón</h3>${S.flash && Date.now() < S.flash.until ? `<p class="fo-ok">${esc(S.flash.text)}</p>` : ""}${list.length ? `<ul class="fo-sug">${list.map(s => `<li><b>${esc(s.text)}</b><span>${esc(s.why || "")}</span>
        <em>de ${esc(s.from || "un agente")}</em>
        <div><button type="button" data-acc="${esc(s.id)}">Lo hago</button><button type="button" data-dis="${esc(s.id)}">Ahora no</button><button type="button" data-rep="${esc(s.id)}">Responder</button><button type="button" class="fo-del" data-del="${esc(s.id)}">Hacedlo vosotros</button></div>
        <form class="fo-rep" data-for="${esc(s.id)}" hidden><textarea rows="2" maxlength="2000" placeholder="Contesta a ${esc(s.from || "quien lo pidió")}…"></textarea><button type="submit">Enviar</button></form></li>`).join("")}</ul>` : "<p>Vacío.</p>"}`;
    }
    el.innerHTML = `<button type="button" class="fo-x" aria-label="Cerrar ficha">×</button>` + h;
    el.querySelector(".fo-x").onclick = () => { S.sel = null; renderCard(); };
    const hb = el.querySelector(".fo-hist"); if (hb) hb.onclick = () => { vgHistory(); hb.textContent = VG.hist ? "■ Parar" : "▶ Historia de la bóveda"; };
    el.querySelectorAll("[data-acc],[data-dis]").forEach(b => b.onclick = () => suggAction(b.dataset.acc || b.dataset.dis, b.dataset.acc ? "accept" : "dismiss"));
    el.querySelectorAll("[data-del]").forEach(b => b.onclick = async () => { b.disabled = true; b.textContent = "Enviando…"; let ok = false;
      try { const r = await fetch("api/suggestion/action", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: b.dataset.del, type: "delegate" }) }); ok = r.ok && (await r.json()).ok; } catch (_) { }
      if (!ok) { b.disabled = false; b.textContent = "Reintentar"; return; }
      const s = (S.D.suggestions || []).find(x => x.id === b.dataset.del); if (s) s.state = "delegated";
      S.lastSugg = (S.D.suggestions || []).filter(x => x.state === "open").length; S.flash = { text: "Encargado. Avanzarán solos y te avisarán de lo que falte.", until: Date.now() + 4000 }; renderCard(); });
    el.querySelectorAll("[data-rep]").forEach(b => b.onclick = () => { const f = [...el.querySelectorAll(".fo-rep")].find(x => x.dataset.for === b.dataset.rep); if (!f) return; f.hidden = !f.hidden; if (!f.hidden) f.querySelector("textarea").focus(); });
    el.querySelectorAll(".fo-rep").forEach(f => { const ta = f.querySelector("textarea"); ta.onkeydown = e => { e.stopPropagation(); if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) f.requestSubmit(); };
      f.onsubmit = async e => { e.preventDefault(); const txt = ta.value.trim(); if (!txt) { ta.focus(); return; } const btn = f.querySelector("button"); btn.disabled = true; btn.textContent = "Enviando…";
        let ok = false; try { const r = await fetch("api/suggestion/action", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: f.dataset.for, type: "reply", text: txt }) }); ok = r.ok && (await r.json()).ok; } catch (_) { }
        if (!ok) { btn.disabled = false; btn.textContent = "Reintentar"; return; }
        const s = (S.D.suggestions || []).find(x => x.id === f.dataset.for); if (s) s.state = "answered";
        S.lastSugg = (S.D.suggestions || []).filter(x => x.state === "open").length; S.flash = { text: "Respuesta enviada. Le llega como un mensaje.", until: Date.now() + 4000 }; renderCard(); }; });
  }
  async function suggAction(id, type) {
    try { await fetch("api/suggestion/action", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, type }) }); } catch (e) { }
    const s = (S.D.suggestions || []).find(x => x.id === id); if (s) s.state = type === "accept" ? "accepted" : "dismissed";
    S.lastSugg = (S.D.suggestions || []).filter(x => x.state === "open").length; renderCard();
  }

  /* ───────── DOM ───────── */
  const CSS = `
.fo-root{position:fixed;inset:0;z-index:40;background:#141a24;display:flex;flex-direction:column;font-family:Nunito,system-ui,sans-serif;color:#ece8dc;
  padding:calc(8px + env(safe-area-inset-top,0px)) max(8px,env(safe-area-inset-right,0px)) calc(8px + env(safe-area-inset-bottom,0px)) max(8px,env(safe-area-inset-left,0px));gap:8px;animation:fo-in .35s ease}
@keyframes fo-in{from{opacity:0;transform:scale(.99)}to{opacity:1;transform:none}}
.fo-top{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:0 6px}
.fo-top h2{margin:0;font-size:22px;font-weight:800;letter-spacing:.02em}
.fo-top div{display:flex;gap:6px}
.fo-btn{border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);color:#ece8dc;border-radius:999px;padding:7px 14px;font:700 14px Nunito,system-ui;cursor:pointer}
.fo-btn:hover{background:rgba(255,255,255,.12)} .fo-btn:focus-visible{outline:2px solid #66d9ce;outline-offset:2px}
.fo-stage{position:relative;flex:1;min-height:0;border-radius:18px;overflow:hidden}
.fo-stage>canvas{position:absolute;inset:0;width:100%;height:100%;display:block;cursor:pointer;touch-action:manipulation}
.fo-card{position:absolute;left:12px;bottom:12px;width:min(340px,calc(100% - 24px));max-height:60%;overflow:auto;background:rgba(14,20,46,.94);border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:14px 16px;box-shadow:0 10px 40px rgba(0,0,0,.45)}
.fo-card h3{margin:0 0 6px;font-size:19px;display:flex;align-items:center;gap:8px;padding-right:24px}
.fo-card p{margin:6px 0;font-size:15px;line-height:1.35}
.fo-row{display:flex;gap:8px;align-items:baseline;font-size:15px}
.fo-card h4{margin:16px 0 6px;font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:#aab6cf;border-top:1px solid rgba(102,217,206,.14);padding-top:12px}
.fo-chips{display:flex;flex-wrap:wrap;gap:6px;margin:4px 0 8px}.fo-chip{border:1px solid;border-radius:999px;padding:3px 10px;font-size:12.5px;font-weight:800;white-space:nowrap}
.fo-kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:8px 0}.fo-kpi{background:rgba(102,217,206,.05);border:1px solid rgba(102,217,206,.14);border-radius:12px;padding:8px 10px}.fo-kpi b{display:block;font-size:26px;line-height:1.1}.fo-kpi span{font-size:11.5px;color:#aab6cf}
.fo-warn{color:#ffb3b3;background:rgba(255,90,95,.08);border:1px solid rgba(255,90,95,.3);border-radius:10px;padding:7px 10px;font-size:13.5px !important}.fo-dim{opacity:.72;font-size:13px !important}
.fo-list{margin:4px 0;padding-left:18px;font-size:14.5px;display:grid;gap:3px}
.fo-stages{display:grid;grid-template-columns:repeat(6,1fr);gap:5px}.fo-st{border:1px solid rgba(255,255,255,.1);border-radius:9px;padding:5px 6px;min-height:46px;opacity:.55}.fo-st.on{opacity:1;border-color:rgba(255,62,165,.6);background:rgba(255,62,165,.07)}
.fo-st span{font-size:9.5px;letter-spacing:.08em;font-weight:800;color:#ffd8f0}.fo-st b{float:right;font-size:13px}.fo-st i{display:flex;gap:3px;flex-wrap:wrap;margin-top:4px}.fo-st em{font-style:normal;font-size:10.5px;font-weight:800;color:#161c27;border-radius:5px;padding:0 5px}
.fo-tb{width:100%;border-collapse:collapse;font-size:13.5px;margin:4px 0}.fo-tb th{text-align:left;font-size:11px;color:#aab6cf;font-weight:800;padding:3px 6px;border-bottom:1px solid rgba(102,217,206,.18)}.fo-tb td{padding:4px 6px;border-bottom:1px solid rgba(255,255,255,.06);vertical-align:top;overflow-wrap:anywhere}
.fo-j{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:3px}.fo-hrs{display:flex;align-items:flex-end;gap:2px;height:36px;margin:6px 0 2px}.fo-hrs i{flex:1;background:#f2b77a;border-radius:2px 2px 0 0}
@media (max-width:520px){.fo-kpis{grid-template-columns:repeat(2,1fr)}.fo-stages{grid-template-columns:repeat(3,1fr)}}
.fo-row b{font-size:17px}
.fo-meta{font-size:12.5px;color:#9aa6d6;margin-top:6px}
.fo-sw{width:12px;height:12px;border-radius:4px;flex:none}
.fo-x{position:absolute;right:10px;top:8px;background:none;border:0;color:#9aa6d6;font-size:22px;cursor:pointer}
.fo-list{margin:6px 0 0;padding-left:18px;font-size:14px;color:#d9d4ee}
.fo-sug{list-style:none;margin:6px 0 0;padding:0;display:flex;flex-direction:column;gap:8px}
.fo-sug li{background:rgba(255,255,255,.05);border-radius:12px;padding:8px 10px;display:flex;flex-direction:column;gap:4px}
.fo-sug span{font-size:13px;color:#9aa6d6}
.fo-sug button{border:0;border-radius:999px;padding:5px 12px;font:700 13px Nunito,system-ui;cursor:pointer;margin-right:6px;background:#f2c078;color:#252f3b}
.fo-sug button+button{background:rgba(255,255,255,.1);color:#ece8dc}
.fo-sug em{font-style:normal;font-size:12px;color:#f2c078;opacity:.8}
.fo-rep{display:flex;gap:6px;align-items:flex-end;margin-top:4px}
.fo-rep textarea{flex:1;min-width:0;background:rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.16);border-radius:10px;padding:8px;color:#ece8dc;font:600 14px Nunito,system-ui;resize:vertical}
.fo-rep button{border:0;border-radius:999px;padding:7px 14px;font:700 13px Nunito,system-ui;background:#66d9ce;color:#1a2230;cursor:pointer}
.fo-rep button:disabled{opacity:.6}
.fo-ok{color:#8fdcae;font-weight:700}
.fo-spark{display:block;width:100%;height:34px;margin:6px 0 2px;background:rgba(255,255,255,.04);border-radius:8px}
.fo-mach{padding:8px 0;border-top:1px solid rgba(255,255,255,.08)}.fo-mach p{margin:4px 0 0;font-size:13px;color:#d9d4ee}
.fo-chat{list-style:none;margin:6px 0 0;padding:0;display:flex;flex-direction:column;gap:8px}.fo-chat li{background:rgba(255,255,255,.05);border-radius:12px;padding:8px 10px;font-size:13px;color:#d9d4ee}.fo-chat li b{color:#fff}.fo-chat li span{float:right;color:#9aa6d6;font-size:12px}.fo-chat p{margin:4px 0 0;font-size:14px;color:#ece8dc}
.fo-sug .fo-del{background:#66d9ce;color:#1a2230}
.fo-sug li div{display:flex;flex-wrap:wrap;gap:6px}.fo-sug li div button{margin-right:0}
.fo-card.fo-wide{width:min(920px,calc(100% - 24px));max-height:88%;background:rgba(11,16,38,.975)}.fo-vg{width:100%;height:min(62vh,640px);display:block;border-radius:14px;margin:6px 0 4px;background:#120f26}
@media (max-width:520px){.fo-card{left:8px;right:8px;width:auto;max-height:70%}.fo-card.fo-wide{width:auto;max-height:78%}.fo-vg{height:56vh}}
.fo-vleg{display:flex;flex-wrap:wrap;gap:4px 12px;font-size:12px;color:#d9d4ee}.fo-vleg span::before{content:"";display:inline-block;width:9px;height:9px;border-radius:50%;background:var(--c);margin-right:5px;vertical-align:-1px}
.fo-help{position:absolute;right:12px;top:12px;width:min(300px,calc(100% - 24px));background:rgba(14,20,46,.94);border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:12px 14px;font-size:13.5px}
.fo-help ul{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:1fr 1fr;gap:6px 10px}
.fo-help li{display:flex;align-items:center;gap:6px}
[hidden]{display:none!important}
@media (prefers-reduced-motion:reduce){.fo-root{animation:none}}`;
  function mount() {
    if (S.root) return;
    if (!document.getElementById("fo-style")) {
      const st = document.createElement("style"); st.id = "fo-style"; st.textContent = CSS; document.head.appendChild(st);
      const ln = document.createElement("link"); ln.rel = "stylesheet"; ln.href = "https://fonts.googleapis.com/css2?family=Nunito:wght@600;700;800&display=swap"; document.head.appendChild(ln);
    }
    const r = document.createElement("div"); r.className = "fo-root"; r.setAttribute("role", "dialog"); r.setAttribute("aria-label", "La oficina");
    r.innerHTML = `<div class="fo-top"><h2>La oficina</h2><div><button type="button" class="fo-btn" data-k="box">Buzón</button><button type="button" class="fo-btn" data-k="help">?</button><button type="button" class="fo-btn" data-k="close">Cerrar</button></div></div>
      <div class="fo-stage"><canvas aria-label="Agentes trabajando en la oficina"></canvas><div class="fo-card" hidden></div><div class="fo-help" hidden></div></div>`;
    document.body.appendChild(r); S.root = r; S.cv = r.querySelector("canvas"); S.ctx = S.cv.getContext("2d");
    r.querySelector('[data-k="close"]').onclick = close;
    r.querySelector('[data-k="box"]').onclick = () => { S.sel = { type: "box" }; renderCard(); };
    r.querySelector('[data-k="help"]').onclick = () => { const hp = r.querySelector(".fo-help"); hp.hidden = !hp.hidden; if (!hp.hidden) hp.innerHTML = helpHTML(); };
    S.cv.addEventListener("click", e => {
      const b = S.cv.getBoundingClientRect(), x = (e.clientX - b.left - S.ox) / S.scale, y = (e.clientY - b.top - S.oy) / S.scale;
      S.sel = hit(x, y); renderCard();
    });
  }
  function helpHTML() {
    const sil = [["Claude", "boina", "#f2a35e"], ["GPT / Codex", "gafas", "#9cc4ee"], ["Hermes", "casco alado", "#aa9de8"], ["Strata", "capas", "#8fdcae"]];
    return `<b>Quién es quién</b><ul>${sil.map(([n, d, c]) => `<li><span class="fo-sw" style="background:${c}"></span>${n} · ${d}</li>`).join("")}</ul>
      <div style="margin-top:8px"><b>Cómo leerla</b></div><ul>
      <li>Mesas: solo para quien trabaja, por prioridad; las más cerca de la bóveda, para lo más importante. Los agentes se teletransportan a su mesa al empezar y se desmaterializan al parar (luego salen en la espera).</li>
      <li>Panel de cada mesa: color y símbolo de lo que usa (código, web, bóveda…), arriba el color del agente, a la derecha nube o PC, abajo el avance. Strata enseña su propio monitor (lee, escribe, disco y temperatura).</li>
      <li>El orbe recorre a quien trabaja, en orden y sin volver a empezar: ilumina, enfoca, persigue y alumbra desde arriba. Sin trabajo se queda flotando y, al rato, sobrevuela la bóveda. Al pasar sobre ella absorbe partículas de las notas y, cuando lleva de 7 a 12 satélites, se le sueltan sobre una conexión, entran y recorren el grafo hasta una nota que se haya tocado de verdad hace poco (por el camino más corto); sin actividad reciente, vagan y se apagan.</li>
      <li>Chispas: cambios reales de un agente; vuelan al orbe y lo alimentan con su color. Entrada: tus órdenes, la nube y los vigías del PC/Mac; debajo, quien espera (libres, hechos y sin señal).</li>
      <li>Proyectos: la altura de cada aguja son sus entregas reales de los últimos 7 días (misma escala para todos; baja si se para). Colores: cada aguja suma un segmento por cosa hecha (cian, entregas; violeta, artefactos; oro, orgullo, que cuenta doble). «En obra» si alguien trabaja en él. La tele de GTA VI es el monitor de su máquina: verde que late, trabajando; ámbar, en pausa; con cada aviso nuevo destella.</li>
      <li>Bóveda: el grafo de tus notas, vivo como en Obsidian. Al instante: azul, se lee; amarillo, se escribe; verde, nota nueva (nace junto a la que enlaza); rojo, borrada. Tócala para verla en grande con quién hace qué.</li></ul>`;
  }
  function onKey(e) { if (e.key === "Escape" && S.open) close(); }

  /* ───────── API ───────── */
  function open(D) {
    mount(); S.root.hidden = false; S.open = true; S.reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    S.L = null; S.D = D || {}; S.lastT = 0; S.nextSocial = now() + 8; S.nextDemoDelivery = now() + 6; spLoad(); pollMachines(); vgPoll();
    document.addEventListener("keydown", onKey);
    cancelAnimationFrame(S.raf); S.raf = requestAnimationFrame(frame);
  }
  function update(D) { if (!S.open) return; S.D = D || {}; if (S.L) sync(S.D); }
  function close() {
    if (!S.root) return; S.open = false; S.root.hidden = true; cancelAnimationFrame(S.raf); clearInterval(S.mTimer); clearInterval(VG.timer); document.removeEventListener("keydown", onKey);
    S.sel = null; if (window.FaroOfficeOnClose) window.FaroOfficeOnClose();
  }
  window.FaroOffice = { open, update, close, isOpen: () => S.open,
    _motes: n => { const cs = ["#66d9ce", "#ff6fb5", "#f2c078", "#7fd3a6", "#aa9de8"]; for (let i = 0; i < n; i++) orbMote(cs[i % 5], "dato"); return (S.orb.motes || []).length; },   // solo para pruebas
    _orb: () => { const O = S.orb || {}, E = S.eye || {}, a = [...VG.nodes.values()]; return { motes: (O.motes || []).length, drops: (O.drops || []).length, ms: S.ms, pf: S.pf, gravN: VG.gravN, grav: (VG.grav || []).length, chf: CHF.ok, gravAge: now() - (VG.gravT || 0), x: O.x, y: O.y, phase: E.phase, target: E.target, pull: VG.orbPull, fe: a.filter(s => (s.fe || 0) > .04).length, pj: a.filter(s => s.pj && isFinite(s.pj[0])).length }; },
    _vg: () => { const a = [...VG.nodes.values()]; return { cam: { wide: VG.cam.wide, zm: +(VG.cam.zm || 0).toFixed(2), p: VG.cam.p.map(v => +v.toFixed(2)) }, ring: a.filter(s => s.ring).length, n: a.length, nan: a.filter(s => !isFinite(s.x) || !isFinite(s.y)).length, out: a.filter(s => s.x < 0 || s.x > 1 || s.y < 0 || s.y > 1).length,
      dead: a.filter(s => s.dead).length, edges: VG.edges.length, gv: VG.gv, seq: VG.seq, mode: VG.mode, errs: S.errs || 0, lastErr: S.lastErr || null }; },
    _debug: () => ({ agents: [...S.ag.values()].map(a => ({ id: a.id, x: a.x, y: a.y, v: a.v || 0, zone: a.zone, st: a.st })), packets: S.packets.length, bonus: { ...S.bonus } }) };

  // Sin agentes ni encargos de demostración.
})();
