/* Faro · La oficina (estilo consola acogedora)
   API: window.FaroOffice = { open(D), update(D), close(), isOpen() }  ·  window.FaroOfficeSample */
(function () {
  "use strict";
  const iso = m => new Date(Date.now() - m * 60000).toISOString();
  const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const ease = k => k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;

  /* ───────── vocabulario ───────── */
  const BRANDS = {
    claude: { label: "Claude", c: "#f0a35e" }, gpt: { label: "GPT", c: "#8fc7ff" }, codex: { label: "Codex", c: "#8fc7ff" },
    hermes: { label: "Hermes", c: "#b9b4ff" }, local: { label: "Strata", c: "#39ff88" }, faro: { label: "Faro", c: "#e6ff5c" }
  };
  const ZONES = {
    obsidian: { label: "Obsidian", c: "#a78bfa", doing: "consulta la bóveda" },
    web: { label: "Web", c: "#60a5fa", doing: "busca en la web" },
    write: { label: "Escritura", c: "#f472b6", doing: "escribe" },
    mail: { label: "Correo", c: "#fb7185", doing: "prepara correos" },
    code: { label: "Código", c: "#34d399", doing: "programa" },
    edit: { label: "Edición", c: "#fb923c", doing: "edita" },
    skills: { label: "Skills", c: "#facc15", doing: "usa una skill" },
    system: { label: "Servidores", c: "#94a3b8", doing: "trabaja en el sistema" }
  };
  const SCRIPTS = {
    code: ["obsidian", "code", "web", "code", "skills"], writing: ["obsidian", "write", "write"], research: ["web", "obsidian", "write"],
    video: ["edit", "skills"], audio: ["edit"], thinking: ["obsidian", "write"], email: ["mail", "write"], system: ["system", "skills"],
    summary: ["obsidian", "write"], question: ["obsidian"]
  };
  const ACTION_ZONE = { codigo: "code", editar: "edit", pensar: "write", buscar: "web", obsidian: "obsidian", web: "web", code: "code", edit: "edit", write: "write", skills: "skills", mail: "mail", system: "system", think: "write", cards: "write" };
  function brandOf(s) { s = (s || "").toLowerCase(); if (/codex/.test(s)) return "codex"; if (/claude/.test(s)) return "claude"; if (/gpt|openai|chatgpt/.test(s)) return "gpt"; if (/hermes/.test(s)) return "hermes"; if (/strata|ollama|local|qwen/.test(s)) return "local"; if (/faro/.test(s)) return "faro"; return "hermes"; }
  function roleOf(t, brand) {
    t = (t || "").toLowerCase();
    if (/render|v[ií]deo|clip|reel|ffmpeg|montaje|davinci|premiere|blender|transcrib/.test(t)) return /transcrib|audio|voz/.test(t) ? "audio" : "video";
    if (/c[oó]digo|script|bug|\bprogram(a|ar)\b|repositorio|github|api|deploy|backtest|freqtrade|build/.test(t)) return "code";
    if (/correo|email|gmail|responde|contesta|\bdm/.test(t)) return "email";
    if (/instala|actualiza|configura|copia|mueve|backup|reinicia|carpeta|archivo|descarga/.test(t)) return "system";
    if (/resume|resumen|traduce|clasifica|corrige/.test(t)) return "summary";
    if (/busca|investiga|noticias|compara|precio|mercado/.test(t)) return "research";
    if (/escribe|redacta|propuesta|guion|texto|post|plan|estrategia|dise[ñn]a/.test(t)) return "writing";
    return brand === "faro" ? "question" : "thinking";
  }
  const fitText = (c, s, w) => { if (c.measureText(s).width <= w) return s; while (s.length > 2 && c.measureText(s + "…").width > w) s = s.slice(0, -1); return s + "…"; };
  const shortName = n => { n = String(n || ""); return n.length > 14 ? n.slice(0, 13) + "…" : n; };

  /* ───────── estado ───────── */
  const S = {
    open: false, D: null, root: null, cv: null, ctx: null, raf: 0, t0: performance.now(), lastT: 0,
    L: null, evq: [], nextEv: 0, scale: 1, ox: 0, oy: 0, bg: null, bgKey: "",
    ag: new Map(), deskOf: new Map(), packets: [], flashes: [], bonus: {}, seenDone: new Set(), lastSugg: null,
    nextDemoDelivery: 0, nextSocial: 0, mailFlash: 0, sel: null, bokeh: [], reduce: false, sprite: {}
  };

  /* ───────── layouts ───────── */
  function makeLayout(wide) {
    if (wide) {
      const W = 1400, H = 860, L = { W, H, wide: true, zones: {}, desks: [] };
      const lz = ["obsidian", "web", "write", "mail"], rz = ["code", "edit", "skills", "system"];
      lz.forEach((k, i) => L.zones[k] = { x: 20, y: 96 + i * 150, w: 160, h: 132 });
      rz.forEach((k, i) => L.zones[k] = { x: W - 180, y: 96 + i * 150, w: 160, h: 132 });
      L.tower = { x: W / 2 - 50, y: 96, w: 100, h: 560 };
      const cols = [[215, 425], [W - 215 - 190, W - 425 - 190 + 0]];
      for (let r = 0; r < 3; r++) for (const side of [0, 1]) for (let c = 0; c < 2; c++) {
        const x = side === 0 ? 215 + c * 210 : 785 + c * 210; L.desks.push({ x, y: 112 + r * 150, w: 190, h: 120 });
      }
      L.rest = { x: 215, y: 580, w: 400, h: 260 };
      L.proj = { x: 785, y: 580, w: 400, h: 260 };
      L.door = { x: W / 2 - 90, y: 672, w: 180, h: 168 };
      L.meter = { x: W / 2 - 210, y: 14, w: 420, h: 66 };
      return L;
    }
    const W = 620, H = 1240, L = { W, H, wide: false, zones: {}, desks: [] };
    const order = ["obsidian", "web", "write", "mail", "code", "edit", "skills", "system"];
    order.forEach((k, i) => L.zones[k] = { x: 10 + (i % 4) * 150, y: 92 + Math.floor(i / 4) * 118, w: 140, h: 108 });
    L.tower = { x: W / 2 - 34, y: 330, w: 68, h: 520 };
    for (let r = 0; r < 4; r++) for (const side of [0, 1]) L.desks.push({ x: side === 0 ? 10 : W - 10 - 256, y: 340 + r * 128, w: 256, h: 120 });
    L.rest = { x: 10, y: 864, w: 300, h: 230 };
    L.proj = { x: 318, y: 864, w: 292, h: 230 };
    L.door = { x: W / 2 - 150, y: 1104, w: 300, h: 126 };
    L.meter = { x: 30, y: 14, w: W - 60, h: 66 };
    return L;
  }
  function pickLayout(w, h) {
    const a = makeLayout(true), b = makeLayout(false);
    const sa = Math.min(w / a.W, h / a.H), sb = Math.min(w / b.W, h / b.H);
    return sb > sa * 1.1 ? b : a;
  }

  /* ───────── utilidades de dibujo ───────── */
  function rr(c, x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function hexA(hex, a) { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`; }
  function glowSprite(col) {
    if (S.sprite[col]) return S.sprite[col];
    const s = document.createElement("canvas"); s.width = s.height = 128; const c = s.getContext("2d");
    const g = c.createRadialGradient(64, 64, 0, 64, 64, 64); g.addColorStop(0, hexA(col, .9)); g.addColorStop(.35, hexA(col, .35)); g.addColorStop(1, hexA(col, 0));
    c.fillStyle = g; c.fillRect(0, 0, 128, 128); S.sprite[col] = s; return s;
  }
  function glow(c, x, y, r, col, a) { c.globalAlpha = a; c.drawImage(glowSprite(col), x - r, y - r, r * 2, r * 2); c.globalAlpha = 1; }
  function center(b) { return [b.x + b.w / 2, b.y + b.h / 2]; }

  /* ───────── iconos de zona ───────── */
  function icon(c, k, x, y, s, col) {
    c.save(); c.translate(x, y); c.scale(s, s); c.strokeStyle = col; c.fillStyle = col; c.lineWidth = 2.6; c.lineCap = "round"; c.lineJoin = "round";
    switch (k) {
      case "obsidian": for (let i = 0; i < 3; i++) { rr(c, -14 + i * 9, -14 + (i === 1 ? -3 : 0), 7, 28 - (i === 1 ? -3 : 0), 2); c.stroke(); } c.beginPath(); c.moveTo(-17, 16); c.lineTo(17, 16); c.stroke(); break;
      case "web": c.beginPath(); c.arc(0, 0, 15, 0, 7); c.stroke(); c.beginPath(); c.ellipse(0, 0, 6, 15, 0, 0, 7); c.stroke(); c.beginPath(); c.moveTo(-15, 0); c.lineTo(15, 0); c.stroke(); break;
      case "write": c.beginPath(); c.moveTo(-12, 14); c.lineTo(-14, 6); c.lineTo(8, -16); c.lineTo(14, -10); c.lineTo(-8, 12); c.closePath(); c.stroke(); break;
      case "mail": rr(c, -16, -11, 32, 22, 3); c.stroke(); c.beginPath(); c.moveTo(-16, -9); c.lineTo(0, 3); c.lineTo(16, -9); c.stroke(); break;
      case "code": c.beginPath(); c.moveTo(-8, -10); c.lineTo(-16, 0); c.lineTo(-8, 10); c.moveTo(8, -10); c.lineTo(16, 0); c.lineTo(8, 10); c.moveTo(3, -13); c.lineTo(-3, 13); c.stroke(); break;
      case "edit": rr(c, -16, -11, 32, 22, 3); c.stroke(); c.beginPath(); c.moveTo(-4, -6); c.lineTo(6, 0); c.lineTo(-4, 6); c.closePath(); c.fill(); break;
      case "skills": c.beginPath(); c.moveTo(-12, 12); c.lineTo(4, -4); c.stroke(); c.beginPath(); c.arc(8, -8, 7, Math.PI * .9, Math.PI * 2.6); c.stroke(); break;
      case "system": for (let i = 0; i < 3; i++) { rr(c, -13, -14 + i * 10, 26, 7, 2); c.stroke(); c.fillRect(6, -12 + i * 10, 3, 3); } break;
      case "queue": rr(c, -14, -9, 28, 18, 3); c.stroke(); c.beginPath(); c.moveTo(-4, -9); c.lineTo(-4, 9); c.stroke(); break;
      case "rest": rr(c, -12, -6, 20, 18, 4); c.stroke(); c.beginPath(); c.arc(10, 2, 5, -1.4, 1.4); c.stroke(); c.beginPath(); c.moveTo(-6, -10); c.quadraticCurveTo(-2, -15, -6, -20); c.moveTo(2, -10); c.quadraticCurveTo(6, -15, 2, -20); c.stroke(); break;
      case "work": rr(c, -15, -12, 30, 20, 3); c.stroke(); c.beginPath(); c.moveTo(-6, 14); c.lineTo(6, 14); c.moveTo(0, 8); c.lineTo(0, 14); c.stroke(); break;
      case "box": rr(c, -15, -8, 30, 20, 3); c.stroke(); c.beginPath(); c.moveTo(-8, -8); c.lineTo(-8, -14); c.lineTo(8, -14); c.lineTo(8, -8); c.stroke(); break;
      case "bulb": c.beginPath(); c.arc(0, -4, 9, Math.PI * .8, Math.PI * 2.2); c.stroke(); c.beginPath(); c.moveTo(-4, 6); c.lineTo(4, 6); c.moveTo(-3, 10); c.lineTo(3, 10); c.stroke(); break;
    }
    c.restore();
  }

  /* ───────── fondo estático (cacheado) ───────── */
  function buildBg() {
    const L = S.L, cv = document.createElement("canvas"); cv.width = L.W; cv.height = L.H; const c = cv.getContext("2d");
    const g = c.createLinearGradient(0, 0, 0, L.H); g.addColorStop(0, "#070b18"); g.addColorStop(1, "#111a33"); c.fillStyle = g; c.fillRect(0, 0, L.W, L.H);
    // suelo de la oficina: alfombra cálida
    const fl = { x: L.wide ? 200 : 4, y: L.wide ? 92 : 326, w: L.wide ? L.W - 400 : L.W - 8, h: L.wide ? 560 : 528 };
    const fg = c.createLinearGradient(0, fl.y, 0, fl.y + fl.h); fg.addColorStop(0, "#1a2340"); fg.addColorStop(1, "#151d36");
    c.fillStyle = fg; rr(c, fl.x, fl.y, fl.w, fl.h, 26); c.fill(); c.strokeStyle = "rgba(255,255,255,.05)"; c.lineWidth = 2; c.stroke();
    // halo cálido general
    glow(c, L.W / 2, fl.y + fl.h * .5, fl.w * .55, "#ffb86b", .08);
    // módulos de zona (apagados)
    for (const [k, z] of Object.entries(L.zones)) {
      const zc = ZONES[k].c; c.fillStyle = "rgba(255,255,255,.04)"; rr(c, z.x, z.y, z.w, z.h, 22); c.fill();
      c.strokeStyle = hexA(zc, .35); c.lineWidth = 2; c.stroke();
      icon(c, k, z.x + z.w / 2, z.y + z.h / 2 - 12, 1.25, hexA(zc, .55));
      c.fillStyle = "rgba(230,235,255,.75)"; c.font = `700 ${L.wide ? 19 : 17}px Nunito, system-ui, sans-serif`; c.textAlign = "center"; c.fillText(ZONES[k].label, z.x + z.w / 2, z.y + z.h - 14);
    }
    // sala de descanso
    const r = L.rest; c.fillStyle = "#1d2038"; rr(c, r.x, r.y, r.w, r.h, 24); c.fill(); c.strokeStyle = "rgba(255,184,107,.25)"; c.stroke();
    glow(c, r.x + r.w * .7, r.y + 40, 150, "#ffb86b", .12);
    // ventana con luna
    c.fillStyle = "#0b1230"; rr(c, r.x + r.w - 130, r.y + 22, 104, 74, 10); c.fill(); c.strokeStyle = "rgba(255,255,255,.12)"; c.stroke();
    c.fillStyle = "#f5f0d8"; c.beginPath(); c.arc(r.x + r.w - 58, r.y + 52, 13, 0, 7); c.fill(); c.fillStyle = "#0b1230"; c.beginPath(); c.arc(r.x + r.w - 52, r.y + 48, 12, 0, 7); c.fill();
    for (let i = 0; i < 6; i++) { c.fillStyle = "rgba(255,255,255,.6)"; c.fillRect(r.x + r.w - 122 + i * 17, r.y + 30 + (i * 13) % 50, 2, 2); }
    // alfombra redonda
    c.fillStyle = "#2a2547"; c.beginPath(); c.ellipse(r.x + r.w * .42, r.y + r.h * .68, r.w * .32, 34, 0, 0, 7); c.fill();
    // sofá
    const sw = SOFA_W(), sx = r.x + 34, sy = r.y + r.h - 110; c.fillStyle = "#3b4a8c"; rr(c, sx, sy, sw, 54, 16); c.fill(); c.fillStyle = "#4b5ba6"; rr(c, sx + 10, sy - 30, sw - 20, 40, 14); c.fill();
    c.fillStyle = "#33427d"; rr(c, sx - 10, sy - 16, 26, 70, 10); c.fill(); rr(c, sx + sw - 16, sy - 16, 26, 70, 10); c.fill();
    // mesa de café + taza
    const cx0 = CUP().x; c.fillStyle = "#5b3a26"; rr(c, cx0 - 30, r.y + r.h - 70, 60, 14, 5); c.fill(); c.fillRect(cx0 - 4, r.y + r.h - 56, 8, 26);
    c.fillStyle = "#e9e4d8"; rr(c, cx0 - 9, r.y + r.h - 86, 18, 16, 4); c.fill();
    // planta
    c.fillStyle = "#6b4630"; rr(c, r.x + 20, r.y + 36, 30, 30, 6); c.fill(); c.fillStyle = "#3fbf7f";
    for (let i = 0; i < 5; i++) { c.beginPath(); c.ellipse(r.x + 35 + Math.cos(i * 1.3) * 12, r.y + 24 - i * 3, 7, 16, i * .6 - 1.2, 0, 7); c.fill(); }
    // lámpara de pie
    if (L.wide) { c.fillStyle = "#c9a36b"; c.fillRect(r.x + r.w - 40, r.y + 120, 4, 110); c.beginPath(); c.moveTo(r.x + r.w - 56, r.y + 122); c.lineTo(r.x + r.w - 22, r.y + 122); c.lineTo(r.x + r.w - 30, r.y + 96); c.lineTo(r.x + r.w - 48, r.y + 96); c.closePath(); c.fill();
    glow(c, r.x + r.w - 38, r.y + 128, 80, "#ffcf8a", .25); }
    c.fillStyle = "rgba(255,215,170,.85)"; c.font = "700 18px Nunito, system-ui"; c.textAlign = "left"; c.fillText("Descanso", r.x + 18, r.y + r.h - 14);
    // buzón
    const bx = BOX(); c.fillStyle = "#8a4b3a"; rr(c, bx.x - 26, bx.y - 22, 52, 44, 8); c.fill(); c.fillStyle = "#1a0f0c"; rr(c, bx.x - 14, bx.y - 14, 28, 5, 2); c.fill();
    c.fillStyle = "#6b3a2d"; c.fillRect(bx.x - 3, bx.y + 22, 6, 34);
    c.fillStyle = "rgba(255,215,170,.85)"; c.font = "700 15px Nunito, system-ui"; c.textAlign = "center"; c.fillText("Buzón", bx.x, bx.y + 72);
    // zona proyectos
    const p = L.proj; c.fillStyle = "#121a35"; rr(c, p.x, p.y, p.w, p.h, 24); c.fill(); c.strokeStyle = "rgba(124,245,255,.2)"; c.stroke();
    const sky = c.createLinearGradient(0, p.y, 0, p.y + p.h); sky.addColorStop(0, "#162455"); sky.addColorStop(1, "#0c1430"); c.fillStyle = sky; rr(c, p.x + 8, p.y + 8, p.w - 16, p.h - 16, 18); c.fill();
    c.fillStyle = "rgba(255,255,255,.08)"; c.fillRect(p.x + 14, p.y + p.h - 44, p.w - 28, 3);
    c.fillStyle = "rgba(200,230,255,.85)"; c.font = "700 18px Nunito, system-ui"; c.textAlign = "left"; c.fillText("Proyectos", p.x + 20, p.y + 32);
    // puerta / cola
    const d = L.door; c.fillStyle = "#18203f"; rr(c, d.x, d.y, d.w, d.h, 22); c.fill(); c.strokeStyle = "rgba(230,255,92,.25)"; c.stroke();
    c.fillStyle = "#0b1028"; rr(c, d.x + d.w / 2 - 34, d.y + 18, 68, d.h - 30, 30); c.fill();
    c.fillStyle = "rgba(240,250,190,.8)"; c.font = "700 15px Nunito, system-ui"; c.textAlign = "center"; c.fillText("Entrada", d.x + d.w / 2, d.y + d.h - 8);
    // mesas (vacías)
    L.desks.forEach(dk => drawDeskBase(c, dk));
    S.bg = cv;
  }
  function BOX() { const r = S.L.rest; return S.L.wide ? { x: r.x + r.w - 70, y: r.y + r.h - 92 } : { x: r.x + r.w - 34, y: r.y + 150 }; }
  function SOFA_W() { return S.L.wide ? 210 : 160; }
  function CUP() { const r = S.L.rest; return { x: S.L.wide ? r.x + 290 : r.x + SOFA_W() + 64 }; }
  function drawDeskBase(c, dk) {
    const x = dk.x, y = dk.y;
    c.fillStyle = "rgba(0,0,0,.25)"; c.beginPath(); c.ellipse(x + dk.w / 2, y + dk.h - 8, dk.w * .45, 10, 0, 0, 7); c.fill();
    c.fillStyle = "#6b4a33"; rr(c, x + 10, y + dk.h - 48, dk.w - 20, 16, 6); c.fill(); c.fillStyle = "#57392a"; c.fillRect(x + 22, y + dk.h - 32, 8, 22); c.fillRect(x + dk.w - 30, y + dk.h - 32, 8, 22);
    // monitor apagado
    c.fillStyle = "#2a3150"; rr(c, x + dk.w / 2 - 38, y + dk.h - 104, 76, 50, 6); c.fill(); c.fillStyle = "#0d1226"; rr(c, x + dk.w / 2 - 33, y + dk.h - 99, 66, 40, 4); c.fill();
    c.fillStyle = "#2a3150"; c.fillRect(x + dk.w / 2 - 4, y + dk.h - 54, 8, 8);
    // lámpara
    c.strokeStyle = "#8b93b8"; c.lineWidth = 3; c.beginPath(); c.moveTo(x + dk.w - 34, y + dk.h - 48); c.lineTo(x + dk.w - 34, y + dk.h - 86); c.lineTo(x + dk.w - 22, y + dk.h - 98); c.stroke();
    c.fillStyle = "#8b93b8"; c.beginPath(); c.moveTo(x + dk.w - 30, y + dk.h - 104); c.lineTo(x + dk.w - 8, y + dk.h - 94); c.lineTo(x + dk.w - 18, y + dk.h - 88); c.closePath(); c.fill();
  }

  /* ───────── datos → agentes ───────── */
  function buildAgents(D) {
    const out = [], used = new Set(), nowT = Date.now(), counter = {};
    const exLabel = k => (D.executors && D.executors[k] && D.executors[k].label) || k;
    const named = (D.agents || []).map(a => ({ ...a, brand: a.brand || brandOf(a.name), busy: a.state === "run" }));
    (D.orders || []).forEach(o => {
      const b = brandOf(o.executor + " " + exLabel(o.executor));
      const age = o.finished ? (nowT - new Date(o.finished)) / 60000 : 1e9;
      if (o.state === "done" && age < 3 && !S.seenDone.has(o.id)) { S.seenDone.add(o.id); S.pendingDeliveries = (S.pendingDeliveries || []).concat([{ brand: b, project: o.project, title: o.title }]); }
      if (o.state !== "running" && o.state !== "queued") return;
      const host = o.state === "running" ? named.find(a => a.brand === b && a.busy && !used.has(a.name)) : null;
      counter[b] = (counter[b] || 0) + 1; if (host) used.add(host.name);
      out.push({ id: host ? "a:" + host.name : "o:" + o.id, name: host ? host.name : (BRANDS[b] || BRANDS.hermes).label + " " + counter[b], brand: b,
        role: o.role || roleOf(o.text, b), st: o.state === "running" ? "work" : "queue", label: o.title || o.text, project: o.project, reason: o.reason,
        action: host && host.action, example: o.example, cloud: !!(host && host.cloud), prio: o.priority });
    });
    (D.running || []).forEach(r => {
      if (used.has(r.agent)) return; used.add(r.agent); const b = brandOf(r.agent || r.name);
      out.push({ id: "r:" + r.id, name: r.agent || r.name, brand: b, role: r.role || roleOf(r.name + " " + (r.step || ""), b), st: "work", label: r.name, pct: r.pct, project: r.project, action: r.action, example: r.example, cloud: !!r.cloud });
    });
    named.forEach(a => {
      if (used.has(a.name) || a.state === "off" || a.state === "bad" || a.state === "warn") return;
      out.push({ id: "a:" + a.name, name: a.name, brand: a.brand, role: a.role || roleOf(a.task, a.brand), st: a.busy ? "work" : "rest", label: a.task, project: a.project || guessProject(a.task, D), action: a.action, example: a.example, cloud: !!a.cloud });
    });
    out.forEach(a => { if (!a.project) a.project = guessProject(a.label, D); });
    return out;
  }
  function guessProject(t, D) {
    t = (t || "").toLowerCase(); const ps = D.projects || [];
    for (const p of ps) if (t.includes(String(p.id).toLowerCase()) || t.includes(String(p.name).toLowerCase())) return p.id;
    if (/correo|productora|campaña|cliente|propuesta/.test(t)) return ps.find(p => p.id === "ingresos") ? "ingresos" : null;
    if (/juego|itch/.test(t)) return ps.find(p => p.id === "chf") ? "chf" : null;
    return null;
  }

  /* ───────── posiciones ───────── */
  function deskFor(id) {
    if (S.deskOf.has(id)) return S.deskOf.get(id);
    const taken = new Set(S.deskOf.values()); let i = 0; while (taken.has(i) && i < S.L.desks.length) i++;
    if (i >= S.L.desks.length) return null; S.deskOf.set(id, i); return i;
  }
  function seatPos(a) { const dk = a.desk == null ? null : S.L.desks[a.desk]; return dk ? [dk.x + 34, dk.y + dk.h - 44] : hostSpot(); }
  function restSpot(i) {
    const r = S.L.rest, sw = SOFA_W(), spots = [[r.x + 64, r.y + r.h - 96], [r.x + 34 + sw / 2, r.y + r.h - 96], [r.x + 4 + sw, r.y + r.h - 96], [r.x + sw + 40, r.y + r.h - 150], [r.x + 100, r.y + r.h - 170], [r.x + 160, r.y + r.h - 175], [r.x + 50, r.y + r.h - 160]];
    return spots[i % spots.length];
  }
  function queueSpot(i) { const d = S.L.door; return [d.x + 30 + (i % 4) * ((d.w - 60) / 3), d.y + d.h - 40]; }
  function hostSpot() { const d = S.L.door; return [d.x + d.w / 2, d.y + d.h - 34]; }

  function sync(D) {
    S.D = D; const list = buildAgents(D), seen = new Set(); let ri = 0, qi = 0; const t = now();
    list.forEach(a => {
      const cur = S.ag.get(a.id);
      const ag = cur || { ...a, x: 0, y: 0, tx: 0, ty: 0, ph: Math.random() * 6, zone: null, zi: 0, nextZone: 0, mode: "", bubble: null };
      Object.assign(ag, a);
      ag.desk = a.st === "queue" ? (S.deskOf.has(a.id) ? S.deskOf.get(a.id) : null) : a.st === "rest" ? (S.deskOf.has(a.id) ? S.deskOf.get(a.id) : null) : deskFor(a.id);
      if (ag.desk == null && a.st === "rest") ag.desk = deskFor(a.id);
      if (ag.desk == null && a.st === "work") ag.st = "queue";
      let target;
      if (a.st === "work") target = seatPos(ag);
      else if (a.st === "queue") target = queueSpot(qi++);
      else target = restSpot(ri++);
      if (!ag.task || ag.task.mode === "home") { ag.home = target; if (!cur) { const [hx, hy] = a.st === "queue" ? queueSpot(qi) : hostSpot(); ag.x = a.st === "work" ? target[0] : hx; ag.y = a.st === "work" ? target[1] : hy; } goTo(ag, target); }
      else ag.home = target;
      if (a.st === "work") { if (a.action && ACTION_ZONE[a.action]) { ag.zone = ACTION_ZONE[a.action]; ag.real = true; } else { ag.real = true; ag.zone = "system"; } }
      else ag.zone = null;
      S.ag.set(a.id, ag); seen.add(a.id);
    });
    for (const k of [...S.ag.keys()]) if (!seen.has(k)) { S.ag.delete(k); S.deskOf.delete(k); }
    // entregas reales
    (S.pendingDeliveries || []).forEach(dl => {
      const who = [...S.ag.values()].find(a => a.brand === dl.brand && a.st === "work") || [...S.ag.values()].find(a => a.brand === dl.brand);
      if (who && dl.project) sendPacket(who, dl.project, true);
    });
    S.pendingDeliveries = [];
    // buzón: el número baja al instante (descartes, respuestas); sube cuando el agente llega con la carta
    const open = (D.suggestions || []).filter(s => s.state === "open").length;
    if (S.boxShown == null || open < S.boxShown) S.boxShown = open;
    S.lastSugg = open;
    // mensajes reales → escenas
    const chat = D.chat || []; S.seenMsg = S.seenMsg || new Set();
    if (!S.chatPrimed) { S.chatPrimed = true; const recent = Date.now() - 2 * 60000;
      chat.forEach(m => { if (new Date(m.at) < recent) S.seenMsg.add(m.id); }); S.boxShown = Math.max(0, open - chat.filter(m => m.kind === "buzon" && !S.seenMsg.has(m.id)).length); }
    chat.forEach(m => { if (!S.seenMsg.has(m.id)) { S.seenMsg.add(m.id); S.evq.push(m); } });
    if (S.boxShown < open && !S.evq.some(m => m.kind === "buzon") && ![...S.ag.values()].some(a => a.task && a.task.mode === "post")) S.boxShown = open;
    renderCard();
  }
  function goTo(ag, p) { ag.tx = p[0]; ag.ty = p[1]; }
  function now() { return (performance.now() - S.t0) / 1000; }

  /* ───────── acciones visibles ───────── */
  function projectBuildings() {
    const D = S.D || {}, ps = (D.projects || []).slice(0, 5), p = S.L.proj, n = Math.max(1, ps.length), bw = Math.min(64, (p.w - 40) / n - 14);
    return ps.map((pr, i) => {
      const done = (D.orders || []).filter(o => o.project === pr.id && o.state === "done").length;
      const arts = (D.artifacts || []).filter(a => a.project === pr.id).length, proud = (D.proud || []).filter(a => a.project === pr.id).length;
      const saved = ((D.build || {})[pr.id] || {}).floors || 0;  // la obra guardada en el servidor
      const floors = clamp(Math.max(saved, 1 + done + arts + 2 * proud) + (S.bonus[pr.id] || 0), 1, 12);
      const active = [...S.ag.values()].some(a => a.st === "work" && a.project === pr.id);
      const x = p.x + 24 + i * ((p.w - 48) / n) + ((p.w - 48) / n - bw) / 2;
      return { id: pr.id, name: pr.name || pr.id, floors, active, x, w: bw, base: p.y + p.h - 44, done, arts, proud };
    });
  }
  function buildingTop(id) { const b = projectBuildings().find(b => b.id === id); if (!b) return null; const fh = Math.min(15, (S.L.proj.h - 110) / 12); return [b.x + b.w / 2, b.base - b.floors * fh]; }
  function sendPacket(ag, project, real) {
    const to = buildingTop(project); if (!to) return;
    const from = [ag.x, ag.y - 40];
    S.packets.push({ from, to, t: 0, dur: 3.6, col: ZONES[ag.zone || "write"] ? ZONES[ag.zone || "write"].c : "#e6ff5c", project, real });
    ag.bubble = { text: "entrega", until: now() + 2.5 };
  }
  const short = (t, n) => { t = String(t || "").replace(/\s+/g, " ").trim(); return t.length > n ? t.slice(0, n - 1) + "…" : t; };
  const isNawe = n => /^(nawe|nahuel|t[uú]|yo)$/i.test(String(n || "").trim());
  function agentFor(name, preferRest) {
    const all = [...S.ag.values()]; if (!name || isNawe(name)) return null;
    const exact = all.find(a => a.name === name); if (exact) return exact;
    const b = brandOf(name), same = all.filter(a => a.brand === b);
    return (preferRest && same.find(a => a.st === "rest" && !a.task)) || same.find(a => !a.task) || same[0] || null;
  }
  // Reproduce, uno a uno, los mensajes reales del sistema (D.chat). Nada inventado: si no hay mensajes, no hay escenas.
  function socialTick(t) {
    if (t < S.nextEv || !S.evq.length) return;
    const m = S.evq.shift(); S.nextEv = t + 5;
    const fromA = agentFor(m.from, true), toA = agentFor(m.to, true), bx = BOX();
    const free = a => a && a.st !== "work" && !a.task && !a.walking;   // quien trabaja no se levanta de su mesa
    if (m.kind === "buzon" && free(fromA)) {             // un agente deja una sugerencia en el buzón
      fromA.task = { mode: "post", stage: 0 }; fromA.bulb = true; fromA.say = { text: short(m.text, 34), until: t + 9 }; goTo(fromA, [bx.x - 34, bx.y + 18]); return;
    }
    if (m.kind === "buzon") { S.boxShown = Math.min((S.boxShown || 0) + 1, S.lastSugg || 0); S.mailFlash = t; if (fromA) fromA.say = { text: short(m.text, 34), until: t + 7 }; return; }
    if (m.kind === "orden") return;                // una orden no pasa por el buzón: el agente aparece en cola y luego en su mesa
    if (isNawe(m.from) && (m.kind === "respuesta" || m.kind === "encargo") && free(toA)) {                    // Nawe contesta o encarga: el agente recoge la carta
      toA.task = { mode: "fetch", stage: 0 }; toA.say = { text: "Nawe: " + short(m.text, 30), until: t + 10 }; goTo(toA, [bx.x - 34, bx.y + 18]); return;
    }
    if (free(fromA) && free(toA) && fromA !== toA) {   // conversación real entre dos agentes
      const r = S.L.rest, cx = r.x + r.w * .45, cy = r.y + r.h * .62;
      fromA.task = { mode: "chat", until: t + 10 }; toA.task = { mode: "chat", until: t + 10 }; fromA.chatWith = toA; toA.chatWith = fromA;
      goTo(fromA, [cx - 26, cy]); goTo(toA, [cx + 26, cy]); fromA.say = { text: short(m.text, 34), until: t + 10 }; return;
    }
    const sp = fromA || (isNawe(m.from) ? toA : null);
    if (sp) sp.say = { text: (isNawe(m.from) ? "Nawe: " : "") + short(m.text, 34), until: t + 7 };   // entrega, fallo, o mensaje con alguien ocupado
  }

  /* ───────── simulación ───────── */
  function stepAgents(dt, t) {
    S.ag.forEach(a => {
      if (false && a.st === "work" && !a.real && t > a.nextZone) {  // sin rotación inventada: sin «action» real, el agente se queda en la zona que encaja con su tarea
        const sc = SCRIPTS[a.role] || SCRIPTS.thinking; a.zi = (a.zi + 1) % sc.length; a.zone = sc[a.zi]; a.nextZone = t + 6 + Math.random() * 4;
        a.bubble = { text: ZONES[a.zone].doing, until: t + 2.4 };
      }
      if (a.task) {
        if (a.task.mode === "chat" && t > a.task.until) { a.task = null; a.chatWith = null; goTo(a, a.home); }
        if (a.task && (a.task.mode === "post" || a.task.mode === "fetch") && dist(a) < 2) {
          if (a.task.stage === 0) { a.task.stage = 1; a.task.until = t + 1.8; S.mailFlash = t; if (a.task.mode === "post") S.boxShown = Math.min((S.boxShown || 0) + 1, S.lastSugg || 0); }
          else if (t > a.task.until) { a.task = null; a.bulb = false; goTo(a, a.home); }
        }
      }
      // movimiento lento con aceleración suave
      const dx = a.tx - a.x, dy = a.ty - a.y, d = Math.hypot(dx, dy);
      if (S.reduce) { a.x = a.tx; a.y = a.ty; a.v = 0; return; }
      if (d > .5) { a.v = Math.min((a.v || 0) + 60 * dt, 52, d * 2.2 + 6); a.x += dx / d * a.v * dt; a.y += dy / d * a.v * dt; a.walking = true; }
      else { a.v = 0; a.walking = false; }
    });
    S.packets = S.packets.filter(p => {
      p.t += dt / p.dur; if (p.t >= 1) { if (p.project) { if (!p.real) S.bonus[p.project] = Math.min((S.bonus[p.project] || 0) + 1, 6); S.flashes.push({ project: p.project, t: 0 }); } return false; } return true;
    });
    S.flashes = S.flashes.filter(f => (f.t += dt) < 1.6);
  }
  const dist = a => Math.hypot(a.tx - a.x, a.ty - a.y);

  /* ───────── dibujo dinámico ───────── */
  function drawBokeh(c, t) {
    if (!S.bokeh.length) for (let i = 0; i < 26; i++) S.bokeh.push({ x: Math.random() * S.L.W, y: Math.random() * S.L.H, r: 20 + Math.random() * 60, v: 4 + Math.random() * 10, c: ["#3b82f6", "#a78bfa", "#22d3ee", "#f472b6"][i % 4], a: .05 + Math.random() * .07 });
    S.bokeh.forEach(b => { if (!S.reduce) { b.y -= b.v / 60; if (b.y < -b.r) b.y = S.L.H + b.r; } glow(c, b.x + Math.sin(t * .2 + b.r) * 10, b.y, b.r, b.c, b.a); });
  }
  function drawTower(c, t, working) {
    const T = S.L.tower, cx = T.x + T.w / 2;
    const g = c.createLinearGradient(T.x, 0, T.x + T.w, 0); g.addColorStop(0, "#2a3560"); g.addColorStop(.5, "#5a6aa8"); g.addColorStop(1, "#2a3560");
    c.fillStyle = g; rr(c, T.x, T.y + 40, T.w, T.h - 40, 30); c.fill();
    // franjas
    for (let i = 0; i < 4; i++) { c.fillStyle = "rgba(255,255,255,.07)"; c.fillRect(T.x, T.y + 120 + i * (T.h - 160) / 4, T.w, 18); }
    // ventana de energía
    const iw = T.w * .44; c.fillStyle = "#081030"; rr(c, cx - iw / 2, T.y + 70, iw, T.h - 110, 16); c.fill();
    const inten = .35 + Math.min(1, working / 5) * .65;
    glow(c, cx, T.y + T.h * .5, T.h * .35, "#7cf5ff", .18 * inten);
    const n = 8 + Math.round(working * 6);
    for (let i = 0; i < n; i++) {
      const k = ((t * (.12 + inten * .08)) + i / n) % 1, py = T.y + T.h - 50 - k * (T.h - 130), px = cx + Math.sin(i * 2.3 + t * 1.2) * iw * .28;
      const col = ["#7cf5ff", "#a78bfa", "#e6ff5c", "#34d399"][i % 4]; glow(c, px, py, 9, col, (1 - k) * .9 * inten); c.fillStyle = "#fff"; c.globalAlpha = (1 - k) * inten; c.fillRect(px - 1.2, py - 1.2, 2.4, 2.4); c.globalAlpha = 1;
    }
    // linterna y haz
    const capW = S.L.wide ? T.w * .84 : 120; c.fillStyle = "#3b4a8c"; rr(c, cx - capW / 2, T.y - (S.L.wide ? 0 : 14), capW, S.L.wide ? 56 : 72, 18); c.fill();
    drawEye(c, cx, T.y + (S.L.wide ? 28 : 22), t);
  }
  /* El ojo del faro: vigila a quien trabaja. Se queda más y estrecha el haz cuanto menos le falta a la tarea;
     salta a quien empieza algo nuevo; sin trabajo, se apaga y parpadea de vez en cuando. */
  function drawEye(c, ex, ey, t) {
    const E = S.eye || (S.eye = { ang: Math.PI / 2, w: .35, target: null, until: 0, seen: new Set(), open: 0 });
    const workers = [...S.ag.values()].filter(a => a.st === "work" && a.desk != null && S.L.desks[a.desk]);
    const fresh = workers.find(a => !E.seen.has(a.id)); workers.forEach(a => E.seen.add(a.id));
    const pct = a => a.pct != null ? a.pct : 0;
    if (fresh) { E.target = fresh.id; E.until = t + 5; E.fresh = t; }
    else if (!workers.some(a => a.id === E.target) || t > E.until) {
      if (workers.length) {
        let tot = 0; const ws = workers.map(a => { const w = 1 + pct(a) / 100 * 3; tot += w; return w; });
        let r = Math.random() * tot, k = 0; while ((r -= ws[k]) > 0 && k < ws.length - 1) k++;
        const a = workers[k]; E.target = a.id; E.until = t + 3 + pct(a) / 100 * 7;
      } else E.target = null;
    }
    const tgt = E.target && S.ag.get(E.target);
    E.open += ((tgt ? 1 : 0) - E.open) * .05;
    const blink = !tgt && (t % 9) < .35;
    // ojo: llama y pupila rasgada; la rendija se cierra cuanto más se concentra
    const focus = tgt ? pct(tgt) / 100 : 0, fire = .55 + .45 * Math.sin(t * 3) * .3 + E.open * .4;
    const K = S.L.wide ? 1 : 1.9; // en vertical la torre es estrecha y la escala pequeña: el ojo crece para seguir siendo un ojo
    glow(c, ex, ey, (60 + 40 * E.open) * K, "#ff8a2a", .35 + .4 * E.open + (blink ? .5 : 0));
    c.save(); c.translate(ex, ey); c.scale(K, K);
    // corona de llamas
    for (let i = 0; i < 9; i++) { const a0 = i / 9 * Math.PI * 2, fl = 1 + (S.reduce ? 0 : .25 * Math.sin(t * 6 + i * 1.7)), r1 = 13, r2 = (19 + 3 * E.open) * fl;
      c.fillStyle = i % 2 ? "rgba(255,90,0,.75)" : "rgba(255,170,40,.65)"; c.beginPath();
      c.moveTo(Math.cos(a0 - .3) * r1, Math.sin(a0 - .3) * r1 * .7); c.quadraticCurveTo(Math.cos(a0) * r2 * .8, Math.sin(a0) * r2 * .62, Math.cos(a0) * r2, Math.sin(a0) * r2 * .72);
      c.quadraticCurveTo(Math.cos(a0) * r2 * .8, Math.sin(a0) * r2 * .62, Math.cos(a0 + .3) * r1, Math.sin(a0 + .3) * r1 * .7); c.fill(); }
    c.fillStyle = "#ffb347"; c.beginPath(); c.ellipse(0, 0, 15, 9 + 3 * E.open, 0, 0, 7); c.fill();
    c.fillStyle = "#ff6a00"; c.beginPath(); c.ellipse(0, 0, 10, 7, 0, 0, 7); c.fill();
    c.fillStyle = "#1a0700"; c.beginPath(); c.ellipse(0, 0, Math.max(1, 3.4 - focus * 2.4), 8, 0, 0, 7); c.fill();
    c.restore();
    if (!tgt) return;
    const dk = S.L.desks[tgt.desk], tx = dk.x + dk.w / 2, ty = dk.y + dk.h - 60, want = Math.atan2(ty - ey, tx - ex);
    let d = want - E.ang; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
    if (S.reduce) { E.ang = want; d = 0; E.open = 1; } else E.ang += d * .04; const moving = Math.min(1, Math.abs(d) * 2);
    const half = (.05 + .22 * (1 - focus)) + .18 * moving + (E.fresh && t - E.fresh < 1.2 ? .15 : 0);
    const len = Math.hypot(tx - ex, ty - ey) + 50;
    c.save(); c.translate(ex, ey); c.rotate(E.ang);
    const g = c.createLinearGradient(0, 0, len, 0); g.addColorStop(0, "rgba(255,170,60," + (.45 * E.open) + ")"); g.addColorStop(1, "rgba(255,120,30,0)");
    c.fillStyle = g; c.beginPath(); c.moveTo(0, 0); c.lineTo(len, -Math.tan(half) * len); c.lineTo(len, Math.tan(half) * len); c.closePath(); c.fill();
    c.restore();
    if (moving < .2) glow(c, tx, ty, 60 - focus * 25, "#ffa040", .25 + .25 * focus);
  }
  function drawZonesLit(c, t, usage) {
    for (const [k, z] of Object.entries(S.L.zones)) {
      const n = usage[k] || 0; if (!n) continue; const col = ZONES[k].c, pulse = .65 + .35 * Math.sin(t * 2.4);
      glow(c, z.x + z.w / 2, z.y + z.h / 2, z.w * .85, col, .35 * pulse);
      c.strokeStyle = col; c.lineWidth = 3; rr(c, z.x, z.y, z.w, z.h, 22); c.stroke();
      icon(c, k, z.x + z.w / 2, z.y + z.h / 2 - 12, 1.25, "#ffffff");
      c.fillStyle = col; c.beginPath(); c.arc(z.x + z.w - 22, z.y + 22, 13, 0, 7); c.fill();
      c.fillStyle = "#0b1028"; c.font = "800 15px Nunito, system-ui"; c.textAlign = "center"; c.fillText(n, z.x + z.w - 22, z.y + 27);
    }
  }
  function drawThreads(c, t) {
    S.ag.forEach(a => {
      if (a.st !== "work" || !a.zone || a.walking || a.desk == null) return; const z = S.L.zones[a.zone], col = ZONES[a.zone].c;
      const [zx, zy] = center(z), dk = S.L.desks[a.desk], sx = dk.x + dk.w / 2, sy = dk.y + dk.h - 104;
      const mx = (sx + zx) / 2, my = Math.min(sy, zy) - 60;
      c.strokeStyle = hexA(col, .28); c.lineWidth = 2.5; c.beginPath(); c.moveTo(sx, sy); c.quadraticCurveTo(mx, my, zx, zy); c.stroke();
      if (!S.reduce) for (let i = 0; i < 3; i++) {
        const k = (t * .35 + i / 3 + a.ph) % 1, x = (1 - k) * (1 - k) * sx + 2 * (1 - k) * k * mx + k * k * zx, y = (1 - k) * (1 - k) * sy + 2 * (1 - k) * k * my + k * k * zy;
        glow(c, x, y, 10, col, .8); c.fillStyle = "#fff"; c.fillRect(x - 1.5, y - 1.5, 3, 3);
      }
    });
  }
  function drawDeskLights(c, t) {
    S.ag.forEach(a => {
      const dk = a.desk == null ? null : S.L.desks[a.desk]; if (!dk) return; const lit = a.st === "work" && a.zone && !a.walking, col = lit ? ZONES[a.zone].c : null;
      const mx = dk.x + dk.w / 2, my = dk.y + dk.h - 79;
      if (lit) {
        glow(c, dk.x + dk.w - 18, dk.y + dk.h - 70, 70, col, .5);
        c.fillStyle = hexA(col, .9); rr(c, mx - 33, my - 20, 66, 40, 4); c.fill();
        c.fillStyle = "rgba(255,255,255,.65)"; for (let i = 0; i < 3; i++) c.fillRect(mx - 26, my - 12 + i * 9, 20 + ((Math.sin(t * 3 + i + a.ph) + 1) * 14), 3);
        c.fillStyle = col; c.beginPath(); c.moveTo(dk.x + dk.w - 30, dk.y + dk.h - 104); c.lineTo(dk.x + dk.w - 8, dk.y + dk.h - 94); c.lineTo(dk.x + dk.w - 18, dk.y + dk.h - 88); c.closePath(); c.fill();
      }
      // nombre bajo la mesa
      c.fillStyle = lit ? "#ffffff" : "rgba(200,210,240,.6)"; c.font = `700 ${S.L.wide ? 15 : 20}px Nunito, system-ui`; c.textAlign = "center";
      c.fillText(fitText(c, String(a.name || ""), dk.w - (a.cloud ? 56 : 12)), dk.x + dk.w / 2 + (a.cloud ? 18 : 0), dk.y + dk.h + (S.L.wide ? 12 : 14));
      if (a.cloud) { // nube sobre la mesa: este agente trabaja en la nube, no en tu PC
        const cx = dk.x + 22, cy = (S.L.wide ? dk.y + dk.h - 112 : dk.y + dk.h + 6) + Math.sin(t * 1.2 + a.ph) * 2;
        c.fillStyle = lit ? "#e6f1ff" : "rgba(220,232,255,.75)";
        c.beginPath(); c.arc(cx - 9, cy + 2, 7, 0, 7); c.arc(cx, cy - 3, 9, 0, 7); c.arc(cx + 10, cy + 2, 7, 0, 7); c.fill();
        c.fillRect(cx - 9, cy + 2, 19, 7);
      }
      if (a.example) { c.fillStyle = "rgba(192,132,252,.7)"; c.font = "600 11px Nunito, system-ui"; c.fillText("ejemplo", dk.x + dk.w / 2, dk.y + dk.h + 25); }
    });
  }
  function drawAgent(c, a, t) {
    const B = BRANDS[a.brand] || BRANDS.hermes, seated = a.st === "work" && !a.walking && Math.hypot(a.x - seatPos(a)[0], a.y - seatPos(a)[1]) < 3;
    const bob = a.walking ? Math.abs(Math.sin(t * 7 + a.ph)) * 3 : Math.sin(t * 1.6 + a.ph) * 1.2, x = a.x, y = a.y - bob;
    c.fillStyle = "rgba(0,0,0,.28)"; c.beginPath(); c.ellipse(x, a.y + 26, 18, 5, 0, 0, 7); c.fill();
    if (S.sel === a.id) { c.strokeStyle = "#ffffff"; c.lineWidth = 2.5; c.beginPath(); c.ellipse(x, a.y + 26, 26, 8, 0, 0, 7); c.stroke(); }
    // piernas
    if (!seated) { const sw = a.walking ? Math.sin(t * 7 + a.ph) * 6 : 0; c.strokeStyle = "#2a3150"; c.lineWidth = 6; c.lineCap = "round"; c.beginPath(); c.moveTo(x - 6, y + 8); c.lineTo(x - 6 + sw, y + 24); c.moveTo(x + 6, y + 8); c.lineTo(x + 6 - sw, y + 24); c.stroke(); }
    // cuerpo
    c.fillStyle = B.c; rr(c, x - 15, y - 16, 30, 30, 11); c.fill(); c.fillStyle = "rgba(255,255,255,.18)"; rr(c, x - 11, y - 13, 10, 22, 5); c.fill();
    // brazos
    c.strokeStyle = B.c; c.lineWidth = 6; c.lineCap = "round"; const k = seated ? Math.sin(t * 9 + a.ph) * 2 : 0;
    c.beginPath(); c.moveTo(x - 14, y - 6); c.lineTo(x - 20, y + 6 + k); c.moveTo(x + 14, y - 6); c.lineTo(x + 20, y + 6 - k); c.stroke();
    // cabeza
    const hy = y - 32; c.fillStyle = "#f6dcc3";
    if (a.brand === "gpt" || a.brand === "codex") { rr(c, x - 15, hy - 15, 30, 30, 8); c.fill(); }
    else if (a.brand === "local") { for (let i = 0; i < 3; i++) { c.fillStyle = ["#f6dcc3", "#e9c9ad", "#dcb798"][i]; rr(c, x - 15 + i * 1.5, hy - 15 + i * 10, 30 - i * 3, 10, 4); c.fill(); } }
    else { c.beginPath(); c.arc(x, hy, 15, 0, 7); c.fill(); }
    // ojos
    const blink = Math.sin(t * 1.1 + a.ph * 3) > .985, ey = hy - 1;
    c.fillStyle = "#1b2140"; if (a.st === "rest" && !a.task) { c.fillRect(x - 7, ey, 5, 2); c.fillRect(x + 2, ey, 5, 2); } else { c.fillRect(x - 6, ey - 2, 3, blink ? 1 : 5); c.fillRect(x + 3, ey - 2, 3, blink ? 1 : 5); }
    // rasgos de silueta
    c.fillStyle = B.c; c.strokeStyle = "#1b2140"; c.lineWidth = 2;
    switch (a.brand) {
      case "claude": c.save(); c.translate(x + 3, hy - 13); c.rotate(-.25); c.beginPath(); c.ellipse(0, 0, 17, 6, 0, 0, 7); c.fill(); c.fillRect(-1, -9, 3, 5); c.restore(); break;
      case "gpt": case "codex": c.beginPath(); c.arc(x - 5, ey + 1, 5, 0, 7); c.arc(x + 5, ey + 1, 5, 0, 7); c.stroke(); c.beginPath(); c.moveTo(x - 1, ey + 1); c.lineTo(x + 1, ey + 1); c.stroke();
        if (a.brand === "codex") { c.fillStyle = "#8fc7ff"; c.fillRect(x - 15, hy - 12, 30, 5); } break;
      case "hermes": c.beginPath(); c.arc(x, hy - 2, 16, Math.PI, 0); c.fill(); for (const s of [-1, 1]) { c.beginPath(); c.moveTo(x + s * 15, hy - 6); c.quadraticCurveTo(x + s * 30, hy - 18, x + s * 26, hy - 2); c.closePath(); c.fillStyle = "#ffffff"; c.fill(); } break;
      case "faro": for (let i = 0; i < 3; i++) { c.fillStyle = i % 2 ? "#ffffff" : "#ff5a5f"; c.fillRect(x - 10 + i * 1.5, hy - 20 - i * 7, 20 - i * 3, 7); } glow(c, x, hy - 44, 22, "#e6ff5c", .8); c.fillStyle = "#e6ff5c"; c.beginPath(); c.arc(x, hy - 42, 5, 0, 7); c.fill(); break;
    }
    // extras de estado
    if (a.st === "queue") { c.fillStyle = "#ffffff"; rr(c, x + 16, y - 50, 26, 18, 4); c.fill(); icon(c, "queue", x + 29, y - 41, .55, "#1b2140"); }
    if (a.bulb) { glow(c, x, hy - 32, 30, "#facc15", .9); icon(c, "bulb", x, hy - 30, .9, "#fff7c2"); }
    if (a.task && a.task.mode === "chat" && a.chatWith && a.x < a.chatWith.x && dist(a) < 2) {
      const sp = a.say && now() < a.say.until ? a : a.chatWith, txt = sp.say && now() < sp.say.until ? sp.say.text : "";
      if (txt) { c.font = "700 15px Nunito, system-ui"; const w = Math.min(c.measureText(txt).width + 24, 300), bx = (a.x + a.chatWith.x) / 2, by = Math.min(a.y, a.chatWith.y) - 80;
        c.fillStyle = "#ffffff"; rr(c, bx - w / 2, by - 16, w, 30, 12); c.fill(); c.beginPath(); c.moveTo(sp.x - 6, by + 13); c.lineTo(sp.x + 6, by + 13); c.lineTo(sp.x, by + 24); c.fill();
        c.fillStyle = "#1b2140"; c.textAlign = "center"; c.fillText(fitText(c, txt, w - 20), bx, by + 4); }
    }
    const said = a.say && now() < a.say.until && !(a.task && a.task.mode === "chat");
    if (said || (a.bubble && now() < a.bubble.until && !(a.task && a.task.mode === "chat"))) {
      const txt = said ? a.say.text : a.bubble.text; c.font = "700 15px Nunito, system-ui"; const w = c.measureText(txt).width + 22, bx = x, by = hy - 40;
      const col = a.zone && ZONES[a.zone] ? ZONES[a.zone].c : "#ffffff"; c.fillStyle = "rgba(11,16,40,.92)"; rr(c, bx - w / 2, by - 16, w, 28, 12); c.fill(); c.strokeStyle = col; c.lineWidth = 2; c.stroke();
      c.fillStyle = "#ffffff"; c.textAlign = "center"; c.fillText(txt, bx, by + 3);
    }
    if (a.st === "rest" && !a.task && !a.walking && !S.reduce) { const kz = (t * .4 + a.ph) % 1; c.globalAlpha = 1 - kz; c.fillStyle = "#c7d2fe"; c.font = "800 14px Nunito"; c.textAlign = "center"; c.fillText("z", x + 16 + kz * 8, hy - 18 - kz * 16); c.globalAlpha = 1; }
  }
  function drawProjects(c, t) {
    const bs = projectBuildings(), fh = Math.min(15, (S.L.proj.h - 110) / 12);
    bs.forEach((b, i) => {
      const top = b.base - b.floors * fh, fl = S.flashes.find(f => f.project === b.id);
      for (let f = 0; f < b.floors; f++) {
        const y = b.base - (f + 1) * fh, lit = f === b.floors - 1 && fl;
        c.fillStyle = f % 2 ? "#2b3a78" : "#33448a"; rr(c, b.x, y + 1, b.w, fh - 2, 3); c.fill();
        for (let wi = 0; wi < 3; wi++) { const on = ((f * 7 + wi * 3 + i) % 5) > 1; c.fillStyle = on ? "rgba(255,214,140,.85)" : "rgba(255,255,255,.08)"; c.fillRect(b.x + 6 + wi * ((b.w - 12) / 3), y + 4, (b.w - 12) / 3 - 4, fh - 9); }
        if (lit) glow(c, b.x + b.w / 2, y + fh / 2, b.w, "#e6ff5c", 1 - fl.t / 1.6);
      }
      if (b.active) {
        c.strokeStyle = "rgba(250,204,21,.8)"; c.lineWidth = 2; for (let s = 0; s < 3; s++) { c.beginPath(); c.moveTo(b.x - 4, top - s * 10); c.lineTo(b.x + b.w + 4, top - s * 10); c.stroke(); }
        c.beginPath(); c.moveTo(b.x + b.w + 6, b.base); c.lineTo(b.x + b.w + 6, top - 44); c.lineTo(b.x - 10, top - 44); c.stroke();
        const sw = S.reduce ? 0 : Math.sin(t * .8 + i) * 8; c.beginPath(); c.moveTo(b.x + 6 + sw, top - 44); c.lineTo(b.x + 6 + sw, top - 24); c.stroke(); c.fillStyle = "#facc15"; c.fillRect(b.x + 1 + sw, top - 24, 10, 8);
      }
      c.fillStyle = "rgba(220,230,255,.9)"; c.font = `700 ${S.L.wide ? 14 : 13}px Nunito, system-ui`; c.textAlign = "center"; c.fillText(fitText(c, String(b.name), b.w + 14), b.x + b.w / 2, b.base + 22);
    });
    S.packets.forEach(p => {
      const k = ease(p.t), x = p.from[0] + (p.to[0] - p.from[0]) * k, y = p.from[1] + (p.to[1] - p.from[1]) * k - Math.sin(k * Math.PI) * 160;
      glow(c, x, y, 26, p.col, .9); c.fillStyle = "#ffffff"; rr(c, x - 7, y - 7, 14, 14, 3); c.fill();
      for (let i = 1; i < 6; i++) { const kk = ease(Math.max(0, p.t - i * .03)), tx = p.from[0] + (p.to[0] - p.from[0]) * kk, ty = p.from[1] + (p.to[1] - p.from[1]) * kk - Math.sin(kk * Math.PI) * 160; glow(c, tx, ty, 12 - i, p.col, .5 - i * .08); }
    });
  }
  function drawMailbox(c, t) {
    const bx = BOX(), D = S.D || {}, n = S.boxShown == null ? (D.suggestions || []).filter(s => s.state === "open").length : S.boxShown;
    const fl = Math.max(0, 1 - (t - S.mailFlash) / 1.6);
    if (fl > 0) glow(c, bx.x, bx.y, 60, "#facc15", fl);
    for (let i = 0; i < Math.min(n, 4); i++) { c.fillStyle = "#fff7e0"; c.save(); c.translate(bx.x - 8 + i * 5, bx.y - 16); c.rotate(-.2 + i * .12); c.fillRect(-5, -9, 12, 10); c.restore(); }
    c.fillStyle = "#facc15"; c.beginPath(); c.arc(bx.x + 26, bx.y - 22, 13, 0, 7); c.fill(); c.fillStyle = "#1b2140"; c.font = "800 14px Nunito"; c.textAlign = "center"; c.fillText(n, bx.x + 26, bx.y - 17);
  }
  function drawSteam(c, t) { if (S.reduce) return; const r = S.L.rest, x = CUP().x, y = r.y + r.h - 92; c.strokeStyle = "rgba(255,255,255,.35)"; c.lineWidth = 2; for (let i = 0; i < 2; i++) { c.beginPath(); c.moveTo(x + i * 6 - 3, y); c.bezierCurveTo(x + i * 6 - 8 + Math.sin(t * 2 + i) * 4, y - 10, x + i * 6 + 4, y - 18, x + i * 6 - 2 + Math.sin(t * 1.6 + i) * 3, y - 28); c.stroke(); } }
  function drawMeter(c, t, counts) {
    const m = S.L.meter, items = [["work", counts.work, "#34d399"], ["queue", counts.queue, "#facc15"], ["rest", counts.rest, "#a78bfa"]];
    const waste = counts.queue > 0 && counts.rest > 0, w = m.w / 3;
    c.fillStyle = "rgba(255,255,255,.05)"; rr(c, m.x, m.y, m.w, m.h, m.h / 2); c.fill();
    items.forEach(([k, n, col], i) => {
      let cc = col; if (k === "rest" && waste) cc = (Math.sin(t * 5) > 0 || S.reduce) ? "#fb7185" : col;
      const cx = m.x + w * i + w / 2 - 22, cy = m.y + m.h / 2;
      if (k === "work" && n) glow(c, cx, cy, 34, col, .35);
      icon(c, k, cx - 10, cy, 1, cc); c.fillStyle = cc; c.font = "800 34px Nunito, system-ui"; c.textAlign = "left"; c.fillText(n, cx + 16, cy + 12);
    });
  }

  /* ───────── bucle ───────── */
  function frame(ts) {
    if (!S.open) return;
    const t = now(), dt = Math.min(.05, (ts - (S.lastT || ts)) / 1000); S.lastT = ts;
    const st = S.cv.parentElement, w = st.clientWidth, h = st.clientHeight, dpr = Math.min(2, devicePixelRatio || 1);
    const L = pickLayout(w, h);
    if (!S.L || S.L.wide !== L.wide) { S.L = L; S.bg = null; S.bokeh = []; S.ag.clear(); S.deskOf.clear(); if (S.D) sync(S.D); }
    if (!S.bg) buildBg();
    if (S.cv.width !== Math.round(w * dpr) || S.cv.height !== Math.round(h * dpr)) { S.cv.width = Math.round(w * dpr); S.cv.height = Math.round(h * dpr); }
    const c = S.ctx; S.scale = Math.min(w / S.L.W, h / S.L.H); S.ox = (w - S.L.W * S.scale) / 2; S.oy = (h - S.L.H * S.scale) / 2;
    c.setTransform(dpr, 0, 0, dpr, 0, 0); c.fillStyle = "#070b18"; c.fillRect(0, 0, w, h);
    c.setTransform(dpr * S.scale, 0, 0, dpr * S.scale, dpr * S.ox, dpr * S.oy);
    c.drawImage(S.bg, 0, 0);
    stepAgents(dt, t); socialTick(t);
    const ags = [...S.ag.values()], usage = {}, counts = { work: 0, queue: 0, rest: 0 };
    ags.forEach(a => { if (a.st === "work") { counts.work++; if (a.zone && !a.walking) usage[a.zone] = (usage[a.zone] || 0) + 1; } else if (a.st === "queue") counts.queue++; else counts.rest++; });
    drawBokeh(c, t); drawZonesLit(c, t, usage); drawTower(c, t, counts.work); drawThreads(c, t); drawDeskLights(c, t);
    drawSteam(c, t); drawMailbox(c, t);
    drawAgent(c, { id: "faro", name: "Faro", brand: "faro", st: "host", x: hostSpot()[0], y: hostSpot()[1] - 6, tx: 0, ty: 0, ph: 1 }, t);
    ags.sort((a, b) => a.y - b.y).forEach(a => drawAgent(c, a, t));
    drawProjects(c, t); drawMeter(c, t, counts);
    S.raf = requestAnimationFrame(frame);
  }

  /* ───────── fichas ───────── */
  function hit(x, y) {
    const L = S.L; let best = null, bd = 40;
    S.ag.forEach(a => { const d = Math.hypot(a.x - x, a.y - 20 - y); if (d < bd) { bd = d; best = { type: "agent", id: a.id }; } });
    if (best) return best;
    for (const [k, z] of Object.entries(L.zones)) if (x > z.x && x < z.x + z.w && y > z.y && y < z.y + z.h) return { type: "zone", id: k };
    const bx = BOX(); if (Math.hypot(x - bx.x, y - bx.y) < 50) return { type: "box" };
    const R = L.rest; if (x > R.x && x < R.x + R.w && y > R.y && y < R.y + R.h) return { type: "chat" };
    for (const b of projectBuildings()) if (x > b.x - 10 && x < b.x + b.w + 10 && y > S.L.proj.y && y < b.base + 30) return { type: "proj", id: b.id };
    const T = L.tower; if (x > T.x && x < T.x + T.w && y > T.y && y < T.y + T.h) return { type: "tower" };
    return null;
  }
  function renderCard() {
    const el = S.root && S.root.querySelector(".fo-card"); if (!el) return; const sel = S.sel, D = S.D || {};
    if (!sel) { el.hidden = true; return; } el.hidden = false; let h = "";
    const ae = document.activeElement; if (ae && ae.tagName === "TEXTAREA" && el.contains(ae)) return;  // no borrar lo que estás escribiendo
    if (sel.type === "chat") {
      const ms = (D.chat || []).slice(-15).reverse(), when = iso => new Date(iso).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
      h = `<h3><span class="fo-sw" style="background:#ffb86b"></span>Conversaciones</h3>${ms.length ? `<ul class="fo-chat">${ms.map(m => `<li><b>${esc(m.from)}</b> → ${esc(m.to)} <span>${when(m.at)}</span><p>${esc(m.text)}</p></li>`).join("")}</ul>` : "<p>Aún no hay mensajes reales. Aparecen cuando un agente propone, entrega o te escribe, o cuando tú contestas.</p>"}`;
      el.innerHTML = `<button type="button" class="fo-x" aria-label="Cerrar">×</button>` + h; el.querySelector(".fo-x").onclick = () => { S.sel = null; renderCard(); }; return;
    }
    if (sel.type === "agent") {
      const a = S.ag.get(sel.id); if (!a) { el.hidden = true; return; } const z = a.zone && ZONES[a.zone];
      const st = { work: "trabajando", queue: "en cola", rest: "descansando" }[a.st];
      const pr = (D.projects || []).find(p => p.id === a.project);
      h = `<h3><span class="fo-sw" style="background:${(BRANDS[a.brand] || BRANDS.hermes).c}"></span>${esc(a.name)}</h3>
        <div class="fo-row"><b style="color:${z ? z.c : "#c7d2fe"}">${z ? esc(z.label) : esc(st)}</b>${z ? `<span>${esc(z.doing)}</span>` : ""}</div>
        ${a.label ? `<p>${esc(a.label)}</p>` : ""}
        <div class="fo-meta">${pr ? "Proyecto: " + esc(pr.name) + " · " : ""}${a.st === "work" ? (a.real ? "acción real" : "representación según el tipo de tarea") : st}${a.reason ? " · " + esc(a.reason) : ""}</div>`;
    } else if (sel.type === "zone") {
      const z = ZONES[sel.id], who = [...S.ag.values()].filter(a => a.st === "work" && a.zone === sel.id && !a.walking);
      h = `<h3><span class="fo-sw" style="background:${z.c}"></span>${esc(z.label)}</h3><p>${who.length ? who.map(a => esc(shortName(a.name))).join(" · ") : "Nadie ahora"}</p>`;
      if (sel.id === "obsidian") { const v = D.vault || {}; h += `<div class="fo-meta">${v.total || 0} notas</div><ul class="fo-list">${(v.recent || []).slice(0, 8).map(n => `<li>${esc(n.title)}</li>`).join("")}</ul>`; }
      if (sel.id === "skills") h += `<ul class="fo-list">${(D.skills || []).slice(0, 12).map(s => `<li>${esc(s.name)}</li>`).join("")}</ul>`;
    } else if (sel.type === "proj") {
      const b = projectBuildings().find(x => x.id === sel.id); if (!b) { el.hidden = true; return; }
      const arts = (D.artifacts || []).filter(a => a.project === b.id).slice(-4), pr = (D.proud || []).filter(a => a.project === b.id);
      h = `<h3><span class="fo-sw" style="background:#7cf5ff"></span>${esc(b.name)}</h3><div class="fo-row"><b>${b.floors}</b><span>plantas${b.active ? " · en obras" : ""}</span></div>
        ${pr.length ? `<p>★ ${pr.map(p => esc(p.title)).join(" · ")}</p>` : ""}${arts.length ? `<ul class="fo-list">${arts.map(a => `<li>${esc(a.name)}</li>`).join("")}</ul>` : ""}`;
    } else if (sel.type === "tower") {
      const n = [...S.ag.values()].filter(a => a.st === "work").length;
      h = `<h3><span class="fo-sw" style="background:#e6ff5c"></span>Faro</h3><p>${n} trabajando. Cuanta más luz sube, más se está haciendo.</p>`;
    } else if (sel.type === "box") {
      const list = (D.suggestions || []).filter(s => s.state === "open").sort((a, b) => (b.imp * b.ret / (b.cost || 1)) - (a.imp * a.ret / (a.cost || 1)));
      h = `<h3><span class="fo-sw" style="background:#facc15"></span>Buzón</h3>${S.flash && Date.now() < S.flash.until ? `<p class="fo-ok">${esc(S.flash.text)}</p>` : ""}${list.length ? `<ul class="fo-sug">${list.map(s => `<li><b>${esc(s.text)}</b><span>${esc(s.why || "")}</span>
        <em>de ${esc(s.from || "un agente")}</em>
        <div><button type="button" data-acc="${esc(s.id)}">Lo hago</button><button type="button" data-dis="${esc(s.id)}">Ahora no</button><button type="button" data-rep="${esc(s.id)}">Responder</button><button type="button" class="fo-del" data-del="${esc(s.id)}">Hacedlo vosotros</button></div>
        <form class="fo-rep" data-for="${esc(s.id)}" hidden><textarea rows="2" maxlength="2000" placeholder="Contesta a ${esc(s.from || "quien lo pidió")}…"></textarea><button type="submit">Enviar</button></form></li>`).join("")}</ul>` : "<p>Vacío.</p>"}`;
    }
    el.innerHTML = `<button type="button" class="fo-x" aria-label="Cerrar ficha">×</button>` + h;
    el.querySelector(".fo-x").onclick = () => { S.sel = null; renderCard(); };
    el.querySelectorAll("[data-acc],[data-dis]").forEach(b => b.onclick = () => suggAction(b.dataset.acc || b.dataset.dis, b.dataset.acc ? "accept" : "dismiss"));
    el.querySelectorAll("[data-del]").forEach(b => b.onclick = async () => { b.disabled = true; b.textContent = "Enviando…"; let ok = false;
      try { const r = await fetch("api/suggestion/action", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: b.dataset.del, type: "delegate" }) }); ok = r.ok && (await r.json()).ok; } catch (_) { }
      if (!ok) { b.disabled = false; b.textContent = "Reintentar"; return; }
      const s = (S.D.suggestions || []).find(x => x.id === b.dataset.del); if (s) s.state = "delegated";
      S.lastSugg = (S.D.suggestions || []).filter(x => x.state === "open").length; S.flash = { text: "Encargado. Avanzarán solos y te avisarán de lo que falte.", until: Date.now() + 4000 }; renderCard(); });
    el.querySelectorAll("[data-rep]").forEach(b => b.onclick = () => { const f = [...el.querySelectorAll(".fo-rep")].find(x => x.dataset.for === b.dataset.rep); if (!f) return; f.hidden = !f.hidden; if (!f.hidden) f.querySelector("textarea").focus(); });
    el.querySelectorAll(".fo-rep").forEach(f => { const ta = f.querySelector("textarea"); ta.onkeydown = e => { e.stopPropagation(); if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) f.requestSubmit(); };
      f.onsubmit = async e => { e.preventDefault(); const txt = ta.value.trim(); if (!txt) { ta.focus(); return; } const btn = f.querySelector("button"); btn.disabled = true; btn.textContent = "Enviando…";
        let ok = false; try { const r = await fetch("api/suggestion/action", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: f.dataset.for, type: "reply", text: txt }) }); ok = r.ok && (await r.json()).ok; } catch (_) { }
        if (!ok) { btn.disabled = false; btn.textContent = "Reintentar"; return; }
        const s = (S.D.suggestions || []).find(x => x.id === f.dataset.for); if (s) s.state = "answered";
        S.lastSugg = (S.D.suggestions || []).filter(x => x.state === "open").length; S.flash = { text: "Respuesta enviada. Le llega como un mensaje.", until: Date.now() + 4000 }; renderCard(); }; });
  }
  async function suggAction(id, type) {
    try { await fetch("api/suggestion/action", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, type }) }); } catch (e) { }
    const s = (S.D.suggestions || []).find(x => x.id === id); if (s) s.state = type === "accept" ? "accepted" : "dismissed";
    S.lastSugg = (S.D.suggestions || []).filter(x => x.state === "open").length; renderCard();
  }

  /* ───────── DOM ───────── */
  const CSS = `
.fo-root{position:fixed;inset:0;z-index:40;background:#070b18;display:flex;flex-direction:column;font-family:Nunito,system-ui,sans-serif;color:#e6ebff;
  padding:calc(8px + env(safe-area-inset-top,0px)) max(8px,env(safe-area-inset-right,0px)) calc(8px + env(safe-area-inset-bottom,0px)) max(8px,env(safe-area-inset-left,0px));gap:8px;animation:fo-in .35s ease}
@keyframes fo-in{from{opacity:0;transform:scale(.99)}to{opacity:1;transform:none}}
.fo-top{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:0 6px}
.fo-top h2{margin:0;font-size:22px;font-weight:800;letter-spacing:.02em}
.fo-top div{display:flex;gap:6px}
.fo-btn{border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);color:#e6ebff;border-radius:999px;padding:7px 14px;font:700 14px Nunito,system-ui;cursor:pointer}
.fo-btn:hover{background:rgba(255,255,255,.12)} .fo-btn:focus-visible{outline:2px solid #7cf5ff;outline-offset:2px}
.fo-stage{position:relative;flex:1;min-height:0;border-radius:18px;overflow:hidden}
.fo-stage canvas{position:absolute;inset:0;width:100%;height:100%;display:block;cursor:pointer;touch-action:manipulation}
.fo-card{position:absolute;left:12px;bottom:12px;width:min(340px,calc(100% - 24px));max-height:60%;overflow:auto;background:rgba(14,20,46,.94);border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:14px 16px;box-shadow:0 10px 40px rgba(0,0,0,.45)}
.fo-card h3{margin:0 0 6px;font-size:19px;display:flex;align-items:center;gap:8px;padding-right:24px}
.fo-card p{margin:6px 0;font-size:15px;line-height:1.35}
.fo-row{display:flex;gap:8px;align-items:baseline;font-size:15px}
.fo-row b{font-size:17px}
.fo-meta{font-size:12.5px;color:#9aa6d6;margin-top:6px}
.fo-sw{width:12px;height:12px;border-radius:4px;flex:none}
.fo-x{position:absolute;right:10px;top:8px;background:none;border:0;color:#9aa6d6;font-size:22px;cursor:pointer}
.fo-list{margin:6px 0 0;padding-left:18px;font-size:14px;color:#c7d2fe}
.fo-sug{list-style:none;margin:6px 0 0;padding:0;display:flex;flex-direction:column;gap:8px}
.fo-sug li{background:rgba(255,255,255,.05);border-radius:12px;padding:8px 10px;display:flex;flex-direction:column;gap:4px}
.fo-sug span{font-size:13px;color:#9aa6d6}
.fo-sug button{border:0;border-radius:999px;padding:5px 12px;font:700 13px Nunito,system-ui;cursor:pointer;margin-right:6px;background:#facc15;color:#1b2140}
.fo-sug button+button{background:rgba(255,255,255,.1);color:#e6ebff}
.fo-sug em{font-style:normal;font-size:12px;color:#facc15;opacity:.8}
.fo-rep{display:flex;gap:6px;align-items:flex-end;margin-top:4px}
.fo-rep textarea{flex:1;min-width:0;background:rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.16);border-radius:10px;padding:8px;color:#e6ebff;font:600 14px Nunito,system-ui;resize:vertical}
.fo-rep button{border:0;border-radius:999px;padding:7px 14px;font:700 13px Nunito,system-ui;background:#7cf5ff;color:#0b1028;cursor:pointer}
.fo-rep button:disabled{opacity:.6}
.fo-ok{color:#39ff88;font-weight:700}
.fo-chat{list-style:none;margin:6px 0 0;padding:0;display:flex;flex-direction:column;gap:8px}.fo-chat li{background:rgba(255,255,255,.05);border-radius:12px;padding:8px 10px;font-size:13px;color:#c7d2fe}.fo-chat li b{color:#fff}.fo-chat li span{float:right;color:#9aa6d6;font-size:12px}.fo-chat p{margin:4px 0 0;font-size:14px;color:#e6ebff}
.fo-sug .fo-del{background:#7cf5ff;color:#0b1028}
.fo-sug li div{display:flex;flex-wrap:wrap;gap:6px}.fo-sug li div button{margin-right:0}
@media (max-width:520px){.fo-card{left:8px;right:8px;width:auto;max-height:70%}}
.fo-help{position:absolute;right:12px;top:12px;width:min(300px,calc(100% - 24px));background:rgba(14,20,46,.94);border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:12px 14px;font-size:13.5px}
.fo-help ul{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:1fr 1fr;gap:6px 10px}
.fo-help li{display:flex;align-items:center;gap:6px}
[hidden]{display:none!important}
@media (prefers-reduced-motion:reduce){.fo-root{animation:none}}`;
  function mount() {
    if (S.root) return;
    if (!document.getElementById("fo-style")) {
      const st = document.createElement("style"); st.id = "fo-style"; st.textContent = CSS; document.head.appendChild(st);
      const ln = document.createElement("link"); ln.rel = "stylesheet"; ln.href = "https://fonts.googleapis.com/css2?family=Nunito:wght@600;700;800&display=swap"; document.head.appendChild(ln);
    }
    const r = document.createElement("div"); r.className = "fo-root"; r.setAttribute("role", "dialog"); r.setAttribute("aria-label", "La oficina");
    r.innerHTML = `<div class="fo-top"><h2>La oficina</h2><div><button type="button" class="fo-btn" data-k="box">Buzón</button><button type="button" class="fo-btn" data-k="help">?</button><button type="button" class="fo-btn" data-k="close">Cerrar</button></div></div>
      <div class="fo-stage"><canvas aria-label="Agentes trabajando en la oficina"></canvas><div class="fo-card" hidden></div><div class="fo-help" hidden></div></div>`;
    document.body.appendChild(r); S.root = r; S.cv = r.querySelector("canvas"); S.ctx = S.cv.getContext("2d");
    r.querySelector('[data-k="close"]').onclick = close;
    r.querySelector('[data-k="box"]').onclick = () => { S.sel = { type: "box" }; renderCard(); };
    r.querySelector('[data-k="help"]').onclick = () => { const hp = r.querySelector(".fo-help"); hp.hidden = !hp.hidden; if (!hp.hidden) hp.innerHTML = helpHTML(); };
    S.cv.addEventListener("click", e => {
      const b = S.cv.getBoundingClientRect(), x = (e.clientX - b.left - S.ox) / S.scale, y = (e.clientY - b.top - S.oy) / S.scale;
      S.sel = hit(x, y); renderCard();
    });
  }
  function helpHTML() {
    const sil = [["Claude", "boina", "#f0a35e"], ["GPT", "gafas", "#8fc7ff"], ["Codex", "gafas y cinta", "#8fc7ff"], ["Hermes", "casco alado", "#b9b4ff"], ["Strata", "capas", "#39ff88"], ["Faro", "en la entrada", "#e6ff5c"]];
    return `<b>Quién es quién</b><ul>${sil.map(([n, d, c]) => `<li><span class="fo-sw" style="background:${c}"></span>${n} · ${d}</li>`).join("")}</ul>
      <div style="margin-top:8px"><b>Luces</b></div><ul>${Object.values(ZONES).map(z => `<li><span class="fo-sw" style="background:${z.c}"></span>${z.label}</li>`).join("")}</ul>
      <p style="margin:8px 0 0;color:#9aa6d6">La luz de cada mesa dice qué está usando ese agente. Los paquetes que vuelan van a su proyecto.</p>`;
  }
  function onKey(e) { if (e.key === "Escape" && S.open) close(); }

  /* ───────── API ───────── */
  function open(D) {
    mount(); S.root.hidden = false; S.open = true; S.reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    S.L = null; S.D = D || {}; S.lastT = 0; S.nextSocial = now() + 8; S.nextDemoDelivery = now() + 6;
    document.addEventListener("keydown", onKey);
    cancelAnimationFrame(S.raf); S.raf = requestAnimationFrame(frame);
  }
  function update(D) { if (!S.open) return; S.D = D || {}; if (S.L) sync(S.D); }
  function close() {
    if (!S.root) return; S.open = false; S.root.hidden = true; cancelAnimationFrame(S.raf); document.removeEventListener("keydown", onKey);
    S.sel = null; if (window.FaroOfficeOnClose) window.FaroOfficeOnClose();
  }
  window.FaroOffice = { open, update, close, isOpen: () => S.open,
    _debug: () => ({ agents: [...S.ag.values()].map(a => ({ id: a.id, x: a.x, y: a.y, v: a.v || 0, zone: a.zone, st: a.st })), packets: S.packets.length, bonus: { ...S.bonus } }) };

  // Sin agentes ni encargos de demostración.
})();
