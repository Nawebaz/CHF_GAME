/* Faro · ¿hay voz de verdad ahora? Una sola regla para la nave (oficina.js), gta.html y, si se quiere, la cubierta.
   Enciende solo con trabajo de voz real y en marcha: entrenamiento, generación o ingesta.
   No enciende por una palabra suelta («flora», «floración», «clonar esquejes», «watts»), ni por el título que el servidor
   copia en la ficha viva de Hermes desde un informe ya cerrado («Ingesta de voz · con «Mimo…»»), ni por el cerrojo de voz
   de la máquina GTA si no hay un clip en VOZ que se esté tocando. Pura: sin DOM; se prueba con node (tests/test_voz_real.js). */
(function (root) {
  "use strict";
  const CTX = /\b(voz|voces|voice|audio|audios|tts|xtts|chatterbox|narrador\w*|narraci\w*|locuci\w*)\b/i;
  const KINDS = [
    ["entreno", "entrenando voz", /\b(entren\w*|training|train|fine-?tun\w*|lora|clon(ar|ando|ado|aci\w*))\b|perfil de voz/i],
    ["generacion", "generando voz", /\b(gener\w*|sintetiz\w*|s[ií]ntesis|tts|xtts|chatterbox|narra\w*|locuci\w*|audio|audios)\b/i],
    ["ingesta", "ingesta de voz", /\bingest\w*/i]];
  const VOICE_ACTION = /^(voice|voz|audio)$/i;
  const ms = v => { const t = Date.parse(v || ""); return isFinite(t) ? t : NaN; };

  function records(status, now) {
    const by = new Map();
    for (const r of [...((status || {}).agents || []), ...((status || {}).running || [])]) if (r && (r.id || r.name)) by.set(r.id || r.name, { ...(by.get(r.id || r.name) || {}), ...r });
    const out = [];
    for (const r of by.values()) {
      if (r.state !== "run" || (r.presence && r.presence !== "desk")) continue;
      if (r.live || /^live:/.test(String(r.id || ""))) {
        // Ficha viva (Hermes · PC…): su «task» la compone el servidor con el último informe, esté abierto o cerrado.
        // Solo cuentan sus tareas abiertas y en marcha, cada una con su propio texto.
        for (const t of r.tasks || []) if (t && !t.closed && t.state === "run" && !(now - ms(t.at) > 10 * 60e3))
          out.push({ name: t.name || "", task: t.title || "", step: "", project: t.project || "", action: "" });
        continue;
      }
      const at = ms(r.at), ttl = Math.min((r.ttl || 600) * 1000, 45 * 60e3);
      if (isFinite(at) && now - at > ttl) continue;                       // informe caducado: no es «en marcha»
      out.push({ name: r.name || "", task: r.task || "", step: r.step || "", project: r.project || "", action: r.action || "", id: r.id || "" });
    }
    return out;
  }

  function faroVoz(status, machines, gta, now) {
    now = now || Date.now(); const found = [];
    const probe = (machines && machines.voz) || (status || {}).voz_probe || {};
    if (probe.running) found.push({ kind: "generacion", label: "generando voz", src: "proceso", gta: true });
    for (const r of records(status, now)) {
      const all = r.name + " " + r.task + " " + r.step + " " + r.project, act = r.task + " " + r.step;
      const voiceAct = VOICE_ACTION.test(r.action), ctx = voiceAct || /^voz$/i.test(r.project) || CTX.test(all);
      if (!ctx) continue;
      const k = KINDS.find(q => q[2].test(act)) || (voiceAct ? KINDS[1] : null);
      if (!k) continue;                                                     // habla de voz pero no hace nada de voz (espera, encargo…)
      found.push({ kind: k[0], label: k[1] + (r.step ? " · " + r.step : ""), src: r.id || r.name, gta: /gta|^voz$/i.test(r.project) });
    }
    const g = gta || {};
    if (g.voz_ocupada && now - ms(g.at) < 3 * 60e3 && (g.clips || []).some(c => c.p === "VOZ" && now - ms(c.u) < 30 * 60e3))
      found.push({ kind: "generacion", label: "voz de GTA en marcha", src: "gta", gta: true });
    const rank = { entreno: 0, generacion: 1, ingesta: 2 };
    found.sort((a, b) => rank[a.kind] - rank[b.kind]);
    return found[0] || null;
  }
  root.faroVoz = faroVoz;
  if (typeof module !== "undefined") module.exports = { faroVoz };
})(typeof window !== "undefined" ? window : globalThis);
