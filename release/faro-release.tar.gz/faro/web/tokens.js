/* Shared palette access for DOM, canvas and both entry pages. */
const faroPalette=new Map();
function faroColor(name){if(!faroPalette.has(name))faroPalette.set(name,getComputedStyle(document.documentElement).getPropertyValue(name).trim());return faroPalette.get(name);}
function faroProjectColor(id){const key=String(id||"").toLowerCase();return faroColor("--project-"+({chf:"chf",gta:"gta",agentes:"agentes",ingresos:"ingresos",voz:"voz",trading:"trading"}[key]||"agentes"));}

function faroRGB(name){const v=faroColor(name);if(v.startsWith(String.fromCharCode(35))){const h=v.slice(1);return [0,2,4].map(i=>parseInt(h.slice(i,i+2),16));}return (v.match(/[\d.]+/g)||[]).slice(0,3).map(Number);}

function faroAlpha(name,a){const [r,g,b]=faroRGB(name);return `rgba(${r},${g},${b},${a})`;}

function faroEase(k){const p=faroColor("--ease").match(/[\d.]+/g).map(Number),[x1,y1,x2,y2]=p;const bez=(t,a,b)=>3*(1-t)*(1-t)*t*a+3*(1-t)*t*t*b+t*t*t;let lo=0,hi=1;for(let i=0;i<12;i++){const t=(lo+hi)/2;if(bez(t,x1,x2)<k)lo=t;else hi=t;}return bez((lo+hi)/2,y1,y2);}
