/* Capa local de Faro (faro-overlay): la oficina es la nave. La oficina clásica queda archivada en ~/faro-overlay/archivo/. */
window.openOffice = function () { location.href = "oficina.html"; };
if (location.hash === "#oficina") location.replace("oficina.html");
addEventListener("hashchange", function () { if (location.hash === "#oficina") location.replace("oficina.html"); });
