/* One owner for page timers. Hidden pages have no scheduled animation or polling. */
(() => {
  const native = {setTimeout: window.setTimeout.bind(window), clearTimeout: window.clearTimeout.bind(window),
    request: window.requestAnimationFrame.bind(window), cancel: window.cancelAnimationFrame.bind(window)};
  const originalFetch = window.fetch?.bind(window), requests = new Set();
  if (originalFetch) window.fetch = async (input, options = {}) => {
    if (document.hidden) throw new DOMException('Page hidden', 'AbortError');
    const controller = new AbortController(); requests.add(controller);
    const signal = options.signal ? AbortSignal.any([options.signal, controller.signal]) : controller.signal;
    try { return await originalFetch(input, {...options, signal}); } finally { requests.delete(controller); }
  };
  const timers = new Map(), frames = new Map(); let serial = 0;
  function arm(id, job) {
    if (document.hidden) return;
    job.handle = native.setTimeout(() => {
      job.handle = 0;
      if (document.hidden || !timers.has(id)) return;
      if (!job.repeat) timers.delete(id);
      try { job.fn(...job.args); } finally { if (job.repeat && timers.has(id)) arm(id, job); }
    }, job.delay);
  }
  function schedule(fn, delay, repeat, args) {
    const id = ++serial, job = {fn, delay, repeat, args, handle: 0};
    timers.set(id, job); arm(id, job); return id;
  }
  window.setTimeout = (fn, delay = 0, ...args) => schedule(fn, delay, false, args);
  window.setInterval = (fn, delay = 0, ...args) => schedule(fn, delay, true, args);
  window.clearTimeout = window.clearInterval = id => { const job = timers.get(id); if (job) native.clearTimeout(job.handle); timers.delete(id); };
  function armFrame(id, job) {
    if (!document.hidden) job.handle = native.request(t => { frames.delete(id); job.fn(t); });
  }
  window.requestAnimationFrame = fn => { const id = ++serial, job = {fn, handle: 0}; frames.set(id, job); armFrame(id, job); return id; };
  window.cancelAnimationFrame = id => { const job = frames.get(id); if (job) native.cancel(job.handle); frames.delete(id); };
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) for (const controller of requests) controller.abort();
    document.documentElement.classList.toggle('faro-hidden', document.hidden);
    for (const [id, job] of timers) { native.clearTimeout(job.handle); job.handle = 0; if (!document.hidden) arm(id, job); }
    for (const [id, job] of frames) { native.cancel(job.handle); job.handle = 0; if (!document.hidden) armFrame(id, job); }
  });
})();
