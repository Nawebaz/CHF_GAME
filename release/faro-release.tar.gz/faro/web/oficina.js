/* Faro · La oficina — implementación de la dirección de arte v1 (faro_art_direction.v1.json, ChatGPT como director de arte).
   Canvas 2D = diorama (fondo cacheado, bóveda viva, mesas, personajes, orbe, luz cacheada y partículas).
   HTML = todo lo legible (cabecera y avisos, chips «nombre · motor», proyectos, máquinas, Strata, GTA, voz, detalle).
   Datos reales: api/status, api/machines, api/vault/live y gta-estado.js. Nada se inventa: ?demo=N enseña datos de prueba con aviso visible. */
"use strict";
(() => {
const $ = s => document.querySelector(s);
const C = $("#art"), X = C.getContext("2d"), STAGE = $("#stage"), CHIPS = $("#chips");
const RM = matchMedia("(prefers-reduced-motion: reduce)"), WIDE = matchMedia("(min-aspect-ratio:1/1) and (min-width:700px)");
const DEMO_N = +((location.search.match(/[?&]demo=(\d+)/) || [])[1] || 0);
const T = { bg900: "#0F1514", bg800: "#16201E", bg700: "#20302C", ivory: "#E8E4DC", silver: "#C9D0CC", metal: "#66706C", furn: "#2A3331",
  core: "#F2EEE6", bounce: "#E6D6B8", focus: "#D7F0E8", ingest: "#B9E7DA", ok: "#63D297", run: "#F2C45A", att: "#FFB56B", bad: "#EE6B6E", stale: "#9AA5B1",
  nLow: "#66706C", nMid: "#4DE0B5", nHigh: "#E8E4DC" };
const ZONE = { codigo: ["Código", "#5ED0FF"], edicion: ["Edición", "#FF8A5B"], pensar: ["Pensar", "#A78BFA"], web: ["Web", "#4DE0B5"], escribir: ["Escribir", "#F4C95D"],
  correo: ["Correo", "#7DD3FC"], sistema: ["Sistema", "#9AA5B1"], skills: ["Skills", "#7EE081"], gta: ["GTA", "#F97316"], voz: ["Voz", "#E879F9"] };
const ACT = { codigo: "codigo", "código": "codigo", code: "codigo", editar: "edicion", edit: "edicion", imagen: "edicion", image: "edicion", pensar: "pensar", think: "pensar",
  buscar: "web", web: "web", escribir: "escribir", write: "escribir", cards: "escribir", obsidian: "escribir", "bóveda": "escribir", correo: "correo", mail: "correo",
  sistema: "sistema", system: "sistema", skills: "skills", voz: "voz", voice: "voz", audio: "voz", gta: "gta" };
function zoneOf(a) {
  const ak = String(a.action || "").toLowerCase(), t = ((a.task || "") + " " + (a.name || "") + " " + (a.step || "")).toLowerCase();
  let z = ACT[ak];
  if (!z) z = /\bvoz\b|audio|narra|locuci|tts|lora|chatterbox/.test(t) ? "voz" : /render|v[ií]deo|clip|montaje|sprite|imagen|ilustra|miniatura/.test(t) ? "edicion"
    : /c[oó]digo|script|bug|program|github|api|build|faro|oficina/.test(t) ? "codigo" : /correo|email|gmail/.test(t) ? "correo"
    : /instala|actualiza|configura|backup|gpu|servidor|descarga/.test(t) ? "sistema" : /busca|investiga|noticias|radar|precio/.test(t) ? "web"
    : /escribe|redacta|guion|texto|nota|b[oó]veda|obsidian/.test(t) ? "escribir" : "pensar";
  if (/gta/.test(String(a.project || "").toLowerCase()) && (z === "pensar" || z === "edicion")) z = "gta";
  return z;
}
const SPRITES = [["claude", "claude"], ["chatgpt", "gpt"], ["gpt", "gpt"], ["hermes", "hermes"], ["codex", "codex"], ["strata", "strata"], ["ollama", "strata"],
  ["bibliotec", "librarian"], ["jardin", "gardener"], ["mimo", "gardener"], ["investig", "researcher"]];
const spriteFor = a => { const s = ((a.name || "") + " " + (a.brand || "") + " " + (a.expert || "")).toLowerCase(); for (const [k, v] of SPRITES) if (s.includes(k)) return v; return "generic"; };
const BRAND = { claude: "Claude", gpt: "GPT", codex: "Codex", hermes: "Hermes", local: "local", strata: "local" };
const PROJ_ALIAS = { gta: "gta", "gta vi": "gta", gta_vi: "gta", chf: "chf", ingresos: "ingresos", agentes: "agentes", biblioteca: "biblioteca", "bóveda": "biblioteca", mimo: "mimo", faro: "faro" };

/* ── estado y datos ── */
const S = { agents: [], status: {}, machines: {}, strata: {}, gta: {}, voz: {}, hist: {}, decide: [], projects: [], graph: null, seq: 0, gv: 0, flashes: new Map(), ok: 0, err: 0 };
const hexA = (h, a) => { const n = parseInt(h.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const hash = s => { s = String(s); let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) / 4294967296; };
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const rel = iso => { const t = Date.parse(iso || ""); if (!t) return "—"; const s = Math.max(0, (Date.now() - t) / 1000); return s < 60 ? "hace " + Math.round(s) + " s" : s < 3600 ? "hace " + Math.round(s / 60) + " min" : "hace " + Math.round(s / 3600) + " h"; };
const projKey = p => { p = String(p || "").toLowerCase().trim(); if (!p || p === "-") return null; for (const k in PROJ_ALIAS) if (p.startsWith(k)) return PROJ_ALIAS[k]; return p; };

function adapt(r) {                                                  // adaptador: informe de Faro → contrato del JSON (agentExample)
  const parts = String(r.name || r.id).split("·"), sp = spriteFor(r), brand = String(r.brand || "").toLowerCase();
  const engine = r.engine || r.model || (sp === "strata" ? (S.strata.model || "local") : BRAND[brand] || "");
  const status = r.state === "bad" ? "bad" : r.state === "warn" ? "attention" : r.stale ? "stale" : "run";
  return { id: r.id || r.name, name: parts[0].trim(), task: r.task || (parts[1] || "").trim(), step: r.step || "", engine, zone: zoneOf(r), projectId: projKey(r.project), project: r.project || "",
    pct: typeof r.pct === "number" ? r.pct : null, status, needsUser: !!r.need, need: typeof r.need === "string" ? r.need : "", cloud: r.cloud ?? (brand === "claude" || brand === "gpt"),
    updatedAt: r.at || "", sprite: sp, raw: r };
}
const DEMO = [["Claude · Oficina de Faro", "claude", "codigo", "faro", "Opus"], ["Hermes · Tanda de lanzamiento", "hermes", "editar", "gta", "Codex"], ["GPT · Diseño de sprites", "gpt", "imagen", "faro", "GPT-5"],
  ["Codex · Insertos en gta.py", "codex", "codigo", "gta", "Codex"], ["Strata · Síntesis local", "strata", "sistema", "biblioteca", "qwen3:14b"], ["Bibliotecario · Limpieza", "", "obsidian", "agentes", ""],
  ["Jardinero · Mimo", "", "escribir", "mimo", ""], ["Investigación · Radar", "", "buscar", "gta", ""], ["Hermes · Entreno de voz", "hermes", "voz", "gta", "local"]];
function demoAgents() { const t = Date.now() / 1000; return DEMO.slice(0, DEMO_N).map((d, i) => ({ id: "demo-" + i, name: d[0], brand: d[1], action: d[2], project: d[3], engine: d[4], state: "run",
  pct: Math.floor((t / (6 + i) + i * 13) % 100), need: i === 2 ? "Elegir entre dos paletas" : undefined, at: new Date().toISOString() })); }

const j = async u => { const r = await fetch(u, { cache: "no-store" }); if (!r.ok) throw Error(r.status); return r.json(); };
async function pull() {
  try {
    const [s, m] = await Promise.all([j("api/status"), j("api/machines")]);
    S.status = s; S.strata = m.strata || {}; S.gta = m.gta || {}; S.voz = m.voz || {};
    if (DEMO_N && !(m.machines || []).length) m.machines = [{ name: "PC", at: new Date().toISOString(), cpu: 30 + Math.random() * 40, cpu_temp: 58 + Math.random() * 14, gpu: 60 + Math.random() * 38, gpu_temp: 50 + Math.random() * 25, ram: 47, vram_gb: 9, vram_total_gb: 16, gpu_w: 120 },
      { name: "Mac", at: new Date().toISOString(), cpu: 12 + Math.random() * 20, cpu_temp: 48 + Math.random() * 8, gpu: 18, ram: 68 }];
    S.machines = {}; for (const x of m.machines || []) S.machines[x.name] = x;
    const byId = new Map(); for (const r of [...(s.agents || []), ...(s.running || [])]) if (r && (r.id || r.name)) byId.set(r.id || r.name, { ...(byId.get(r.id || r.name) || {}), ...r });
    const live = r => { if (r.state !== "run" && r.state !== "warn") return false; if (r.presence) return r.presence === "desk"; const at = Date.parse(r.at || ""); return !at || Date.now() - at < Math.min((r.ttl || 3600) * 1000, 45 * 60e3); };
    const prev = new Map(S.agents.map(a => [a.id, a]));
    S.agents = (DEMO_N ? demoAgents() : [...byId.values()].filter(live)).map(adapt);
    for (const a of S.agents) { const p = prev.get(a.id); if (p && p.pct !== a.pct && a.pct != null) deliver(a.id, "pct"); }
    S.decide = (s.decide || []).filter(d => d.kind === "toca" || d.kind === "buzón" || d.kind === "orden");
    S.projects = s.projects || [];
    for (const c of machineCards()) { const h = S.hist[c.id] || (S.hist[c.id] = []); h.push(c.main); if (h.length > 80) h.shift(); }
    S.ok = Date.now(); renderHud();
  } catch (e) { S.err = Date.now(); $("#count").textContent = "sin conexión"; }
}
async function pullVault() {
  try {
    const v = await j(`api/vault/live?since=${S.seq}&gv=${S.gv}`);
    if (v.graph) { const n = (v.graph.nodes || []).length, cur = G ? G.n : 0, now = Date.now();
      if (G && cur > 40 && n < cur * .6 && !(S.gpend && now - S.gpend > 20e3)) S.gpend = S.gpend || now;            // caída brusca (Obsidian animando): espera a que se confirme
      else { buildGraph(v.graph); S.gv = v.gv; S.gpend = 0; } }
    let n = 0; for (const e of v.ev || []) if (e.s > S.seq) { if (S.seq && n++ < 8) vaultEvent(e); }
    S.seq = v.seq || S.seq;
  } catch (e) {}
}
function pullGta() { const o = document.getElementById("gtaE"); if (o) o.remove(); const e = document.createElement("script"); e.id = "gtaE"; e.src = "gta-estado.js?t=" + Date.now(); e.onerror = () => {}; document.head.appendChild(e); }
function voiceTraining() {
  const fresh = r => { const at = Date.parse(r.updatedAt || r.at || ""); return !at || Date.now() - at < 45 * 60e3; };
  const a = S.agents.find(r => fresh(r) && /entren|lora|training|clon(ar|ando)|perfil de voz/i.test(r.id + " " + r.name + " " + r.task + " " + r.step));
  if (a) return a.step || a.task || "entrenando";
  if ((S.status.voz_probe || {}).running || S.voz.running) return "voz en marcha";
  if ((window.GTA_ESTADO || {}).voz_ocupada) return "voz ocupada";
  return null;
}
function gtaActive() { const ge = window.GTA_ESTADO || {}, gl = Date.parse(ge.last || "");
  return !!(ge.voz_ocupada || (gl && Date.now() - gl < 45 * 60e3) || voiceTraining() || S.gta.state === "run" || S.agents.some(a => a.projectId === "gta")); }

/* ── HUD HTML: cabecera, chips, proyectos, máquinas, lateral ── */
let wide = WIDE.matches;
const cap = () => wide ? 8 : 4;
function visibleAgents() {                                        // prioridad: quien necesita a Nawe, luego orden de llegada estable
  const order = [...S.agents].sort((p, q) => (q.needsUser - p.needsUser) || (arrival(p.id) - arrival(q.id)));
  return { shown: order.slice(0, cap()), rest: order.slice(cap()) };
}
const ARR = new Map(); let arrSeq = 0; const arrival = id => { if (!ARR.has(id)) ARR.set(id, arrSeq++); return ARR.get(id); };
function renderHud() {
  const { shown, rest } = visibleAgents(), needs = S.agents.filter(a => a.needsUser), vt = voiceTraining();
  $("#count").textContent = S.agents.length ? `${S.agents.length} trabajando` : "nadie trabajando ahora";
  $("#clock").textContent = new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
  const al = []; for (const a of needs) al.push(`<button class="chip att" data-agent="${esc(a.id)}" aria-label="${esc(a.name)} te necesita${a.need ? ": " + esc(a.need) : ""}">⚑ ${esc(a.name)} te necesita${wide && a.need ? ": " + esc(a.need.slice(0, 40)) : ""}</button>`);
  const toca = S.decide.filter(d => d.kind === "toca" || d.kind === "buzón").length, fallos = S.decide.filter(d => d.kind === "orden").length;
  if (toca) al.push(`<button class="chip att" data-decide="1">Te toca · ${toca}</button>`);
  if (fallos) al.push(`<button class="chip bad" data-decide="1">Órdenes en cola o fallidas · ${fallos}</button>`);
  if (vt) al.push(`<button class="chip voz" data-voz="1">🎙 ${esc(String(vt).slice(0, 32))}</button>`);
  $("#alerts").innerHTML = al.join("");
  const more = $("#more"); more.hidden = !rest.length; more.textContent = rest.length ? `+${rest.length} más` : "";
  $("#overflow").innerHTML = rest.length ? `<h3>También trabajando</h3>` + rest.map(a => `<button class="agent" style="position:static;transform:none;max-width:none;margin:4px 0;--acc:${ZONE[a.zone][1]}" data-agent="${esc(a.id)}"><span class="l1">${esc(a.name)} <em>· ${esc(a.engine || "—")}</em></span><span class="l2">${esc(ZONE[a.zone][0])} · ${esc(a.project || "—")}</span></button>`).join("") : "";
  if (!rest.length) $("#overflow").hidden = true;
  $("#demo").hidden = !DEMO_N;
  renderProjects(); renderTele(); renderSide(); syncChips(shown);
}
function renderProjects() {
  const run = S.agents, by = {}; for (const a of run) { const k = a.projectId || "otros"; (by[k] = by[k] || []).push(a); }
  const meta = new Map((S.projects || []).map(p => [String(p.id).toLowerCase(), p]));
  const ids = new Set(["faro"]); for (const k in by) if (k !== "otros") ids.add(k); if (gtaActive()) ids.add("gta");   // Nawe: solo lo que se toca ahora (+ Faro siempre)
  const cards = [...ids].sort((a, b) => (a === "faro" ? -1 : b === "faro" ? 1 : (by[b] || []).length - (by[a] || []).length)).map(k => {
    const m = meta.get(k === "gta" ? "gta" : k) || meta.get(k) || {}, ag = by[k] || [], hue = m.hue || (k === "faro" ? "#F2C45A" : ZONE.codigo[1]);
    const wp = ag.filter(a => a.pct != null), pct = wp.length ? Math.round(wp.reduce((s, a) => s + a.pct, 0) / wp.length) : null, st = ag.some(a => a.status === "bad") ? "bad" : ag.some(a => a.needsUser) ? "attention" : ag.length ? "run" : "ok";
    const name = m.name || (k === "gta" ? "GTA VI" : k.charAt(0).toUpperCase() + k.slice(1));
    const ge = window.GTA_ESTADO || {}, gtaLine = k === "gta" ? (voiceTraining() ? "voz entrenando" : ge.resumen || ge.estado || (gtaActive() ? "máquina trabajando" : "en espera")) : "";
    const sub = ag.length ? `${ag.length === 1 ? ag[0].name : ag.length + " agentes"} · ${pct != null ? pct + " %" : "en marcha"}` : (gtaLine || "en calma");
    const road = k === "gta" && !wide ? `<span class="road${gtaActive() ? "" : " off"}" style="${roadCss()}"></span>` : "";
    return `<button class="card${ag.length ? "" : " idle"}${k === "faro" ? " faro" : ""}" style="--acc:${hue}" data-proj="${esc(k)}">${road}<span class="n"><span class="dot ${st}"></span>${esc(name)}</span><span class="s">${esc(sub)}</span>${pct != null ? `<span class="bar"><i style="width:${pct}%"></i></span>` : ""}</button>`; });
  $("#proj").innerHTML = cards.join("");
}
function roadCss() { const a = (window.NAVE_ATLAS || {})["screen.road"] || [649, 172, 227, 146], AW = 1024, AH = 1141;
  return `background-size:${(AW / a[2] * 100).toFixed(2)}% auto;background-position:${(a[0] / (AW - a[2]) * 100).toFixed(2)}% ${(a[1] / (AH - a[3]) * 100).toFixed(2)}%`; }
function machineCards() {
  const m = S.machines, pc = m.PC, mac = m.Mac, vr = pc && pc.vram_total_gb ? pc.vram_gb / pc.vram_total_gb * 100 : null;
  return [{ id: "mac", lab: "Mac", short: "Mac", temp: mac && mac.cpu_temp, main: mac && mac.cpu, rows: [["CPU", mac && mac.cpu], ["GPU", mac && mac.gpu], ["RAM", mac && mac.ram]], m: mac },
    { id: "cpu", lab: "PC · CPU", short: "PC CPU", temp: pc && pc.cpu_temp, main: pc && pc.cpu, rows: [["CPU", pc && pc.cpu], ["RAM", pc && pc.ram]], m: pc },
    { id: "gpu", lab: "PC · GPU", short: "PC GPU", temp: pc && pc.gpu_temp, main: pc && pc.gpu, rows: [["GPU", pc && pc.gpu], ["VRAM", vr]], m: pc, extra: pc && pc.gpu_w != null ? Math.round(pc.gpu_w) + " W" : "" }];
}
const tempCol = v => v == null ? T.metal : v >= 85 ? T.bad : v >= 70 ? T.att : v >= 55 ? T.run : "#4DE0B5";
const loadCol = v => v == null ? T.metal : v >= 92 ? T.bad : v >= 75 ? T.att : "#4DE0B5";
function machineAge(m) { if (!m) return Infinity; if (typeof m.age === "number") return m.age * 1000; const t = Date.parse(m.at || ""); return t ? Date.now() - t : Infinity; }
function renderTele() {
  $("#tele").innerHTML = machineCards().map(c => {
    const stale = machineAge(c.m) > 15000, tc = stale ? T.stale : tempCol(c.temp), hs = S.hist[c.id] || [];
    const pts = hs.map((v, i) => `${(100 - (hs.length - 1 - i) * 100 / 79).toFixed(1)},${(100 - Math.min(100, v || 0) * .62).toFixed(1)}`).join(" ");
    const rows = (wide ? c.rows : c.rows.slice(0, 2)).map(([l, v]) => `<div class="rr"><div class="r"><span>${l}</span><b>${v == null ? "–" : Math.round(v) + " %"}</b></div><div class="bar"><i style="width:${Math.max(0, Math.min(100, v || 0))}%;background:${loadCol(v)}"></i></div></div>`).join("");
    const ttl = `${c.lab}: ${stale ? "datos antiguos" : (c.temp == null ? "sin temperatura" : Math.round(c.temp) + " grados")}`;
    const svg = hs.length > 1 ? `<svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><polyline points="${pts}" fill="none" stroke="${hexA(loadCol(c.main), .5)}" stroke-width="1.2" vector-effect="non-scaling-stroke"/></svg>` : "";
    const t = stale || c.temp == null ? "–" : Math.round(c.temp) + "°";
    return wide ? `<div class="mc${stale ? " stale" : ""}${c.temp >= 70 ? " hot" : ""}" style="--tc:${tc}" role="group" aria-label="${esc(ttl)}" ${c.id === "gpu" ? 'data-strata="1" tabindex="0"' : ""}>${svg}<div class="tw"><span class="lab">${c.lab}</span><span class="t">${t}</span><span class="dim">${stale ? "sin datos · " + (isFinite(machineAge(c.m)) ? rel(new Date(Date.now() - machineAge(c.m)).toISOString()) : "—") : c.extra || ""}</span></div><div class="rows">${rows}</div></div>`
      : `<div class="mc${stale ? " stale" : ""}${c.temp >= 70 ? " hot" : ""}" style="--tc:${tc}" role="group" aria-label="${esc(ttl)}" ${c.id === "gpu" ? 'data-strata="1" tabindex="0"' : ""}>${svg}<div class="h"><span class="lab">${c.short}</span><span class="t">${t}</span></div>${rows}</div>`; }).join("");
}
function strataInfo() { const st = S.strata || {}, pc = S.machines.PC || {};
  return { on: !!st.ok, model: st.model || "—", busy: !!st.busy, rw: st.io ? `${st.io.r ?? st.io.read ?? "–"} / ${st.io.w ?? st.io.write ?? "–"}` : "–", temp: pc.gpu_temp, at: pc.at }; }
function renderSide() {
  if (!wide) return;
  const s = strataInfo(), ge = window.GTA_ESTADO || {}, vt = voiceTraining(), ga = gtaActive();
  $("#side").innerHTML =
    `<div class="panel" data-strata="1" tabindex="0" role="button" aria-label="Informe de Strata"><h3><span class="dot ${s.on ? (s.busy ? "run" : "ok") : ""}"></span> Strata</h3>
      <div class="row"><span>Modelo</span><b>${esc(s.model)}</b></div><div class="row"><span>Lectura / escritura</span><b>${esc(s.rw)}</b></div>
      <div class="row"><span>Temperatura GPU</span><b>${s.temp != null ? Math.round(s.temp) + " °C" : "–"}</b></div><div class="row"><span>Estado</span><b>${s.on ? (s.busy ? "trabajando" : "en espera") : "apagado"}</b></div>
      <div class="row"><span>Actualizado</span><b>${esc(rel(s.at))}</b></div></div>` +
    `<a class="panel" href="gta.html" style="text-decoration:none;color:inherit;display:block" aria-label="Máquina de GTA VI"><h3><span class="dot ${ga ? "run" : ""}"></span> Máquina GTA VI ›</h3>
      <span class="road${ga ? "" : " off"}" style="${roadCss()};display:block"></span>
      <div class="row"><span>Estado</span><b>${esc(vt ? "voz entrenando" : ge.resumen || ge.estado || (ga ? "trabajando" : "en espera"))}</b></div>
      <div class="row"><span>Último</span><b>${esc(rel(ge.last))}</b></div></a>` +
    `<div class="panel" data-voz="1" tabindex="0" role="button" aria-label="Panel de voz"><h3><span class="dot ${vt ? "attention" : ""}"></span> Voz</h3>
      <canvas id="vozc" width="200" height="34" style="width:100%;height:34px;display:block" aria-hidden="true"></canvas>
      <div class="row"><span>Estado</span><b>${esc(vt || "en reposo")}</b></div><div class="row"><span>Hoy</span><b>${S.voz.today ?? "–"} audios</b></div></div>`;
}

/* chips «nombre · motor» encima de cada mesa (HTML accesible, nunca imagen) */
function syncChips(shown) {
  const ids = new Set(shown.map(a => a.id));
  for (const el of [...CHIPS.children]) if (!ids.has(el.dataset.agent)) el.remove();
  for (const a of shown) { let el = CHIPS.querySelector(`[data-agent="${CSS.escape(a.id)}"]`);
    if (!el) { el = document.createElement("button"); el.className = "agent"; el.dataset.agent = a.id; el.style.opacity = "0"; CHIPS.appendChild(el); }
    el.classList.toggle("need", a.needsUser); el.style.setProperty("--acc", ZONE[a.zone][1]);
    el.setAttribute("aria-label", `${a.name}, motor ${a.engine || "desconocido"}, ${ZONE[a.zone][0]}, ${a.project || "sin proyecto"}${a.pct != null ? ", " + Math.round(a.pct) + " por ciento" : ""}${a.needsUser ? ", te necesita" : ""}`);
    const eng = a.engine && a.engine.toLowerCase() !== a.name.toLowerCase() ? ` <em>· ${esc(a.engine)}</em>` : "";
    el.innerHTML = `<span class="l1">${a.cloud ? '<span class="cloud" aria-hidden="true">☁</span>' : ""}${esc(a.name)}${eng}</span><span class="l2">${esc(ZONE[a.zone][0])}${a.project ? " · " + esc(a.project) : ""}${a.pct != null ? ` <b>${Math.round(a.pct)}%</b>` : ""}</span>${a.pct != null ? `<i class="pb" style="--p:${Math.max(3, Math.min(100, Math.round(a.pct)))}%"></i>` : ""}`; }
  placeChips();
}
function placeChips() { for (const el of CHIPS.children) { const ac = actors.get(el.dataset.agent); if (!ac || ac.slot == null) continue; const d = DESKS[ac.slot]; if (!d) continue;
  el.classList.toggle("side", !!d.side);
  if (d.side) { const ch = Math.min(d.h * .74, 62 * k); el.style.left = (d.x - d.w * .5 + ch * 1.05) + "px"; el.style.top = (d.y + d.h * .18 - ch * .78) + "px"; el.style.maxWidth = (d.w - ch * 1.05) + "px"; }
  else { el.style.left = d.x + "px"; el.style.top = (d.y + d.h * .3) + "px"; el.style.maxWidth = ""; } } }

/* detalle accesible */
function openDlg(t, html) { $("#dlgT").textContent = t; $("#dlgB").innerHTML = html; const d = $("#dlg"); if (d.showModal) d.showModal(); else d.setAttribute("open", ""); }
document.addEventListener("click", e => {
  const b = e.target.closest("[data-agent],[data-proj],[data-decide],[data-voz],[data-strata],#more"); if (!b) return;
  if (b.id === "more") { const o = $("#overflow"); o.hidden = !o.hidden; b.setAttribute("aria-expanded", String(!o.hidden)); return; }
  if (b.dataset.agent) { const a = S.agents.find(x => x.id === b.dataset.agent); if (!a) return;
    openDlg(`${a.name} · ${a.engine || "motor desconocido"}`, `<div class="row"><span>Tarea</span><b>${esc(a.task || "—")}</b></div><div class="row"><span>Paso</span><b>${esc(a.step || "—")}</b></div>
      <div class="row"><span>Zona</span><b>${esc(ZONE[a.zone][0])}</b></div><div class="row"><span>Proyecto</span><b>${esc(a.project || "—")}</b></div><div class="row"><span>Avance</span><b>${a.pct != null ? Math.round(a.pct) + " %" : "—"}</b></div>
      <div class="row"><span>Estado</span><b>${esc(a.status)}${a.needsUser ? " · te necesita" : ""}</b></div>${a.need ? `<p>${esc(a.need)}</p>` : ""}<div class="row"><span>Última noticia</span><b>${esc(rel(a.updatedAt))}</b></div>`); return; }
  if (b.dataset.proj) { const k = b.dataset.proj, ag = S.agents.filter(a => a.projectId === k), m = (S.projects || []).find(p => String(p.id).toLowerCase() === k) || {};
    if (k === "gta" && !ag.length) { location.href = "gta.html"; return; }
    openDlg(m.name || k, (ag.length ? ag.map(a => `<div class="row"><span>${esc(a.name)} · ${esc(a.task)}</span><b>${a.pct != null ? Math.round(a.pct) + " %" : "—"}</b></div>`).join("") : "<p class='dim'>Nadie trabajando ahora.</p>") +
      (m.jobs || []).slice(0, 6).map(jb => `<div class="row"><span>${esc(jb.name)}</span><b>${esc(jb.state || "")}</b></div>`).join("") + (k === "gta" ? `<p><a class="btn" href="gta.html">Abrir la máquina de GTA VI</a></p>` : "")); return; }
  if (b.dataset.decide) { openDlg("Te toca", S.decide.slice(0, 12).map(d => `<div class="row"><span>${esc(d.kind)}</span><b>${esc(d.title || d.id)}</b></div>`).join("") || "<p class='dim'>Nada pendiente.</p>"); return; }
  if (b.dataset.strata) { const s = strataInfo(); openDlg("Strata · informe directo", `<div class="row"><span>Modelo</span><b>${esc(s.model)}</b></div><div class="row"><span>Lectura / escritura</span><b>${esc(s.rw)}</b></div><div class="row"><span>Temperatura GPU</span><b>${s.temp != null ? Math.round(s.temp) + " °C" : "–"}</b></div><div class="row"><span>Estado</span><b>${s.on ? (s.busy ? "trabajando" : "en espera") : "apagado"}</b></div><div class="row"><span>Actualizado</span><b>${esc(rel(s.at))}</b></div>`); return; }
  if (b.dataset.voz) { openDlg("Voz", `<div class="row"><span>Estado</span><b>${esc(voiceTraining() || "en reposo")}</b></div><div class="row"><span>Audios hoy</span><b>${S.voz.today ?? "–"}</b></div><div class="row"><span>Último</span><b>${esc(rel(S.voz.last))}</b></div>`); }
});
document.addEventListener("keydown", e => { if ((e.key === "Enter" || e.key === " ") && e.target.matches("[data-strata],[data-voz]") && e.target.tagName !== "BUTTON") { e.preventDefault(); e.target.click(); } });

/* ── escena: medidas por breakpoint (no se estira el fondo 16:9: se recorta al centro) ── */
let SW = 0, SH = 0, DPR = 1, bgS = 1, bgX = 0, bgY = 0, k = 1;
const ORB = { x: 0, y: 0, core: 58, ex: 154, ey: 104 }, VAULT = { x: 0, y: 0, w: 198, h: 106 }; let DESKS = [];
const IMG = {}; const bgCache = document.createElement("canvas");
function layout() {
  wide = WIDE.matches; const r = STAGE.getBoundingClientRect(); SW = Math.max(1, r.width); SH = Math.max(1, r.height);
  DPR = Math.min(wide ? 2 : 1.75, window.devicePixelRatio || 1); C.width = Math.round(SW * DPR); C.height = Math.round(SH * DPR);
  bgS = Math.max(SW / 1344, SH / 752); bgX = (SW - 1344 * bgS) / 2; bgY = (SH - 752 * bgS) / 2;
  if (!wide) { k = Math.min(1.25, SW / 390);                       // VERTICAL: composición propia (no es un recorte de la horizontal). La bóveda manda: un gran ojo de buey con la galaxia,
    const x0 = 10, x1 = SW - 10, y0 = SH * .025, y1 = SH * .6;        // el orbe asomado arriba y la cubierta con los agentes abajo.
    Object.assign(PORT, { x0, y0, w: x1 - x0, h: y1 - y0, r: Math.min((x1 - x0) / 2, 130 * k) });
    Object.assign(VAULT, { x: SW / 2, y: (y0 + y1) / 2 + 14 * k, w: x1 - x0 - 14, h: y1 - y0 - 30 * k });
    Object.assign(ORB, { x: SW * .5, y: y0 + 40 * k, core: 44 * k, ex: 128 * k, ey: 70 * k });
    Object.assign(DECK, { cx: SW / 2, cy: SH * 1.05, rx: SW * .8, ry: SH * .44 });
    const hd = Math.min(84 * k, SH * .18); DESKS = [[25, .76], [75, .76], [25, .955], [75, .955]].map(([x, f]) => ({ x: SW * x / 100, y: SH * f - hd * .18, w: SW / 2 - 8, h: hd, side: true }));
    RINGS_P = [mkRing(ellipsePts(DECK.cx, SH * 1.02, SW * .64, SH * .33, 300).filter(p => p[1] <= SH + 4), false), mkRing(ellipsePts(DECK.cx, SH * 1.06, SW * .5, SH * .27, 300).filter(p => p[1] <= SH + 4), false)];
  } else { k = Math.min(1.6, Math.max(.7, SH / 720));
    Object.assign(ORB, { x: SW * .5, y: SH * .16, core: 64 * k, ex: 190 * k, ey: 110 * k }); 
    DESKS = []; for (const y of [64, 84]) for (const x of [14, 38, 62, 86]) DESKS.push({ x: SW * x / 100, y: SH * y / 100, w: Math.min(SW * .2, 220 * k), h: SH * .16 }); }
  // capa estática: fondo (horizontal: la ilustración; vertical: decorado propio dibujado en código) + viñeta + mesas apagadas (offOpacity .25)
  bgCache.width = C.width; bgCache.height = C.height; const b = bgCache.getContext("2d"); b.setTransform(DPR, 0, 0, DPR, 0, 0);
  b.fillStyle = T.bg900; b.fillRect(0, 0, SW, SH);
  if (wide) { if (IMG.bg) { b.globalAlpha = .9; b.drawImage(IMG.bg, bgX, bgY, 1344 * bgS, 752 * bgS); b.globalAlpha = 1; } }
  else portraitSet(b);
  const v = b.createRadialGradient(SW / 2, SH * .45, Math.min(SW, SH) * .3, SW / 2, SH * .5, Math.max(SW, SH) * .75); v.addColorStop(0, "rgba(15,21,20,0)"); v.addColorStop(1, "rgba(15,21,20,.55)"); b.fillStyle = v; b.fillRect(0, 0, SW, SH);
  if (wide) Object.assign(VAULT, { x: bgX + 668 * bgS, y: bgY + 290 * bgS, w: 824 * bgS, h: 280 * bgS });   // horizontal: la galaxia vive en el ventanal del fondo
  galAt = 0; placeChips();
}
const PORT = { x0: 0, y0: 0, w: 0, h: 0, r: 0 }, DECK = { cx: 0, cy: 0, rx: 0, ry: 0 };
function portraitSet(b) {                                        // decorado vertical: espacio profundo, ojo de buey metálico y cubierta con sus dos anillos
  const g = b.createLinearGradient(0, 0, 0, SH); g.addColorStop(0, T.bg800); g.addColorStop(.7, T.bg900); g.addColorStop(1, "#0b100f"); b.fillStyle = g; b.fillRect(0, 0, SW, SH);
  const rnd = (n => () => (n = (n * 16807) % 2147483647) / 2147483647)(7);
  for (let i = 0; i < 90; i++) { b.globalAlpha = .12 + rnd() * .3; b.fillStyle = T.silver; b.beginPath(); b.arc(rnd() * SW, rnd() * SH * .7, .4 + rnd() * .9, 0, 7); b.fill(); } b.globalAlpha = 1;
  const { x0, y0, w, h, r } = PORT;
  // ojo de buey: cristal oscuro, brillo interior, marco metálico grueso con filo claro y remaches
  rr(b, x0, y0, w, h, r); b.fillStyle = "#060b0d"; b.fill();
  const gl = b.createRadialGradient(VAULT.x, VAULT.y, 0, VAULT.x, VAULT.y, Math.max(w, h) * .6); gl.addColorStop(0, "rgba(77,224,181,.07)"); gl.addColorStop(1, "rgba(77,224,181,0)"); b.fillStyle = gl; b.fill();
  const fg = b.createLinearGradient(x0, y0, x0 + w, y0 + h); fg.addColorStop(0, "rgba(201,208,204,.65)"); fg.addColorStop(.5, "rgba(102,112,108,.75)"); fg.addColorStop(1, "rgba(201,208,204,.4)");
  b.lineWidth = 7 * k; b.strokeStyle = fg; rr(b, x0, y0, w, h, r); b.stroke();
  b.lineWidth = 1.2; b.strokeStyle = "rgba(232,228,220,.22)"; rr(b, x0 + 5 * k, y0 + 5 * k, w - 10 * k, h - 10 * k, r - 5 * k); b.stroke();
  b.fillStyle = "rgba(201,208,204,.55)"; for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2, px = PORT.x0 + w / 2 + Math.cos(a) * (w / 2 - 1.5 * k), py = y0 + h / 2 + Math.sin(a) * (h / 2 - 1.5 * k);
    if (Math.abs(Math.cos(a)) > .3 || Math.abs(Math.sin(a)) > .9) { b.beginPath(); b.arc(Math.max(x0 + 2, Math.min(x0 + w - 2, px)), py, 1.6 * k, 0, 7); b.fill(); } }
  // cubierta: plataforma elíptica de metal mate con filo iluminado y los dos anillos por los que corre la luz
  b.save(); b.beginPath(); b.ellipse(DECK.cx, DECK.cy, DECK.rx, DECK.ry, 0, 0, 7); const dg = b.createLinearGradient(0, DECK.cy - DECK.ry, 0, SH); dg.addColorStop(0, "#2A3331"); dg.addColorStop(.5, "#1b2422"); dg.addColorStop(1, "#121918");
  b.fillStyle = dg; b.fill(); b.lineWidth = 1.5; b.strokeStyle = "rgba(201,208,204,.22)"; b.stroke(); b.restore();
  RINGS_P.forEach((rg, j) => { b.beginPath(); rg.pts.forEach((p, i) => i ? b.lineTo(p[0], p[1]) : b.moveTo(p[0], p[1])); b.lineWidth = 1; b.strokeStyle = `rgba(201,208,204,${j ? .07 : .13})`; b.stroke(); });
}
function rr(c, x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
function sprOn(c, name, x, y, h, o = {}) { const a = (window.NAVE_ATLAS || {})[name]; if (!a || !IMG.atlas) return 0; const w = a[2] * h / a[3], ay = o.center ? .5 : 1;
  c.save(); if (o.alpha != null) c.globalAlpha = o.alpha; if (o.flip) { c.translate(x, 0); c.scale(-1, 1); x = 0; }
  c.drawImage(IMG.atlas, a[0], a[1], a[2], a[3], x - w / 2, y - h * ay, w, h); c.restore(); return w; }
const spr = (n, x, y, h, o) => sprOn(X, n, x, y, h, o);

/* luz cacheada: dos texturas radiales (rebote cálido y foco), nunca shadowBlur ni filtros por fotograma */
const LIGHT = {}; for (const [n, c] of [["warm", T.bounce], ["focus", T.focus]]) { const cv = document.createElement("canvas"); cv.width = cv.height = 128; const g = cv.getContext("2d"), rg = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  rg.addColorStop(0, hexA(c, .9)); rg.addColorStop(.35, hexA(c, .35)); rg.addColorStop(1, hexA(c, 0)); g.fillStyle = rg; g.fillRect(0, 0, 128, 128); LIGHT[n] = cv; }
const light = (n, x, y, rx, ry, a) => { if (a <= .01) return; X.globalAlpha = Math.min(1, a); X.drawImage(LIGHT[n], x - rx, y - ry, rx * 2, ry * 2); };

/* ── galaxia de la bóveda (como en la cubierta): estrellas en 3D dentro del ventanal, posiciones reales de Obsidian, privada aparte,
      orbes en los nodos de verdad más conectados (con su nombre), energía al leer o escribir ── */
let G = null, galAt = 0; const gCache = document.createElement("canvas"), DOTS = {};
const GC = { gold: "#E9C37A", teal: "#66D9CE", violet: "#B39DDB", amber: "#FFB347", silver: "#C3D6E3", ivory: "#E8E4DC" };
function dot(col) { if (DOTS[col]) return DOTS[col]; const c = document.createElement("canvas"), R = 32; c.width = c.height = R * 2; const s = c.getContext("2d"), g = s.createRadialGradient(R, R, 0, R, R, R);
  g.addColorStop(0, "#fff"); g.addColorStop(.12, col); g.addColorStop(.35, hexA(col, .35)); g.addColorStop(1, hexA(col, 0)); s.fillStyle = g; s.fillRect(0, 0, R * 2, R * 2); return DOTS[col] = c; }
function buildGraph(g) {
  if (!g || !g.nodes || !g.nodes.length) return;
  const N = g.nodes, priv = N.map(n => (n.dir || "").startsWith("70 Privado") || String(n.id || "").startsWith("70 Privado"));
  const deg = new Array(N.length).fill(0); for (const [a, b] of g.edges) { deg[a]++; deg[b]++; }
  const maxd = Math.max(1, ...deg); let pcx = 0, pcy = 0, pn = 0, prad = 0;
  N.forEach((n, i) => { if (priv[i]) { pcx += n.x; pcy += n.y; pn++; } }); if (pn) { pcx /= pn; pcy /= pn; }
  N.forEach((n, i) => { if (priv[i]) prad = Math.max(prad, Math.hypot(n.x - pcx, n.y - pcy)); });
  const psc = pn > 1 ? Math.min(.45, .075 / Math.max(prad, 1e-4)) : .45, old = G ? new Map(G.pts.map(p => [p.id, p])) : null;
  const pts = N.map((n, i) => { const d = deg[i] / maxd, h = hash(n.id || String(i)), o = old && old.get(n.id);
    let x = n.x - .5, y = n.y - .5, z = (h - .5) * .35 - d * .25;
    if (priv[i]) { x = (n.x - pcx) * psc + .62; y = (n.y - pcy) * psc - .28; z = -.55 + (h - .5) * .12; }
    return { x, y, z, cx: o ? o.cx : x, cy: o ? o.cy : y, cz: o ? o.cz : z, a: o ? 1 : (old ? 0 : 1), h: n.h || 0, r: 1.1 + Math.sqrt(d) * 5.5,
      col: d > .45 ? GC.gold : d > .12 ? GC.teal : GC.violet, priv: priv[i], id: n.id, t: n.t || String(n.id || "").split("/").pop(), deg: deg[i], sx: 0, sy: 0, ss: 1 }; });
  const adj = N.map(() => []); for (const [a, b] of g.edges) { adj[a].push(b); adj[b].push(a); }
  const hubs = deg.map((d, i) => [d, i]).filter(([d, i]) => !priv[i] && d >= Math.max(12, maxd * .18)).sort((a, b) => b[0] - a[0]).slice(0, 8).map(t => t[1]);
  G = { n: N.length, pts, adj, edges: g.edges, hubs, maxd, index: new Map(N.map((n, i) => [n.id, i])) }; galAt = 0;
}
const HUBV = new Map();
const hubLook = p => { const id = p.id || ""; if (id.startsWith("20 Áreas/Agentes")) return ["teal", GC.teal]; if (id.startsWith("10 Proyectos") || id.startsWith("Faro")) return ["gold", GC.gold];
  if (id.startsWith("20 Áreas/Expertos")) return ["violet", GC.violet]; return ["teal", GC.teal]; };
function clipVault(c) { c.beginPath(); if (wide) c.rect(VAULT.x - VAULT.w / 2, VAULT.y - VAULT.h / 2, VAULT.w, VAULT.h); else rr(c, PORT.x0 + 5, PORT.y0 + 5, PORT.w - 10, PORT.h - 10, PORT.r - 5); c.clip(); }
function projectGalaxy(t, dt) {
  const sxk = wide ? 1.25 : 1.12, syk = wide ? 1 : 1.12, R = wide ? VAULT.w * .95 : Math.min(VAULT.w * .96 / (.94 * sxk), VAULT.h * .9 / (.94 * syk)), still = RM.matches, yaw = still ? .3 : Math.sin(t * .068) * .45 + t * .018, pitch = still ? -.22 : -.22 + Math.sin(t * .046) * .06;
  const cyw = Math.cos(yaw), syw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch), f = 900 * R / 783, e = Math.min(1, dt * 1.8);
  for (const p of G.pts) { p.cx += (p.x - p.cx) * e; p.cy += (p.y - p.cy) * e; p.cz += (p.z - p.cz) * e; p.a = Math.min(1, p.a + dt * .8);
    const x = p.cx * R * sxk, y = p.cy * R * syk, z = p.cz * R, x1 = x * cyw + z * syw; let z1 = -x * syw + z * cyw; const y1 = y * cp - z1 * sp; z1 = y * sp + z1 * cp;
    const kk = f / (f + z1 + 260 * R / 783); p.sx = VAULT.x + x1 * kk; p.sy = VAULT.y + y1 * kk; p.ss = kk * (R / 783) ; }
}
function renderGalaxy() {                                          // estrellas y enlaces al lienzo cacheado (~12 veces por segundo): lo vivo va encima
  gCache.width = C.width; gCache.height = C.height; const g = gCache.getContext("2d"); g.setTransform(DPR, 0, 0, DPR, 0, 0); if (!G) return;
  g.save(); clipVault(g); g.globalCompositeOperation = "lighter";
  g.lineWidth = .6; g.strokeStyle = hexA(GC.silver, .07); g.beginPath(); for (const [a, b] of G.edges) { const A = G.pts[a], B = G.pts[b]; g.moveTo(A.sx, A.sy); g.lineTo(B.sx, B.sy); } g.stroke();
  const zk = Math.max(.6, Math.min(1.3, VAULT.w / 783));
  for (const p of G.pts) { const r = Math.max(.8, p.r * p.ss * zk); if (p.h > .35 && !p.priv) { const hr = r * (2 + p.h * 2.5); g.globalAlpha = (.1 + p.h * .22) * p.a; g.drawImage(dot(GC.amber), p.sx - hr * 3, p.sy - hr * 3, hr * 6, hr * 6); }
    g.globalAlpha = Math.min(1, .45 + p.ss * .4) * (p.priv ? .75 : 1) * p.a; g.drawImage(dot(p.col), p.sx - r * 3, p.sy - r * 3, r * 6, r * 6); }
  g.restore();
}
function drawGalaxyLive(now, dt) {                                 // consultas/escrituras: enlaces y nodo del color del agente, con energía cinética; orbes con nombre
  X.save(); clipVault(X); X.globalCompositeOperation = "lighter";
  for (const [id, fl] of S.flashes) { const age = now - fl.t; if (age > 7000) { S.flashes.delete(id); continue; } const i = G.index.get(id); if (i == null) continue; const b = Math.max(0, 1 - age / 7000), A = G.pts[i];
    X.strokeStyle = hexA(fl.col, .55 * b); X.lineWidth = 1.4; X.beginPath(); const nb = G.adj[i]; for (let q = 0; q < nb.length && q < 40; q++) { const B = G.pts[nb[q]]; X.moveTo(A.sx, A.sy); X.lineTo(B.sx, B.sy); } X.stroke();
    const boost = Math.max(0, 1 - age / 5000), kk = boost * boost * 5, x = A.sx + Math.sin(now * .021 + A.r * 9) * kk, y = A.sy + Math.cos(now * .017 + A.r * 5) * kk, r = Math.max(2, A.r * A.ss) * (1 + boost * 2.4);
    X.globalAlpha = Math.min(1, .5 + boost); X.drawImage(dot(fl.col), x - r * 3, y - r * 3, r * 6, r * 6);
    if (boost > .3 && fl.k !== "read") { X.strokeStyle = hexA(fl.col, boost * .8); X.lineWidth = 1.5; X.beginPath(); X.arc(x, y, r * 3 + (1 - boost) * 26, 0, 7); X.stroke(); } X.globalAlpha = 1; }
  const live = new Set(G.hubs.map(i => G.pts[i].id)); for (const id of live) if (!HUBV.has(id)) HUBV.set(id, 0);
  for (const [id, v] of HUBV) { const nv = live.has(id) && G.index.has(id) ? Math.min(1, v + dt * 1.2) : v - dt * 1.5; if (nv <= 0) HUBV.delete(id); else HUBV.set(id, nv); }
  X.globalCompositeOperation = "source-over"; const placed = [{ l: ORB.x - ORB.core * 1.5, r: ORB.x + ORB.core * 1.5, t: ORB.y - ORB.core * 1.8, b: ORB.y + ORB.core * 1.5 }], n = wide ? 6 : 4, fs = wide ? 12 : 11; X.font = `600 ${fs}px Inter,system-ui,sans-serif`; X.textAlign = "left"; X.textBaseline = "middle";
  for (const i of G.hubs.slice(0, n)) { const p = G.pts[i], v = HUBV.get(p.id) || 0; if (v < .02) continue; const lab = p.t.length > 18 ? p.t.slice(0, 17) + "…" : p.t, lw = X.measureText(lab).width;
    let box = null; for (const [dx, dy] of [[7, 0], [-7 - lw, 0], [-lw / 2, -11], [-lw / 2, 11]]) { const b = { l: p.sx + dx - 2, r: p.sx + dx + lw + 2, t: p.sy + dy - fs / 2 - 1, b: p.sy + dy + fs / 2 + 1, x: p.sx + dx, y: p.sy + dy };
      if (!placed.some(q => !(b.r < q.l || b.l > q.r || b.b < q.t || b.t > q.b))) { box = b; break; } }
    if (!box) continue; placed.push(box); const fl = S.flashes.get(p.id), fb = fl ? Math.max(0, 1 - (now - fl.t) / 5000) : 0;
    X.lineWidth = 3; X.strokeStyle = hexA("#06101a", .8 * v); X.strokeText(lab, box.x, box.y); X.fillStyle = hexA(fb > .05 ? fl.col : GC.ivory, .9 * v); X.fillText(lab, box.x, box.y); }
  X.restore();
}
function drawGalaxy(t, dt, now) { if (!G) return; projectGalaxy(t, dt); if (now - galAt > (RM.matches ? 2000 : 80)) { renderGalaxy(); galAt = now; } X.drawImage(gCache, 0, 0, SW, SH); drawGalaxyLive(now, dt); }
const nodePos = id => { if (G && G.index.has(id)) { const p = G.pts[G.index.get(id)]; return { x: p.sx, y: p.sy }; } return { x: VAULT.x, y: VAULT.y }; };
function actorFor(w) { const s = String(w || "").toLowerCase(); if (!s) return null; for (const ac of actors.values()) { const a = ac.a; if (s.includes(a.name.toLowerCase()) || (a.raw.brand && s.includes(String(a.raw.brand).toLowerCase()))) return ac; } return null; }
function vaultEvent(e) { const id = String(e.p || "").replace(/\.md$/, ""), ac = actorFor(e.who || e.maybe), col = ac ? ZONE[ac.a.zone][1] : T.ingest;
  S.flashes.set(id, { t: performance.now(), col, k: e.k }); if (e.k !== "read" && ac) deliver(ac.id, "vault", id); }

/* ── suelo vivo (v3.15): la luz de cada envío recorre los dos anillos dibujados en el suelo del fondo ── */
function mkRing(pts, closed) { const s = [0]; for (let i = 1; i < pts.length; i++) s.push(s[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  return { pts, s, L: closed ? s[s.length - 1] + Math.hypot(pts[0][0] - pts[pts.length - 1][0], pts[0][1] - pts[pts.length - 1][1]) : s[s.length - 1], closed }; }
function ellipsePts(cx, cy, rx, ry, n) { const o = []; for (let i = 0; i < n; i++) { const a = Math.PI * .5 + i / n * Math.PI * 2; o.push([cx + Math.cos(a) * rx, cy + Math.sin(a) * ry]); } return o; }
let RINGS_P = [];
const RINGS = (() => { const mk = mkRing;
  const inner = []; for (let i = 0; i < 120; i++) { const a = i / 120 * Math.PI * 2; inner.push([674 + Math.cos(a) * 137, 611 + Math.sin(a) * 35.5]); }
  const outer = []; for (let i = 0; i <= 400; i++) { const a = Math.PI * .5 + i / 400 * Math.PI * 2, c = Math.cos(a), sn = Math.sin(a), x = 673 + 483 * Math.sign(c) * Math.pow(Math.abs(c), 2 / 3), y = 770 + 234 * Math.sign(sn) * Math.pow(Math.abs(sn), 2 / 3); if (y <= 756) outer.push([x, y]); }
  return [mk(outer, false), mk(inner, true)]; })();
const FLOOR = [];
const ringAt = (r, s) => { if (r.closed) s = ((s % r.L) + r.L) % r.L; else if (s < 0 || s > r.L) return null; let lo = 0, hi = r.s.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (r.s[m] <= s) lo = m; else hi = m - 1; }
  const a = r.pts[lo], b = r.pts[(lo + 1) % r.pts.length], u = (s - r.s[lo]) / (((r.s[lo + 1] ?? r.L) - r.s[lo]) || 1); return [a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u]; };
function floorPulse(sx, sy, col) { const wx = wide ? (sx - bgX) / bgS : sx, wy = wide ? (sy - bgY) / bgS : sy, RS = wide ? RINGS : RINGS_P; if (FLOOR.length > 5) FLOOR.shift(); if (!RS.length) return;
  FLOOR.push({ x: wx, y: wy, col, t: 0, wide, hits: RS.map((r, i) => { let bi = 0, bd = 1e9; r.pts.forEach((p, q) => { const d = (p[0] - wx) ** 2 + ((p[1] - wy) * 2.6) ** 2; if (d < bd) { bd = d; bi = q; } }); return { s: r.s[bi], v: wide ? (i ? 300 : 620) : (i ? 150 * k : 340 * k) }; }) }); }
function drawFloor(dt) {
  if (!FLOOR.length) return; X.save(); if (wide) { X.translate(bgX, bgY); X.scale(bgS, bgS); } X.lineCap = "round";
  for (let q = FLOOR.length - 1; q >= 0; q--) { const f = FLOOR[q]; f.t += dt; if (f.t > 3) { FLOOR.splice(q, 1); continue; } const fade = f.t < .15 ? f.t / .15 : Math.pow(1 - (f.t - .15) / 2.85, 1.6);
    if (f.wide !== wide) { FLOOR.splice(q, 1); continue; }
    f.hits.forEach((h, i) => { const r = (wide ? RINGS : RINGS_P)[i], a = f.t - (i ? .18 : .1); if (a <= 0) return; const d = Math.min(a * h.v, r.closed ? r.L / 2 : r.L);
      for (let pass = 0; pass < 2; pass++) { X.globalCompositeOperation = pass ? "source-over" : "lighter"; X.lineWidth = wide ? (pass ? 2.2 : 8) / Math.max(.6, bgS) : (pass ? 2 : 7) * k; X.strokeStyle = f.col; X.beginPath(); let started = false;
        for (let s = h.s - d; s <= h.s + d; s += wide ? 10 : 6) { const p = ringAt(r, s); if (!p) { started = false; continue; } if (!started) { X.moveTo(p[0], p[1]); started = true; } else X.lineTo(p[0], p[1]); }
        X.globalAlpha = fade * (pass ? .75 : .18); X.stroke(); } }); }
  X.restore(); X.globalAlpha = 1; X.globalCompositeOperation = "source-over";
}

/* ── agentes: absent → enter (rayo de su color + «¡Hola!») → work/think/deliver → exit (al revés). Sin sala de descanso. ── */
const actors = new Map(), SLOT = new Map();
function syncActors() {
  const { shown } = visibleAgents(), ids = new Set(shown.map(a => a.id)), used = new Set(); let moved = false;
  for (const [id, s] of SLOT) { if (ids.has(id) && s < DESKS.length) used.add(s); else SLOT.delete(id); }
  for (const a of shown) { let ac = actors.get(a.id);
    if (!SLOT.has(a.id)) { let s = 0; while (used.has(s)) s++; SLOT.set(a.id, s); used.add(s); }
    if (!ac) { ac = { id: a.id, ph: "enter", pt: 0, sit: 0 }; actors.set(a.id, ac); }
    else if (ac.ph === "exit") { ac.ph = "enter"; ac.pt = 0; }
    if (ac.slot !== SLOT.get(a.id)) { ac.slot = SLOT.get(a.id); moved = true; } ac.a = a; }
  for (const [id, ac] of actors) if (!ids.has(id) && ac.ph !== "exit") { ac.ph = "exit"; ac.pt = 0; }
  if (moved) placeChips();
}
function deliver(id, kind, nodeId) { const ac = actors.get(id); if (!ac) return; ac.dt = performance.now(); ac.kind = kind;
  const d = DESKS[ac.slot]; if (!d) return; const col = ZONE[ac.a.zone][1]; floorPulse(d.x, d.y + d.h * .18, col);
  const to = nodeId ? nodePos(nodeId) : { x: ORB.x, y: ORB.y }; for (let i = 0; i < 6; i++) PARTS.push({ x0: d.x, y0: d.y - d.h * .45, x1: ORB.x, y1: ORB.y, t: -i * .07, col, then: i === 5 ? () => orbIngest(col, to) : null }); }
const PARTS = [];
function drawParts(dt) { if (!PARTS.length) return; X.save(); X.globalCompositeOperation = "lighter";
  for (let i = PARTS.length - 1; i >= 0; i--) { const p = PARTS[i]; p.t += dt / .9; if (p.t < 0) continue; if (p.t >= 1) { PARTS.splice(i, 1); if (p.then) p.then(); continue; }
    const u = p.t, cx = (p.x0 + p.x1) / 2, cy = Math.min(p.y0, p.y1) - 40 * k, x = (1 - u) * (1 - u) * p.x0 + 2 * (1 - u) * u * cx + u * u * p.x1, y = (1 - u) * (1 - u) * p.y0 + 2 * (1 - u) * u * cy + u * u * p.y1;
    X.globalAlpha = Math.sin(Math.PI * u); X.fillStyle = p.col; X.beginPath(); X.arc(x, y, 2.4 * k, 0, 7); X.fill(); }
  X.restore(); }
function drawAgents(t, dt, now) {
  let focus = null, best = -1; const list = [...actors.values()].sort((p, q) => (DESKS[p.slot] || {}).y - (DESKS[q.slot] || {}).y);
  for (const ac of list) { const d = DESKS[ac.slot]; if (!d) { actors.delete(ac.id); continue; } const z = ZONE[ac.a.zone][1];
    ac.pt += dt; if (ac.ph === "enter" && ac.pt > 1.9) { ac.ph = "work"; ac.pt = 0; } if (ac.ph === "exit" && ac.pt > 1.6) { actors.delete(ac.id); continue; }
    const ch = d.side ? Math.min(d.h * .74, 62 * k) : Math.min(d.h * .8, 78 * k), feet = d.y + d.h * .18, x = d.side ? d.x - d.w * .5 + ch * .58 : d.x, s = ch / 96;
    const tp = ac.ph === "enter" ? Math.min(1, ac.pt / .85) : ac.ph === "exit" ? Math.max(0, 1 - Math.max(0, ac.pt - .7) / .85) : 1, vis = Math.max(0, Math.min(1, (tp - .3) / .55));
    if ((ac.ph === "enter" && ac.pt < .85) || (ac.ph === "exit" && ac.pt > .7)) beam(x, feet, z, ac.ph === "enter" ? ac.pt / .85 : (ac.pt - .7) / .85, s);
    const seated = ac.ph === "work"; ac.sit = Math.max(0, Math.min(1, ac.sit + (seated ? 1 : -1.5) * dt / .32));            // mesa: encender 320 ms, apagar 240 ms
    const pulse = RM.matches ? 0 : Math.sin(t * Math.PI * 2 / 1.8) * .08, deskA = (.7 + pulse) * ac.sit;
    if (ac.sit > .01) { X.save(); X.globalCompositeOperation = "lighter"; light("focus", x, feet, ch * .9, ch * .25, .35 * ac.sit); X.restore(); }
    const breath = RM.matches ? 0 : Math.sin(t * Math.PI * 2 / 2.2 + ac.slot) * 2 * s * (seated ? 1 : 0);
    const delivering = now - (ac.dt || 0) < 1100, think = seated && !delivering && (ac.a.zone === "pensar" || now - (ac.dt || 0) > 180e3);
    let pose = ac.ph === "enter" && ac.pt > .85 ? "talk" : ac.ph === "exit" && ac.pt < .7 ? "talk" : "work"; if (!(window.NAVE_ATLAS || {})[ac.a.sprite + "." + pose]) pose = "work";
    if (vis > 0) { X.save(); X.translate(x, feet); X.scale(.35 + .65 * Math.pow(vis, .6), 1 + (1 - vis) * .35); X.translate(-x, -feet);
      spr(ac.a.sprite + "." + pose, x, feet - breath, ch, { alpha: vis }); X.restore(); }
    if (ac.sit > .01) spr("desk.on", x, feet + ch * .2, ch * .46, { alpha: Math.min(.78, Math.max(.62, deskA)) * ac.sit });     // la mesa por delante de las piernas
    { const dd = Math.hypot(x - ORB.x, feet - ORB.y), kk = 1 / (1 + (dd / (SH * .55)) ** 2); X.save(); X.globalCompositeOperation = "lighter"; light("warm", x, feet - ch * .55, ch * .7, ch * .75, .16 * kk * vis); X.restore(); }   // luz local del orbe: cae con la distancia
    if (ac.sit > .5 && !d.side) screen(x + ch * .46, feet - ch * 1.02, ch * .82, ch * .5, ac, z, t, delivering);
    if ((ac.ph === "enter" && ac.pt > .95) || (ac.ph === "exit" && ac.pt < .7)) bubble(d.side ? x - ch * .3 : x + ch * .32, feet - ch * (d.side ? 1.12 : 1.05), ac.ph === "enter" ? "¡Hola!" : "¡Hasta luego!", z, s);
    else if (think && ac.sit > .9 && !RM.matches) thought(d.side ? x + ch * .1 : x - ch * .36, feet - ch * (d.side ? 1.1 : 1.0), z, s, t);
    const sc = (ac.a.needsUser ? 1000 : 0) + (delivering ? 500 : 0) + (ac.a.pct || 0); if (seated && sc > best) { best = sc; focus = { ac, x, y: feet - ch * .6 }; }
    const el = CHIPS.querySelector(`[data-agent="${CSS.escape(ac.id)}"]`); if (el) el.style.opacity = String(Math.max(.15, vis)); }
  return focus;
}
function beam(x, y, col, p, s) { const kk = Math.sin(Math.PI * Math.min(1, Math.max(0, p))), H = 200 * s, w = 40 * s * (.55 + .45 * kk);
  X.save(); X.globalCompositeOperation = "lighter"; const g = X.createLinearGradient(0, y - H, 0, y); g.addColorStop(0, hexA(col, 0)); g.addColorStop(1, hexA(col, .7 * kk)); X.fillStyle = g; X.beginPath(); X.ellipse(x, y - H / 2, w / 2, H / 2, 0, 0, 7); X.fill();
  for (let i = 0; i < 2; i++) { const q = (p * 1.6 + i / 2) % 1; X.strokeStyle = hexA(col, (1 - q) * .8 * kk); X.lineWidth = 2 * s; X.beginPath(); X.ellipse(x, y, (12 + q * 50) * s, (4 + q * 14) * s, 0, 0, 7); X.stroke(); }
  X.restore(); }
function bubble(x, y, msg, col, s) { const r = Math.max(9, 10 * s); X.save(); X.font = `700 ${Math.round(r * 1.2)}px Inter,system-ui,sans-serif`; const w = X.measureText(msg).width;
  rr(X, x - r * .6, y - r, w + r * 1.2, r * 2, r); X.fillStyle = "rgba(232,228,220,.95)"; X.fill(); X.strokeStyle = col; X.lineWidth = 1.4; X.stroke(); X.fillStyle = T.bg900; X.textBaseline = "middle"; X.fillText(msg, x, y + 1); X.restore(); }
function thought(x, y, col, s, t) { const r = Math.max(8, 9 * s); X.save(); X.fillStyle = "rgba(232,228,220,.92)"; X.strokeStyle = col; X.lineWidth = 1.2;
  X.beginPath(); X.ellipse(x, y, r * 1.5, r, 0, 0, 7); X.fill(); X.stroke(); X.beginPath(); X.arc(x + r * 1.1, y + r * 1.4, r * .28, 0, 7); X.fill(); X.stroke();
  X.fillStyle = col; for (let q = 0; q < 3; q++) { X.globalAlpha = .35 + .65 * Math.max(0, Math.sin(t * Math.PI * 2 / 1.8 - q)); X.beginPath(); X.arc(x - r * .6 + q * r * .6, y, r * .18, 0, 7); X.fill(); } X.restore(); }
function screen(x, y, w, h, ac, col, t, hot) {                    // pantalla holográfica de la mesa: color de zona + avance (el texto legible va en el chip HTML)
  X.save(); X.globalAlpha = .9; rr(X, x, y, w, h, 6 * k); X.fillStyle = hexA(col, hot ? .26 : .16); X.fill(); X.strokeStyle = hexA(col, .8); X.lineWidth = 1; X.stroke();
  X.beginPath(); rr(X, x, y, w, h, 6 * k); X.clip(); X.strokeStyle = hexA(col, .7); X.lineWidth = 1.2;
  for (let i = 0; i < 3; i++) { const yy = y + h * (.25 + i * .2), ww = w * (.35 + .45 * hash(ac.id + i + Math.floor((RM.matches ? 0 : t) / 2.2))); X.beginPath(); X.moveTo(x + w * .1, yy); X.lineTo(x + w * .1 + ww, yy); X.stroke(); }
  if (ac.a.pct != null) { X.fillStyle = hexA(col, .9); X.fillRect(x + w * .1, y + h * .82, w * .8 * ac.a.pct / 100, 2.5); }
  X.restore(); }

/* ── orbe: núcleo marfil-gris con aletas; estados idle / focus / toplight / ingest; orbitales independientes ── */
const orb = { state: "idle", st: 0, x: 0, col: T.ingest, ring: [] };
function orbIngest(col, to) { orb.state = "ingest"; orb.st = 0; orb.col = col; orb.ring.push({ a: 0, col }); orb.to = to; }
function drawOrb(t, dt, focus) {
  const needs = S.agents.some(a => a.needsUser), still = RM.matches;
  if (orb.state === "ingest") { orb.st += dt; if (orb.st > 1.4) orb.state = "idle"; } else orb.state = needs ? "toplight" : focus ? "focus" : "idle";
  const tx = orb.state === "focus" && focus ? ORB.x + Math.max(-.08, Math.min(.08, (focus.x - ORB.x) / SW)) * SW : ORB.x; orb.x = orb.x ? orb.x + (tx - orb.x) * Math.min(1, dt / .9 * 2) : ORB.x;
  const fy = still ? 0 : Math.sin(t * Math.PI * 2 / 2.4) * 4 * k, sc = still ? 1 : 1 + (Math.sin(t * Math.PI * 2 / 2.4) + 1) * .01, x = orb.x, y = ORB.y + fy, core = ORB.core * sc;
  X.save(); X.globalCompositeOperation = "lighter";
  light("warm", x, y + core * .6, core * 2.4, core * 1.2, .55);                                                          // rebote cálido bajo el orbe
  if (orb.state === "toplight") { const p = still ? .7 : .55 + .45 * Math.sin(t * Math.PI * 2 / 1.2); light("focus", x, VAULT.y - VAULT.h * .1, core * 2.2, VAULT.h * .9, .5 * p); }
  if (orb.state === "focus" && focus) light("focus", focus.x, focus.y, core * 1.8, core * 1.3, .45);
  if (orb.state === "ingest" && orb.to) { const u = orb.st / 1.4; X.globalAlpha = .5 * (1 - u); X.strokeStyle = orb.col; X.lineWidth = 1.4; X.beginPath(); X.moveTo(x, y + core * .4); X.quadraticCurveTo(x, (y + orb.to.y) / 2, orb.to.x, orb.to.y); X.stroke(); }
  X.restore(); X.globalAlpha = 1;
  // orbitales: dos satélites en la envolvente, por delante o por detrás del núcleo según el ángulo
  const sats = [["sat.a", .42, 0, core * .5], ["sat.b", -.31, 2.1, core * .36]].map(([n, w, ph, h]) => { const a = (still ? 0 : t * w) + ph; return { n, h, x: x + Math.cos(a) * ORB.ex / 2, y: y + Math.sin(a) * ORB.ey / 2 * .55, front: Math.sin(a) > 0 }; });
  for (const s of sats) if (!s.front) spr(s.n, s.x, s.y, s.h, { center: true, alpha: .85 });
  spr(orb.state === "ingest" ? "orb.data" : orb.state === "idle" ? "orb.idle" : "orb.focus", x, y, core * 1.75, { center: true });
  for (const s of sats) if (s.front) spr(s.n, s.x, s.y, s.h, { center: true, alpha: .95 });
  for (let i = orb.ring.length - 1; i >= 0; i--) { const r = orb.ring[i]; r.a += dt; if (r.a > 1.4) { orb.ring.splice(i, 1); continue; } X.strokeStyle = hexA(r.col, .7 * (1 - r.a / 1.4)); X.lineWidth = 1.6; X.beginPath(); X.ellipse(x, y, core * (.6 + r.a), core * (.6 + r.a) * .5, 0, 0, 7); X.stroke(); }
}
function drawVoiceMeter(t) { const c = document.getElementById("vozc"); if (!c) return; const g = c.getContext("2d"), on = !!voiceTraining(); g.clearRect(0, 0, c.width, c.height);
  for (let i = 0; i < 20; i++) { const h = on && !RM.matches ? 4 + Math.abs(Math.sin(t * 6 + i * 1.3)) * 26 : 4; g.fillStyle = on ? "#E879F9" : T.metal; g.fillRect(4 + i * 10, (c.height - h) / 2, 6, h); } }

/* ── bucle: 24 fps móvil / 30 escritorio, pausa en segundo plano, movimiento reducido = solo cambios de estado ── */
let last = 0, lt = 0, running = true, raf = 0, ready = false;
const kick = () => { if (!raf && running && ready) raf = requestAnimationFrame(frame); };
function frame(ts) {
  raf = 0; if (!running) return; kick();
  const fps = RM.matches ? 6 : wide ? 30 : 24; if (ts - last < 1000 / fps - 2) return; last = ts;
  const t = ts / 1000, dt = lt ? Math.min(.1, t - lt) : 0; lt = t; const now = performance.now();
  X.setTransform(DPR, 0, 0, DPR, 0, 0); X.globalAlpha = 1; X.globalCompositeOperation = "source-over";
  X.drawImage(bgCache, 0, 0, SW, SH);
  drawGalaxy(t, dt, now);
  drawFloor(dt); syncActors(); const focus = drawAgents(t, dt, now); drawParts(dt); drawOrb(t, dt, focus);
  if (wide && !RM.matches) drawVoiceMeter(t);
}
let inView = true;
document.addEventListener("visibilitychange", () => { running = !document.hidden && inView; if (running) { lt = 0; kick(); } });
if ("IntersectionObserver" in window) new IntersectionObserver(es => { for (const e of es) { inView = e.isIntersecting; running = inView && !document.hidden; if (running) { lt = 0; kick(); } } }).observe(STAGE);
addEventListener("resize", () => { clearTimeout(layout._t); layout._t = setTimeout(() => { layout(); renderHud(); }, 120); });
const load = src => new Promise(r => { const i = new Image(); i.onload = () => r(i); i.onerror = () => r(null); i.src = src; });
Promise.all([load("nave-bg.webp?v=3"), load("nave-atlas.webp?v=3")]).then(([bg, at]) => { IMG.bg = bg; IMG.atlas = at; layout(); ready = true; kick(); });
pull(); pullVault(); pullGta();
setInterval(() => { if (!document.hidden) pull(); }, 3000); setInterval(() => { if (!document.hidden) pullVault(); }, 2000); setInterval(() => { if (!document.hidden) pullGta(); }, 10000);
setInterval(() => { if (!document.hidden) { renderTele(); $("#clock").textContent = new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }); } }, 5000);
if (/[?&]dbg/.test(location.search)) window.__o = { S, actors, deliver, layout };
})();
