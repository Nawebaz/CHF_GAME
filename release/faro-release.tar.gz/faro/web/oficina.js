/* Faro · La oficina — implementación de la dirección de arte v1 (faro_art_direction.v1.json, ChatGPT como director de arte).
   Canvas 2D = diorama (fondo cacheado, bóveda viva, mesas, personajes, orbe, luz cacheada y partículas).
   HTML = todo lo legible (cabecera y avisos, chips «nombre · motor», proyectos, máquinas, Strata, GTA, voz, detalle).
   Datos reales: api/status, api/machines, api/vault/live y gta-estado.js. Nada se inventa: ?demo=N enseña datos de prueba con aviso visible. */
"use strict";
(() => {
const $ = s => document.querySelector(s);
const C = $("#art"), X = C.getContext("2d"), STAGE = $("#stage"), CHIPS = $("#chips");
const RM = matchMedia("(prefers-reduced-motion: reduce)"), WIDE = matchMedia("(min-aspect-ratio:1/1) and (min-width:700px)");
const DEMO_N = +((location.search.match(/[?&]demo=(\d+)/) || [])[1] || 0);
const T = { bg900: "#0F1514", bg800: "#16201E", bg700: "#20302C", ivory: "#E8E4DC", silver: "#C9D0CC", metal: "#66706C", furn: "#2A3331",
  core: "#F2EEE6", bounce: "#E6D6B8", focus: "#D7F0E8", ingest: "#B9E7DA", ok: "#63D297", run: "#F2C45A", att: "#FFB56B", bad: "#EE6B6E", stale: "#9AA5B1",
  nLow: "#66706C", nMid: "#4DE0B5", nHigh: "#E8E4DC" };
const ZONE = { codigo: ["Código", "#5ED0FF"], edicion: ["Edición", "#FF8A5B"], pensar: ["Pensar", "#A78BFA"], web: ["Web", "#4DE0B5"], escribir: ["Escribir", "#F4C95D"],
  correo: ["Correo", "#7DD3FC"], sistema: ["Sistema", "#9AA5B1"], skills: ["Skills", "#7EE081"], gta: ["GTA", "#F97316"], voz: ["Voz", "#E879F9"] };
const ACT = { codigo: "codigo", "código": "codigo", code: "codigo", editar: "edicion", edit: "edicion", imagen: "edicion", image: "edicion", pensar: "pensar", think: "pensar",
  buscar: "web", web: "web", escribir: "escribir", write: "escribir", cards: "escribir", obsidian: "escribir", "bóveda": "escribir", correo: "correo", mail: "correo",
  sistema: "sistema", system: "sistema", skills: "skills", voz: "voz", voice: "voz", audio: "voz", gta: "gta" };
function zoneOf(a) {
  const ak = String(a.action || "").toLowerCase(), t = ((a.task || "") + " " + (a.name || "") + " " + (a.step || "")).toLowerCase();
  let z = ACT[ak];
  if (!z) z = /\bvoz\b|audio|narra|locuci|tts|lora|chatterbox/.test(t) ? "voz" : /render|v[ií]deo|clip|montaje|sprite|imagen|ilustra|miniatura/.test(t) ? "edicion"
    : /c[oó]digo|script|bug|program|github|api|build|faro|oficina/.test(t) ? "codigo" : /correo|email|gmail/.test(t) ? "correo"
    : /instala|actualiza|configura|backup|gpu|servidor|descarga/.test(t) ? "sistema" : /busca|investiga|noticias|radar|precio/.test(t) ? "web"
    : /escribe|redacta|guion|texto|nota|b[oó]veda|obsidian/.test(t) ? "escribir" : "pensar";
  if (/gta/.test(String(a.project || "").toLowerCase()) && (z === "pensar" || z === "edicion")) z = "gta";
  return z;
}
const SPRITES = [["claude", "claude"], ["chatgpt", "gpt"], ["gpt", "gpt"], ["hermes", "hermes"], ["codex", "codex"], ["strata", "strata"], ["ollama", "strata"],
  ["bibliotec", "librarian"], ["jardin", "gardener"], ["mimo", "gardener"], ["investig", "researcher"]];
const spriteFor = a => { const s = ((a.name || "") + " " + (a.brand || "") + " " + (a.expert || "")).toLowerCase(); for (const [k, v] of SPRITES) if (s.includes(k)) return v; return "generic"; };
const BRAND = { claude: "Claude", gpt: "GPT", codex: "Codex", hermes: "Hermes", local: "local", strata: "local" };
const PROJ_ALIAS = { gta: "gta", "gta vi": "gta", gta_vi: "gta", chf: "chf", ingresos: "ingresos", agentes: "agentes", biblioteca: "biblioteca", "bóveda": "biblioteca", mimo: "mimo", faro: "faro" };

/* ── estado y datos ── */
const S = { agents: [], status: {}, machines: {}, strata: {}, gta: {}, voz: {}, hist: {}, decide: [], projects: [], graph: null, seq: 0, gv: 0, flashes: new Map(), ok: 0, err: 0 };
const hexA = (h, a) => { const n = parseInt(h.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const hash = s => { s = String(s); let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) / 4294967296; };
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const rel = iso => { const t = Date.parse(iso || ""); if (!t) return "—"; const s = Math.max(0, (Date.now() - t) / 1000); return s < 60 ? "hace " + Math.round(s) + " s" : s < 3600 ? "hace " + Math.round(s / 60) + " min" : "hace " + Math.round(s / 3600) + " h"; };
const projKey = p => { p = String(p || "").toLowerCase().trim(); if (!p || p === "-") return null; for (const k in PROJ_ALIAS) if (p.startsWith(k)) return PROJ_ALIAS[k]; return p; };

function adapt(r) {                                                  // adaptador: informe de Faro → contrato del JSON (agentExample)
  const parts = String(r.name || r.id).split("·"), sp = spriteFor(r), brand = String(r.brand || "").toLowerCase();
  const engine = r.engine || r.model || (sp === "strata" ? (S.strata.model || "local") : BRAND[brand] || "");
  const status = r.state === "bad" ? "bad" : r.state === "warn" ? "attention" : r.stale ? "stale" : "run";
  return { id: r.id || r.name, name: parts[0].trim(), task: r.task || (parts[1] || "").trim(), step: r.step || "", engine, zone: zoneOf(r), projectId: projKey(r.project), project: r.project || "",
    pct: typeof r.pct === "number" ? r.pct : null, status, needsUser: !!r.need, need: typeof r.need === "string" ? r.need : "", cloud: r.cloud ?? (brand === "claude" || brand === "gpt"),
    updatedAt: r.at || "", sprite: sp, raw: r };
}
const DEMO = [["Claude · Oficina de Faro", "claude", "codigo", "faro", "Opus"], ["Hermes · Tanda de lanzamiento", "hermes", "editar", "gta", "Codex"], ["GPT · Diseño de sprites", "gpt", "imagen", "faro", "GPT-5"],
  ["Codex · Insertos en gta.py", "codex", "codigo", "gta", "Codex"], ["Strata · Síntesis local", "strata", "sistema", "biblioteca", "qwen3:14b"], ["Bibliotecario · Limpieza", "", "obsidian", "agentes", ""],
  ["Jardinero · Mimo", "", "escribir", "mimo", ""], ["Investigación · Radar", "", "buscar", "gta", ""], ["Hermes · Entreno de voz", "hermes", "voz", "gta", "local"]];
function demoAgents() { const t = Date.now() / 1000; return DEMO.slice(0, DEMO_N).map((d, i) => ({ id: "demo-" + i, name: d[0], brand: d[1], action: d[2], project: d[3], engine: d[4], state: "run",
  pct: Math.floor((t / (6 + i) + i * 13) % 100), need: i === 2 ? "Elegir entre dos paletas" : undefined, at: new Date().toISOString() })); }

const j = async u => { const r = await fetch(u, { cache: "no-store" }); if (!r.ok) throw Error(r.status); return r.json(); };
async function pull() {
  try {
    const [s, m] = await Promise.all([j("api/status"), j("api/machines")]);
    S.status = s; S.strata = m.strata || {}; S.gta = m.gta || {}; S.voz = m.voz || {};
    if (DEMO_N && !(m.machines || []).length) m.machines = [{ name: "PC", at: new Date().toISOString(), cpu: 30 + Math.random() * 40, cpu_temp: 58 + Math.random() * 14, gpu: 60 + Math.random() * 38, gpu_temp: 50 + Math.random() * 25, ram: 47, vram_gb: 9, vram_total_gb: 16, gpu_w: 120 },
      { name: "Mac", at: new Date().toISOString(), cpu: 12 + Math.random() * 20, cpu_temp: 48 + Math.random() * 8, gpu: 18, ram: 68 }];
    S.machines = {}; for (const x of m.machines || []) S.machines[x.name] = x;
    const byId = new Map(); for (const r of [...(s.agents || []), ...(s.running || [])]) if (r && (r.id || r.name)) byId.set(r.id || r.name, { ...(byId.get(r.id || r.name) || {}), ...r });
    const live = r => { if (r.state !== "run" && r.state !== "warn") return false; if (r.presence) return r.presence === "desk"; const at = Date.parse(r.at || ""); return !at || Date.now() - at < Math.min((r.ttl || 3600) * 1000, 45 * 60e3); };
    const prev = new Map(S.agents.map(a => [a.id, a]));
    S.agents = (DEMO_N ? demoAgents() : [...byId.values()].filter(live)).map(adapt);
    for (const a of S.agents) { const p = prev.get(a.id); if (p && p.pct !== a.pct && a.pct != null) deliver(a.id, "pct"); }
    S.decide = (s.decide || []).filter(d => d.kind === "toca" || d.kind === "buzón" || d.kind === "orden");
    S.projects = s.projects || [];
    for (const c of machineCards()) { const h = S.hist[c.id] || (S.hist[c.id] = []); h.push(c.main); if (h.length > 80) h.shift(); }
    S.ok = Date.now(); renderHud();
  } catch (e) { S.err = Date.now(); $("#count").textContent = "sin conexión"; }
}
async function pullVault() {
  try {
    const v = await j(`api/vault/live?since=${S.seq}&gv=${S.gv}`);
    if (v.graph) { const n = (v.graph.nodes || []).length, cur = G ? G.n : 0, now = Date.now();
      if (G && cur > 40 && n < cur * .6 && !(S.gpend && now - S.gpend > 20e3)) S.gpend = S.gpend || now;            // caída brusca (Obsidian animando): espera a que se confirme
      else { buildGraph(v.graph); S.gv = v.gv; S.gpend = 0; } }
    let n = 0; for (const e of v.ev || []) if (e.s > S.seq) { if (S.seq && n++ < 8) vaultEvent(e); }
    S.seq = v.seq || S.seq;
  } catch (e) {}
}
function pullGta() { const o = document.getElementById("gtaE"); if (o) o.remove(); const e = document.createElement("script"); e.id = "gtaE"; e.src = "gta-estado.js?t=" + Date.now(); e.onerror = () => {}; document.head.appendChild(e); }
function voiceTraining() {
  const fresh = r => { const at = Date.parse(r.updatedAt || r.at || ""); return !at || Date.now() - at < 45 * 60e3; };
  const a = S.agents.find(r => fresh(r) && /entren|lora|training|clon(ar|ando)|perfil de voz/i.test(r.id + " " + r.name + " " + r.task + " " + r.step));
  if (a) return a.step || a.task || "entrenando";
  if ((S.status.voz_probe || {}).running || S.voz.running) return "voz en marcha";
  if ((window.GTA_ESTADO || {}).voz_ocupada) return "voz ocupada";
  return null;
}
function gtaActive() { const ge = window.GTA_ESTADO || {}, gl = Date.parse(ge.last || "");
  return !!(ge.voz_ocupada || (gl && Date.now() - gl < 45 * 60e3) || voiceTraining() || S.gta.state === "run" || S.agents.some(a => a.projectId === "gta")); }

/* ── HUD HTML: cabecera, chips, proyectos, máquinas, lateral ── */
let wide = WIDE.matches;
const cap = () => wide ? 8 : 4;
function visibleAgents() {                                        // prioridad: quien necesita a Nawe, luego orden de llegada estable
  const order = [...S.agents].sort((p, q) => (q.needsUser - p.needsUser) || (arrival(p.id) - arrival(q.id)));
  return { shown: order.slice(0, cap()), rest: order.slice(cap()) };
}
const ARR = new Map(); let arrSeq = 0; const arrival = id => { if (!ARR.has(id)) ARR.set(id, arrSeq++); return ARR.get(id); };
function renderHud() {
  const { shown, rest } = visibleAgents(), needs = S.agents.filter(a => a.needsUser), vt = voiceTraining();
  $("#count").textContent = S.agents.length ? `${S.agents.length} trabajando` : "nadie trabajando ahora";
  $("#clock").textContent = new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
  const al = []; for (const a of needs) al.push(`<button class="chip att" data-agent="${esc(a.id)}" aria-label="${esc(a.name)} te necesita${a.need ? ": " + esc(a.need) : ""}">⚑ ${esc(a.name)} te necesita${wide && a.need ? ": " + esc(a.need.slice(0, 40)) : ""}</button>`);
  const toca = S.decide.filter(d => d.kind === "toca" || d.kind === "buzón").length, fallos = S.decide.filter(d => d.kind === "orden").length;
  if (toca) al.push(`<button class="chip att" data-decide="1">Te toca · ${toca}</button>`);
  if (fallos) al.push(`<button class="chip bad" data-decide="1">Órdenes en cola o fallidas · ${fallos}</button>`);
  if (vt) al.push(`<button class="chip voz" data-voz="1">🎙 ${esc(String(vt).slice(0, 32))}</button>`);
  $("#alerts").innerHTML = al.join("");
  const more = $("#more"); more.hidden = !rest.length; more.textContent = rest.length ? `+${rest.length} más` : "";
  $("#overflow").innerHTML = rest.length ? `<h3>También trabajando</h3>` + rest.map(a => `<button class="agent" style="position:static;transform:none;max-width:none;margin:4px 0;--acc:${ZONE[a.zone][1]}" data-agent="${esc(a.id)}"><span class="l1">${esc(a.name)} <em>· ${esc(a.engine || "—")}</em></span><span class="l2">${esc(ZONE[a.zone][0])} · ${esc(a.project || "—")}</span></button>`).join("") : "";
  if (!rest.length) $("#overflow").hidden = true;
  $("#demo").hidden = !DEMO_N;
  renderProjects(); renderTele(); renderSide(); syncChips(shown);
}
function renderProjects() {
  const run = S.agents, by = {}; for (const a of run) { const k = a.projectId || "otros"; (by[k] = by[k] || []).push(a); }
  const meta = new Map((S.projects || []).map(p => [String(p.id).toLowerCase(), p]));
  const ids = new Set(["faro"]); for (const k in by) if (k !== "otros") ids.add(k); if (gtaActive()) ids.add("gta");   // Nawe: solo lo que se toca ahora (+ Faro siempre)
  const cards = [...ids].sort((a, b) => (a === "faro" ? -1 : b === "faro" ? 1 : (by[b] || []).length - (by[a] || []).length)).map(k => {
    const m = meta.get(k === "gta" ? "gta" : k) || meta.get(k) || {}, ag = by[k] || [], hue = m.hue || (k === "faro" ? "#F2C45A" : ZONE.codigo[1]);
    const wp = ag.filter(a => a.pct != null), pct = wp.length ? Math.round(wp.reduce((s, a) => s + a.pct, 0) / wp.length) : null, st = ag.some(a => a.status === "bad") ? "bad" : ag.some(a => a.needsUser) ? "attention" : ag.length ? "run" : "ok";
    const name = m.name || (k === "gta" ? "GTA VI" : k.charAt(0).toUpperCase() + k.slice(1));
    const ge = window.GTA_ESTADO || {}, gtaLine = k === "gta" ? (voiceTraining() ? "voz entrenando" : ge.resumen || ge.estado || (gtaActive() ? "máquina trabajando" : "en espera")) : "";
    const sub = ag.length ? `${ag.length === 1 ? ag[0].name : ag.length + " agentes"} · ${pct != null ? pct + " %" : "sin %"}` : (gtaLine || "en calma");
    const road = k === "gta" && !wide ? `<span class="road${gtaActive() ? "" : " off"}" style="${roadCss()}"></span>` : "";
    return `<button class="card${ag.length ? "" : " idle"}${k === "faro" ? " faro" : ""}" style="--acc:${hue}" data-proj="${esc(k)}">${road}<span class="n"><span class="dot ${st}"></span>${esc(name)}</span><span class="s">${esc(sub)}</span>${pct != null ? `<span class="bar"><i style="width:${pct}%"></i></span>` : ""}</button>`; });
  $("#proj").innerHTML = cards.join("");
}
function roadCss() { const a = (window.NAVE_ATLAS || {})["screen.road"] || [649, 172, 227, 146], AW = 1024, AH = 1141;
  return `background-size:${(AW / a[2] * 100).toFixed(2)}% auto;background-position:${(a[0] / (AW - a[2]) * 100).toFixed(2)}% ${(a[1] / (AH - a[3]) * 100).toFixed(2)}%`; }
function machineCards() {
  const m = S.machines, pc = m.PC, mac = m.Mac, vr = pc && pc.vram_total_gb ? pc.vram_gb / pc.vram_total_gb * 100 : null;
  return [{ id: "mac", lab: "Mac", short: "Mac", temp: mac && mac.cpu_temp, main: mac && mac.cpu, rows: [["CPU", mac && mac.cpu], ["GPU", mac && mac.gpu], ["RAM", mac && mac.ram]], m: mac },
    { id: "cpu", lab: "PC · CPU", short: "PC CPU", temp: pc && pc.cpu_temp, main: pc && pc.cpu, rows: [["CPU", pc && pc.cpu], ["RAM", pc && pc.ram]], m: pc },
    { id: "gpu", lab: "PC · GPU", short: "PC GPU", temp: pc && pc.gpu_temp, main: pc && pc.gpu, rows: [["GPU", pc && pc.gpu], ["VRAM", vr]], m: pc, extra: pc && pc.gpu_w != null ? Math.round(pc.gpu_w) + " W" : "" }];
}
const tempCol = v => v == null ? T.metal : v >= 85 ? T.bad : v >= 70 ? T.att : v >= 55 ? T.run : "#4DE0B5";
const loadCol = v => v == null ? T.metal : v >= 92 ? T.bad : v >= 75 ? T.att : "#4DE0B5";
function machineAge(m) { if (!m) return Infinity; if (typeof m.age === "number") return m.age * 1000; const t = Date.parse(m.at || ""); return t ? Date.now() - t : Infinity; }
function renderTele() {
  $("#tele").innerHTML = machineCards().map(c => {
    const stale = machineAge(c.m) > 15000, tc = stale ? T.stale : tempCol(c.temp), hs = S.hist[c.id] || [];
    const pts = hs.map((v, i) => `${(100 - (hs.length - 1 - i) * 100 / 79).toFixed(1)},${(100 - Math.min(100, v || 0) * .62).toFixed(1)}`).join(" ");
    const rows = (wide ? c.rows : c.rows.slice(0, 2)).map(([l, v]) => `<div class="rr"><div class="r"><span>${l}</span><b>${v == null ? "–" : Math.round(v) + " %"}</b></div><div class="bar"><i style="width:${Math.max(0, Math.min(100, v || 0))}%;background:${loadCol(v)}"></i></div></div>`).join("");
    const ttl = `${c.lab}: ${stale ? "datos antiguos" : (c.temp == null ? "sin temperatura" : Math.round(c.temp) + " grados")}`;
    const svg = hs.length > 1 ? `<svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><polyline points="${pts}" fill="none" stroke="${hexA(loadCol(c.main), .5)}" stroke-width="1.2" vector-effect="non-scaling-stroke"/></svg>` : "";
    const t = stale || c.temp == null ? "–" : Math.round(c.temp) + "°";
    return wide ? `<div class="mc${stale ? " stale" : ""}${c.temp >= 70 ? " hot" : ""}" style="--tc:${tc}" role="group" aria-label="${esc(ttl)}" ${c.id === "gpu" ? 'data-strata="1" tabindex="0"' : ""}>${svg}<div class="tw"><span class="lab">${c.lab}</span><span class="t">${t}</span><span class="dim">${stale ? "sin datos · " + (isFinite(machineAge(c.m)) ? rel(new Date(Date.now() - machineAge(c.m)).toISOString()) : "—") : c.extra || ""}</span></div><div class="rows">${rows}</div></div>`
      : `<div class="mc${stale ? " stale" : ""}${c.temp >= 70 ? " hot" : ""}" style="--tc:${tc}" role="group" aria-label="${esc(ttl)}" ${c.id === "gpu" ? 'data-strata="1" tabindex="0"' : ""}>${svg}<div class="h"><span class="lab">${c.short}</span><span class="t">${t}</span></div>${rows}</div>`; }).join("");
}
function strataInfo() { const st = S.strata || {}, pc = S.machines.PC || {};
  return { on: !!st.ok, model: st.model || "—", busy: !!st.busy, rw: st.io ? `${st.io.r ?? st.io.read ?? "–"} / ${st.io.w ?? st.io.write ?? "–"}` : "–", temp: pc.gpu_temp, at: pc.at }; }
function renderSide() {
  if (!wide) return;
  const s = strataInfo(), ge = window.GTA_ESTADO || {}, vt = voiceTraining(), ga = gtaActive();
  $("#side").innerHTML =
    `<div class="panel" data-strata="1" tabindex="0" role="button" aria-label="Informe de Strata"><h3><span class="dot ${s.on ? (s.busy ? "run" : "ok") : ""}"></span> Strata</h3>
      <div class="row"><span>Modelo</span><b>${esc(s.model)}</b></div><div class="row"><span>Lectura / escritura</span><b>${esc(s.rw)}</b></div>
      <div class="row"><span>Temperatura GPU</span><b>${s.temp != null ? Math.round(s.temp) + " °C" : "–"}</b></div><div class="row"><span>Estado</span><b>${s.on ? (s.busy ? "trabajando" : "en espera") : "apagado"}</b></div>
      <div class="row"><span>Actualizado</span><b>${esc(rel(s.at))}</b></div></div>` +
    `<a class="panel" href="gta.html" style="text-decoration:none;color:inherit;display:block" aria-label="Máquina de GTA VI"><h3><span class="dot ${ga ? "run" : ""}"></span> Máquina GTA VI ›</h3>
      <span class="road${ga ? "" : " off"}" style="${roadCss()};display:block"></span>
      <div class="row"><span>Estado</span><b>${esc(vt ? "voz entrenando" : ge.resumen || ge.estado || (ga ? "trabajando" : "en espera"))}</b></div>
      <div class="row"><span>Último</span><b>${esc(rel(ge.last))}</b></div></a>` +
    `<div class="panel" data-voz="1" tabindex="0" role="button" aria-label="Panel de voz"><h3><span class="dot ${vt ? "attention" : ""}"></span> Voz</h3>
      <canvas id="vozc" width="200" height="34" style="width:100%;height:34px;display:block" aria-hidden="true"></canvas>
      <div class="row"><span>Estado</span><b>${esc(vt || "en reposo")}</b></div><div class="row"><span>Hoy</span><b>${S.voz.today ?? "–"} audios</b></div></div>`;
}

/* chips «nombre · motor» encima de cada mesa (HTML accesible, nunca imagen) */
function syncChips(shown) {
  const ids = new Set(shown.map(a => a.id));
  for (const el of [...CHIPS.children]) if (!ids.has(el.dataset.agent)) el.remove();
  for (const a of shown) { let el = CHIPS.querySelector(`[data-agent="${CSS.escape(a.id)}"]`);
    if (!el) { el = document.createElement("button"); el.className = "agent"; el.dataset.agent = a.id; el.style.opacity = "0"; CHIPS.appendChild(el); }
    el.classList.toggle("need", a.needsUser); el.style.setProperty("--acc", ZONE[a.zone][1]);
    el.setAttribute("aria-label", `${a.name}, motor ${a.engine || "desconocido"}, ${ZONE[a.zone][0]}, ${a.project || "sin proyecto"}${a.pct != null ? ", " + Math.round(a.pct) + " por ciento" : ""}${a.needsUser ? ", te necesita" : ""}`);
    el.innerHTML = `<span class="l1">${a.cloud ? '<span class="cloud" aria-hidden="true">☁</span>' : ""}${esc(a.name)} <em>· ${esc(a.engine || "—")}</em></span><span class="l2">${esc(ZONE[a.zone][0])} · ${esc(a.project || a.task || "—")}${a.pct != null ? " · " + Math.round(a.pct) + " %" : ""}</span>`; }
  placeChips();
}
function placeChips() { for (const el of CHIPS.children) { const ac = actors.get(el.dataset.agent); if (!ac || ac.slot == null) continue; const d = DESKS[ac.slot]; if (!d) continue;
  el.style.left = d.x + "px"; el.style.top = (d.y + d.h * (wide ? .3 : .21)) + "px"; } }

/* detalle accesible */
function openDlg(t, html) { $("#dlgT").textContent = t; $("#dlgB").innerHTML = html; const d = $("#dlg"); if (d.showModal) d.showModal(); else d.setAttribute("open", ""); }
document.addEventListener("click", e => {
  const b = e.target.closest("[data-agent],[data-proj],[data-decide],[data-voz],[data-strata],#more"); if (!b) return;
  if (b.id === "more") { const o = $("#overflow"); o.hidden = !o.hidden; b.setAttribute("aria-expanded", String(!o.hidden)); return; }
  if (b.dataset.agent) { const a = S.agents.find(x => x.id === b.dataset.agent); if (!a) return;
    openDlg(`${a.name} · ${a.engine || "motor desconocido"}`, `<div class="row"><span>Tarea</span><b>${esc(a.task || "—")}</b></div><div class="row"><span>Paso</span><b>${esc(a.step || "—")}</b></div>
      <div class="row"><span>Zona</span><b>${esc(ZONE[a.zone][0])}</b></div><div class="row"><span>Proyecto</span><b>${esc(a.project || "—")}</b></div><div class="row"><span>Avance</span><b>${a.pct != null ? Math.round(a.pct) + " %" : "—"}</b></div>
      <div class="row"><span>Estado</span><b>${esc(a.status)}${a.needsUser ? " · te necesita" : ""}</b></div>${a.need ? `<p>${esc(a.need)}</p>` : ""}<div class="row"><span>Última noticia</span><b>${esc(rel(a.updatedAt))}</b></div>`); return; }
  if (b.dataset.proj) { const k = b.dataset.proj, ag = S.agents.filter(a => a.projectId === k), m = (S.projects || []).find(p => String(p.id).toLowerCase() === k) || {};
    if (k === "gta" && !ag.length) { location.href = "gta.html"; return; }
    openDlg(m.name || k, (ag.length ? ag.map(a => `<div class="row"><span>${esc(a.name)} · ${esc(a.task)}</span><b>${a.pct != null ? Math.round(a.pct) + " %" : "—"}</b></div>`).join("") : "<p class='dim'>Nadie trabajando ahora.</p>") +
      (m.jobs || []).slice(0, 6).map(jb => `<div class="row"><span>${esc(jb.name)}</span><b>${esc(jb.state || "")}</b></div>`).join("") + (k === "gta" ? `<p><a class="btn" href="gta.html">Abrir la máquina de GTA VI</a></p>` : "")); return; }
  if (b.dataset.decide) { openDlg("Te toca", S.decide.slice(0, 12).map(d => `<div class="row"><span>${esc(d.kind)}</span><b>${esc(d.title || d.id)}</b></div>`).join("") || "<p class='dim'>Nada pendiente.</p>"); return; }
  if (b.dataset.strata) { const s = strataInfo(); openDlg("Strata · informe directo", `<div class="row"><span>Modelo</span><b>${esc(s.model)}</b></div><div class="row"><span>Lectura / escritura</span><b>${esc(s.rw)}</b></div><div class="row"><span>Temperatura GPU</span><b>${s.temp != null ? Math.round(s.temp) + " °C" : "–"}</b></div><div class="row"><span>Estado</span><b>${s.on ? (s.busy ? "trabajando" : "en espera") : "apagado"}</b></div><div class="row"><span>Actualizado</span><b>${esc(rel(s.at))}</b></div>`); return; }
  if (b.dataset.voz) { openDlg("Voz", `<div class="row"><span>Estado</span><b>${esc(voiceTraining() || "en reposo")}</b></div><div class="row"><span>Audios hoy</span><b>${S.voz.today ?? "–"}</b></div><div class="row"><span>Último</span><b>${esc(rel(S.voz.last))}</b></div>`); }
});
document.addEventListener("keydown", e => { if ((e.key === "Enter" || e.key === " ") && e.target.matches("[data-strata],[data-voz]") && e.target.tagName !== "BUTTON") { e.preventDefault(); e.target.click(); } });

/* ── escena: medidas por breakpoint (no se estira el fondo 16:9: se recorta al centro) ── */
let SW = 0, SH = 0, DPR = 1, bgS = 1, bgX = 0, bgY = 0, k = 1;
const ORB = { x: 0, y: 0, core: 58, ex: 154, ey: 104 }, VAULT = { x: 0, y: 0, w: 198, h: 106 }; let DESKS = [];
const IMG = {}; const bgCache = document.createElement("canvas");
function layout() {
  wide = WIDE.matches; const r = STAGE.getBoundingClientRect(); SW = Math.max(1, r.width); SH = Math.max(1, r.height);
  DPR = Math.min(wide ? 2 : 1.75, window.devicePixelRatio || 1); C.width = Math.round(SW * DPR); C.height = Math.round(SH * DPR);
  bgS = Math.max(SW / 1344, SH / 752); bgX = (SW - 1344 * bgS) / 2; bgY = (SH - 752 * bgS) / 2;
  if (!wide) { k = Math.min(1.25, SW / 390);
    Object.assign(ORB, { x: SW * .5, y: SH * .16, core: 58 * k, ex: 154 * k, ey: 104 * k }); Object.assign(VAULT, { x: SW * .5, y: SH * .38, w: 198 * k, h: 106 * k });
    DESKS = [[26, 65], [74, 65], [26, 86], [74, 86]].map(([x, y]) => ({ x: SW * x / 100, y: SH * y / 100, w: 168 * k, h: 96 * k }));
  } else { k = Math.min(1.6, Math.max(.7, SH / 720));
    Object.assign(ORB, { x: SW * .5, y: SH * .16, core: 64 * k, ex: 190 * k, ey: 110 * k }); Object.assign(VAULT, { x: SW * .5, y: SH * .37, w: SW * .46, h: SH * .3 });
    DESKS = []; for (const y of [64, 84]) for (const x of [14, 38, 62, 86]) DESKS.push({ x: SW * x / 100, y: SH * y / 100, w: Math.min(SW * .2, 220 * k), h: SH * .16 }); }
  // capa estática: fondo recortado + viñeta + mesas apagadas (offOpacity .25)
  bgCache.width = C.width; bgCache.height = C.height; const b = bgCache.getContext("2d"); b.setTransform(DPR, 0, 0, DPR, 0, 0);
  b.fillStyle = T.bg900; b.fillRect(0, 0, SW, SH);
  if (IMG.bg) { b.globalAlpha = .9; b.drawImage(IMG.bg, bgX, bgY, 1344 * bgS, 752 * bgS); b.globalAlpha = 1; }
  const v = b.createRadialGradient(SW / 2, SH * .45, Math.min(SW, SH) * .3, SW / 2, SH * .5, Math.max(SW, SH) * .75); v.addColorStop(0, "rgba(15,21,20,0)"); v.addColorStop(1, "rgba(15,21,20,.55)"); b.fillStyle = v; b.fillRect(0, 0, SW, SH);
  // marco redondeado de la bóveda (radio 28)
  b.save(); const R = 28 * k, x0 = VAULT.x - VAULT.w / 2, y0 = VAULT.y - VAULT.h / 2; rr(b, x0, y0, VAULT.w, VAULT.h, R); b.fillStyle = "rgba(15,21,20,.86)"; b.fill();
  b.lineWidth = 1.5; b.strokeStyle = hexA(T.silver, .38); b.stroke(); rr(b, x0 + 4, y0 + 4, VAULT.w - 8, VAULT.h - 8, R - 4); b.strokeStyle = hexA(T.metal, .35); b.lineWidth = 1; b.stroke(); b.restore();
  for (const d of DESKS) sprOn(b, "desk.off", d.x, d.y + d.h * .3, d.h * .55, { alpha: .25 });
  graphDirty = true; placeChips();
}
function rr(c, x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
function sprOn(c, name, x, y, h, o = {}) { const a = (window.NAVE_ATLAS || {})[name]; if (!a || !IMG.atlas) return 0; const w = a[2] * h / a[3], ay = o.center ? .5 : 1;
  c.save(); if (o.alpha != null) c.globalAlpha = o.alpha; if (o.flip) { c.translate(x, 0); c.scale(-1, 1); x = 0; }
  c.drawImage(IMG.atlas, a[0], a[1], a[2], a[3], x - w / 2, y - h * ay, w, h); c.restore(); return w; }
const spr = (n, x, y, h, o) => sprOn(X, n, x, y, h, o);

/* luz cacheada: dos texturas radiales (rebote cálido y foco), nunca shadowBlur ni filtros por fotograma */
const LIGHT = {}; for (const [n, c] of [["warm", T.bounce], ["focus", T.focus]]) { const cv = document.createElement("canvas"); cv.width = cv.height = 128; const g = cv.getContext("2d"), rg = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  rg.addColorStop(0, hexA(c, .9)); rg.addColorStop(.35, hexA(c, .35)); rg.addColorStop(1, hexA(c, 0)); g.fillStyle = rg; g.fillRect(0, 0, 128, 128); LIGHT[n] = cv; }
const light = (n, x, y, rx, ry, a) => { if (a <= .01) return; X.globalAlpha = Math.min(1, a); X.drawImage(LIGHT[n], x - rx, y - ry, rx * 2, ry * 2); };

/* ── bóveda viva: grafo real de Obsidian en código (nodos 3/5/8 px por grado, color por conectividad) ── */
let G = null, graphDirty = true, graphAt = 0; const gCache = document.createElement("canvas");
function buildGraph(g) {
  if (!g || !g.nodes || !g.nodes.length) return;
  const N = g.nodes, deg = new Array(N.length).fill(0); for (const [a, b] of g.edges) { deg[a]++; deg[b]++; }
  const sorted = [...deg].sort((a, b) => b - a), hiCut = Math.max(12, sorted[Math.floor(N.length * .03)] || 0), midCut = Math.max(3, sorted[Math.floor(N.length * .25)] || 0), maxd = sorted[0] || 1;
  let mx = 0, my = 0; for (const n of N) { mx = Math.max(mx, Math.abs(n.x - .5)); my = Math.max(my, Math.abs(n.y - .5)); }
  const old = G ? new Map(G.pts.map(p => [p.id, p])) : null;
  const pts = N.map((n, i) => { const d = deg[i], priv = String(n.id || "").startsWith("70 Privado"), o = old && old.get(n.id);
    const x = (n.x - .5) / (mx || .5), y = (n.y - .5) / (my || .5);
    return { id: n.id, t: n.t || String(n.id).split("/").pop(), x, y, cx: o ? o.cx : x, cy: o ? o.cy : y, a: o ? 1 : (old ? 0 : 1), d, priv,
      b: d >= hiCut ? 2 : d >= midCut ? 1 : 0, sx: 0, sy: 0 }; });
  const hubs = deg.map((d, i) => [d, i]).filter(([d, i]) => !pts[i].priv && d >= hiCut).sort((a, b) => b[0] - a[0]).slice(0, 8).map(t => t[1]);
  G = { n: N.length, pts, edges: g.edges, hubs, maxd, index: new Map(N.map((n, i) => [n.id, i])) }; graphDirty = true;
}
function graphStep(t, dt) {                                        // posición en pantalla con una deriva orgánica muy lenta (alga/medusa), suave al cambiar el grafo
  if (!G) return; const e = Math.min(1, dt * 1.6), still = RM.matches, rot = still ? 0 : Math.sin(t * .05) * .05, br = still ? 1 : 1 + Math.sin(t * .4) * .012;
  const cs = Math.cos(rot), sn = Math.sin(rot), hw = VAULT.w / 2 - 14 * k, hh = VAULT.h / 2 - 12 * k;
  for (const p of G.pts) { p.cx += (p.x - p.cx) * e; p.cy += (p.y - p.cy) * e; p.a = Math.min(1, p.a + dt * .8);
    const wob = still ? 0 : Math.sin(t * .7 + p.d * .3 + p.x * 4) * .006;
    const x = (p.cx * cs - p.cy * sn) * br + wob, y = (p.cx * sn + p.cy * cs) * br; p.sx = VAULT.x + x * hw; p.sy = VAULT.y + y * hh; }
}
function renderGraph() {                                           // al lienzo cacheado, ~8 veces por segundo (render sucio, no a cada fotograma)
  gCache.width = C.width; gCache.height = C.height; const g = gCache.getContext("2d"); g.setTransform(DPR, 0, 0, DPR, 0, 0);
  if (!G) return; g.save(); rr(g, VAULT.x - VAULT.w / 2 + 3, VAULT.y - VAULT.h / 2 + 3, VAULT.w - 6, VAULT.h - 6, 26 * k); g.clip();
  g.strokeStyle = hexA(T.metal, .22); g.lineWidth = .6; g.beginPath(); for (const [a, b] of G.edges) { const A = G.pts[a], B = G.pts[b]; g.moveTo(A.sx, A.sy); g.lineTo(B.sx, B.sy); } g.stroke();
  const size = [3, 5, 8].map(s => s * Math.max(.75, Math.min(1.3, k))), col = [T.nLow, T.nMid, T.nHigh];
  for (let b = 0; b < 3; b++) { g.fillStyle = col[b]; g.beginPath(); for (const p of G.pts) { if (p.b !== b) continue; const r = size[b] / 2 * (p.priv ? .8 : 1); g.globalAlpha = p.a * (p.priv ? .55 : 1); g.moveTo(p.sx + r, p.sy); g.arc(p.sx, p.sy, r, 0, 7); } g.fill(); }
  g.globalAlpha = 1; g.restore();
}
function drawHubLabels() {                                         // nombres de los nodos que de verdad concentran enlaces (Hermes, Faro, Claude…); si desaparecen, no salen
  if (!G) return; const n = wide ? 6 : 3, fs = Math.round(11 * Math.max(1, Math.min(1.2, k))); X.save(); X.font = `600 ${fs}px Inter,system-ui,sans-serif`; X.textAlign = "center"; X.textBaseline = "top";
  const placed = [], x0 = VAULT.x - VAULT.w / 2 + 8, x1 = VAULT.x + VAULT.w / 2 - 8, y0 = VAULT.y - VAULT.h / 2 + 6, y1 = VAULT.y + VAULT.h / 2 - fs - 6;
  for (const i of G.hubs.slice(0, n)) { const p = G.pts[i], w = X.measureText(p.t).width + 6; let best = null;
    for (const r of [0, 26, 48, 70].map(v => v * k)) { for (const a of [0, Math.PI, .6, Math.PI - .6, -.6, Math.PI + .6, Math.PI / 2, -Math.PI / 2]) {   // busca un hueco cerca de su nodo; si se aleja, una línea lo une
        const cx = p.sx + Math.cos(a) * r * 1.6, cy = p.sy + 5 + Math.sin(a) * r * .7, bx = { l: cx - w / 2, r: cx + w / 2, t: cy, b: cy + fs };
        if (bx.l < x0 || bx.r > x1 || bx.t < y0 || bx.t > y1) continue; if (placed.some(q => !(bx.r < q.l || bx.l > q.r || bx.b < q.t || bx.t > q.b))) continue; best = { ...bx, cx, cy, rad: r }; break; } if (best) break; }
    if (!best) continue; placed.push(best);
    if (best.rad > 0) { X.strokeStyle = hexA(T.ivory, .45); X.lineWidth = 1; X.beginPath(); X.moveTo(p.sx, p.sy); X.lineTo(best.cx, best.cy + (best.cy > p.sy ? 0 : fs)); X.stroke(); }
    X.lineWidth = 3; X.strokeStyle = "rgba(15,21,20,.9)"; X.strokeText(p.t, best.cx, best.cy); X.fillStyle = T.ivory; X.fillText(p.t, best.cx, best.cy); }
  X.restore();
}
function drawFlashes(now) {                                        // nodo consultado/escrito con el color de la zona del agente
  if (!G) return; X.save(); X.globalCompositeOperation = "lighter";
  for (const [id, f] of S.flashes) { const age = now - f.t; if (age > 4000) { S.flashes.delete(id); continue; } const i = G.index.get(id); if (i == null) continue; const p = G.pts[i], b = 1 - age / 4000;
    light("focus", p.sx, p.sy, 10 * k, 10 * k, .7 * b); X.globalAlpha = b; X.strokeStyle = f.col; X.lineWidth = 1.2; X.beginPath(); X.arc(p.sx, p.sy, 3 + (1 - b) * 9 * k, 0, 7); X.stroke(); }
  X.restore();
}
const nodePos = id => { if (G && G.index.has(id)) { const p = G.pts[G.index.get(id)]; return { x: p.sx, y: p.sy }; } return { x: VAULT.x, y: VAULT.y }; };
function actorFor(w) { const s = String(w || "").toLowerCase(); if (!s) return null; for (const ac of actors.values()) { const a = ac.a; if (s.includes(a.name.toLowerCase()) || (a.raw.brand && s.includes(String(a.raw.brand).toLowerCase()))) return ac; } return null; }
function vaultEvent(e) { const id = String(e.p || "").replace(/\.md$/, ""), ac = actorFor(e.who || e.maybe), col = ac ? ZONE[ac.a.zone][1] : T.ingest;
  S.flashes.set(id, { t: performance.now(), col, k: e.k }); if (e.k !== "read" && ac) deliver(ac.id, "vault", id); }

/* ── suelo vivo (v3.15): la luz de cada envío recorre los dos anillos dibujados en el suelo del fondo ── */
const RINGS = (() => { const mk = (pts, closed) => { const s = [0]; for (let i = 1; i < pts.length; i++) s.push(s[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
    return { pts, s, L: closed ? s[s.length - 1] + Math.hypot(pts[0][0] - pts[pts.length - 1][0], pts[0][1] - pts[pts.length - 1][1]) : s[s.length - 1], closed }; };
  const inner = []; for (let i = 0; i < 120; i++) { const a = i / 120 * Math.PI * 2; inner.push([674 + Math.cos(a) * 137, 611 + Math.sin(a) * 35.5]); }
  const outer = []; for (let i = 0; i <= 400; i++) { const a = Math.PI * .5 + i / 400 * Math.PI * 2, c = Math.cos(a), sn = Math.sin(a), x = 673 + 483 * Math.sign(c) * Math.pow(Math.abs(c), 2 / 3), y = 770 + 234 * Math.sign(sn) * Math.pow(Math.abs(sn), 2 / 3); if (y <= 756) outer.push([x, y]); }
  return [mk(outer, false), mk(inner, true)]; })();
const FLOOR = [];
const ringAt = (r, s) => { if (r.closed) s = ((s % r.L) + r.L) % r.L; else if (s < 0 || s > r.L) return null; let lo = 0, hi = r.s.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (r.s[m] <= s) lo = m; else hi = m - 1; }
  const a = r.pts[lo], b = r.pts[(lo + 1) % r.pts.length], u = (s - r.s[lo]) / (((r.s[lo + 1] ?? r.L) - r.s[lo]) || 1); return [a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u]; };
function floorPulse(sx, sy, col) { const wx = (sx - bgX) / bgS, wy = (sy - bgY) / bgS; if (FLOOR.length > 5) FLOOR.shift();
  FLOOR.push({ x: wx, y: wy, col, t: 0, hits: RINGS.map((r, i) => { let bi = 0, bd = 1e9; r.pts.forEach((p, q) => { const d = (p[0] - wx) ** 2 + ((p[1] - wy) * 2.6) ** 2; if (d < bd) { bd = d; bi = q; } }); return { s: r.s[bi], v: i ? 300 : 620 }; }) }); }
function drawFloor(dt) {
  if (!FLOOR.length) return; X.save(); X.translate(bgX, bgY); X.scale(bgS, bgS); X.lineCap = "round";
  for (let q = FLOOR.length - 1; q >= 0; q--) { const f = FLOOR[q]; f.t += dt; if (f.t > 3) { FLOOR.splice(q, 1); continue; } const fade = f.t < .15 ? f.t / .15 : Math.pow(1 - (f.t - .15) / 2.85, 1.6);
    f.hits.forEach((h, i) => { const r = RINGS[i], a = f.t - (i ? .18 : .1); if (a <= 0) return; const d = Math.min(a * h.v, r.closed ? r.L / 2 : r.L);
      for (let pass = 0; pass < 2; pass++) { X.globalCompositeOperation = pass ? "source-over" : "lighter"; X.lineWidth = (pass ? 2.2 : 8) / Math.max(.6, bgS); X.strokeStyle = f.col; X.beginPath(); let started = false;
        for (let s = h.s - d; s <= h.s + d; s += 10) { const p = ringAt(r, s); if (!p) { started = false; continue; } if (!started) { X.moveTo(p[0], p[1]); started = true; } else X.lineTo(p[0], p[1]); }
        X.globalAlpha = fade * (pass ? .75 : .18); X.stroke(); } }); }
  X.restore(); X.globalAlpha = 1; X.globalCompositeOperation = "source-over";
}

/* ── agentes: absent → enter (rayo de su color + «¡Hola!») → work/think/deliver → exit (al revés). Sin sala de descanso. ── */
const actors = new Map(), SLOT = new Map();
function syncActors() {
  const { shown } = visibleAgents(), ids = new Set(shown.map(a => a.id)), used = new Set(); let moved = false;
  for (const [id, s] of SLOT) { if (ids.has(id) && s < DESKS.length) used.add(s); else SLOT.delete(id); }
  for (const a of shown) { let ac = actors.get(a.id);
    if (!SLOT.has(a.id)) { let s = 0; while (used.has(s)) s++; SLOT.set(a.id, s); used.add(s); }
    if (!ac) { ac = { id: a.id, ph: "enter", pt: 0, sit: 0 }; actors.set(a.id, ac); }
    else if (ac.ph === "exit") { ac.ph = "enter"; ac.pt = 0; }
    if (ac.slot !== SLOT.get(a.id)) { ac.slot = SLOT.get(a.id); moved = true; } ac.a = a; }
  for (const [id, ac] of actors) if (!ids.has(id) && ac.ph !== "exit") { ac.ph = "exit"; ac.pt = 0; }
  if (moved) placeChips();
}
function deliver(id, kind, nodeId) { const ac = actors.get(id); if (!ac) return; ac.dt = performance.now(); ac.kind = kind;
  const d = DESKS[ac.slot]; if (!d) return; const col = ZONE[ac.a.zone][1]; floorPulse(d.x, d.y + d.h * .18, col);
  const to = nodeId ? nodePos(nodeId) : { x: ORB.x, y: ORB.y }; for (let i = 0; i < 6; i++) PARTS.push({ x0: d.x, y0: d.y - d.h * .45, x1: ORB.x, y1: ORB.y, t: -i * .07, col, then: i === 5 ? () => orbIngest(col, to) : null }); }
const PARTS = [];
function drawParts(dt) { if (!PARTS.length) return; X.save(); X.globalCompositeOperation = "lighter";
  for (let i = PARTS.length - 1; i >= 0; i--) { const p = PARTS[i]; p.t += dt / .9; if (p.t < 0) continue; if (p.t >= 1) { PARTS.splice(i, 1); if (p.then) p.then(); continue; }
    const u = p.t, cx = (p.x0 + p.x1) / 2, cy = Math.min(p.y0, p.y1) - 40 * k, x = (1 - u) * (1 - u) * p.x0 + 2 * (1 - u) * u * cx + u * u * p.x1, y = (1 - u) * (1 - u) * p.y0 + 2 * (1 - u) * u * cy + u * u * p.y1;
    X.globalAlpha = Math.sin(Math.PI * u); X.fillStyle = p.col; X.beginPath(); X.arc(x, y, 2.4 * k, 0, 7); X.fill(); }
  X.restore(); }
function drawAgents(t, dt, now) {
  let focus = null, best = -1; const list = [...actors.values()].sort((p, q) => (DESKS[p.slot] || {}).y - (DESKS[q.slot] || {}).y);
  for (const ac of list) { const d = DESKS[ac.slot]; if (!d) { actors.delete(ac.id); continue; } const z = ZONE[ac.a.zone][1];
    ac.pt += dt; if (ac.ph === "enter" && ac.pt > 1.9) { ac.ph = "work"; ac.pt = 0; } if (ac.ph === "exit" && ac.pt > 1.6) { actors.delete(ac.id); continue; }
    const ch = Math.min(d.h * .8, 78 * k), feet = d.y + d.h * .18, x = d.x, s = ch / 96;
    const tp = ac.ph === "enter" ? Math.min(1, ac.pt / .85) : ac.ph === "exit" ? Math.max(0, 1 - Math.max(0, ac.pt - .7) / .85) : 1, vis = Math.max(0, Math.min(1, (tp - .3) / .55));
    if ((ac.ph === "enter" && ac.pt < .85) || (ac.ph === "exit" && ac.pt > .7)) beam(x, feet, z, ac.ph === "enter" ? ac.pt / .85 : (ac.pt - .7) / .85, s);
    const seated = ac.ph === "work"; ac.sit = Math.max(0, Math.min(1, ac.sit + (seated ? 1 : -1.5) * dt / .32));            // mesa: encender 320 ms, apagar 240 ms
    const pulse = RM.matches ? 0 : Math.sin(t * Math.PI * 2 / 1.8) * .08, deskA = (.7 + pulse) * ac.sit;
    if (ac.sit > .01) { X.save(); X.globalCompositeOperation = "lighter"; light("focus", x, feet, ch * .9, ch * .25, .35 * ac.sit); X.restore(); }
    const breath = RM.matches ? 0 : Math.sin(t * Math.PI * 2 / 2.2 + ac.slot) * 2 * s * (seated ? 1 : 0);
    const delivering = now - (ac.dt || 0) < 1100, think = seated && !delivering && (ac.a.zone === "pensar" || now - (ac.dt || 0) > 180e3);
    let pose = ac.ph === "enter" && ac.pt > .85 ? "talk" : ac.ph === "exit" && ac.pt < .7 ? "talk" : "work"; if (!(window.NAVE_ATLAS || {})[ac.a.sprite + "." + pose]) pose = "work";
    if (vis > 0) { X.save(); X.translate(x, feet); X.scale(.35 + .65 * Math.pow(vis, .6), 1 + (1 - vis) * .35); X.translate(-x, -feet);
      spr(ac.a.sprite + "." + pose, x, feet - breath, ch, { alpha: vis }); X.restore(); }
    if (ac.sit > .01) spr("desk.on", x, feet + ch * .2, ch * .46, { alpha: Math.min(.78, Math.max(.62, deskA)) * ac.sit });     // la mesa por delante de las piernas
    { const dd = Math.hypot(x - ORB.x, feet - ORB.y), kk = 1 / (1 + (dd / (SH * .55)) ** 2); X.save(); X.globalCompositeOperation = "lighter"; light("warm", x, feet - ch * .55, ch * .7, ch * .75, .16 * kk * vis); X.restore(); }   // luz local del orbe: cae con la distancia
    if (ac.sit > .5) screen(x + ch * .46, feet - ch * 1.02, ch * .82, ch * .5, ac, z, t, delivering);
    if ((ac.ph === "enter" && ac.pt > .95) || (ac.ph === "exit" && ac.pt < .7)) bubble(x + ch * .32, feet - ch * 1.05, ac.ph === "enter" ? "¡Hola!" : "¡Hasta luego!", z, s);
    else if (think && ac.sit > .9 && !RM.matches) thought(x - ch * .36, feet - ch * 1.0, z, s, t);
    const sc = (ac.a.needsUser ? 1000 : 0) + (delivering ? 500 : 0) + (ac.a.pct || 0); if (seated && sc > best) { best = sc; focus = { ac, x, y: feet - ch * .6 }; }
    const el = CHIPS.querySelector(`[data-agent="${CSS.escape(ac.id)}"]`); if (el) el.style.opacity = String(Math.max(.15, vis)); }
  return focus;
}
function beam(x, y, col, p, s) { const kk = Math.sin(Math.PI * Math.min(1, Math.max(0, p))), H = 200 * s, w = 40 * s * (.55 + .45 * kk);
  X.save(); X.globalCompositeOperation = "lighter"; const g = X.createLinearGradient(0, y - H, 0, y); g.addColorStop(0, hexA(col, 0)); g.addColorStop(1, hexA(col, .7 * kk)); X.fillStyle = g; X.beginPath(); X.ellipse(x, y - H / 2, w / 2, H / 2, 0, 0, 7); X.fill();
  for (let i = 0; i < 2; i++) { const q = (p * 1.6 + i / 2) % 1; X.strokeStyle = hexA(col, (1 - q) * .8 * kk); X.lineWidth = 2 * s; X.beginPath(); X.ellipse(x, y, (12 + q * 50) * s, (4 + q * 14) * s, 0, 0, 7); X.stroke(); }
  X.restore(); }
function bubble(x, y, msg, col, s) { const r = Math.max(9, 10 * s); X.save(); X.font = `700 ${Math.round(r * 1.2)}px Inter,system-ui,sans-serif`; const w = X.measureText(msg).width;
  rr(X, x - r * .6, y - r, w + r * 1.2, r * 2, r); X.fillStyle = "rgba(232,228,220,.95)"; X.fill(); X.strokeStyle = col; X.lineWidth = 1.4; X.stroke(); X.fillStyle = T.bg900; X.textBaseline = "middle"; X.fillText(msg, x, y + 1); X.restore(); }
function thought(x, y, col, s, t) { const r = Math.max(8, 9 * s); X.save(); X.fillStyle = "rgba(232,228,220,.92)"; X.strokeStyle = col; X.lineWidth = 1.2;
  X.beginPath(); X.ellipse(x, y, r * 1.5, r, 0, 0, 7); X.fill(); X.stroke(); X.beginPath(); X.arc(x + r * 1.1, y + r * 1.4, r * .28, 0, 7); X.fill(); X.stroke();
  X.fillStyle = col; for (let q = 0; q < 3; q++) { X.globalAlpha = .35 + .65 * Math.max(0, Math.sin(t * Math.PI * 2 / 1.8 - q)); X.beginPath(); X.arc(x - r * .6 + q * r * .6, y, r * .18, 0, 7); X.fill(); } X.restore(); }
function screen(x, y, w, h, ac, col, t, hot) {                    // pantalla holográfica de la mesa: color de zona + avance (el texto legible va en el chip HTML)
  X.save(); X.globalAlpha = .9; rr(X, x, y, w, h, 6 * k); X.fillStyle = hexA(col, hot ? .26 : .16); X.fill(); X.strokeStyle = hexA(col, .8); X.lineWidth = 1; X.stroke();
  X.beginPath(); rr(X, x, y, w, h, 6 * k); X.clip(); X.strokeStyle = hexA(col, .7); X.lineWidth = 1.2;
  for (let i = 0; i < 3; i++) { const yy = y + h * (.25 + i * .2), ww = w * (.35 + .45 * hash(ac.id + i + Math.floor((RM.matches ? 0 : t) / 2.2))); X.beginPath(); X.moveTo(x + w * .1, yy); X.lineTo(x + w * .1 + ww, yy); X.stroke(); }
  if (ac.a.pct != null) { X.fillStyle = hexA(col, .9); X.fillRect(x + w * .1, y + h * .82, w * .8 * ac.a.pct / 100, 2.5); }
  X.restore(); }

/* ── orbe: núcleo marfil-gris con aletas; estados idle / focus / toplight / ingest; orbitales independientes ── */
const orb = { state: "idle", st: 0, x: 0, col: T.ingest, ring: [] };
function orbIngest(col, to) { orb.state = "ingest"; orb.st = 0; orb.col = col; orb.ring.push({ a: 0, col }); orb.to = to; }
function drawOrb(t, dt, focus) {
  const needs = S.agents.some(a => a.needsUser), still = RM.matches;
  if (orb.state === "ingest") { orb.st += dt; if (orb.st > 1.4) orb.state = "idle"; } else orb.state = needs ? "toplight" : focus ? "focus" : "idle";
  const tx = orb.state === "focus" && focus ? ORB.x + Math.max(-.08, Math.min(.08, (focus.x - ORB.x) / SW)) * SW : ORB.x; orb.x = orb.x ? orb.x + (tx - orb.x) * Math.min(1, dt / .9 * 2) : ORB.x;
  const fy = still ? 0 : Math.sin(t * Math.PI * 2 / 2.4) * 4 * k, sc = still ? 1 : 1 + (Math.sin(t * Math.PI * 2 / 2.4) + 1) * .01, x = orb.x, y = ORB.y + fy, core = ORB.core * sc;
  X.save(); X.globalCompositeOperation = "lighter";
  light("warm", x, y + core * .6, core * 2.4, core * 1.2, .55);                                                          // rebote cálido bajo el orbe
  if (orb.state === "toplight") { const p = still ? .7 : .55 + .45 * Math.sin(t * Math.PI * 2 / 1.2); light("focus", x, VAULT.y - VAULT.h * .1, core * 2.2, VAULT.h * .9, .5 * p); }
  if (orb.state === "focus" && focus) light("focus", focus.x, focus.y, core * 1.8, core * 1.3, .45);
  if (orb.state === "ingest" && orb.to) { const u = orb.st / 1.4; X.globalAlpha = .5 * (1 - u); X.strokeStyle = orb.col; X.lineWidth = 1.4; X.beginPath(); X.moveTo(x, y + core * .4); X.quadraticCurveTo(x, (y + orb.to.y) / 2, orb.to.x, orb.to.y); X.stroke(); }
  X.restore(); X.globalAlpha = 1;
  // orbitales: dos satélites en la envolvente, por delante o por detrás del núcleo según el ángulo
  const sats = [["sat.a", .42, 0, core * .5], ["sat.b", -.31, 2.1, core * .36]].map(([n, w, ph, h]) => { const a = (still ? 0 : t * w) + ph; return { n, h, x: x + Math.cos(a) * ORB.ex / 2, y: y + Math.sin(a) * ORB.ey / 2 * .55, front: Math.sin(a) > 0 }; });
  for (const s of sats) if (!s.front) spr(s.n, s.x, s.y, s.h, { center: true, alpha: .85 });
  spr(orb.state === "ingest" ? "orb.data" : orb.state === "idle" ? "orb.idle" : "orb.focus", x, y, core * 1.75, { center: true });
  for (const s of sats) if (s.front) spr(s.n, s.x, s.y, s.h, { center: true, alpha: .95 });
  for (let i = orb.ring.length - 1; i >= 0; i--) { const r = orb.ring[i]; r.a += dt; if (r.a > 1.4) { orb.ring.splice(i, 1); continue; } X.strokeStyle = hexA(r.col, .7 * (1 - r.a / 1.4)); X.lineWidth = 1.6; X.beginPath(); X.ellipse(x, y, core * (.6 + r.a), core * (.6 + r.a) * .5, 0, 0, 7); X.stroke(); }
}
function drawVoiceMeter(t) { const c = document.getElementById("vozc"); if (!c) return; const g = c.getContext("2d"), on = !!voiceTraining(); g.clearRect(0, 0, c.width, c.height);
  for (let i = 0; i < 20; i++) { const h = on && !RM.matches ? 4 + Math.abs(Math.sin(t * 6 + i * 1.3)) * 26 : 4; g.fillStyle = on ? "#E879F9" : T.metal; g.fillRect(4 + i * 10, (c.height - h) / 2, 6, h); } }

/* ── bucle: 24 fps móvil / 30 escritorio, pausa en segundo plano, movimiento reducido = solo cambios de estado ── */
let last = 0, lt = 0, running = true, raf = 0, ready = false;
const kick = () => { if (!raf && running && ready) raf = requestAnimationFrame(frame); };
function frame(ts) {
  raf = 0; if (!running) return; kick();
  const fps = RM.matches ? 6 : wide ? 30 : 24; if (ts - last < 1000 / fps - 2) return; last = ts;
  const t = ts / 1000, dt = lt ? Math.min(.1, t - lt) : 0; lt = t; const now = performance.now();
  X.setTransform(DPR, 0, 0, DPR, 0, 0); X.globalAlpha = 1; X.globalCompositeOperation = "source-over";
  X.drawImage(bgCache, 0, 0, SW, SH);
  graphStep(t, dt); if (graphDirty || now - graphAt > (RM.matches ? 2000 : 125)) { renderGraph(); graphAt = now; graphDirty = false; }
  X.drawImage(gCache, 0, 0, SW, SH); drawFlashes(now); drawHubLabels();
  drawFloor(dt); syncActors(); const focus = drawAgents(t, dt, now); drawParts(dt); drawOrb(t, dt, focus);
  if (wide && !RM.matches) drawVoiceMeter(t);
}
let inView = true;
document.addEventListener("visibilitychange", () => { running = !document.hidden && inView; if (running) { lt = 0; kick(); } });
if ("IntersectionObserver" in window) new IntersectionObserver(es => { for (const e of es) { inView = e.isIntersecting; running = inView && !document.hidden; if (running) { lt = 0; kick(); } } }).observe(STAGE);
addEventListener("resize", () => { clearTimeout(layout._t); layout._t = setTimeout(() => { layout(); renderHud(); }, 120); });
const load = src => new Promise(r => { const i = new Image(); i.onload = () => r(i); i.onerror = () => r(null); i.src = src; });
Promise.all([load("nave-bg.webp?v=3"), load("nave-atlas.webp?v=3")]).then(([bg, at]) => { IMG.bg = bg; IMG.atlas = at; layout(); ready = true; kick(); });
pull(); pullVault(); pullGta();
setInterval(() => { if (!document.hidden) pull(); }, 3000); setInterval(() => { if (!document.hidden) pullVault(); }, 2000); setInterval(() => { if (!document.hidden) pullGta(); }, 10000);
setInterval(() => { if (!document.hidden) { renderTele(); $("#clock").textContent = new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }); } }, 5000);
if (/[?&]dbg/.test(location.search)) window.__o = { S, actors, deliver, layout };
})();
