/* Faro · Oficina híbrida (2026-11-18): la nave (bóveda con posiciones reales de Obsidian, «70 Privado» aparte,
   parallax, sprites nuevos) + lo que la oficina clásica enseñaba de un vistazo (colores por zona, pantallas de cada
   agente, hilos que alimentan la bóveda, monitores de proyectos con avance, aviso de entrenamiento de voz) + un muelle
   que recibe lo que llega y lo eyecta hacia la bóveda o hacia el agente que lo procesa.
   Datos: api/status, api/machines, api/vault/live. Ligero: ≤30 fps, pausa en segundo plano. */
(() => {
"use strict";
const C = document.getElementById("c"), X = C.getContext("2d"), ST = document.getElementById("st");
const WW = 1344, WH = 752, WIN = { x0: 256, x1: 1080, y0: 148, y1: 428 };
const VC = { x: (WIN.x0 + WIN.x1) / 2, y: (WIN.y0 + WIN.y1) / 2 + 10 };
const PAL = { bg: "#0A131A", bg8: "#0F1E29", bg7: "#17303F", ivory: "#D4EAF7", silver: "#C3D6E3", metal: "#5C7384",
  orb: "#E3F3FC", bounce: "#A9D8F5", focus: "#D7F0E8", ingest: "#B9E7DA",
  gold: "#E9C37A", teal: "#66D9CE", violet: "#B39DDB", ok: "#7FD18B", run: "#E9C37A", bad: "#F2836B", amber: "#FFB347" };
/* zonas de la oficina clásica (mismos colores) */
const ZONES = {
  obsidian: { label: "Bóveda", c: "#aa9de8" }, web: { label: "Web", c: "#60a5fa" }, write: { label: "Escribe", c: "#f29b9d" },
  voice: { label: "Voz", c: "#f29b7d" }, code: { label: "Código", c: "#7fd3a6" }, edit: { label: "Edición", c: "#fb923c" },
  image: { label: "Imagen", c: "#f2c078" }, system: { label: "Sistema", c: "#94a3b8" }, think: { label: "Piensa", c: "#d7f0e8" } };
const ACTION_ZONE = { codigo: "code", "código": "code", editar: "edit", pensar: "think", buscar: "web", escribir: "write", correo: "write",
  voz: "voice", audio: "voice", imagen: "image", sistema: "system", obsidian: "obsidian", "bóveda": "obsidian", web: "web", code: "code",
  edit: "edit", write: "write", skills: "code", mail: "write", voice: "voice", image: "image", system: "system", think: "think", cards: "write" };
function zoneOf(a) {
  const ak = String(a.action || "").toLowerCase(); if (ACTION_ZONE[ak]) return ACTION_ZONE[ak];
  const t = ((a.task || "") + " " + (a.name || "") + " " + (a.step || "")).toLowerCase();
  if (/\bvoz\b|voces|audio|narra|locuci|chatterbox|tts|transcrib|lora/.test(t)) return "voice";
  if (/sprite|imagen|im[aá]genes|ilustra|higgsfield|logo|icono|cartel|miniatura|manga/.test(t)) return "image";
  if (/render|v[ií]deo|clip|reel|ffmpeg|montaje|davinci|premiere|blender|gancho/.test(t)) return "edit";
  if (/c[oó]digo|script|bug|program|repositorio|github|api|deploy|backtest|freqtrade|build|faro|oficina/.test(t)) return "code";
  if (/b[oó]veda|obsidian|nota|enlace|biblioteca|s[ií]ntesis/.test(t)) return "obsidian";
  if (/instala|actualiza|configura|copia|mueve|backup|reinicia|carpeta|descarga|gpu|servidor/.test(t)) return "system";
  if (/busca|investiga|noticias|compara|precio|mercado|radar|licitaci/.test(t)) return "web";
  if (/correo|email|gmail|escribe|redacta|propuesta|guion|texto|post|plan/.test(t)) return "write";
  return "think";
}
const GTA_ST = [["FUENTES", 0], ["GUION", 1], ["ITV GUION", 5], ["VOZ", 3], ["CAPTURA", 2], ["RÓTULOS", 12], ["MONTAJE", 4], ["ITV VÍDEO", 7], ["TALLER", 6], ["EMPAQUE", 8], ["PEAJE", 9], ["PUBLICADO", 10]];
const GTA_IDX = {}; GTA_ST.forEach((s, i) => GTA_IDX[s[1]] = i);
const PROJ = [["gta", "GTA VI", "panel.gta", "#ff4fd8"], ["chf", "CHF", "panel.chf", "#39ff88"], ["ingresos", "Ingresos", "panel.ingresos", "#C3D6E3"],
  ["agentes", "Agentes", "panel.agentes", "#7cf5ff"], ["biblioteca", "Biblioteca", "panel.biblioteca", "#aa9de8"], ["mimo", "Mimo", "panel.mimo", "#78c798"], ["faro", "Faro", "panel.core", "#f2c078"]];

const FPS = 30; let DPR = Math.min(2, window.devicePixelRatio || 1), LS = 0, RS = 0, HU = 1, BAND = 0;
let BH = 0, W = 0, H = 0, S = 1, OX = 0, OY = 0, portrait = false, hudY = 0;
const IMG = {}, AT = {}; let atlasImg = null;
const state = { hist: {}, plist: [], agents: [], status: {}, machines: {}, build: {}, voz: {}, gta: {}, graph: null, seq: 0, gv: 0, flashes: new Map(), t0: performance.now(), orders: 0 };
const actors = new Map();
const parts = [];      // partículas de los hilos
const cargo = []; if (/dbg/.test(location.search)) window.__h = { actors, state };      // paquetes del muelle

function load(src) { return new Promise(r => { const i = new Image(); i.onload = () => r(i); i.onerror = () => r(null); i.src = src; }); }
Promise.all([load("nave-bg.webp?v=3"), load("nave-atlas.webp?v=3")]).then(([bg, at]) => { IMG.bg = bg; atlasImg = at; Object.assign(AT, window.NAVE_ATLAS || {}); resize(); requestAnimationFrame(loop); });

function spr(name, x, y, h, opt = {}) {
  const a = AT[name]; if (!a || !atlasImg) return 0;
  const w = a[2] * h / a[3], ay = opt.center ? 0.5 : 1;
  X.save(); if (opt.alpha != null) X.globalAlpha = opt.alpha; if (opt.filter) X.filter = opt.filter;
  if (opt.flip) { X.translate(x, 0); X.scale(-1, 1); x = 0; }
  X.drawImage(atlasImg, a[0], a[1], a[2], a[3], x - w * .5, y - h * ay, w, h); X.restore(); return w;
}

/* ── cámara ── */
function resize() {
  const r = C.getBoundingClientRect(), vv = window.visualViewport;
  W = Math.max(200, Math.round(r.width || innerWidth)); H = Math.max(200, Math.round((vv && vv.height < r.height ? vv.height : r.height) || innerHeight));
  DPR = Math.min(2, window.devicePixelRatio || 1, Math.max(1, Math.sqrt(5.2e6 / (W * H))));
  C.width = Math.round(W * DPR); C.height = Math.round(H * DPR);
  const a = W / H, cl = (v, lo, hi) => Math.max(lo, Math.min(hi, v)), safeT = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--sat")) || 0;
  portrait = a < 1.18; DOCKP(); LS = RS = BAND = BH = 0;
  if (portrait) {                                                 // apilado: escena arriba, lectura rápida debajo
    const k = cl((a - .6) / .4, 0, 1), VW = (WIN.x1 - WIN.x0) + 120 + (WW - (WIN.x1 - WIN.x0) - 120) * k;
    S = W / VW; OX = W / 2 - (WIN.x0 + WIN.x1) / 2 * S; OY = 44 + safeT; HU = cl(W / 520, 1, 1.4);
    const sceneH = (WH - 10) * S, hudMin = Math.min(330 * HU, H * .4); if (OY + sceneH > H - hudMin) OY = Math.max(H - hudMin - sceneH, -70 * S);
    hudY = OY + sceneH;
  } else {                                                        // apaisado: la escena cubre la ventana; los paneles se anclan a los bordes
    BH = Math.round(cl(H * .19, 84, 156)); const Hs = H - BH + 6;
    HU = 1; S = Math.max(W / WW, Hs / WH); S = Math.min(S, Hs / 700);
    OX = (W - WW * S) / 2; OY = Hs - WH * S; hudY = Hs; BAND = Math.max(0, OX / S);
    if (OX > 0) { LS = -Math.min(Math.max(0, BAND - 10), 236); RS = Math.min(Math.max(0, BAND - 10), 190); }
    else { LS = Math.max(0, (10 - OX) / S - 18); RS = Math.min(0, (W - 8 - OX) / S - 1300); }
  }
  if (/dbg/.test(location.search)) document.title = [W,H,innerWidth,innerHeight,window.visualViewport&&visualViewport.height,DPR,S.toFixed(3),OY,hudY,HU].join(",");
  buildStars();
}
const reflow = () => { clearTimeout(resize._t); resize._t = setTimeout(resize, 120); };
addEventListener("resize", reflow); addEventListener("orientationchange", reflow); if (window.visualViewport) visualViewport.addEventListener("resize", reflow);

/* ── espacio lejano ── */
let stars = null;
function buildStars() {
  stars = document.createElement("canvas"); stars.width = Math.ceil(W * DPR * 1.2); stars.height = Math.ceil(H * DPR * 1.2);
  const s = stars.getContext("2d"), rnd = mulberry(7);
  s.fillStyle = PAL.bg; s.fillRect(0, 0, stars.width, stars.height);
  for (let g = 0; g < 3; g++) { const gx = rnd() * stars.width, gy = rnd() * stars.height * .6, r = (60 + rnd() * 120) * DPR;
    const gr = s.createRadialGradient(gx, gy, 0, gx, gy, r), c = [PAL.teal, PAL.violet, PAL.gold][g];
    gr.addColorStop(0, hexA(c, .16)); gr.addColorStop(1, hexA(c, 0)); s.fillStyle = gr; s.beginPath(); s.ellipse(gx, gy, r, r * .45, rnd() * 3, 0, 7); s.fill(); }
  for (let i = 0; i < 420; i++) { s.fillStyle = hexA(PAL.ivory, .15 + rnd() * .55); const z = rnd() < .08 ? 1.6 : .8; s.fillRect(rnd() * stars.width, rnd() * stars.height, z * DPR, z * DPR); }
}

/* ── galaxia de la bóveda (posiciones reales; privada aparte) ── */
let G = null;
function buildGraph(g) {
  if (!g || !g.nodes || !g.nodes.length) return;
  const N = g.nodes, priv = N.map(n => (n.dir || "").startsWith("70 Privado") || (n.id || "").startsWith("70 Privado"));
  const deg = new Array(N.length).fill(0); for (const [a, b] of g.edges) { deg[a]++; deg[b]++; }
  const maxd = Math.max(1, ...deg); let pcx = 0, pcy = 0, pn = 0;
  N.forEach((n, i) => { if (priv[i]) { pcx += n.x; pcy += n.y; pn++; } }); if (pn) { pcx /= pn; pcy /= pn; }
  const pts = N.map((n, i) => { const d = deg[i] / maxd, h = hash(n.id || String(i));
    let x = n.x - .5, y = n.y - .5, z = (h - .5) * .35 - d * .25;
    if (priv[i]) { x = (n.x - pcx) * .45 + .62; y = (n.y - pcy) * .45 - .28; z = -.55 + (h - .5) * .12; }
    return { x, y, z, h: n.h || 0, r: 1.1 + Math.sqrt(d) * 5.5, col: d > .45 ? PAL.gold : d > .12 ? PAL.teal : PAL.violet, priv: priv[i], id: n.id, sx: VC.x, sy: VC.y, ss: 1 }; });
  const adj = N.map(() => []); for (const [a, b] of g.edges) { adj[a].push(b); adj[b].push(a); }
  G = { pts, adj, edges: g.edges, hubs: deg.map((d, i) => [d, i]).sort((a, b) => b[0] - a[0]).slice(0, 10).map(t => t[1]), index: new Map(N.map((n, i) => [n.id, i])) };
}
const dots = {};
function dot(col) { if (dots[col]) return dots[col]; const c = document.createElement("canvas"), R = 32; c.width = c.height = R * 2;
  const s = c.getContext("2d"), g = s.createRadialGradient(R, R, 0, R, R, R);
  g.addColorStop(0, "#fff"); g.addColorStop(.12, col); g.addColorStop(.35, hexA(col, .35)); g.addColorStop(1, hexA(col, 0));
  s.fillStyle = g; s.fillRect(0, 0, R * 2, R * 2); return dots[col] = c; }
function drawGalaxy(t) {
  if (!G) return;
  const R = (WIN.x1 - WIN.x0) * .95, yaw = Math.sin(t * .068) * .45 + t * .018, pitch = -.22 + Math.sin(t * .046) * .06;
  const cyw = Math.cos(yaw), syw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch), f = 900;
  for (const p of G.pts) { const x = p.x * R * 1.25, y = p.y * R, z = p.z * R;
    const x1 = x * cyw + z * syw; let z1 = -x * syw + z * cyw; const y1 = y * cp - z1 * sp; z1 = y * sp + z1 * cp;
    const k = f / (f + z1 + 260); p.sx = VC.x + x1 * k; p.sy = VC.y + y1 * k; p.ss = k; }
  X.save(); X.beginPath(); X.rect(WIN.x0, WIN.y0, WIN.x1 - WIN.x0, WIN.y1 - WIN.y0); X.clip(); X.globalCompositeOperation = "lighter";
  X.lineWidth = .6; X.strokeStyle = hexA(PAL.silver, .07); X.beginPath();
  for (const [a, b] of G.edges) { const A = G.pts[a], B = G.pts[b]; X.moveTo(A.sx, A.sy); X.lineTo(B.sx, B.sy); } X.stroke();
  const now = performance.now();
  // partes consultadas: enlaces del nodo activo con el color del agente
  for (const [id, fl] of state.flashes) { const age = now - fl.t; if (age > 7000) { state.flashes.delete(id); continue; }
    const i = G.index.get(id); if (i == null) continue; const b = Math.max(0, 1 - age / 7000), A = G.pts[i];
    X.strokeStyle = hexA(fl.col, .55 * b); X.lineWidth = 1.4; X.beginPath(); const nb = G.adj[i];
    for (let k = 0; k < nb.length && k < 40; k++) { const B = G.pts[nb[k]]; X.moveTo(A.sx, A.sy); X.lineTo(B.sx, B.sy); B.nb = now; B.nbc = fl.col; } X.stroke(); }
  for (const p of G.pts) { const fl = state.flashes.get(p.id), boost = fl ? Math.max(0, 1 - (now - fl.t) / 5000) : 0;
    if (boost > 0) { const kk = boost * boost * 5; p.sx += Math.sin(now * .021 + p.r * 9) * kk; p.sy += Math.cos(now * .017 + p.r * 5) * kk; }   // energía cinética
    const near = p.nb && now - p.nb < 400 ? .5 : 0;
    const r = (p.r * p.ss) * (1 + boost * 2.4 + near * .5); X.globalAlpha = Math.min(1, .45 + p.ss * .4 + boost + near * .3) * (p.priv ? .75 : 1);
    if (p.h > .35 && !p.priv) { const hr = r * (2 + p.h * 2.5); X.globalAlpha = .1 + p.h * .22 + Math.sin(now * .002 + p.r) * .04; X.drawImage(dot(PAL.amber), p.sx - hr * 3, p.sy - hr * 3, hr * 6, hr * 6); X.globalAlpha = Math.min(1, .45 + p.ss * .4 + boost); }   // zona caliente
    X.drawImage(dot(boost > .05 ? fl.col : near ? p.nbc : p.col), p.sx - r * 3, p.sy - r * 3, r * 6, r * 6);
    if (boost > .3 && fl.k !== "read") { X.strokeStyle = hexA(fl.col, boost * .8); X.lineWidth = 1.5; X.beginPath(); X.arc(p.sx, p.sy, r * 3 + (1 - boost) * 26, 0, 7); X.stroke(); } }
  X.globalAlpha = 1; X.globalCompositeOperation = "source-over";
  for (const i of G.hubs) { const p = G.pts[i]; spr(p.col === PAL.gold ? "node.gold.m" : "node.teal.m", p.sx, p.sy, 18 * p.ss + 6, { center: true, alpha: .9 }); }
  X.restore();
}
function nodePos(id) { if (G && id != null && G.index.has(id)) { const p = G.pts[G.index.get(id)]; return { x: p.sx, y: p.sy }; }
  if (G && id) { let k = String(id); while (k.includes("/")) { k = k.slice(0, k.lastIndexOf("/")); for (const [nid, i] of G.index) if (nid.startsWith(k + "/")) { const p = G.pts[i]; return { x: p.sx, y: p.sy }; } } }
  return { ...VC }; }

/* ── orbe: persigue, enfoca, pulsa al recibir ── */
const orb = { x: 672, y: 112, tx: 672, pulse: 0, rings: [] };
function orbStep(t, dt, focus) {
  orb.tx = focus ? Math.max(380, Math.min(960, focus.x)) : 672 + Math.sin(t * .23) * 120;
  orb.x += (orb.tx - orb.x) * Math.min(1, dt * .9); orb.y = 112 + Math.sin(t * .9) * 9;
  orb.pulse = Math.max(0, orb.pulse - dt * 1.4);
  for (const r of orb.rings) r.a += dt; while (orb.rings.length && orb.rings[0].a > 1.6) orb.rings.shift();
}
function orbHit(col) { orb.pulse = 1; orb.rings.push({ a: 0, col: col || PAL.ingest }); }
function drawOrb(t, focus) {
  const o = orb, name = o.pulse > .2 ? "orb.data" : focus ? "orb.focus" : "orb.idle", sc = 1 + o.pulse * .18 + Math.sin(t * 2.2) * .03;
  X.save(); X.globalCompositeOperation = "lighter";
  for (const r of o.rings) { X.globalAlpha = Math.max(0, .5 - r.a * .3); X.strokeStyle = r.col; X.lineWidth = 2; X.beginPath(); X.ellipse(o.x, o.y, 30 + r.a * 90, (30 + r.a * 90) * .32, 0, 0, 7); X.stroke(); }
  X.restore();
  for (let k = 0; k < 3; k++) { const a = t * (.9 + k * .35) + k * 2.1, rx = 70 + k * 22, sx = o.x + Math.cos(a) * rx, sy = o.y + Math.sin(a) * 18;
    if (Math.sin(a) < 0) spr(k % 2 ? "sat.b" : "sat.a", sx, sy, 22 - k * 3, { center: true, alpha: .8 }); }
  spr(name, o.x, o.y, 58 * sc, { center: true });
  for (let k = 0; k < 3; k++) { const a = t * (.9 + k * .35) + k * 2.1, rx = 70 + k * 22, sx = o.x + Math.cos(a) * rx, sy = o.y + Math.sin(a) * 18;
    if (Math.sin(a) >= 0) spr(k % 2 ? "sat.b" : "sat.a", sx, sy, 26 - k * 3, { center: true }); }
}
function drawLight(t, focus) {
  const o = orb; X.save(); X.globalCompositeOperation = "lighter";
  let g = X.createRadialGradient(o.x, o.y, 10, o.x, o.y, 640);
  g.addColorStop(0, hexA(PAL.bounce, .2 + o.pulse * .15)); g.addColorStop(.25, hexA(PAL.bounce, .07)); g.addColorStop(1, hexA(PAL.bounce, 0));
  X.fillStyle = g; X.fillRect(0, 0, WW, WH);
  if (focus) { const fy = focus.y - 10; X.globalAlpha = .5 + Math.sin(t * 2) * .1;
    const beam = X.createLinearGradient(o.x, o.y, focus.x, fy); beam.addColorStop(0, hexA(PAL.focus, .2)); beam.addColorStop(1, hexA(PAL.focus, .02));
    X.fillStyle = beam; X.beginPath(); X.moveTo(o.x - 8, o.y); X.lineTo(focus.x - 70, fy + 14); X.lineTo(focus.x + 70, fy + 14); X.lineTo(o.x + 8, o.y); X.fill();
    g = X.createRadialGradient(focus.x, fy, 0, focus.x, fy, 100); g.addColorStop(0, hexA(PAL.focus, .3)); g.addColorStop(1, hexA(PAL.focus, 0));
    X.fillStyle = g; X.beginPath(); X.ellipse(focus.x, fy + 10, 100, 30, 0, 0, 7); X.fill(); }
  X.restore();
}

/* ── hilos: agente → orbe → bóveda ── */
function spawn(x0, y0, x1, y1, col, dur, then, glyph) {
  const mx = (x0 + x1) / 2 + (Math.random() - .5) * 80, my = Math.min(y0, y1) - 40 - Math.random() * 60;
  if (parts.length > 60) parts.shift(); parts.push({ x0, y0, x1, y1, cx: mx, cy: my, t: 0, dur, col, then, glyph });
}
function bez(p, u) { const a = (1 - u) * (1 - u), b = 2 * (1 - u) * u, c = u * u; return [a * p.x0 + b * p.cx + c * p.x1, a * p.y0 + b * p.cy + c * p.y1]; }
function drawThreads(dt) {
  X.save(); X.globalCompositeOperation = "lighter";
  for (const ac of actors.values()) if (ac.seated) {            // hilo tenue permanente del puesto al orbe
    const z = ZONES[ac.zone] || ZONES.think; X.strokeStyle = hexA(z.c, .34); X.lineWidth = 2;
    X.beginPath(); X.moveTo(ac.sx, ac.sy); X.quadraticCurveTo((ac.sx + orb.x) / 2, Math.min(ac.sy, orb.y) - 30, orb.x, orb.y + 18); X.stroke(); }
  X.strokeStyle = hexA(PAL.ingest, .26); X.lineWidth = 2; X.beginPath(); X.moveTo(orb.x, orb.y); X.quadraticCurveTo(orb.x, (orb.y + VC.y) / 2 + 30, VC.x, VC.y); X.stroke();
  for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t += dt / p.dur;
    if (p.t >= 1) { parts.splice(i, 1); if (p.then) p.then(); continue; }
    for (let k = 0; k < 4; k++) { const u = Math.max(0, p.t - k * .025), [x, y] = bez(p, u), r = 7 - k * 1.4; X.globalAlpha = .9 - k * .2; X.drawImage(dot(p.col), x - r, y - r, r * 2, r * 2); }
    if (p.glyph) { const [x, y] = bez(p, p.t); X.globalCompositeOperation = "source-over"; X.globalAlpha = 1; X.fillStyle = p.col; X.beginPath(); X.arc(x, y, 9, 0, 7); X.fill(); X.fillStyle = PAL.bg; X.font = "700 12px system-ui,sans-serif"; X.textAlign = "center"; X.textBaseline = "middle"; X.fillText(p.glyph, x, y + 1); X.globalCompositeOperation = "lighter"; } }
  X.restore();
}
let nextFeed = 0;
function feed(t) {                                               // ritmo de alimentación según actividad
  if (t < nextFeed) return; const seated = [...actors.values()].filter(a => a.seated); nextFeed = t + (seated.length ? 1.6 / Math.min(4, seated.length) : 4);
  if (!seated.length) return; const ac = seated[Math.floor(Math.random() * seated.length)], col = (ZONES[ac.zone] || ZONES.think).c;
  spawn(ac.sx, ac.sy, orb.x, orb.y + 14, col, 1.6, () => { orbHit(col); const n = nodePos(null); spawn(orb.x, orb.y + 14, n.x, n.y, col, 1.4); });
}

/* ── muelle de carga: recibe y eyecta ── */
const DOCK = { x: 1040, y: 512 }; let dockFlash = 0;
function DOCKP() { const pt = portrait; DOCK.x = pt ? 300 : 1040; DOCK.y = pt ? 522 : 512; }
const DEMO_VOZ = /[?&]demo=voz/.test(location.search), DEMO_N = +((location.search.match(/[?&]demo=(\d+)/) || [])[1] || 0);
/* cada envío sale de la mesa del agente que lo origina (o entra de fuera si viene de Nawe), pasa por la lanzadera y sale a su destino real */
function receive(kind, col, target, origin) { const o = origin && origin.x != null ? origin : { x: WW + 60, y: -40 }; if (cargo.length > 14) cargo.shift(); cargo.push({ kind, col, target, ph: 0, t: 0, x: o.x, y: o.y, from: !!origin }); }
function actorFor(w) { if (!w) return null; const k = String(w).toLowerCase().split(/[\s·]/)[0]; if (!k) return null; let best = null;
  for (const ac of actors.values()) if (ac.seated && ((ac.a.name || "") + " " + (ac.a.brand || "")).toLowerCase().includes(k)) { if (!best || (ac.lastAct || 0) < (best.lastAct || 0)) best = ac; } return best; }
function deskOf(ac) { return ac ? { x: ac.sx || ac.x, y: ac.sy || ac.y - 70 } : null; }
function vaultEvent(e, ac) {
  const id = String(e.p || "").replace(/\.md$/, ""), now = performance.now(); ac = ac || actorFor(e.who || e.maybe);
  const who = String(e.who || e.maybe || "").trim(), bc = BRANDC[(who.toLowerCase().match(/claude|gpt|codex|hermes|strata|faro|nawe/) || [""])[0]] || PAL.ingest;
  const col = ac ? (ZONES[ac.zone] || ZONES.think).c : bc; state.flashes.set(id, { t: now - (e.ago || 0) * 1000, col, k: e.k });
  if (e.quiet) return; if (ac) ac.lastAct = now;
  if (!ac && who) { dockTag = { txt: who.split("·")[0].trim().slice(0, 18), t: now, col }; }
  if (e.k === "read") { if (!ac && who) { const n = nodePos(id); spawn(n.x, n.y, DOCK.x, DOCK.y - 30, col, 1.3, () => { dockFlash = 1; }); }
    if (ac) { const n = nodePos(id), d = deskOf(ac); spawn(n.x, n.y, d.x, d.y, col, 1.3, () => { ac.lastTalk = performance.now(); }); } return; }
  const inbox = id.match(/_agentes\/inbox\/([^/]+)\//), kind = inbox ? "order" : /adjuntos|outbox|\.(png|jpg|mp4|mp3|wav|json|pdf)$/i.test(e.p) ? "file" : "vault";
  receive(kind, col, () => { const to = inbox && actorFor(inbox[1]); if (to) return { ...deskOf(to), ac: to }; return { ...nodePos(id), vault: true }; }, deskOf(ac) || (who ? { x: DOCK.x, y: DOCK.y - 60 } : null));
}
const DEMO_SET = [["Claude · Oficina de Faro", "claude", "codigo", "faro", 1], ["Hermes · Tanda de lanzamiento", "hermes", "editar", "gta", 0], ["GPT · Diseño de sprites", "gpt", "imagen", "faro", 1],
  ["Codex · Insertos en gta.py", "codex", "codigo", "gta", 1], ["Strata · Síntesis local", "strata", "sistema", "biblioteca", 0], ["Bibliotecario · Limpieza de la bóveda", "", "obsidian", "agentes", 0],
  ["Jardinero · Mimo", "", "escribir", "mimo", 1], ["Investigación · Radar", "", "buscar", "gta", 1], ["Hermes · Entreno de voz", "hermes", "voz", "gta", 0],
  ["Claude · Campaña de ingresos", "claude", "correo", "ingresos", 1], ["GPT · Textos de CHF", "gpt", "escribir", "chf", 1], ["Agente · Copias", "", "sistema", "agentes", 0]];
function demoAgents() { const t = Date.now() / 1000; return DEMO_SET.slice(0, DEMO_N).map((d, i) => ({ id: "demo-" + i, name: d[0], brand: d[1], action: d[2], project: d[3], cloud: !!d[4], state: "run",
  pct: Math.floor((t / (5 + i) + i * 13) % 100), task: d[0].split("·")[1].trim(), at: new Date().toISOString() })); }
let demoNext = 0;
function demoTick(t) { if (t < demoNext || !G) return; demoNext = t + .9; const se = [...actors.values()].filter(a => a.seated); if (!se.length) return;
  const ac = se[Math.floor(Math.random() * se.length)], p = G.pts[Math.floor(Math.random() * G.pts.length)]; vaultEvent({ p: p.id, k: Math.random() < .55 ? "read" : "write" }, ac); }
const BRANDC = { claude: "#f0a35e", gpt: "#8fc7ff", codex: "#8fc7ff", hermes: "#66D9CE", strata: "#7fd3a6", faro: "#E9C37A", nawe: "#E3F3FC" }; let dockTag = null;
const GLYPH = { vault: "✎", order: "✉", agent: "▶", pct: "%", file: "▤" };
function drawDock(t, dt) {
  dockFlash = Math.max(0, dockFlash - dt * 1.5);
  X.save(); X.globalCompositeOperation = "lighter"; const gr = X.createRadialGradient(DOCK.x, DOCK.y - 18, 0, DOCK.x, DOCK.y - 18, 70);
  gr.addColorStop(0, hexA(PAL.teal, .18 + dockFlash * .4)); gr.addColorStop(1, hexA(PAL.teal, 0)); X.fillStyle = gr; X.fillRect(DOCK.x - 80, DOCK.y - 90, 160, 120); X.restore();
  spr("hub", DOCK.x, DOCK.y, 46);
  if (dockTag) { const age = (performance.now() - dockTag.t) / 1000; if (age > 3.5) dockTag = null; else { X.save(); X.globalAlpha = Math.min(1, (3.5 - age) * 1.2); X.font = "700 13px system-ui,sans-serif"; X.textAlign = "center"; X.textBaseline = "middle";
      const tw = X.measureText(dockTag.txt).width + 14; X.fillStyle = "rgba(8,16,23,.85)"; rr(DOCK.x - tw / 2, DOCK.y - 74, tw, 20, 8); X.fill(); X.strokeStyle = hexA(dockTag.col, .8); X.lineWidth = 1.5; rr(DOCK.x - tw / 2, DOCK.y - 74, tw, 20, 8); X.stroke();
      X.fillStyle = PAL.ivory; X.fillText(dockTag.txt, DOCK.x, DOCK.y - 64); X.restore(); } }
  X.save(); X.strokeStyle = hexA(PAL.teal, .35 + dockFlash * .5); X.lineWidth = 2; X.beginPath(); X.ellipse(DOCK.x, DOCK.y - 26, 26 + Math.sin(t * 3) * 2, 8, 0, 0, 7); X.stroke(); X.restore();
  for (let i = cargo.length - 1; i >= 0; i--) { const c = cargo[i]; c.t += dt;
    if (c.ph === 0) { const k = Math.min(1, dt * 2.6); c.x += (DOCK.x - c.x) * k; c.y += (DOCK.y - 30 - c.y) * k; if (Math.hypot(DOCK.x - c.x, DOCK.y - 30 - c.y) < 4) { c.ph = 1; c.t = 0; dockFlash = 1; } }
    else if (c.ph === 1) { c.y = DOCK.y - 30 + Math.sin(c.t * 18) * 2; if (c.t > .45) {                // eyección
      const to = c.target(); cargo.splice(i, 1); spawn(DOCK.x, DOCK.y - 34, to.x, to.y, c.col, 1.2, () => { if (to.vault) { orbHit(c.col); } if (to.ac) to.ac.lastTalk = performance.now(); if (to.proj) projHit[to.proj] = performance.now(); }, GLYPH[c.kind]); continue; } }
    X.save(); X.globalCompositeOperation = "lighter"; X.drawImage(dot(c.col), c.x - 16, c.y - 16, 32, 32); X.restore();
    X.save(); X.font = "700 14px system-ui,sans-serif"; X.textAlign = "center"; X.textBaseline = "middle"; X.fillStyle = PAL.bg; X.fillText(GLYPH[c.kind] || "•", c.x, c.y + 1); X.restore(); }
}

/* ── agentes, mesas y pantallas ── */
const SPRITES = [["claude", "claude"], ["chatgpt", "gpt"], ["gpt", "gpt"], ["hermes", "hermes"], ["codex", "codex"], ["strata", "strata"],
  ["bibliotec", "librarian"], ["jardin", "gardener"], ["mimo", "gardener"], ["investig", "researcher"]];
function spriteFor(a) { const s = ((a.name || "") + " " + (a.brand || "") + " " + (a.expert || "")).toLowerCase(); for (const [k, v] of SPRITES) if (s.includes(k)) return v; return "generic"; }
const LAY = { big: 1, scr: 1, rows: 1 };
function slots(n) {                                             // filas en arco por profundidad: al fondo menos y más pequeños; filas alternas al tresbolillo
  const per = portrait ? 4 : 6, rows = Math.max(1, Math.ceil(n / per)), cx = portrait ? 668 : 690, span = portrait ? 780 : 800;
  const ys = portrait ? [[640], [590, 712], [562, 646, 730]][Math.min(2, rows - 1)] : [[640], [596, 706], [575, 645, 715]][Math.min(2, rows - 1)];
  LAY.rows = rows; LAY.big = portrait ? [1.45, 1.12, .92][Math.min(2, rows - 1)] : [1, .92, .8][Math.min(2, rows - 1)]; LAY.scr = [1, .78, .66][Math.min(2, rows - 1)];
  const out = []; let left = n;
  for (let r = 0; r < rows; r++) { const c = Math.min(left, Math.floor(n / rows) + (r >= rows - (n % rows) ? 1 : 0) || left); left -= c;
    const step = Math.min(span / Math.max(1, per - 1), span / Math.max(1, c)), w = step * (c - 1), off = (r % 2 && c < per ? 0 : 0) + (rows > 1 && r % 2 === 0 && c > 1 ? -step * .18 : rows > 1 ? step * .18 : 0);
    for (let i = 0; i < c; i++) { const x = cx - w / 2 + i * step + off, u = w ? (x - cx) / (span / 2) : 0; out.push({ x, y: ys[r] - u * u * 16 }); } }
  return out;
}
const ORDER = new Map(), SLOT = new Map(); let orderSeq = 0;                       // orden de llegada estable: nadie cambia de sitio porque otro informe llegue antes
function viewX() { return [-OX / S, (W - OX) / S]; }
const FLOOR_Y = 712, WALK = 100;                                 // pasillo delantero por el que se entra y se sale; velocidad de paso (u/s)
function syncActors(now) {
  if (!state.agentsLoaded) return;
  const live0 = state.agents.filter(a => a.state === "run");
  for (const a of live0) { const id = a.id || a.name; if (!ORDER.has(id)) ORDER.set(id, orderSeq++); }
  const live = live0.sort((p, q) => ORDER.get(p.id || p.name) - ORDER.get(q.id || q.name)).slice(0, 12), seen = new Set();
  // sitios fijos: cada agente conserva su mesa mientras trabaja; solo se reparte de nuevo si cambia el número de filas
  const per = portrait ? 4 : 6, cap = Math.max(1, Math.ceil(live.length / per)) * per, sl0 = slots(cap);
  if (state.cap !== cap || state.capP !== portrait) { SLOT.clear(); state.cap = cap; state.capP = portrait; }
  const pref = sl0.map((q, i) => i).sort((a, b) => Math.abs(sl0[a].x - 690) + sl0[a].y * -.2 - (Math.abs(sl0[b].x - 690) + sl0[b].y * -.2));
  const taken = new Set(); for (const a of live) { const v = SLOT.get(a.id || a.name); if (v != null && v < cap && !taken.has(v)) taken.add(v); else SLOT.delete(a.id || a.name); }
  for (const a of live) { const id = a.id || a.name; if (!SLOT.has(id)) { const f = pref.find(i => !taken.has(i)); SLOT.set(id, f); taken.add(f); } }
  for (const id of [...SLOT.keys()]) if (!live.some(a => (a.id || a.name) === id)) SLOT.delete(id);
  const sl = live.map(a => sl0[SLOT.get(a.id || a.name)]);
  const [vx0, vx1] = viewX(); let k = 0;
  live.forEach((a, i) => { const id = a.id || a.name; seen.add(id); let ac = actors.get(id);
    if (!ac) { const sx = Math.max(250, Math.min(1130, sl[i].x + (hash(id) < .5 ? -1 : 1) * 240));   // sube a la cubierta desde el lado de la cámara y camina hasta su mesa
      ac = { id, x: sx, y: WH + 70, born: now, gone: 0, sit: 0, ph: hash(id) * 6, wait: state.synced ? 0 : (k++) * .55 }; actors.set(id, ac);
      if (state.synced) receive("agent", (ZONES[zoneOf(a)] || ZONES.think).c, () => ({ x: ac.x, y: ac.y - 60, ac })); }
    Object.assign(ac, { a, sp: spriteFor(a), tx: sl[i].x, ty: sl[i].y, zone: zoneOf(a) }); ac.gone = 0; });
  for (const [id, ac] of actors) if (!seen.has(id) && !ac.gone) { ac.gone = now; ac.seated = false; ac.ty = WH + 90; ac.tx = Math.max(250, Math.min(1130, ac.x + (hash(id) < .5 ? -1 : 1) * 220)); }
  state.synced = true;
}
let lastT = 0;
function drawActors(t, now, dt) {
  const list = [...actors.values()].sort((p, q) => p.y - q.y); let focus = null, best = -1;
  const big = LAY.big;
  for (const ac of list) {
    if (ac.wait > 0) { ac.wait -= dt; continue; }
    const dx = ac.tx - ac.x, dy = ac.ty - ac.y, d = Math.hypot(dx, dy), walking = d > 2.5;
    if (walking) { const stp = Math.min(d, WALK * dt * (d < 40 ? .55 + d / 90 : 1)); ac.x += dx / d * stp; ac.y += dy / d * stp; ac.ph = (ac.ph || 0) + stp * .085; if (Math.abs(dx) > 1) ac.face = dx < 0; }
    if (ac.gone && !walking) { actors.delete(ac.id); ORDER.delete(ac.id); continue; }
    ac.seated = !walking && !ac.gone; ac.sit = Math.max(0, Math.min(1, (ac.sit || 0) + (ac.seated ? 1 : -2) * dt * 2.2));
    const scale = (.78 + (ac.y - 560) / 700) * big, h = 96 * scale, bob = walking ? Math.abs(Math.sin(ac.ph)) * 7 * scale : 0;
    const z = ZONES[ac.zone] || ZONES.think;
    // halo de zona en el suelo
    X.save(); X.globalCompositeOperation = "lighter"; const gl = X.createRadialGradient(ac.x, ac.y, 0, ac.x, ac.y, 70 * scale);
    gl.addColorStop(0, hexA(z.c, ac.seated ? .32 : .1)); gl.addColorStop(1, hexA(z.c, 0)); X.fillStyle = gl; X.beginPath(); X.ellipse(ac.x, ac.y, 70 * scale, 20 * scale, 0, 0, 7); X.fill(); X.restore();
    X.fillStyle = "rgba(0,0,0,.35)"; X.beginPath(); X.ellipse(ac.x, ac.y + 2, 34 * scale, 8 * scale, 0, 0, 7); X.fill();
    const st = walking ? (ac.gone ? "out" : "in") : "work", talking = !walking && now - (ac.lastTalk || 0) < 2500, thinking = !walking && !talking && Math.sin(t * .3 + hash(ac.id) * 9) > .93;
    let name = ac.sp + "." + st; if (!AT[name]) name = ac.sp + ".work";
    if (walking) { X.save(); X.globalAlpha = .35; X.fillStyle = hexA(z.c, .5); for (let f = 0; f < 2; f++) { const u = (ac.ph / Math.PI + f * .5) % 1; X.beginPath(); X.ellipse(ac.x + (ac.face ? 1 : -1) * (8 + u * 18) * scale, ac.y + 3, (5 - u * 4) * scale, 1.6 * scale, 0, 0, 7); X.fill(); } X.restore(); }
    if (walking) { X.save(); X.translate(ac.x, ac.y); X.rotate(Math.sin(ac.ph) * .11); X.translate(-ac.x, -ac.y); }
    spr(name, ac.x, ac.y - bob, h * (walking ? 1 - Math.abs(Math.sin(ac.ph)) * .03 : 1), { flip: walking ? !!ac.face : false, filter: ac.sp === "generic" ? "hue-rotate(" + Math.round(hash(ac.id) * 300) + "deg)" : null });
    if (walking) X.restore();
    if ((talking || thinking) && ac.sit > .9) { const bx = ac.x - h * .34, by = ac.y - h * 1.02, r = 9 * scale;   // bocadillo: habla (puntos de su color) o piensa (burbujas)
      X.save(); X.fillStyle = "rgba(236,244,248,.92)"; X.strokeStyle = hexA(z.c, .9); X.lineWidth = 1.4;
      if (talking) { rr(bx - r * 1.6, by - r, r * 3.2, r * 2, r); X.fill(); X.stroke(); X.beginPath(); X.moveTo(bx + r * .6, by + r * .9); X.lineTo(bx + r * 1.3, by + r * 1.8); X.lineTo(bx + r * 1.2, by + r * .8); X.fill();
        X.fillStyle = z.c; for (let q = 0; q < 3; q++) { X.globalAlpha = .4 + .6 * Math.max(0, Math.sin(t * 8 - q)); X.beginPath(); X.arc(bx - r * .8 + q * r * .8, by, r * .22, 0, 7); X.fill(); } }
      else { X.beginPath(); X.ellipse(bx, by, r * 1.5, r, 0, 0, 7); X.fill(); X.stroke(); for (const [ox, oy, rr2] of [[r * 1.1, r * 1.4, .28], [r * 1.6, r * 2.1, .18]]) { X.beginPath(); X.arc(bx + ox, by + oy, r * rr2, 0, 7); X.fill(); X.stroke(); }
        X.fillStyle = z.c; X.font = `800 ${Math.round(r * 1.1)}px system-ui,sans-serif`; X.textAlign = "center"; X.textBaseline = "middle"; X.fillText("…", bx, by - r * .15); }
      X.restore(); }
    if (ac.sit > .02) {
      const e = 1 - Math.pow(1 - ac.sit, 3);
      spr("desk.on", ac.x, ac.y + 20 * scale, 44 * scale, { alpha: .95 * e });
      const sw = 118 * scale * LAY.scr * (.4 + .6 * e), sh = 70 * scale * LAY.scr * e, side = LAY.rows > 1, sx = side ? ac.x + h * .3 : ac.x - sw / 2, sy = side ? ac.y - h * .98 : ac.y - h - sh - 8 * scale;   // con varias filas la pantalla va al lado, en el hueco del tresbolillo
      if (e > .5) screen(ac, sx, sy, sw, sh, t, z); ac.sx = side ? sx + sw / 2 : ac.x; ac.sy = side ? sy : sy + sh;
      const sc = (ac.a.pct || 0) + hash(ac.id + Math.floor(t / 8)) * 40; if (ac.seated && sc > best) { best = sc; focus = ac; }
    }
  }
  return focus;
}
/* pantalla flotante de cada agente: color de zona + contenido animado + tema y avance */
function screen(ac, x, y, w, h, t, z) {
  X.save(); X.fillStyle = "rgba(8,16,23,.88)"; rr(x, y, w, h, 8); X.fill();
  X.strokeStyle = hexA(z.c, .85); X.lineWidth = 2; rr(x, y, w, h, 8); X.stroke();
  X.save(); rr(x + 3, y + 3, w - 6, h - 22, 6); X.clip(); content(ac, x + 3, y + 3, w - 6, h - 22, t, z); X.restore();
  // pie: tema + %
  const nm = (ac.a.name || "").replace(/\s+/g, " "), topic = nm.includes("·") ? nm.split("·").slice(1).join("·").trim() : nm;
  X.font = `700 ${Math.max(10, h * .17)}px system-ui,sans-serif`; X.textBaseline = "middle"; X.fillStyle = PAL.ivory; X.textAlign = "left";
  X.fillText(fit((ac.a.cloud ? "☁ " : "") + topic, w - 40), x + 6, y + h - 10);
  const eng = ac.a.engine || ac.a.motor || ac.a.model; if (eng) { X.save(); X.font = `600 ${Math.max(9, h * .14)}px system-ui,sans-serif`; X.textAlign = "center"; X.textBaseline = "top";
    const ew = Math.min(w, X.measureText(String(eng)).width + 12); X.fillStyle = "rgba(8,16,23,.82)"; rr(x + w / 2 - ew / 2, y + h + 3, ew, Math.max(13, h * .2), 6); X.fill();
    X.fillStyle = PAL.silver; X.fillText(fit(String(eng), w - 8), x + w / 2, y + h + 5); X.restore(); }
  if (ac.a.pct != null) { X.textAlign = "right"; X.fillStyle = z.c; X.fillText(Math.round(ac.a.pct) + "%", x + w - 6, y + h - 10);
    X.fillStyle = hexA(z.c, .25); X.fillRect(x + 4, y + h - 2.5, w - 8, 2); X.fillStyle = z.c; X.fillRect(x + 4, y + h - 2.5, (w - 8) * Math.min(1, ac.a.pct / 100), 2); }
  X.restore();
}
function content(ac, x, y, w, h, t, z) { if (!(h > 8 && w > 12)) return;
  const id = (ac.id || "") + " " + (ac.a.name || ""), lc = z.c;
  if (/gta/i.test(ac.a.project || "") || /gta/i.test(id)) {                   // carretera de GTA
    const g = X.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, "#ff7a59"); g.addColorStop(.45, "#ff4fd8"); g.addColorStop(.46, "#1c1430"); g.addColorStop(1, "#0b0b14");
    X.fillStyle = g; X.fillRect(x, y, w, h); X.fillStyle = "#ffd36b"; X.beginPath(); X.arc(x + w * .5, y + h * .45, h * .2, Math.PI, 0); X.fill();
    X.strokeStyle = "#ffe8a3"; X.lineWidth = 1.5; for (let i = 0; i < 5; i++) { const u = ((t * .9 + i / 5) % 1), yy = y + h * .5 + u * u * h * .5; X.beginPath(); X.moveTo(x + w * .5, yy); X.lineTo(x + w * .5, yy + 2 + u * 6); X.stroke(); }
    X.strokeStyle = "#ff4fd8"; X.beginPath(); X.moveTo(x + w * .5, y + h * .46); X.lineTo(x, y + h); X.moveTo(x + w * .5, y + h * .46); X.lineTo(x + w, y + h); X.stroke(); return; }
  if (/strata|ollama|local/i.test(id)) {                                       // informe directo de Strata
    const m = state.machines.PC || {}; X.fillStyle = "#0c1412"; X.fillRect(x, y, w, h); X.font = `600 ${Math.max(8, h * .2)}px ui-monospace,monospace`; X.fillStyle = lc; X.textAlign = "left"; X.textBaseline = "top";
    X.fillText("GPU " + (m.gpu ?? "–") + "% " + (m.gpu_temp ?? "–") + "°", x + 4, y + 3); X.fillText("VRAM " + (m.vram_gb ?? "–") + "/" + (m.vram_total_gb ?? "–"), x + 4, y + 3 + h * .3);
    X.fillText(((m.gpu_apps || [])[0] || {}).name || "—", x + 4, y + 3 + h * .6); return; }
  X.fillStyle = hexA(lc, .08); X.fillRect(x, y, w, h); X.fillStyle = lc; X.strokeStyle = lc;
  const z0 = ac.zone, k = t * 2 + hash(ac.id) * 9;
  if (z0 === "code") { for (let i = 0; i < 5; i++) { const ww = (.3 + hash(ac.id + i + Math.floor(k / 2)) * .6) * w; X.globalAlpha = .8; X.fillRect(x + 4 + (i % 3) * 6, y + 4 + i * h / 5.2, Math.min(ww, w - 12), Math.max(2, h * .08)); } }
  else if (z0 === "web") { X.lineWidth = 1.2; X.beginPath(); X.arc(x + w / 2, y + h / 2, h * .38, 0, 7); X.stroke(); X.beginPath(); X.ellipse(x + w / 2, y + h / 2, h * .38 * Math.abs(Math.cos(k * .5)), h * .38, 0, 0, 7); X.stroke(); X.beginPath(); X.moveTo(x + w / 2 - h * .38, y + h / 2); X.lineTo(x + w / 2 + h * .38, y + h / 2); X.stroke(); }
  else if (z0 === "voice") { for (let i = 0; i < 12; i++) { const hh = (.2 + Math.abs(Math.sin(k * 2 + i * 1.3)) * .7) * h; X.fillRect(x + 6 + i * (w - 12) / 12, y + (h - hh) / 2, (w - 12) / 18, hh); } }
  else if (z0 === "edit") { for (let i = 0; i < 3; i++) for (let j = 0; j < 4; j++) { X.globalAlpha = .35 + hash(ac.id + i * 7 + j) * .5; X.fillRect(x + 4 + j * (w - 8) / 4, y + 5 + i * h / 3.3, (w - 8) / 4 - 3, h / 4.2); } X.globalAlpha = 1; X.fillStyle = "#fff"; X.fillRect(x + 4 + ((k * .15) % 1) * (w - 8), y + 2, 1.5, h - 4); }
  else if (z0 === "image") { X.globalAlpha = .6; X.beginPath(); X.moveTo(x + 6, y + h - 4); X.lineTo(x + w * .4, y + h * .35); X.lineTo(x + w * .6, y + h * .65); X.lineTo(x + w * .75, y + h * .45); X.lineTo(x + w - 6, y + h - 4); X.fill(); X.beginPath(); X.arc(x + w * .78, y + h * .28, h * .12, 0, 7); X.fill(); }
  else if (z0 === "system") { for (let i = 0; i < 3; i++) { const f = .3 + Math.abs(Math.sin(k * .4 + i)) * .6; X.globalAlpha = .3; X.fillRect(x + 6, y + 6 + i * h / 3.2, w - 12, h / 5); X.globalAlpha = .9; X.fillRect(x + 6, y + 6 + i * h / 3.2, (w - 12) * f, h / 5); } }
  else if (z0 === "obsidian") { X.globalAlpha = .7; const P = []; for (let i = 0; i < 7; i++) P.push([x + 8 + hash(ac.id + "x" + i) * (w - 16), y + 6 + hash(ac.id + "y" + i) * (h - 12)]);
    X.lineWidth = .8; X.beginPath(); for (let i = 1; i < 7; i++) { X.moveTo(...P[i]); X.lineTo(...P[(i * 3) % i]); } X.stroke(); for (const [px, py] of P) { X.beginPath(); X.arc(px, py, 2 + Math.sin(k + px) * .8, 0, 7); X.fill(); } }
  else if (z0 === "write") { for (let i = 0; i < 4; i++) { const full = i < 3 ? 1 : ((k * .2) % 1); X.globalAlpha = .75; X.fillRect(x + 6, y + 6 + i * h / 4.5, (w - 12) * (.6 + hash(ac.id + i) * .4) * full, Math.max(2, h * .07)); } }
  else { X.globalAlpha = .7; for (let i = 0; i < 3; i++) { X.beginPath(); X.arc(x + w / 2 - 12 + i * 12, y + h / 2, 3 + (Math.floor(k * 1.5) % 3 === i ? 2 : 0), 0, 7); X.fill(); } }
  X.globalAlpha = 1;
}

/* ── proyectos con avance ── */
const projPos = {}, projHit = {}, PV = {};
const PHUES = ["#7cf5ff", "#f2c078", "#aa9de8", "#78c798", "#60a5fa", "#f29b9d", "#fb923c"];
function projKey(a) { const p = String(a.project || "").toLowerCase().trim(); if (!p || p === "-") return null;
  for (const [k] of PROJ) if (p.startsWith(k === "biblioteca" ? "bibli" : k)) return k; return "x:" + p; }
function projMeta(k) { const f = PROJ.find(q => q[0] === k); if (f) return f;
  const lab = k.slice(2), nice = (state.agents.find(a => projKey(a) === k) || {}).project || lab; return [k, nice.charAt(0).toUpperCase() + nice.slice(1), "panel.core", PHUES[Math.floor(hash(k) * PHUES.length)]]; }
function projData() {
  const s = state.status, run = state.agents.filter(a => a.state === "run"), out = {}, keys = PROJ.map(q => q[0]);
  for (const a of run) { const k = projKey(a); if (k && !keys.includes(k)) keys.push(k); }
  for (const k of keys) { const mine = run.filter(a => projKey(a) === k), wp = mine.filter(a => a.pct != null);
    out[k] = { n: mine.length, pct: wp.length ? wp.reduce((q, a) => q + a.pct, 0) / wp.length : null, note: "" }; }
  const clips = ((s.gta_last || {}).gta || {}).clips || []; const act = clips.filter(c => c.p !== "DESGUACE" && /launch|radar/.test(c.n));
  if (act.length) { out.gta.pct = act.reduce((q, c) => q + (GTA_IDX[c.st] ?? 0) / 11, 0) / act.length * 100; out.gta.note = act.length + " clips · " + act.filter(c => c.st === 10).length + " publ."; }
  const si = (s.biblio_probe || {}).sint; if (si && si.total) { out.biblioteca.pct = si.done / si.total * 100; out.biblioteca.note = "síntesis " + si.done + "/" + si.total; }
  const ag = (s.projects || []).find(p => p.id === "agentes"); if (ag) { const f = ag.figs || []; out.agentes.note = (f[0]?.value ?? 0) + " activos · " + (f[1]?.value ?? 0) + " en cola"; }
  const ing = (s.projects || []).find(p => p.id === "ingresos"); if (ing) out.ingresos.note = ((s.income || {}).count || 0) + " pagos · meta " + ((s.income || {}).goal || 0) + " €";
  for (const k of keys) if (!out[k].note || out[k].n) out[k].note = out[k].n ? (out[k].n === 1 ? (((run.find(a => projKey(a) === k) || {}).name || "").split("·")[0].trim() || "1") + " trabajando" : out[k].n + " trabajando") + (out[k].note && out[k].n ? " · " + out[k].note : "") : out[k].note;
  out.gta.n = out.gta.n || (gtaActive() && ((window.GTA_ESTADO || {}).voz_ocupada || (state.gta || {}).state === "run") ? 1 : 0);
  return out;
}
function projStep(dt) {                                          // presencia animada: entra lo que se toca, se apaga y sale lo que se deja
  const d = projData(); let i = 0;
  for (const k in d) { const live = d[k].n > 0; if (!live && !PV[k]) continue; const v = PV[k] || (PV[k] = { v: 0, y: null, k, p: d[k] });
    v.p = d[k]; v.live = live; v.v = Math.max(0, Math.min(1, v.v + (live ? 1.6 : -1.1) * dt)); if (live) v.idx = i++; }
  for (const k in PV) { if (!d[k]) PV[k].live = false; if (!PV[k].live && PV[k].v <= 0) { delete PV[k]; delete projPos[k]; } }
  return Object.values(PV).sort((a, b) => (a.live === b.live ? (a.idx ?? 99) - (b.idx ?? 99) : a.live ? -1 : 1));
}
function drawProjectsWorld(t, list, dt) {                        // apaisado: solo los proyectos que se están tocando, arriba a la izquierda, a tamaño de pantalla (legible también en el móvil girado)
  const u = Math.max(.62, Math.min(1.1, Math.min(W / 1440, H / 900) * 1.08)), x0 = 14 / u, w = 214, rh = 58, y0 = (52 + (parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--sat")) || 0)) / u; let n = 0;
  X.save(); X.setTransform(DPR * u, 0, 0, DPR * u, 0, 0);
  list.forEach(v => { const [k, lab, sp, hue] = projMeta(v.k), p = v.p, live = v.live, ty = y0 + (live ? n++ : (v.idx ?? n)) * (rh + 6);
    v.y = v.y == null ? ty : v.y + (ty - v.y) * Math.min(1, dt * 5); const e = 1 - Math.pow(1 - v.v, 3), y = v.y, x = x0 - (1 - e) * 60;
    if (live) projPos[k] = { x: ((x + w - 14) * u - OX) / S, y: ((y + rh / 2) * u - OY) / S }; const GA = e;
    if (projHit[k] && performance.now() - projHit[k] < 900) { X.save(); X.globalCompositeOperation = "lighter"; X.fillStyle = hexA(hue, .35); rr(x - 4, y - 4, w + 8, rh + 8, 12); X.fill(); X.restore(); }
    X.save(); X.globalAlpha = GA; X.fillStyle = "rgba(8,16,23,.86)"; rr(x, y, w, rh, 10); X.fill(); X.strokeStyle = hexA(hue, live ? .9 : .35); X.lineWidth = live ? 2 : 1; rr(x, y, w, rh, 10); X.stroke();
    spr(sp, x + 26, y + rh - 6, rh - 12, { alpha: GA * (live ? 1 : .7) }); X.globalAlpha = GA;
    X.font = "700 15px system-ui,sans-serif"; X.fillStyle = PAL.ivory; X.textAlign = "left"; X.textBaseline = "alphabetic"; X.fillText(lab, x + 52, y + 21);
    X.font = "600 11px system-ui,sans-serif"; X.fillStyle = live ? hue : PAL.silver; X.fillText(fit(p.note, w - 100), x + 52, y + 37);
    bar(x + 52, y + 44, w - 62, 6, p.pct, hue, t, live);
    if (p.pct != null) { X.font = "700 13px system-ui,sans-serif"; X.textAlign = "right"; X.fillStyle = PAL.ivory; X.fillText(Math.round(p.pct) + "%", x + w - 10, y + 21); }
    if (live && GA > .95) pulse(x + w - 12, y + 34, hue, t);
    X.restore(); });
  X.restore();
}
function bar(x, y, w, h, pct, col, t, live) {
  X.fillStyle = hexA(col, .18); rr(x, y, w, h, h / 2); X.fill();
  if (pct != null) { X.fillStyle = col; rr(x, y, Math.max(h, w * Math.min(1, pct / 100)), h, h / 2); X.fill(); }
  else if (live) { const u = (t * .5) % 1; X.fillStyle = hexA(col, .7); rr(x + u * (w - 30), y, 30, h, h / 2); X.fill(); }
}

/* ── máquina GTA y aviso de entrenamiento de voz ── */
function voiceTraining() {
  const s = state.status, run = state.agents.filter(a => a.state === "run");
  const fresh = r => { const at = Date.parse(r.at || r.updated || ""); return !at || Date.now() - at < 45 * 60e3; };
  const a = run.find(r => fresh(r) && /entren|lora|training|clon(ar|ando)|perfil de voz|natural2?\b/i.test((r.id || "") + " " + (r.name || "") + " " + (r.task || "") + " " + (r.step || "")) && !/ingesta/i.test(r.step || ""));
  if (DEMO_VOZ) return "demo";
  if (a) return a.step || a.task || "entrenando";
  const ing = [...(s.agents || []), ...(s.running || [])].some(r => /ingesta/i.test((r.id || "") + (r.name || "")) && Date.now() - Date.parse(r.at || 0) < 4 * 60e3);   // la ingesta de grabaciones coge el cerrojo de voz: no es entrenar
  if ((s.voz_probe || {}).running || (state.voz || {}).running) return "voz en marcha";
  if ((window.GTA_ESTADO || {}).voz_ocupada && !ing) return "voz ocupada";
  return null;
}
const GTAHIT = { x: 0, y: 0, r: 0, on: false };
function gtaActive() { const fresh = r => { const at = Date.parse(r.at || ""); return !at || Date.now() - at < 45 * 60e3; };
  const ge = window.GTA_ESTADO || {}, gl = Date.parse(ge.last || ""); if (ge.voz_ocupada || (gl && Date.now() - gl < 45 * 60e3)) return true;
  return !!voiceTraining() || (state.gta || {}).state === "run" || state.agents.some(a => a.state === "run" && fresh(a) && /gta/i.test(a.project || "")); }
C.addEventListener("click", e => { if (GTAHIT.on && Math.hypot(e.clientX - GTAHIT.x, e.clientY - GTAHIT.y) < GTAHIT.r) location.href = "gta.html"; });
function drawGTA(t, x, y, sc) {
  GTAHIT.x = OX + x * S; GTAHIT.y = OY + (y - 30 * sc) * S; GTAHIT.r = 64 * sc * S; GTAHIT.on = true;
  const train = voiceTraining(), gr = state.gta || {}, busy = gr.state === "run" || state.agents.some(a => a.state === "run" && /gta/i.test(a.project || ""));
  spr("screen.road", x, y, 70 * sc, { alpha: busy || train ? 1 : .55 });
  X.save(); X.font = `700 ${12 * sc}px system-ui,sans-serif`; X.textAlign = "center"; X.fillStyle = PAL.ivory; X.fillText("Máquina GTA VI ›", x, y + 18 * sc);
  X.font = `600 ${10 * sc}px system-ui,sans-serif`; X.fillStyle = busy ? "#ff4fd8" : PAL.silver; X.fillText(train ? "voz entrenando" : busy ? "trabajando · toca" : "en espera", x, y + 31 * sc); X.restore();
  if (train) { const a = .65 + Math.sin(t * 5) * .35, bw = 168 * sc, bh = 30 * sc, bx = x - bw / 2, by = y - 70 * sc - bh - 8;
    X.save(); X.globalCompositeOperation = "lighter"; X.fillStyle = hexA(PAL.amber, .25 * a); rr(bx - 6, by - 6, bw + 12, bh + 12, 14); X.fill(); X.restore();
    X.save(); X.fillStyle = hexA(PAL.amber, .92); rr(bx, by, bw, bh, 10); X.fill(); X.fillStyle = "#1a1206"; X.font = `800 ${13 * sc}px system-ui,sans-serif`; X.textAlign = "center"; X.textBaseline = "middle";
    X.fillText("🎙 ENTRENANDO VOZ", x, by + bh / 2); X.restore(); }
}
function voice(x, y, t) {
  const on = !!voiceTraining(); spr("voice", x, y, 22, { alpha: on ? 1 : .5 });
  if (on) { X.save(); X.globalCompositeOperation = "lighter"; for (let i = 0; i < 9; i++) { const h = 4 + Math.abs(Math.sin(t * 6 + i * 1.3)) * 12; X.fillStyle = hexA(PAL.amber, .75); X.fillRect(x - 36 + i * 8, y - 11 - h / 2, 4, h); } X.restore(); }
}
function thermos(x, y, sc) {
  const m = state.machines, pc = m.PC || {}, mac = m.Mac || {};
  [["thermo.mac", "Mac", mac.cpu_temp, "°"], ["thermo.cpu", "PC CPU", pc.cpu_temp, "°"], ["thermo.gpu", "PC GPU", pc.gpu, " %"]].forEach(([sp, lab, v, u], i) => {
    const xx = x + i * 52 * sc, hh = 110 * sc; spr(sp, xx, y + hh, hh);
    if (v != null) { const f = Math.max(0, Math.min(1, v / 100)), top = y + hh * .16, bot = y + hh * .8, yy = bot - (bot - top) * f;
      X.save(); X.globalCompositeOperation = "lighter"; X.fillStyle = hexA(v > 80 ? PAL.bad : v > 60 ? PAL.run : PAL.teal, .55); rr(xx - 3 * sc, yy, 6 * sc, bot - yy, 3); X.fill(); X.restore(); }
    X.save(); X.font = `700 ${12 * sc}px system-ui,sans-serif`; X.textAlign = "center"; X.fillStyle = PAL.ivory; X.fillText(v != null ? Math.round(v) + u : "–", xx, y + hh + 15 * sc);
    X.font = `600 ${10 * sc}px system-ui,sans-serif`; X.fillStyle = PAL.silver; X.fillText(lab, xx, y + hh + 28 * sc); X.restore(); });
}
function pulse(x, y, col, t) { X.save(); X.globalCompositeOperation = "lighter"; X.globalAlpha = .5 + Math.sin(t * 4) * .3; X.fillStyle = col; X.beginPath(); X.arc(x, y, 4, 0, 7); X.fill(); X.restore(); }

/* ── HUD móvil: aviso, quién hace qué, proyectos, termómetros ── */
function drawHUD(t) {
  if (!portrait) return;
  const W0 = W, H0 = H, hy0 = hudY, HU0 = HU, nA = Math.min(12, [...actors.values()].filter(a => a.seated).length);
  const need = (8 + Math.max(1, Math.ceil(nA / 2)) * 28 + Math.ceil(Math.max(1, (state.plist || []).filter(v => v.live).length) / (nA > 8 || W0 / HU0 >= 520 ? 4 : 2)) * 34 + 96) * HU0;
  if (W0 < 520) HU = HU0 * Math.max(1, Math.min(1.3, (H0 - hy0) / need));          // móvil alto: letra más grande si sobra sitio
  W = W0 / HU; H = H0 / HU; hudY = hy0 / HU;
  try { drawHUD_(t); } finally { W = W0; H = H0; hudY = hy0; HU = HU0; }
}
function drawHUD_(t) {
  X.save(); X.setTransform(DPR * HU, 0, 0, DPR * HU, 0, 0);
  let y = hudY + 4; X.fillStyle = PAL.bg8; X.fillRect(0, y - 4, W, H - y + 4);
  const g = X.createLinearGradient(0, y - 30, 0, y); g.addColorStop(0, hexA(PAL.bg8, 0)); g.addColorStop(1, PAL.bg8); X.fillStyle = g; X.fillRect(0, y - 30, W, 30);
  const train = voiceTraining();
  if (train) { const a = .7 + Math.sin(t * 5) * .3; X.fillStyle = hexA(PAL.amber, .9 * a); rr(12, y, W - 24, 30, 10); X.fill();
    X.fillStyle = "#1a1206"; X.font = "800 13px system-ui,sans-serif"; X.textAlign = "left"; X.textBaseline = "middle"; X.fillText("🎙 ENTRENANDO VOZ · " + fit(String(train), W - 200), 22, y + 15); y += 38; }
  // quién hace qué
  const all = [...actors.values()].filter(a => a.seated), dense = all.length > 2, ag = dense ? all.slice(0, 12) : all.slice(0, train ? 3 : 4);
  if (dense) { const cw2 = (W - 32) / 2; ag.forEach((ac, i) => { const z = ZONES[ac.zone] || ZONES.think, nm = (ac.a.name || ""), who = nm.split("·")[0].trim(), topic = nm.includes("·") ? nm.split("·").slice(1).join("·").trim() : nm;
      const cx = 12 + (i % 2) * (cw2 + 8), cy = y + Math.floor(i / 2) * 28; X.fillStyle = PAL.bg7; rr(cx, cy, cw2, 24, 7); X.fill(); X.fillStyle = z.c; rr(cx, cy, 5, 24, 2); X.fill();
      X.font = "700 11px system-ui,sans-serif"; X.textAlign = "left"; X.textBaseline = "alphabetic"; X.fillStyle = PAL.ivory; X.fillText(fit((ac.a.cloud ? "☁ " : "") + who + " · " + topic, cw2 - 46), cx + 11, cy + 12);
      if (ac.a.pct != null) { X.textAlign = "right"; X.font = "700 11px system-ui,sans-serif"; X.fillStyle = PAL.ivory; X.fillText(Math.round(ac.a.pct) + "%", cx + cw2 - 7, cy + 12); bar(cx + 11, cy + 17, cw2 - 20, 3, ac.a.pct, z.c, t, true); } });
    y += Math.ceil(ag.length / 2) * 28 + 4; }
  else for (const ac of ag) { const z = ZONES[ac.zone] || ZONES.think, nm = (ac.a.name || "").replace(/\s+/g, " "), who = nm.split("·")[0].trim(), topic = nm.includes("·") ? nm.split("·").slice(1).join("·").trim() : nm;
    X.fillStyle = PAL.bg7; rr(12, y, W - 24, 36, 10); X.fill(); X.fillStyle = z.c; rr(12, y, 6, 36, 3); X.fill();
    X.font = "700 13px system-ui,sans-serif"; X.textAlign = "left"; X.textBaseline = "alphabetic"; X.fillStyle = PAL.ivory; X.fillText(fit((ac.a.cloud ? "☁ " : "") + topic, W - 150), 26, y + 16);
    X.font = "600 11px system-ui,sans-serif"; X.fillStyle = z.c; X.fillText(z.label + " · " + who, 26, y + 30);
    if (ac.a.pct != null) { X.textAlign = "right"; X.font = "700 13px system-ui,sans-serif"; X.fillStyle = PAL.ivory; X.fillText(Math.round(ac.a.pct) + "%", W - 22, y + 16); bar(W - 92, y + 24, 70, 5, ac.a.pct, z.c, t, true); }
    y += 42; }
  if (!ag.length) { X.font = "600 12px system-ui,sans-serif"; X.fillStyle = PAL.silver; X.textAlign = "left"; X.textBaseline = "alphabetic"; X.fillText("Nadie trabajando ahora mismo", 16, y + 14); y += 24; }
  // proyectos (2 columnas)
  const pc4 = all.length > 8 || W >= 520 ? 4 : 2, cw = (W - 24 - (pc4 - 1) * 6) / pc4, PL = (state.plist || []).filter(v => v.live || v.v > .05); let pn = 0;
  PL.forEach(v => { const [k, lab, , hue] = projMeta(v.k), p = v.p, live = v.live, i = live ? pn++ : (v.idx ?? pn), cx = 12 + (i % pc4) * (cw + 6), cy = y + Math.floor(i / pc4) * 34;
    if (live) projPos[k] = { x: ((cx + cw / 2) * HU - OX) / S, y: ((cy + 14) * HU - OY) / S }; X.save(); X.globalAlpha = 1 - Math.pow(1 - v.v, 3);
    if (projHit[k] && performance.now() - projHit[k] < 900) { X.fillStyle = hexA(hue, .4); rr(cx - 2, cy - 2, cw + 4, 32, 10); X.fill(); }
    X.fillStyle = PAL.bg7; rr(cx, cy, cw, 28, 9); X.fill(); if (live) { X.strokeStyle = hexA(hue, .9); X.lineWidth = 1.5; rr(cx, cy, cw, 28, 9); X.stroke(); }
    X.font = (pc4 > 2 ? "700 10px" : "700 12px") + " system-ui,sans-serif"; X.textAlign = "left"; X.textBaseline = "alphabetic"; X.fillStyle = PAL.ivory; X.fillText(fit(lab, cw - 38), cx + 7, cy + 13);
    X.textAlign = "right"; X.fillStyle = live ? hue : PAL.silver; X.font = pc4 > 2 ? "700 10px system-ui,sans-serif" : X.font; X.fillText(p.pct != null ? Math.round(p.pct) + "%" : (live ? p.n + "▶" : "·"), cx + cw - 7, cy + 13);
    bar(cx + 9, cy + 19, cw - 18, 4, p.pct, hue, t, live); X.restore(); });
  if (!pn) { X.font = "600 11px system-ui,sans-serif"; X.fillStyle = hexA(PAL.silver, .6); X.textAlign = "left"; X.textBaseline = "alphabetic"; X.fillText("Ningún proyecto en marcha", 16, y + 14); }
  y += Math.max(1, Math.ceil(pn / pc4)) * 34 + 4;
  // máquinas: temperatura y esfuerzo
  const mh = Math.max(58, Math.min(70, H - y - 8)), bw = (W - 40) / 3;
  if (y + 40 < H) machineCards().forEach((c, i) => machineCard(c, 12 + i * (bw + 8), y, bw, mh, t, true));
  X.restore();
}

/* ── máquinas: temperatura grande y % de esfuerzo, con su rastro de los últimos minutos ── */
const HMAX = 80;
function machineCards() {
  const m = state.machines, pc = m.PC, mac = m.Mac, vr = pc && pc.vram_total_gb ? pc.vram_gb / pc.vram_total_gb * 100 : null;
  return [
    { id: "mac", lab: "Mac", temp: mac && mac.cpu_temp, main: mac && mac.cpu, rows: [["CPU", mac && mac.cpu, PAL.teal], ["GPU", mac && mac.gpu, PAL.violet], ["RAM", mac && mac.ram, PAL.silver]], m: mac },
    { id: "cpu", lab: "PC · CPU", short: "PC CPU", temp: pc && pc.cpu_temp, main: pc && pc.cpu, rows: [["CPU", pc && pc.cpu, PAL.teal], ["RAM", pc && pc.ram, PAL.silver]], m: pc },
    { id: "gpu", lab: "PC · GPU", short: "PC GPU", temp: pc && pc.gpu_temp, main: pc && pc.gpu, rows: [["GPU", pc && pc.gpu, PAL.violet], ["VRAM", vr, PAL.silver]], m: pc, extra: pc && pc.gpu_w != null ? Math.round(pc.gpu_w) + " W" : "" }];
}
function tempCol(v) { return v == null ? PAL.metal : v >= 85 ? PAL.bad : v >= 70 ? PAL.amber : v >= 55 ? PAL.gold : PAL.teal; }
function loadCol(v, c) { return v == null ? PAL.metal : v >= 92 ? PAL.bad : v >= 75 ? PAL.amber : c; }
function machineCard(c, x, y, w, h, t, compact) {
  const at = c.m ? Date.parse(c.m.at || "") : 0, stale = !c.m || (at && Date.now() - at > 150e3), tc = stale ? PAL.metal : tempCol(c.temp), hs = state.hist[c.id] || [];
  X.save(); X.globalAlpha = stale ? .55 : 1;
  X.fillStyle = "rgba(13,27,37,.94)"; rr(x, y, w, h, compact ? 10 : 14); X.fill();
  if (hs.length > 1) { X.save(); rr(x, y, w, h, compact ? 10 : 14); X.clip(); X.beginPath(); const px = i => x + w - (hs.length - 1 - i) * w / (HMAX - 1), py = v => y + h - 3 - (h * .62) * Math.min(1, (v || 0) / 100);
    X.moveTo(px(0), y + h); hs.forEach((v, i) => X.lineTo(px(i), py(v))); X.lineTo(px(hs.length - 1), y + h); X.closePath();
    const g = X.createLinearGradient(0, y + h * .3, 0, y + h); g.addColorStop(0, hexA(loadCol(c.main, c.rows[0][2]), .26)); g.addColorStop(1, hexA(loadCol(c.main, c.rows[0][2]), .02)); X.fillStyle = g; X.fill();
    X.beginPath(); hs.forEach((v, i) => i ? X.lineTo(px(i), py(v)) : X.moveTo(px(i), py(v))); X.strokeStyle = hexA(loadCol(c.main, c.rows[0][2]), .55); X.lineWidth = 1.2; X.stroke(); X.restore(); }
  X.strokeStyle = hexA(tc, c.temp >= 70 ? .55 + Math.sin(t * 4) * .25 : .4); X.lineWidth = c.temp >= 70 ? 2 : 1.2; rr(x + .5, y + .5, w - 1, h - 1, compact ? 10 : 14); X.stroke();
  if (compact) {                                                 // móvil: nombre y temperatura arriba, dos barras a todo lo ancho debajo
    const pad = 8; X.textBaseline = "alphabetic"; X.textAlign = "left"; X.fillStyle = PAL.silver; X.font = "700 10px system-ui,sans-serif"; X.fillText(c.short || c.lab, x + pad, y + 15);
    X.textAlign = "right"; X.fillStyle = tc; X.font = "800 17px system-ui,sans-serif"; X.fillText(stale || c.temp == null ? "–" : Math.round(c.temp) + "°", x + w - pad, y + 19);
    const rows = c.rows.slice(0, 2), rh = (h - 26) / rows.length;
    rows.forEach(([lab, v, col], i) => { const yy = y + 24 + i * rh; X.font = "700 9px system-ui,sans-serif"; X.textAlign = "left"; X.fillStyle = PAL.silver; X.fillText(lab, x + pad, yy + 9);
      X.textAlign = "right"; X.fillStyle = v == null ? PAL.metal : PAL.ivory; X.fillText(v == null ? "–" : Math.round(v) + "%", x + w - pad, yy + 9); bar(x + pad, yy + 12, w - pad * 2, 3, v == null ? null : v, loadCol(v, col), t, false); });
    X.restore(); return;
  }
  const L = Math.max(110, w * .36), pad = 14;
  X.textAlign = "left"; X.textBaseline = "alphabetic"; X.fillStyle = PAL.silver; X.font = `700 ${compact ? 10 : Math.round(Math.min(15, h * .14))}px system-ui,sans-serif`;
  X.fillText(fit(c.lab, L - pad), x + pad, y + (compact ? 14 : pad + Math.min(15, h * .14)));
  const big = compact ? Math.min(22, h * .42) : Math.min(58, h * .46, L * .42); X.font = `800 ${Math.round(big)}px system-ui,sans-serif`; X.fillStyle = tc;
  const tv = stale || c.temp == null ? "–" : Math.round(c.temp) + "°", tvw = X.measureText(tv).width; X.fillText(tv, x + pad, y + h - (compact ? 7 : pad + 2));
  if (!compact && (c.extra || stale)) { X.font = `600 ${Math.round(Math.min(12, h * .11))}px system-ui,sans-serif`; X.fillStyle = PAL.silver; X.fillText(stale ? "sin datos" : c.extra, x + pad + tvw + 8, y + h - pad - 4); }
  const rows = compact ? c.rows.slice(0, 2) : c.rows, rx = x + L, rw = w - L - pad, rh = (h - (compact ? 10 : pad * 2)) / rows.length, fs = compact ? 9 : Math.round(Math.min(13, rh * .42));
  rows.forEach(([lab, v, col], i) => { const yy = y + (compact ? 6 : pad) + i * rh, lc = loadCol(v, col), bh = compact ? 3 : Math.max(4, Math.min(7, rh * .2));
    X.font = `700 ${fs}px system-ui,sans-serif`; X.textAlign = "left"; X.fillStyle = PAL.silver; X.fillText(lab, rx, yy + fs + 1);
    X.textAlign = "right"; X.fillStyle = v == null ? PAL.metal : PAL.ivory; X.font = `800 ${fs + (compact ? 0 : 2)}px system-ui,sans-serif`; X.fillText(v == null ? "–" : Math.round(v) + "%", rx + rw, yy + fs + 1);
    bar(rx, yy + fs + 4, rw, bh, v == null ? null : v, lc, t, false); });
  X.restore();
}
function drawBand(t) {                                           // apaisado: franja inferior con las máquinas en grande
  if (portrait || !BH) return;
  X.save(); X.setTransform(DPR, 0, 0, DPR, 0, 0); const y = H - BH;
  const g = X.createLinearGradient(0, y - 26, 0, y + 10); g.addColorStop(0, hexA(PAL.bg, 0)); g.addColorStop(1, PAL.bg8); X.fillStyle = g; X.fillRect(0, y - 26, W, 36); X.fillStyle = PAL.bg8; X.fillRect(0, y + 10, W, BH);
  const cs = machineCards(), gap = 12, pad = Math.max(12, Math.min(28, W * .02)), cw = Math.min(460, (W - pad * 2 - gap * (cs.length - 1)) / cs.length), x0 = (W - (cw * cs.length + gap * (cs.length - 1))) / 2;
  cs.forEach((c, i) => machineCard(c, x0 + i * (cw + gap), y + 8, cw, BH - 16 - Math.max(0, parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--sab")) || 0), t, false));
  X.restore();
}

/* ── bucle ── */
let last = 0, running = true;
document.addEventListener("visibilitychange", () => { running = !document.hidden; if (running) { lastT = (performance.now() - state.t0) / 1000; requestAnimationFrame(loop); } });
function loop(ts) {
  if (!running) return; requestAnimationFrame(loop);
  if (ts - last < 1000 / FPS) return; last = ts;
  const t = (performance.now() - state.t0) / 1000, now = performance.now(), dt = Math.min(.1, Math.max(0, t - lastT)); lastT = t;
  X.setTransform(DPR, 0, 0, DPR, 0, 0); X.fillStyle = PAL.bg; X.fillRect(0, 0, W, H);
  const par = Math.sin(t * .075);
  if (stars) X.drawImage(stars, -W * .1 + par * 18, -H * .1 + Math.cos(t * .06) * 10, W * 1.2, H * 1.2);
  X.setTransform(DPR * S, 0, 0, DPR * S, DPR * (OX + par * 3), DPR * OY); drawGalaxy(t);
  if (IMG.bg) { X.drawImage(IMG.bg, 0, 0, WW, WH);
    if (BAND > 1) { const b = BAND + 8; X.drawImage(IMG.bg, 0, 0, 3, WH, -b, 0, b + 1, WH); X.drawImage(IMG.bg, WW - 3, 0, 3, WH, WW - 1, 0, b + 1, WH);
      const gl = X.createLinearGradient(-b, 0, 0, 0); gl.addColorStop(0, "rgba(6,12,17,.78)"); gl.addColorStop(1, "rgba(6,12,17,.12)"); X.fillStyle = gl; X.fillRect(-b, 0, b, WH);
      const gr = X.createLinearGradient(WW, 0, WW + b, 0); gr.addColorStop(0, "rgba(6,12,17,.12)"); gr.addColorStop(1, "rgba(6,12,17,.78)"); X.fillStyle = gr; X.fillRect(WW, 0, b, WH); } }
  X.setTransform(DPR * S, 0, 0, DPR * S, DPR * (OX - par * 4), DPR * OY);
  const gOn = gtaActive(); GTAHIT.on = false;
  state.plist = projStep(dt);
  if (!portrait) { drawProjectsWorld(t, state.plist, dt); if (gOn) drawGTA(t, 1222 + RS, 470, Math.max(1, Math.min(1.9, .8 / S))); voice(1222 + RS, gOn ? 560 : 470, t); }
  else if (gOn) drawGTA(t, 975, 455, 1.25);
  drawHUD(t);
  syncActors(now); X.save(); X.beginPath(); X.rect(-4000, -4000, WW + 8000, 4000 + WH); X.clip(); const focus = drawActors(t, now, dt); X.restore();
  orbStep(t, dt, focus); if (DEMO_N) demoTick(t); drawThreads(dt); drawDock(t, dt);
  drawLight(t, focus); drawOrb(t, focus); drawBand(t);
}

/* ── datos ── */
async function j(u) { const r = await fetch(u, { cache: "no-store" }); if (!r.ok) throw Error(r.status); return r.json(); }
async function pull() {
  try {
    const [s, m] = await Promise.all([j("api/status"), j("api/machines")]);
    state.status = s; state.agentsLoaded = true;
    if (DEMO_N) s.running = demoAgents();
    const byId = new Map(); for (const r of [...(s.agents || []), ...(s.running || [])]) if (r && (r.id || r.name)) byId.set(r.id || r.name, { ...(byId.get(r.id || r.name) || {}), ...r });
    const QUIET = 45 * 60e3, liveNow = r => { if (DEMO_N) return true; if (r.state !== "run") return false; if (r.presence) return r.presence === "desk";
      const at = Date.parse(r.at || ""); return !at || Date.now() - at < Math.min((r.ttl || 3600) * 1000, QUIET); };
    state.ghosts = [...byId.values()].filter(r => r.state === "run" && !liveNow(r)).length;
    state.agents = (DEMO_N ? s.running : [...byId.values()].filter(liveNow)).map(r => ({ ...r, cloud: r.cloud ?? (r.brand === "claude" || r.brand === "gpt") }));
    for (const a of state.agents) { const ac = actors.get(a.id || a.name); if (ac && ac.lastPct != null && ac.lastPct !== a.pct) { ac.lastTalk = performance.now();
        const pk = projKey(a);
        receive("pct", (ZONES[zoneOf(a)] || ZONES.think).c, () => pk && projPos[pk] ? { ...projPos[pk], proj: pk } : { x: orb.x, y: orb.y, vault: true }, deskOf(ac)); } if (ac) ac.lastPct = a.pct; }
    const seenO = state.ordersSeen || (state.ordersSeen = new Set()), first = !seenO.size;       // órdenes nuevas: entran de fuera (Nawe) → lanzadera → su ejecutor
    for (const o of s.orders || []) { if (seenO.has(o.id)) continue; seenO.add(o.id); if (first || o.state === "done") continue;
      receive("order", PAL.gold, () => { const h = actorFor(o.executor); return h ? { ...deskOf(h), ac: h } : { x: orb.x, y: orb.y }; }); }
    if (DEMO_N && !(m.machines || []).length) m.machines = [{ name: "PC", at: new Date().toISOString(), cpu: 30 + Math.random() * 40, cpu_temp: 58 + Math.random() * 14, gpu: 60 + Math.random() * 38, gpu_temp: 50 + Math.random() * 25, ram: 47, vram_gb: 9, vram_total_gb: 16, gpu_w: 120 }, { name: "Mac", at: new Date().toISOString(), cpu: 12 + Math.random() * 20, cpu_temp: 48 + Math.random() * 8, gpu: 18, ram: 68 }];
    state.machines = {}; for (const x of m.machines || []) state.machines[x.name] = x;
    for (const c of machineCards()) { const h = state.hist[c.id] || (state.hist[c.id] = []); h.push(c.main); if (h.length > HMAX) h.shift(); } state.build = m.build || {}; state.voz = m.voz || {}; state.gta = m.gta || {};
    state.lastOk = Date.now(); ST.textContent = state.agents.length + " trabajando · " + new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
  } catch (e) { ST.textContent = "sin conexión"; }
}
async function pullVault() {
  try {
    const v = await j(`api/vault/live?since=${state.seq}&gv=${state.gv}`);
    if (v.graph) { buildGraph(v.graph); state.gv = v.gv; }
    let n = 0; for (const e of v.ev || []) if (e.s > state.seq) { e.quiet = !state.seq || n++ >= 8; vaultEvent(e); }
    state.seq = v.seq || state.seq;
  } catch (e) {}
}
pull(); pullVault(); setInterval(() => { if (!document.hidden) pull(); }, 3000);
function pullGta() { const o = document.getElementById("gtaE"); if (o) o.remove(); const e = document.createElement("script"); e.id = "gtaE"; e.src = "gta-estado.js?t=" + Date.now(); e.onerror = () => {}; document.head.appendChild(e); }
pullGta(); setInterval(() => { if (!document.hidden) pullGta(); }, 10000); setInterval(() => { if (!document.hidden) pullVault(); }, 2000);

/* ── utilidades ── */
function fit(s, w) { s = String(s || ""); if (X.measureText(s).width <= w) return s; while (s.length > 2 && X.measureText(s + "…").width > w) s = s.slice(0, -1); return s + "…"; }
function rr(x, y, w, h, r) { X.beginPath(); X.moveTo(x + r, y); X.arcTo(x + w, y, x + w, y + h, r); X.arcTo(x + w, y + h, x, y + h, r); X.arcTo(x, y + h, x, y, r); X.arcTo(x, y, x + w, y, r); X.closePath(); }
function hexA(h, a) { const n = parseInt(h.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; }
function hash(s) { s = String(s); let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return ((h >>> 0) % 10000) / 10000; }
function mulberry(a) { return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
})();
