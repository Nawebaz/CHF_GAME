#!/usr/bin/env python3
"""Faro: panel de estado personal. Un solo proceso, sin dependencias externas (Python 3.9+).

  python faro.py                 arranca servidor + recolectores
  python faro.py --once          ejecuta los recolectores una vez y escribe data/status.json
  python faro.py --demo          arranca con datos de demostración (sin red)

Configuración: config.json (copia de config.example.json). Todo lo personal vive ahí.
"""
import base64, glob, socket, shutil, subprocess, uuid, datetime as dt, email.header, email.message, email.utils, html, imaplib, json, os, re, sys, threading, time, traceback
import urllib.parse, urllib.request, xml.etree.ElementTree as ET
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")
WEB = os.path.join(ROOT, "web")
os.makedirs(DATA, exist_ok=True)
LOCK = threading.RLock()

def _fix_path():
    """El servicio de usuario de systemd arranca con un PATH mínimo: sin esto Faro no encuentra claude, codex ni hermes."""
    home = os.path.expanduser("~"); extra = [os.path.join(home, d) for d in (".local/bin", "bin", ".npm-global/bin", ".bun/bin", ".cargo/bin", ".volta/bin", ".claude/local")]
    extra += ["/usr/local/bin", "/snap/bin", "/opt/homebrew/bin"]
    hh = os.path.join(home, ".hermes")
    if os.path.isdir(hh):  # Hermes Agent suele vivir en su propio venv
        for d in sorted(os.listdir(hh)):
            for sub in ("venv/bin", ".venv/bin", "bin"):
                extra.append(os.path.join(hh, d, sub))
        extra.append(os.path.join(hh, "bin"))
    nvm = os.path.join(home, ".nvm/versions/node")
    if os.path.isdir(nvm):
        extra += [os.path.join(nvm, v, "bin") for v in sorted(os.listdir(nvm), reverse=True)]
    cur = os.environ.get("PATH", "").split(os.pathsep)
    os.environ["PATH"] = os.pathsep.join(cur + [d for d in extra if os.path.isdir(d) and d not in cur])
_fix_path()
VERSION = "1.0"
try:
    with open(os.path.join(ROOT, "VERSION"), encoding="utf-8") as _f: VERSION = _f.read().strip() or VERSION
except Exception:
    pass

# ───────────────────────── utilidades ─────────────────────────
def now():
    return dt.datetime.now().astimezone()

def iso(t):
    return t.isoformat(timespec="seconds") if t else None

def parse_iso(s):
    try:
        t = dt.datetime.fromisoformat(str(s).replace("Z", "+00:00"))
        return t if t.tzinfo else t.astimezone()
    except Exception:
        return None

def jload(name, default):
    p = os.path.join(DATA, name)
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def jsave(name, obj):
    p = os.path.join(DATA, name)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)

def log(*a):
    line = now().strftime("%Y-%m-%d %H:%M:%S") + " " + " ".join(str(x) for x in a)
    print(line, flush=True)
    try:
        with open(os.path.join(DATA, "faro.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

def http(url, data=None, headers=None, timeout=20, method=None):
    h = {"User-Agent": "Faro/" + VERSION}
    h.update(headers or {})
    if isinstance(data, (dict, list)):
        data = json.dumps(data).encode()
        h.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()

def http_json(url, **kw):
    return json.loads(http(url, **kw).decode("utf-8", "replace"))

def load_config():
    """config.example.json da los valores por defecto (y las novedades de cada versión); config.json manda."""
    def rd(name):
        try:
            with open(os.path.join(ROOT, name), encoding="utf-8") as f: return json.load(f)
        except FileNotFoundError: return {}
    base, user = rd("config.example.json"), rd("config.json")
    out = {**base, **user}
    for k in ("sources", "executors", "routing", "decision", "vault"):
        if isinstance(base.get(k), dict) and isinstance(user.get(k), dict):
            out[k] = {**base[k], **user[k]}
    if isinstance(user.get("projects"), list) and isinstance(base.get("projects"), list):  # proyectos nuevos de Faro aparecen aunque tengas los tuyos
        have = {p.get("id") for p in user["projects"]}
        out["projects"] = user["projects"] + [p for p in base["projects"] if p.get("id") not in have]
    # Ajustes cambiados desde Faro (móvil/Mac) sin tocar el PC: data/overrides.json, campo a campo, mandan sobre config.json
    try:
        with open(os.path.join(ROOT, "data", "overrides.json"), encoding="utf-8") as f: ov = json.load(f)
    except (FileNotFoundError, ValueError): ov = {}
    for k, e in (ov.get("executors") or {}).items():
        out.setdefault("executors", {})[k] = {**(out.get("executors", {}).get(k) or base.get("executors", {}).get(k) or {}), **e}
    return out

EXEC_EDITABLE = {"enabled", "type", "url", "model", "timeout"}   # nunca «cmd» desde la red: no se puede inyectar un comando
def set_executor(name, changes):
    if name not in CFG.get("executors", {}): return {"ok": False, "error": "no existe el ejecutor «%s»" % name}
    bad = set(changes) - EXEC_EDITABLE
    if bad: return {"ok": False, "error": "no se puede cambiar: " + ", ".join(sorted(bad))}
    if "type" in changes and changes["type"] not in ("openai", "ollama", "cmd", "faro"): return {"ok": False, "error": "tipo no válido"}
    if "type" in changes and changes["type"] == "cmd" and not CFG["executors"][name].get("cmd"): return {"ok": False, "error": "sin comando definido"}
    with LOCK:
        ov = jload("overrides.json", {}); ov.setdefault("executors", {}).setdefault(name, {}).update(changes); jsave("overrides.json", ov)
        new = load_config(); CFG.clear(); CFG.update(new)
        PROBE.pop(name, None); EXEC_BLOCK.pop(name, None)
        with OQ: OQ.notify_all()   # las órdenes que esperaban a este agente arrancan ya
    build_status()
    return {"ok": True, "executor": name, "now": {k: CFG["executors"][name].get(k) for k in ("enabled", "type", "url", "model")}, "available": executor_ok(name)}

CFG = load_config()

# ───────────────────────── cron mínimo ─────────────────────────
def _field(spec, lo, hi):
    out = set()
    for part in spec.split(","):
        step = 1
        if "/" in part:
            part, s = part.split("/"); step = int(s)
        if part in ("*", ""):
            a, b = lo, hi
        elif "-" in part:
            a, b = map(int, part.split("-"))
        else:
            a = b = int(part)
            if step > 1: b = hi
        out.update(range(a, b + 1, step))
    return out

def cron_next(expr, after=None):
    """Siguiente ejecución de una expresión cron de 5 campos (admite prefijo CRON_TZ=Zona)."""
    tz = None
    expr = expr.strip()
    if expr.startswith("CRON_TZ="):
        name, expr = expr[8:].split(" ", 1)
        try:
            from zoneinfo import ZoneInfo
            tz = ZoneInfo(name)
        except Exception:
            tz = None  # Windows sin tzdata: se usa la hora local del equipo
    m, h, dom, mon, dow = expr.split()
    M, H, DOM, MON = _field(m, 0, 59), _field(h, 0, 23), _field(dom, 1, 31), _field(mon, 1, 12)
    DOW = {d % 7 for d in _field(dow, 0, 7)}
    dom_any, dow_any = dom == "*", dow == "*"
    t = (after or now())
    t = t.astimezone(tz) if tz else t
    t = t.replace(second=0, microsecond=0) + dt.timedelta(minutes=1)
    for _ in range(60 * 24 * 400):
        if t.month in MON and t.hour in H and t.minute in M:
            d_ok = t.day in DOM
            w_ok = ((t.weekday() + 1) % 7) in DOW
            if dom_any and dow_any: ok = True
            elif dom_any: ok = w_ok
            elif dow_any: ok = d_ok
            else: ok = d_ok or w_ok
            if ok:
                return t.astimezone()
        t += dt.timedelta(minutes=1)
    return None

def validate_report(body):
    """Normalize untrusted local and mailbox reports before persistence."""
    if not isinstance(body, dict): raise ValueError("informe debe ser un objeto")
    r = dict(body)
    rid = r.get("id")
    if not isinstance(rid, str) or not rid.strip() or len(rid) > 80:
        raise ValueError("id debe ser texto de 1 a 80 caracteres")
    r["id"] = rid.strip()
    r.setdefault("kind", "job"); r.setdefault("state", "ok")
    if r["kind"] not in ("job", "run", "agent", "todo"): raise ValueError("kind desconocido")
    if r["state"] not in ("ok", "run", "warn", "bad", "off"): raise ValueError("state desconocido")
    for k, v in list(r.items()):
        if isinstance(v, str): r[k] = v.strip()[:2000]
    for k in ("name", "title", "task", "text", "note", "next", "last", "step", "project", "brand", "agent", "where", "action"):
        if k in r and not isinstance(r[k], str): raise ValueError(k + " debe ser texto")
    r["title"] = r.get("title") or r.get("name") or r.get("task") or r["id"]
    pct = r.get("pct")
    if isinstance(pct, bool) or not isinstance(pct, (int, float)) or not 0 <= pct <= 100: r.pop("pct", None)
    for k in ("at", "src_at"):
        if r.get(k) is not None and not parse_iso(r[k]): raise ValueError(k + " inválido")
    if "rate" in r and not isinstance(r["rate"], (int, float)): r.pop("rate")
    ttl = r.get("ttl", 300)
    r["ttl"] = ttl if isinstance(ttl, (int, float)) and not isinstance(ttl, bool) and 0 < ttl < 31536000 else 300
    return r

def _clean_reports():
    global REPORTS
    clean = {}
    for key, value in (REPORTS.items() if isinstance(REPORTS, dict) else []):
        try:
            r = validate_report(value)
            stamp = parse_iso(r.get("at"))
            if r["state"] == "ok" and stamp and (now() - stamp).total_seconds() > 7 * 86400: continue
            clean[r["id"]] = r
        except (ValueError, TypeError): log("reports: entrada inválida descartada")
    if REPORTS != clean:
        REPORTS = clean
        jsave("reports.json", REPORTS)

def clean_reports():
    with LOCK:
        _clean_reports()

# ───────────────────────── estado persistente ─────────────────────────
STATE = jload("state.json", {"xp": 0, "done": 0, "dismissed": {}, "news_hidden": {}, "alerts_sent": {}, "red_days": {}})
REPORTS = jload("reports.json", {})
clean_reports()
HISTORY = jload("history.json", {})
CACHE = {}  # salida de cada recolector: nombre -> dict

def save_state():
    with LOCK:
        jsave("state.json", STATE)

def push_history(key, value, keep=400):
    with LOCK:
        arr = HISTORY.setdefault(key, [])
        stamp = iso(now())
        if arr and arr[-1][0][:13] == stamp[:13]:
            arr[-1] = [stamp, value]  # un punto por hora como máximo
        else:
            arr.append([stamp, value])
        del arr[:-keep]
        jsave("history.json", HISTORY)

def hist(key):
    return HISTORY.get(key, [])

# ───────────────────────── recolectores ─────────────────────────
COLLECTORS = {}
def collector(name, every):
    def deco(fn):
        COLLECTORS[name] = {"fn": fn, "every": every, "last": 0, "error": None}
        return fn
    return deco

def src_cfg(name):
    c = CFG.get("sources", {}).get(name)
    return c if c and c.get("enabled", True) else None

@collector("scheduled", 60)
def c_scheduled():
    """Tareas con horario conocido (p. ej. tareas programadas en la nube). El estado de la última
    ejecución llega por informe (/api/report) con el mismo id; si no hay informe, queda 'sin datos'."""
    jobs = []
    for j in CFG.get("scheduled", []):
        nxt = cron_next(j["cron"]) if j.get("cron") else None
        rep = REPORTS.get(j["id"], {})
        jobs.append({"project": j["project"], "name": j["name"], "where": j.get("where", "nube"),
                     "state": rep.get("state", "off"), "last": rep.get("last") or j.get("last"),
                     "next": iso(nxt), "every": j.get("every_days"),
                     "note": rep.get("note") or j.get("note") or ("" if rep else "Sin informe de la última ejecución.")})
    return {"jobs": jobs}

@collector("gmail", 300)
def c_gmail():
    c = src_cfg("gmail")
    if not c: return None
    M = imaplib.IMAP4_SSL("imap.gmail.com")
    M.login(c["user"], c["app_password"])
    try:
        M.select('"[Gmail]/All Mail"' if c.get("all_mail_name") is None else c["all_mail_name"], readonly=True)
    except Exception:
        M.select("INBOX", readonly=True)
    def search(q, limit=20):
        typ, data = M.uid("SEARCH", "X-GM-RAW", '"' + q.replace('"', '\\"') + '"')
        ids = (data[0] or b"").split()[-limit:]
        out = []
        for uid in reversed(ids):
            typ, msg = M.uid("FETCH", uid, "(X-GM-THRID BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE MESSAGE-ID)] BODY.PEEK[TEXT]<0.4000>)")
            hdr, body, thr = b"", b"", ""
            for part in msg:
                if isinstance(part, tuple):
                    meta = part[0].decode(errors="ignore")
                    m = re.search(r"X-GM-THRID (\d+)", meta)
                    if m: thr = m.group(1)
                    if "HEADER" in meta: hdr = part[1]
                    else: body = part[1]
            em = email.message_from_bytes(hdr)
            subj = str(email.header.make_header(email.header.decode_header(em.get("Subject", ""))))
            frm = email.utils.parseaddr(em.get("From", ""))[1]
            date = email.utils.parsedate_to_datetime(em.get("Date")) if em.get("Date") else None
            text = re.sub(r"<[^>]+>", " ", body.decode("utf-8", "replace"))
            text = html.unescape(re.sub(r"=\r?\n", "", text))
            out.append({"thr": thr, "subject": subj, "from": frm, "date": iso(date), "text": re.sub(r"\s+", " ", text)[:1500],
                        "msgid": em.get("Message-ID", "")})
        return out
    todo, pays = [], []
    for rule in c.get("todo_rules", []):
        for m in search(rule["query"], rule.get("limit", 10)):
            tid = "gm:" + m["thr"]
            todo.append({"id": tid, "kind": "email", "state": rule.get("state", "warn"),
                         "title": rule.get("title") or m["subject"][:80], "text": m["subject"] if rule.get("title") else m["text"][:180],
                         "from": m["from"], "date": m["date"], "reply": rule.get("reply", False),
                         "msgid": m["msgid"], "subject": m["subject"], "project": rule.get("project")})
    selfre = [re.compile(s, re.I) for s in c.get("exclude_self", [])]
    for p in c.get("payment_rules", []):
        for m in search(p["query"], 40):
            blob = m["subject"] + " " + m["text"]
            if any(r.search(blob) for r in selfre):
                continue
            am = re.search(p.get("amount_regex", r"(\d{1,3}(?:[.\s]\d{3})*(?:,\d{2})|\d+(?:[.,]\d{2}))\s?(?:€|EUR)"), blob)
            val = None
            if am:
                s = am.group(1).replace(" ", "")
                s = s.replace(".", "").replace(",", ".") if "," in s else s
                try: val = float(s)
                except Exception: val = None
            pays.append({"id": "pay:" + m["thr"], "source": p["source"], "amount": val, "date": m["date"], "subject": m["subject"][:90]})
    M.logout()
    return {"todo": todo, "payments": pays, "sources": [p["source"] for p in c.get("payment_rules", [])]}

def gmail_draft(item, text):
    c = src_cfg("gmail")
    if not c or not c.get("allow_drafts", True):
        raise RuntimeError("borradores desactivados")
    msg = email.message.EmailMessage()
    msg["From"] = c["user"]; msg["To"] = item.get("from", "")
    subj = item.get("subject", "")
    msg["Subject"] = subj if subj.lower().startswith("re:") else "Re: " + subj
    if item.get("msgid"):
        msg["In-Reply-To"] = item["msgid"]; msg["References"] = item["msgid"]
    msg["Date"] = email.utils.formatdate(localtime=True)
    msg.set_content(text)
    M = imaplib.IMAP4_SSL("imap.gmail.com"); M.login(c["user"], c["app_password"])
    box = None
    for line in M.list()[1]:
        if b"\\Drafts" in line:
            box = line.decode().split(' "/" ')[-1]; break
    M.append(box or '"[Gmail]/Drafts"', "(\\Draft)", imaplib.Time2Internaldate(time.time()), msg.as_bytes())
    M.logout()

BUZON = {"sha": None}

def _buzon_git(c):
    """Lee el buzón por git (sin caché de CDN y sin límite de la API). Devuelve bytes o None si no ha cambiado."""
    git = shutil.which("git")
    if not git: raise RuntimeError("sin git")
    repo = c.get("git", "https://github.com/Nawebaz/CHF_GAME.git"); br = c.get("branch", "faro-buzon")
    d = os.path.join(ROOT, "data", "buzon")
    run = lambda *a: subprocess.run([git, *a], capture_output=True, text=True, timeout=25)
    head = run("ls-remote", repo, "refs/heads/" + br)
    if head.returncode: raise RuntimeError("git ls-remote: " + (head.stderr or "")[:100])
    sha = (head.stdout.split() or [None])[0]
    if sha and sha == BUZON["sha"]: return None
    if not os.path.isdir(os.path.join(d, ".git")):
        os.makedirs(d, exist_ok=True); run("-C", d, "init", "-q")
    f = run("-C", d, "fetch", "-q", "--depth", "1", repo, br)
    if f.returncode: raise RuntimeError("git fetch: " + (f.stderr or "")[:100])
    out = subprocess.run([git, "-C", d, "show", "FETCH_HEAD:" + c.get("path", "reports.json")], capture_output=True, timeout=15)
    if out.returncode: raise RuntimeError("git show: " + out.stderr.decode("utf-8", "replace")[:100])
    BUZON["sha"] = sha
    return out.stdout

@collector("github_inbox", 15)
def c_github_inbox():
    """Buzón de lo que pasa en la nube (sesiones de Claude, tareas programadas): informes genéricos en la rama
    faro-buzon. Se consulta por git cada 15 s; si git falla, por la dirección pública (con caché de unos minutos)."""
    c = src_cfg("github_inbox")
    if not c: return None
    raw, via = None, "git"
    if c.get("git", True) is not False and not c.get("token"):
        try:
            raw = _buzon_git(c)
            if raw is None: return {**(CACHE.get("github_inbox") or {}), "via": via, "changed": False}
        except Exception as e:
            log("buzon git", e); raw = None
    if raw is None:
        via = "http"
        if c.get("token"):
            raw = http("https://api.github.com/repos/%s/contents/%s" % (c["repo"], c.get("path", "faro/reports.json")),
                       headers={"Authorization": "Bearer " + c["token"], "Accept": "application/vnd.github.raw"})
        else:
            url = c.get("url", "https://raw.githubusercontent.com/Nawebaz/CHF_GAME/faro-buzon/reports.json")
            raw = http(url + ("&" if "?" in url else "?") + "t=%d" % time.time(), headers={"Cache-Control": "no-cache"})
    items = json.loads(raw.decode("utf-8"))
    n = 0
    for r in items if isinstance(items, list) else [items]:
        stamp = r.get("src_at") or r.get("at")  # src_at es la hora real del informe; at solo en los antiguos
        if r.get("id") and stamp and stamp != REPORTS.get(r["id"], {}).get("src_at"):
            report({"cloud": True, **r, "at": stamp, "src_at": stamp}); n += 1
    return {"imported": n, "via": via, "changed": True}

@collector("itch", 1800)
def c_itch():
    c = src_cfg("itch")
    if not c: return None
    d = http_json("https://itch.io/api/1/%s/my-games" % c["api_key"])
    out = []
    for g in d.get("games", []):
        key = "itch:%s:views" % g["id"]
        push_history(key, g.get("views_count", 0))
        h = hist(key); week = [v for t, v in h if parse_iso(t) and parse_iso(t) > now() - dt.timedelta(days=7)]
        out.append({"title": g.get("title"), "views": g.get("views_count", 0), "downloads": g.get("downloads_count", 0),
                    "purchases": g.get("purchases_count", 0), "views_7d": (week[-1] - week[0]) if len(week) > 1 else None,
                    "earnings": sum(e.get("amount", 0) for e in g.get("earnings", []) or []) / 100 if g.get("earnings") else 0})
    return {"games": out}

@collector("freqtrade", 300)
def c_freqtrade():
    c = src_cfg("freqtrade")
    if not c: return None
    auth = "Basic " + base64.b64encode(("%s:%s" % (c["user"], c["password"])).encode()).decode()
    base = c["url"].rstrip("/")
    prof = http_json(base + "/api/v1/profit", headers={"Authorization": auth})
    st = http_json(base + "/api/v1/status", headers={"Authorization": auth})
    return {"profit_pct": prof.get("profit_all_ratio", 0) * 100, "trades": prof.get("trade_count"),
            "winrate": (prof.get("winrate") or 0) * 100, "open": len(st) if isinstance(st, list) else 0,
            "first": prof.get("first_trade_humanized")}

@collector("prices", 900)
def c_prices():
    c = src_cfg("prices")
    if not c: return None
    items = []
    cg = [w for w in c.get("watch", []) if w.get("kind") == "crypto"]
    if cg:
        ids = ",".join(w["id"] for w in cg)
        d = http_json("https://api.coingecko.com/api/v3/simple/price?ids=%s&vs_currencies=eur&include_24hr_change=true" % ids)
        for w in cg:
            v = d.get(w["id"], {})
            if "eur" in v:
                items.append({**w, "price": v["eur"], "chg24": v.get("eur_24h_change"), "unit": "€"})
    for w in [w for w in c.get("watch", []) if w.get("kind") == "stooq"]:
        try:
            row = http("https://stooq.com/q/l/?s=%s&f=sd2t2ohlcv&h&e=csv" % w["id"]).decode().splitlines()[1].split(",")
            close, opn = float(row[6]), float(row[3])
            items.append({**w, "price": close, "chg24": (close / opn - 1) * 100 if opn else None, "unit": w.get("unit", "")})
        except Exception as e:
            items.append({**w, "price": None, "error": str(e)[:80]})
    for it in items:
        if it.get("price") is None: continue
        key = "px:" + it["id"]; push_history(key, it["price"])
        h = [v for t, v in hist(key) if parse_iso(t) and parse_iso(t) > now() - dt.timedelta(days=30)]
        it["spark"] = [round(v, 6) for v in h[-48:]]
        if len(h) >= 24:
            avg = sum(h) / len(h); it["vs30"] = (it["price"] / avg - 1) * 100
        lo, hi = it.get("alert_below"), it.get("alert_above")
        it["alert"] = (lo is not None and it["price"] <= lo) or (hi is not None and it["price"] >= hi)
    return {"items": items}

TICKS = jload("ticks.json", {})

@collector("ticks", 30)
def c_ticks():
    """Cotizaciones casi en tiempo real (cripto, cada 30 s) para las gráficas en vivo."""
    c = src_cfg("prices")
    if not c: return None
    cg = [w for w in c.get("watch", []) if w.get("kind") == "crypto"]
    if not cg: return None
    d = http_json("https://api.coingecko.com/api/v3/simple/price?ids=%s&vs_currencies=eur" % ",".join(w["id"] for w in cg), timeout=10)
    t = int(time.time())
    with LOCK:
        for w in cg:
            v = d.get(w["id"], {}).get("eur")
            if v is None: continue
            arr = TICKS.setdefault(w["id"], {"name": w.get("name", w["id"]), "unit": "€", "points": []})["points"]
            arr.append([t, v]); del arr[:-480]  # unas 4 horas a 30 s
        if t % 300 < 30: jsave("ticks.json", TICKS)
    return {"n": len(cg)}

@collector("electricity", 3600)
def c_electricity():
    c = src_cfg("electricity")
    if not c: return None
    today = now().date()
    url = ("https://apidatos.ree.es/es/datos/mercados/precios-mercados-tiempo-real?start_date=%sT00:00&end_date=%sT23:59&time_trunc=hour"
           % (today, today))
    d = http_json(url)
    vals = []
    for inc in d.get("included", []):
        if "PVPC" in inc.get("attributes", {}).get("title", "") or inc.get("type") == "PVPC (€/MWh)":
            vals = inc["attributes"]["values"]; break
    if not vals: return {"error": "sin PVPC hoy"}
    pts = [(parse_iso(v["datetime"]), v["value"] / 1000) for v in vals]
    cur = next((p for t, p in pts if t and t.hour == now().hour), pts[-1][1])
    cheap = sorted(pts, key=lambda x: x[1])[:3]
    avg = sum(p for _, p in pts) / len(pts)
    push_history("pvpc:avg", round(avg, 4))
    return {"now": round(cur, 4), "avg": round(avg, 4), "cheap": [t.strftime("%H:%M") for t, _ in sorted(cheap)],
            "hours": [round(p, 4) for _, p in pts], "kwh_month": c.get("kwh_month")}

@collector("news", 1800)
def c_news():
    c = src_cfg("news")
    if not c: return None
    topics = c.get("topics", {})
    items = []
    for feed in c.get("feeds", []):
        try:
            root = ET.fromstring(http(feed["url"], timeout=15))
        except Exception as e:
            log("news", feed["url"], e); continue
        ns = {"a": "http://www.w3.org/2005/Atom"}
        entries = root.findall(".//item") or root.findall(".//a:entry", ns)
        for e in entries[:30]:
            g = lambda tag: (e.findtext(tag) or e.findtext("a:" + tag, namespaces=ns) or "").strip()
            title = html.unescape(re.sub(r"<[^>]+>", "", g("title")))
            link = g("link") or (e.find("a:link", ns).get("href") if e.find("a:link", ns) is not None else "")
            summ = html.unescape(re.sub(r"<[^>]+>", " ", g("description") or g("summary")))[:400]
            date = None
            for tag in ("pubDate", "published", "updated"):
                if g(tag):
                    try: date = email.utils.parsedate_to_datetime(g(tag))
                    except Exception: date = parse_iso(g(tag))
                    if date: break
            if date and date < now() - dt.timedelta(days=c.get("max_age_days", 3)):
                continue
            blob = (title + " " + summ).lower()
            score, hits = 0, []
            if feed.get("topic"):
                score += topics.get(feed["topic"], {}).get("weight", 1); hits.append(feed["topic"])
            for topic, spec in topics.items():
                for kw in spec["keywords"]:
                    if kw.lower() in blob:
                        score += spec.get("weight", 1); hits.append(topic); break
            if score <= 0: continue
            nid = "n:" + str(abs(hash(link or title)) % 10**12)
            if nid in STATE["news_hidden"]: continue
            items.append({"id": nid, "title": title, "link": link, "summary": re.sub(r"\s+", " ", summ).strip(),
                          "source": feed.get("name", ""), "date": iso(date), "score": score, "topics": sorted(set(hits))})
    seen, uniq = set(), []
    for it in sorted(items, key=lambda x: (x["score"], x["date"] or ""), reverse=True):
        k = re.sub(r"\W+", "", it["title"].lower())[:60]
        if k in seen: continue
        seen.add(k); uniq.append(it)
    capped, per = [], {}
    for it in uniq:
        main = it["topics"][0] if it["topics"] else ""
        cap = topics.get(main, {}).get("max")
        if cap is not None and per.get(main, 0) >= cap: continue
        per[main] = per.get(main, 0) + 1; capped.append(it)
    uniq = capped[: c.get("max_items", 12)]
    oc = CFG.get("ollama")
    if oc and oc.get("enabled") and uniq:
        prev = CACHE.get("news", {}).get("items", [])
        known = {p["id"]: p.get("why") for p in prev if p.get("why")}
        for it in uniq[:5]:
            if it["id"] in known: it["why"] = known[it["id"]]; continue
            try:
                it["why"] = ollama("En una frase de máximo 20 palabras, en español, di por qué esta noticia le importa a alguien "
                                   "con estos intereses: %s.\nNoticia: %s. %s" % (", ".join(topics), it["title"], it["summary"][:300]))
            except Exception as e:
                log("ollama", e); break
    return {"items": uniq}

# ───────── bóveda de Obsidian, skills, buzón, artefactos y orgullo ─────────
SUGG = jload("suggestions.json", None)
ARTS = jload("artifacts.json", [])
PROUD = jload("proud.json", [])
EVENTS = []
MSGS = jload("chat.json", [])

def say(frm, to, text, kind="msg"):
    """Registro de mensajes reales del sistema: sugerencias, respuestas, encargos, entregas y lo que los agentes se dicen por informe."""
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    if not text or not frm: return
    with LOCK:
        MSGS.append({"id": "m:" + uuid.uuid4().hex[:8], "from": str(frm)[:40], "to": str(to or "Nawe")[:40], "text": text[:280], "kind": kind, "at": iso(now())})
        del MSGS[:-150]; jsave("chat.json", MSGS)

def ex_label(k): return CFG.get("executors", {}).get(k, {}).get("label", k or "?")

def expand(p):
    return os.path.abspath(os.path.expanduser(p)) if p else None

@collector("vault", 120)
def c_vault():
    v = CFG.get("vault") or {}
    root = expand(v.get("path"))
    if not root or not os.path.isdir(root): return None
    notes = []
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if not d.startswith(".") and d != "_to_delete"]   # lo apartado para borrar no es bóveda
        for fn in fns:
            if fn.endswith(".md") and ".sync-conflict-" not in fn:
                fp = os.path.join(dp, fn)
                try: notes.append((os.path.getmtime(fp), os.path.relpath(fp, root)[:-3]))
                except OSError: pass
        if len(notes) > 5000: break
    notes.sort(reverse=True)
    VLIVE["known"] = {n for _, n in notes}
    out = {"total": len(notes), "recent": [{"title": os.path.basename(n), "path": n, "mtime": iso(dt.datetime.fromtimestamp(m).astimezone())} for m, n in notes[:24]]}
    try:
        out["graph"] = vault_graph(root, notes)
        g = out["graph"]; sig = hash((tuple(n["id"] for n in g["nodes"]), tuple(map(tuple, g["edges"]))))
        if sig != VLIVE.get("sig"): VLIVE["sig"] = sig; VLIVE["gv"] += 1
    except Exception as e: log("grafo de la bóveda: %s" % e)
    out["live"] = {"mode": VLIVE.get("mode"), "gv": VLIVE.get("gv")}
    return out

LINK_RE = re.compile(r"\[\[([^\]|#^]+)")
GRAPH_CACHE = {"key": None, "pos": {}}
LINKS_CACHE = {}   # nota -> (mtime, tamaño, [destinos]): Faro solo relee lo que ha cambiado (y así no se pinta a sí mismo leyendo)

def _note_links(root, n):
    fp = os.path.join(root, n + ".md")
    try: st = os.stat(fp)
    except OSError: return []
    c = LINKS_CACHE.get(n)
    if c and c[0] == st.st_mtime and c[1] == st.st_size: return c[2]
    SELF_TOUCH[n] = (time.time(), "read")
    try:
        with open(fp, encoding="utf-8", errors="ignore") as f: txt = f.read(200000)
    except OSError: return []
    ln = [t.strip().rstrip("\\").strip() for t in LINK_RE.findall(txt)]  # en tablas el alias va con \|
    LINKS_CACHE[n] = (st.st_mtime, st.st_size, ln); return ln

def vault_graph(root, notes, limit=400):
    """Grafo de la bóveda como el de Obsidian: notas = nodos, [[enlaces]] = aristas. Posiciones estables (fuerzas con semilla fija)."""
    import unicodedata
    K = lambda x: unicodedata.normalize("NFC", x).strip().lower()
    by_name = {}
    for _, n in notes: by_name.setdefault(K(os.path.basename(n)), n); by_name[K(n)] = n
    mt = {n: m for m, n in notes}; edges = set(); deg = {}
    for m, n in notes[:1500]:
        for tgt in _note_links(root, n):
            t = by_name.get(K(tgt)) or by_name.get(K(os.path.basename(tgt)))
            if t and t != n: e = tuple(sorted((n, t))); edges.add(e)
    for a, b in edges: deg[a] = deg.get(a, 0) + 1; deg[b] = deg.get(b, 0) + 1
    tnow = time.time()
    keep = sorted(mt, key=lambda n: (-(deg.get(n, 0) * 3 + (5 if tnow - mt[n] < 86400 else 0)), n))[:limit]
    ks = set(keep); E = [(a, b) for a, b in edges if a in ks and b in ks]
    heat_io(); hv = {n: heat_now(n, tnow) for n in keep}; hmax = max(hv.values() or [0]) or 1
    import math
    hnorm = lambda n: round(math.log1p(hv[n]) / math.log1p(hmax), 3) if hv[n] > .05 else 0
    HN = {n: hnorm(n) for n in keep}
    key = (tuple(sorted(keep)), tuple(sorted(E)), tuple(round(HN[n], 1) for n in sorted(keep)))   # si cambia el calor, cambia la forma
    if GRAPH_CACHE["key"] != key:
        import random; rnd = random.Random(7); pos = dict(GRAPH_CACHE["pos"])
        for n in keep: pos.setdefault(n, [rnd.uniform(-1, 1), rnd.uniform(-1, 1)])
        idx = {n: i for i, n in enumerate(keep)}; P = [pos[n][:] for n in keep]; N = len(P)
        import math
        grp = lambda n: n.split("/")[0] if "/" in n else "·raíz"
        dirs = sorted({grp(n) for n in keep}, key=lambda d: -sum(1 for n in keep if grp(n) == d))
        anc = {d: (0.0, 0.0) if i == 0 and d == "·raíz" else (1.4 * math.cos(2 * math.pi * i / max(1, len(dirs))), 1.4 * math.sin(2 * math.pi * i / max(1, len(dirs)))) for i, d in enumerate(dirs)}
        G = [anc[grp(n)] for n in keep]
        dmx = max([deg.get(n, 0) for n in keep] or [1]) or 1
        Dn = [deg.get(n, 0) / dmx for n in keep]
        Hm = [max(HN[n], Dn[i]) for i, n in enumerate(keep)]   # masa = calor o conexiones: lo grande y lo rojo pesan y atraen
        hot = [j for j in range(N) if Hm[j] > .15]; CORE = 160
        for it in range(160):
            F = [[0.0, 0.0] for _ in range(N)]; k = 1.8 / max(1, N) ** .5
            for i in range(N):
                for j in range(i + 1, N):
                    dx = P[i][0] - P[j][0]; dy = P[i][1] - P[j][1]; d2 = dx * dx + dy * dy + 1e-4; f = k * k / d2
                    F[i][0] += dx * f; F[i][1] += dy * f; F[j][0] -= dx * f; F[j][1] -= dy * f
            for a, b in E:
                i, j = idx[a], idx[b]; dx = P[i][0] - P[j][0]; dy = P[i][1] - P[j][1]; d = (dx * dx + dy * dy) ** .5 + 1e-4; f = d / k * .05
                F[i][0] -= dx * f; F[i][1] -= dy * f; F[j][0] += dx * f; F[j][1] += dy * f
            for j in hot:   # gravedad de las notas calientes (suavizada para que no colapse nada)
                for i in range(N):
                    if i == j: continue
                    dx = P[j][0] - P[i][0]; dy = P[j][1] - P[i][1]; f = .004 * Hm[j] / (dx * dx + dy * dy + .01)
                    F[i][0] += dx * f; F[i][1] += dy * f
            step = .06 * (1 - it / 160) + .004
            for i in range(N):   # cada nota tira hacia el ancla de su carpeta (islas); los nudos grandes, hacia el centro (núcleo)
                c = Dn[i] ** 2; ax, ay = G[i][0] * (1 - c), G[i][1] * (1 - c)
                kc = CORE * Dn[i] ** 1.5   # núcleo: cuanto más enlazado, más fuerte va al centro
                fx, fy = F[i]; fx += (ax - P[i][0]) * .45 - P[i][0] * (.01 + kc); fy += (ay - P[i][1]) * .45 - P[i][1] * (.01 + kc); m = (fx * fx + fy * fy) ** .5 + 1e-9
                si = step / (1 + 2 * Hm[i])   # inercia: lo pesado se mueve menos
                P[i][0] += fx / m * min(m, si); P[i][1] += fy / m * min(m, si)
        # encuadre por percentiles: los nodos sueltos no aplastan el grupo principal (como el zoom del grafo de Obsidian)
        xs = sorted(p[0] for p in P) or [0]; ys = sorted(p[1] for p in P) or [0]; q = lambda a, f: a[min(len(a) - 1, max(0, int(f * (len(a) - 1))))]
        # encuadre simétrico: el centro de fuerzas (donde va el núcleo) queda en el centro de la pantalla, que es el eje del giro
        ax_ = sorted(abs(p[0]) for p in P) or [1]; ay_ = sorted(abs(p[1]) for p in P) or [1]; X = q(ax_, .985) or 1; Y = q(ay_, .985) or 1
        x0, x1, y0, y1 = -X, X, -Y, Y; sx = (x1 - x0) or 1; sy = (y1 - y0) or 1
        cl = lambda v: min(1.0, max(0.0, v))
        GRAPH_CACHE["pos"] = {n: [round(cl((P[i][0] - x0) / sx), 3), round(cl((P[i][1] - y0) / sy), 3)] for n, i in idx.items()}
        GRAPH_CACHE["key"] = key
    pos = GRAPH_CACHE["pos"]; idx = {n: i for i, n in enumerate(keep)}
    lone = re.compile(r"(^|/)(prueba-[^/]*|Bienvenido|LEEME)$|^99 Plantillas/|^01 Bandeja/|^_adjuntos/")
    orph = lambda n: 0 if deg.get(n, 0) else (2 if lone.search(n) else 1)   # 1 = huérfana de verdad · 2 = suelta a propósito
    nodes = [{"id": n, "t": os.path.basename(n), "d": deg.get(n, 0), "x": pos[n][0], "y": pos[n][1], "age": int(tnow - mt[n]), "m": int(mt[n]),
              "dir": n.split("/")[0] if "/" in n else "", "o": orph(n), "h": HN[n], "hr": round(hv[n], 2)} for n in keep]
    return {"nodes": nodes, "edges": [[idx[a], idx[b]] for a, b in E], "total": len(notes), "links": len(edges),
            "orphans": sum(1 for x in nodes if x["o"] == 1), "lone": sum(1 for x in nodes if x["o"] == 2),
            "leaves": sum(1 for x in nodes if x["d"] == 1), "hot": [x["id"] for x in sorted(nodes, key=lambda x: -x["h"])[:5] if x["h"] > 0]}

# ───────── bóveda en vivo: qué nota se lee, se escribe, nace o se borra, al instante ─────────
# En el PC se usa inotify (núcleo de Linux, sin instalar nada): lecturas (cierre sin escritura), escrituras, altas, bajas y
# renombrados. Lo que llega por Syncthing desde el Mac se reconoce por su archivo temporal. Si no hay inotify, se sondea cada 2 s.
VLIVE = {"ev": [], "seq": 0, "gv": 0, "mode": None, "err": None, "dirty": 0.0, "known": set(), "watches": 0}
SELF_TOUCH = {}   # nota -> (t, "read"|"write"): lo que Faro toca él mismo
VSEEN = {}        # nota -> última escritura que ya salió en la oficina (para que el sondeo no la repita)
HEAT = {"n": {}, "saved": 0, "loaded": False}   # nota -> [puntos, t]: lecturas (1) y escrituras (2) reales, mitad cada 3 días
HEAT_HALF = 3 * 86400

def heat_now(rel, t=None):
    v = HEAT["n"].get(rel)
    if not v: return 0.0
    return v[0] * 0.5 ** (((t or time.time()) - v[1]) / HEAT_HALF)

def heat_add(rel, pts):
    t = time.time(); HEAT["n"][rel] = [heat_now(rel, t) + pts, t]

def heat_io():
    fp = os.path.join(ROOT, "data", "vault_heat.json")
    if not HEAT["loaded"]:
        HEAT["loaded"] = True
        try:
            with open(fp, encoding="utf-8") as f: HEAT["n"].update(json.load(f))
        except Exception: pass
    if time.time() - HEAT["saved"] > 120:
        HEAT["saved"] = time.time()
        try:
            tmp = fp + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f: json.dump({k: v for k, v in HEAT["n"].items() if heat_now(k) > .05}, f)
            os.replace(tmp, fp)
        except Exception as e: log("calor de la bóveda: %s" % e)

def vmark(fp):
    root = vault_root(); rel = _vrel(root, os.path.abspath(fp)) if root else None
    if rel: SELF_TOUCH[rel] = (time.time(), "write")

def vault_root():
    return expand((CFG.get("vault") or {}).get("path"))

def _vrel(root, fp):
    rel = os.path.relpath(fp, root)
    if rel.startswith("..") or not rel.endswith(".md"): return None
    if any(p.startswith(".") for p in rel.split(os.sep)): return None
    return rel[:-3].replace(os.sep, "/")

def vault_who(via):
    """Quién toca la bóveda. inotify no dice el proceso: se atribuye solo si hay un único candidato posible
    (o uno solo con la acción «obsidian»). Si no, queda sin identificar: mejor eso que inventarlo."""
    cand = {}
    def add(name, local, obs):
        if not name: return
        k = (brand_of(name), local); cur = cand.get(k)
        if not cur or (obs and not cur[1]): cand[k] = (name, obs)
    for o in ORDERS:
        if o.get("state") == "running" and o.get("executor") not in (None, "faro"):
            add(ex_label(o["executor"]), True, o.get("action") == "obsidian")
    for a in (STATUS.get("agents") or []) + (STATUS.get("running") or []):
        if a.get("state") != "run" or a.get("done"): continue
        local = bool(a.get("live")) or not (a.get("cloud") or "mac" in (a.get("name") or "").lower())
        add(a.get("name"), local, (a.get("action") or "") == "obsidian")
    want = via != "sync"
    c = [v for k, v in cand.items() if k[1] == want]
    obs = [n for n, o in c if o]
    if len(obs) == 1: return obs[0], None          # declara que trabaja en la bóveda: seguro
    if len(c) == 1: return None, c[0][0]           # único en marcha, pero no lo declara: solo «probable»
    return None, None

_SYSR = {"t": 0, "v": None}
def _sys_reader():
    """Lectores del sistema que no son agentes: el historial horario de git de la bóveda."""
    if time.time() - _SYSR["t"] < 1: return _SYSR["v"]
    v = None
    try:
        for pid in os.listdir("/proc"):
            if not pid.isdigit(): continue
            try: comm = open("/proc/%s/comm" % pid).read().strip()
            except OSError: continue
            if comm == "git" or comm.startswith("nahuel-git"): v = "Historial (git)"; break
    except OSError: pass
    _SYSR.update(t=time.time(), v=v); return v

def vault_event(rel, kind, who=None, via=None):
    t = time.time()
    with LOCK:
        ev = VLIVE["ev"]
        for e in reversed(ev[-40:]):
            if e["p"] == rel and t - e["t"] < 2.5 and (e["k"] == kind or (e["k"] == "new" and kind == "write")):
                e["t"] = t; e["n"] = e.get("n", 1) + 1
                if kind in ("new", "write", "del"): VSEEN[rel] = t
                return
        st = SELF_TOUCH.get(rel); maybe = None
        if st and t - st[0] < 6: who, via = "Faro", "faro"
        elif who is None:
            sr = _sys_reader() if via is None else None
            if sr: who, via = sr, "sistema"
            else: who, maybe = vault_who(via)
        VLIVE["seq"] += 1
        ev.append({"s": VLIVE["seq"], "t": t, "p": rel, "k": kind, "who": who, "maybe": maybe, "via": via})
        if who != "Faro" and kind in ("read", "write", "new"): heat_add(rel, 1 if kind == "read" else 2)
        del ev[:-400]
    if kind in ("new", "write", "del"):
        VLIVE["dirty"] = VLIVE["dirty"] or t; VSEEN[rel] = t
        if who != "Faro" and "vault_links" in COLLECTORS: COLLECTORS["vault_links"]["last"] = 0  # repaso al instante

def _vault_rebuild():
    if VLIVE["dirty"] and time.time() - VLIVE["dirty"] > 1.2:
        VLIVE["dirty"] = 0
        try:
            out = c_vault()
            if out: CACHE["vault"] = out; COLLECTORS["vault"]["last"] = time.time(); build_status()
        except Exception as e: log("bóveda en vivo: %s" % e)

def vault_watch():
    root = vault_root()
    if not root or not os.path.isdir(root): return
    try:
        import ctypes, ctypes.util, select, struct
        libc = ctypes.CDLL(ctypes.util.find_library("c") or "libc.so.6", use_errno=True)
        fd = libc.inotify_init1(0o4000 | 0o2000000)   # IN_NONBLOCK | IN_CLOEXEC
        if fd < 0: raise OSError(ctypes.get_errno(), "inotify_init1")
    except Exception as e:
        VLIVE.update(mode="sondeo", err=str(e)[:80]); return _vault_poll(root)
    # IN_CLOSE_WRITE, IN_CLOSE_NOWRITE, IN_MOVED_FROM, IN_MOVED_TO, IN_CREATE, IN_DELETE
    MASK = 0x8 | 0x10 | 0x40 | 0x80 | 0x100 | 0x200
    wds = {}
    def add(d):
        wd = libc.inotify_add_watch(fd, d.encode(), MASK)
        if wd >= 0: wds[wd] = d
    def walk_add(top, announce):
        for dp, dns, fns in os.walk(top):
            dns[:] = [x for x in dns if not x.startswith(".")]
            add(dp)
            if announce:
                for fn in fns:
                    rel = _vrel(root, os.path.join(dp, fn))
                    if rel: VLIVE["known"].add(rel); vault_event(rel, "new")
    walk_add(root, False)
    VLIVE.update(mode="inotify", watches=len(wds), err=None)
    cookies, last_write = {}, {}
    while True:
        try:
            r, _, _ = select.select([fd], [], [], 1.0)
            buf = b""
            if r:
                try: buf = os.read(fd, 65536)
                except BlockingIOError: buf = b""
            i, tnow = 0, time.time()
            while i + 16 <= len(buf):
                wd, mask, cookie, ln = struct.unpack_from("iIII", buf, i)
                name = buf[i + 16:i + 16 + ln].split(b"\0", 1)[0].decode("utf-8", "replace"); i += 16 + ln
                if mask & 0x8000: wds.pop(wd, None); continue          # IN_IGNORED
                d = wds.get(wd)
                if d is None or not name: continue
                fp = os.path.join(d, name)
                if mask & 0x40000000:                                   # carpetas: vigilar las nuevas
                    if mask & (0x100 | 0x80) and not name.startswith("."): walk_add(fp, True)
                    continue
                if mask & 0x40:                                         # sale con nombre viejo (o es el temporal de Syncthing)
                    cookies[cookie] = (tnow, _vrel(root, fp), bool(re.match(r"^(\.syncthing\.|~syncthing~)", name)))
                    continue
                rel = _vrel(root, fp)
                if not rel: continue
                known = VLIVE["known"]
                if mask & 0x80:                                         # entra (renombrado o llegado por Syncthing)
                    c = cookies.pop(cookie, None); via = "sync" if c and c[2] else None
                    if c and c[1] and c[1] != rel: known.discard(c[1]); vault_event(c[1], "del")
                    vault_event(rel, "write" if rel in known else "new", via=via); known.add(rel); last_write[rel] = tnow
                elif mask & (0x100 | 0x8):                              # creada o escrita
                    vault_event(rel, "write" if rel in known else "new"); known.add(rel); last_write[rel] = tnow
                elif mask & 0x10:                                       # leída (cerrada sin escribir)
                    if tnow - last_write.get(rel, 0) < 25: continue     # Syncthing y Obsidian releen justo después de escribir
                    st = SELF_TOUCH.get(rel)
                    if st and tnow - st[0] < 6: continue
                    vault_event(rel, "read")
                elif mask & 0x200:
                    known.discard(rel); vault_event(rel, "del")
            for ck, (t0, rel, sync) in list(cookies.items()):         # salió y no volvió: borrada o fuera de la bóveda
                if tnow - t0 > 1.0:
                    cookies.pop(ck, None)
                    if rel and not sync: VLIVE["known"].discard(rel); vault_event(rel, "del")
            if len(last_write) > 2000: last_write = {k: v for k, v in last_write.items() if tnow - v < 60}
            VLIVE["watches"] = len(wds)
            _vault_rebuild()
        except Exception as e:
            VLIVE["err"] = str(e)[:80]; log("vigía de la bóveda: %s" % e); time.sleep(2)

def _vault_poll(root):
    prev = None
    while True:
        cur = {}
        for dp, dns, fns in os.walk(root):
            dns[:] = [x for x in dns if not x.startswith(".")]
            for fn in fns:
                rel = _vrel(root, os.path.join(dp, fn))
                if rel:
                    try: cur[rel] = os.path.getmtime(os.path.join(dp, fn))
                    except OSError: pass
        if prev is not None:
            for k, m in cur.items():
                if k not in prev: vault_event(k, "new")
                elif m != prev[k]: vault_event(k, "write")
            for k in prev:
                if k not in cur: vault_event(k, "del")
        prev = cur; _vault_rebuild(); time.sleep(2)

def vault_live(since, gv):
    t = time.time()
    with LOCK:
        seq = VLIVE["seq"]
        ev = [e for e in VLIVE["ev"] if e["s"] > since or since > seq][-80:]
        ev = [{**e, "ago": round(t - e["t"], 1)} for e in ev]
    out = {"seq": seq, "gv": VLIVE["gv"], "mode": VLIVE["mode"], "watches": VLIVE.get("watches"), "ev": ev}
    if gv != VLIVE["gv"]: out["graph"] = (CACHE.get("vault") or {}).get("graph")
    return out

# ───────── máquinas: CPU, RAM y gráfica en vivo (PC aquí mismo; el Mac lo envía su vigía) ─────────
MACHINES = {}; _CPU_PREV = [None]; _PC_CACHE = {"t": 0, "v": None}
GPU_AGENT = [(r"ollama|llama|strata|vllm|koboldcpp|lmstudio", "Strata"), (r"hermes", "Hermes"), (r"codex", "Codex"), (r"claude", "Claude"),
             (r"ffmpeg|whisper|blender|davinci|resolve", "render"), (r"freqtrade", "freqtrade")]

def _gpu_owner(name):
    for rx, who in GPU_AGENT:
        if re.search(rx, name or "", re.I): return who
    return None

def pc_machine():
    if time.time() - _PC_CACHE["t"] < 1.5 and _PC_CACHE["v"]: return _PC_CACHE["v"]
    m = {"name": "PC", "kind": "pc", "host": socket.gethostname(), "at": iso(now())}
    try:
        with open("/proc/stat") as f: v = [int(x) for x in f.readline().split()[1:]]
        idle, tot = v[3] + (v[4] if len(v) > 4 else 0), sum(v); pv = _CPU_PREV[0]; _CPU_PREV[0] = (idle, tot)
        if pv and tot > pv[1]: m["cpu"] = round(100 * (1 - (idle - pv[0]) / (tot - pv[1])), 1)
        m["ncpu"] = os.cpu_count()
        mi = {}
        with open("/proc/meminfo") as f:
            for ln in f: k, val = ln.split(":", 1); mi[k] = int(val.split()[0])
        used = mi.get("MemTotal", 0) - mi.get("MemAvailable", 0)
        m.update(ram=round(used / mi["MemTotal"] * 100, 1), ram_gb=round(used / 2**20, 1), ram_total_gb=round(mi["MemTotal"] / 2**20, 1))
    except Exception: pass
    try:   # temperatura de la CPU (coretemp/k10temp/zenpower): la más alta de sus sensores
        for hd in glob.glob("/sys/class/hwmon/hwmon*"):
            try: nm = open(hd + "/name").read().strip()
            except OSError: continue
            if nm in ("coretemp", "k10temp", "zenpower", "cpu_thermal"):
                vals = [int(open(f).read()) / 1000 for f in glob.glob(hd + "/temp*_input")]
                if vals: m["cpu_temp"] = round(max(vals)); break
    except Exception: pass
    if shutil.which("nvidia-smi"):
        try:
            q = subprocess.run(["nvidia-smi", "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw",
                                "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=3).stdout.strip().splitlines()[0]
            n, u, mu, mt, tp, pw = [x.strip() for x in q.split(",")]
            m.update(gpu_name=n, gpu=int(float(u)), vram_gb=round(float(mu) / 1024, 1), vram_total_gb=round(float(mt) / 1024, 1),
                     gpu_temp=int(float(tp)) if tp not in ("", "[N/A]") else None, gpu_w=round(float(pw)) if pw not in ("", "[N/A]") else None)
            apps = subprocess.run(["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory", "--format=csv,noheader,nounits"],
                                  capture_output=True, text=True, timeout=3).stdout.strip().splitlines()
            ga = []
            for ln in apps:
                pid, pn, um = [x.strip() for x in ln.split(",")]
                try: cmd = open("/proc/%s/cmdline" % pid, "rb").read().replace(b"\0", b" ").decode("utf-8", "ignore")[:200]
                except Exception: cmd = pn
                ga.append({"name": os.path.basename(pn)[:28], "vram_gb": round(float(um) / 1024, 1), "agent": _gpu_owner(cmd) or _gpu_owner(pn)})
            m["gpu_apps"] = sorted(ga, key=lambda x: -x["vram_gb"])[:5]
        except Exception as e: m["gpu_error"] = str(e)[:80]
    try:
        io = _disk_io()
        if io: m["disk_r"], m["disk_w"] = io
        elif _PC_CACHE["v"] and _PC_CACHE["v"].get("disk_r") is not None: m["disk_r"], m["disk_w"] = _PC_CACHE["v"]["disk_r"], _PC_CACHE["v"]["disk_w"]
    except Exception: pass
    try:
        tp = _proc_top(os.cpu_count() or 1)
        if tp is not None: m["top"] = tp
        elif _PC_CACHE["v"] and _PC_CACHE["v"].get("top"): m["top"] = _PC_CACHE["v"]["top"]
    except Exception: pass
    _PC_CACHE.update(t=time.time(), v=m); return m

_DISK_PREV = {"t": 0, "v": None}
def _disk_io():
    """MB/s que el PC lee y escribe en disco AHORA (diferencia de /proc/diskstats entre lecturas), solo discos
    físicos (nvme, sd, vd, mmcblk), sin contar particiones dos veces."""
    t, rd, wr = time.time(), 0, 0
    with open("/proc/diskstats") as f:
        for ln in f:
            p = ln.split()
            if len(p) > 9 and re.fullmatch(r"nvme\d+n\d+|sd[a-z]+|vd[a-z]+|xvd[a-z]+|mmcblk\d+", p[2]): rd += int(p[5]); wr += int(p[9])
    prev, pt = _DISK_PREV["v"], _DISK_PREV["t"]; _DISK_PREV.update(t=t, v=(rd, wr))
    if not prev or t - pt <= 0.3 or rd < prev[0] or wr < prev[1]: return None
    return round((rd - prev[0]) * 512 / 1e6 / (t - pt), 1), round((wr - prev[1]) * 512 / 1e6 / (t - pt), 1)

_PROC_PREV = {"t": 0, "v": {}}
def _proc_top(nc):
    """CPU de cada programa AHORA (diferencia de tiempos de /proc entre dos lecturas), sumando sus procesos.
    «ps» da la media de toda la vida del proceso y por eso parecía clavado."""
    tk = os.sysconf("SC_CLK_TCK") or 100; tnow = time.time(); cur = {}
    for pid in os.listdir("/proc"):
        if not pid.isdigit(): continue
        try:
            with open("/proc/%s/stat" % pid, "rb") as f: raw = f.read().decode("utf-8", "replace")
            i, j = raw.index("("), raw.rindex(")"); rest = raw[j + 2:].split()
            cur[pid] = (int(rest[11]) + int(rest[12]), raw[i + 1:j])
        except (OSError, ValueError, IndexError): pass
    prev, dt = _PROC_PREV["v"], tnow - _PROC_PREV["t"]
    _PROC_PREV.update(t=tnow, v=cur)
    if not prev or dt <= 0.2 or dt > 60: return None
    agg = {}
    for pid, (ticks, comm) in cur.items():
        p = prev.get(pid)
        if p and p[1] == comm and ticks >= p[0]: agg[comm] = agg.get(comm, 0) + ticks - p[0]
    top = sorted(((v / tk / dt / nc * 100, k) for k, v in agg.items()), reverse=True)[:6]
    return [{"name": k[:28], "cpu": round(c, 1), "agent": _gpu_owner(k)} for c, k in top if c >= 0.5]

# ───────── Strata en vivo (su pantalla en la oficina): modelo cargado y tokens que lee y escribe ─────────
_ST = {"t": 0, "v": None, "mt": 0, "model": None, "slots": {}, "met": None, "last": None, "pids": [], "pt": 0, "io": None}
def _strata_io():
    """MB/s que leen y escriben en disco los procesos de Strata (cargar un modelo son gigas de lectura).
    /proc/<pid>/io de los procesos del propio usuario; la lista de procesos se renueva cada 30 s."""
    t = time.time()
    if t - _ST["pt"] > 30:
        me, pids = str(os.getpid()), []
        for pid in os.listdir("/proc"):
            if not pid.isdigit() or pid == me: continue
            try: args = open("/proc/%s/cmdline" % pid, "rb").read().decode("utf-8", "ignore").lower().split("\0")
            except OSError: continue
            head = " ".join(args[:2])   # solo el programa (y su script): una orden que solo «menciona» Strata no cuenta
            if re.search(r"strata|llama-server|llama_cpp|llamacpp", head) and not re.search(r"conectar-strata|faro\.py|faro-informa|grep|curl", head): pids.append(pid)
        _ST["pids"], _ST["pt"] = pids, t
    rb = wb = 0; ok = False
    for pid in _ST["pids"]:
        try:
            kv = dict(ln.split(":", 1) for ln in open("/proc/%s/io" % pid).read().splitlines() if ":" in ln)
            rb += int(kv.get("read_bytes", 0)); wb += int(kv.get("write_bytes", 0)); ok = True
        except (OSError, ValueError): pass
    prev = _ST["io"]; _ST["io"] = (rb, wb, t) if ok else None
    if not ok or not prev or t - prev[2] <= 0.3 or rb < prev[0] or wb < prev[1]: return None
    return round((rb - prev[0]) / 1e6 / (t - prev[2]), 1), round((wb - prev[1]) / 1e6 / (t - prev[2]), 1)
def _short_model(mid):
    m = os.path.basename(str(mid or "")).replace(".gguf", "")
    for _ in range(4):   # quita colas de cuantización y empaquetado: -Q4_K_M, -unsloth-ud, -gguf…
        m2 = re.sub(r"(?i)[-_.](q\d[\w]*|iq\d[\w]*|f16|bf16|fp16|gguf|instruct|unsloth|ud|mlx|awq|gptq|\d+bit)$", "", m)
        if m2 == m: break
        m = m2
    return m[:40]
def strata_timings(d, secs):
    """Lo que tarda Strata en cada orden de Faro (llama.cpp devuelve «timings»; si no, «usage» y el reloj)."""
    tm, us = (d or {}).get("timings") or {}, (d or {}).get("usage") or {}
    r = {"read_tps": tm.get("prompt_per_second"), "write_tps": tm.get("predicted_per_second"),
         "read": tm.get("prompt_n") or us.get("prompt_tokens"), "write": tm.get("predicted_n") or us.get("completion_tokens"), "at": time.time()}
    if r["write_tps"] is None and r["write"] and secs > 0: r["write_tps"] = r["write"] / secs
    _ST["last"] = {k: (round(v, 1) if isinstance(v, float) else v) for k, v in r.items()}
def strata_live():
    """Para la pantalla de Strata: modelo cargado, si está pensando y cuántos tokens lee (entrada) y escribe (salida)
    por segundo AHORA. Solo pregunta a localhost con su cabecera (la clave nunca sale ni se muestra), como mucho
    cada 2 s y solo mientras la oficina está abierta (lo pide /api/machines)."""
    t = time.time()
    if _ST["v"] is not None and t - _ST["t"] < 1.8: return _ST["v"]
    _ST["t"] = t
    urls = list(dict.fromkeys([u for u in [strata_url()] + list(CFG.get("strata_urls", ["http://127.0.0.1:18501"])) if u]))
    out = {"ok": False}
    for u in urls:
        base, hdr = u.rstrip("/"), local_auth(u)
        try:
            if t - _ST["mt"] > 30 or not _ST["model"]:
                ms = http_json(base + "/v1/models", timeout=1.5, headers=hdr).get("data") or []
                _ST["model"] = _short_model((ms[0] or {}).get("id")) if ms else None; _ST["mt"] = t
        except Exception: continue
        out = {"ok": True, "model": _ST["model"], "busy": False}
        # en directo: lo que lleva escrito cada hueco (slot) entre dos lecturas
        try:
            sl = http_json(base + "/slots", timeout=1.5, headers=hdr) or []
            busy, wr, had, prev, cur = False, 0.0, False, _ST["slots"], {}
            for x in sl:
                nt = x.get("next_token"); nt = nt[0] if isinstance(nt, list) and nt else (nt or {})
                n, sid = int(nt.get("n_decoded") or 0), x.get("id")
                cur[sid] = (n, t)
                if x.get("is_processing"):
                    busy = True; p = prev.get(sid)
                    if p and n >= p[0] and t > p[1]: wr += (n - p[0]) / (t - p[1]); had = True
                ctx = x.get("n_ctx")
                if ctx: out["ctx"] = ctx
            _ST["slots"] = cur; out["busy"] = busy
            if busy and had: out["write_tps"] = round(wr, 1)
        except Exception: pass
        # métricas de llama.cpp (si Strata las da): totales y ritmo de entrada/salida
        try:
            txt = http(base + "/metrics", timeout=1.5, headers=hdr).decode("utf-8", "replace"); met = {}
            for ln in txt.splitlines():
                mm = re.match(r"llamacpp:(\w+)\s+([0-9.eE+-]+)$", ln.strip())
                if mm: met[mm.group(1)] = float(mm.group(2))
            pm, prev = (met.get("prompt_tokens_total"), met.get("tokens_predicted_total")), _ST["met"]
            if pm[0] is not None:
                out["read_total"], out["write_total"] = int(pm[0]), int(pm[1] or 0)
                if prev and t > prev[2]:
                    dr = (pm[0] - prev[0]) / (t - prev[2])
                    if dr > 0: out["read_tps"] = round(dr, 1)
                _ST["met"] = (pm[0], pm[1] or 0, t)
            if met.get("prompt_tokens_seconds"): out["read_avg"] = round(met["prompt_tokens_seconds"], 1)
            if met.get("predicted_tokens_seconds"): out["write_avg"] = round(met["predicted_tokens_seconds"], 1)
            if met.get("kv_cache_usage_ratio") is not None: out["kv"] = round(met["kv_cache_usage_ratio"] * 100)
        except Exception: pass
        break
    if _ST["last"]: out["last"] = {**_ST["last"], "age": int(t - _ST["last"]["at"])}
    try:
        io = _strata_io()
        if io: out["disk_r"], out["disk_w"] = io
        out["procs"] = len(_ST["pids"])
    except Exception: pass
    _ST["v"] = out; return out

def machines():
    out = [pc_machine()]
    for k, v in list(MACHINES.items()):
        st = parse_iso(v.get("at")); age = (now() - st).total_seconds() if st else 1e9
        if age < 60: out.append({**v, "age": int(age)})
    return out

# ───────── conexiones de la bóveda y espejo del repositorio de GitHub ─────────
sys.path.insert(0, os.path.join(ROOT, "tools"))
try:
    import vault_links as VL
except Exception as _e:
    VL = None
VL_STATE = {"sig": None, "at": 0}
REPO = {"heads": None, "info": None}
REPO_NOTE = "30 Recursos/GitHub CHF_GAME.md"

def _vault_sig(root):
    n, m = 0, 0.0
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if not d.startswith(".") and d != "_to_delete"]
        for fn in fns:
            if fn.endswith(".md"):
                n += 1
                try: m = max(m, os.path.getmtime(os.path.join(dp, fn)))
                except OSError: pass
    return (n, round(m, 1))

def _git(*a, timeout=40):
    return subprocess.run([shutil.which("git") or "git", *a], capture_output=True, text=True, timeout=timeout)

@collector("repo_chf", 300)
def c_repo_chf():
    """Espejo de solo lectura del repo público en la bóveda: qué hay publicado, últimos cambios y versión de Faro."""
    c = CFG.get("repo_mirror") or {}
    if c.get("enabled") is False or not shutil.which("git"): return None
    url = c.get("git", "https://github.com/Nawebaz/CHF_GAME.git")
    ls = _git("ls-remote", "--heads", url)
    if ls.returncode: raise RuntimeError("git ls-remote: " + ls.stderr[:100])
    heads = {l.split("refs/heads/")[-1]: l.split()[0] for l in ls.stdout.splitlines() if "refs/heads/" in l}
    if heads == REPO["heads"] and REPO["info"]: return REPO["info"]
    d = os.path.join(ROOT, "data", "repo")
    if not os.path.isdir(os.path.join(d, ".git")): os.makedirs(d, exist_ok=True); _git("-C", d, "init", "-q")
    main = c.get("branch", "main"); info = {"branches": sorted(heads), "at": iso(now())}
    if _git("-C", d, "fetch", "-q", "--depth", "15", url, main, timeout=120).returncode == 0:
        info["commits"] = [l.split("|", 2) for l in _git("-C", d, "log", "--format=%cs|%h|%s", "-12", "FETCH_HEAD").stdout.splitlines()]
        readme = _git("-C", d, "show", "FETCH_HEAD:README.md").stdout
        info["links"] = []
        for href, label in re.findall(r'<a href="(https?://[^"]+)">(?:<b>)?([^<]+)', readme):
            if (label, href) not in info["links"]: info["links"].append((label.strip(), href))
        if "github.com/Nawebaz/CHF_GAME/discussions" in readme: info["links"].append(("Discussions (fallos e ideas)", "https://github.com/Nawebaz/CHF_GAME/discussions"))
        tag = re.search(r"<i>([^<]+)</i>", readme); info["tagline"] = tag.group(1) if tag else ""
    if "faro-buzon" in heads and _git("-C", d, "fetch", "-q", "--depth", "1", url, "faro-buzon", timeout=120).returncode == 0:
        try: info["faro_version"] = json.loads(_git("-C", d, "show", "FETCH_HEAD:release/VERSION.json").stdout).get("version")
        except Exception: pass
    REPO.update(heads=heads, info=info)
    v = CFG.get("vault") or {}; root = expand(v.get("path"))
    if v.get("write") and root and os.path.isdir(root): _write_repo_note(root, info)
    return info

def _write_repo_note(root, info):
    L = ["---", "tipo: espejo", "fuente: github.com/Nawebaz/CHF_GAME", "---", "# GitHub · CHF_GAME", "",
         "Espejo automático del repositorio público (Faro lo reescribe cuando cambia el repo; no editar a mano). Proyectos: [[10 Proyectos/CHF|CHF]] · [[10 Proyectos/Faro|Faro]].", ""]
    if info.get("tagline"): L += ["*%s*" % info["tagline"], ""]
    L += ["## Enlaces"] + ["- [%s](%s)" % (a, b) for a, b in info.get("links", [])] + ["- [Repositorio](https://github.com/Nawebaz/CHF_GAME)", ""]
    L += ["## Ramas", "- `main`: el juego publicado (index.html, assets, README, licencia). Se sirve en GitHub Pages.",
          "- `faro-buzon`: herramientas de Faro (`faro-informa.py`, vigía del Mac, release autoactualizable) y el buzón público `reports.json`. Versión publicada: **%s**." % info.get("faro_version", "?")]
    L += ["- Otras: " + ", ".join("`%s`" % b for b in info["branches"] if b not in ("main", "faro-buzon"))] if len(info.get("branches", [])) > 2 else []
    L += ["", "## Últimos cambios del juego (main)"] + ["- %s · `%s` · %s" % tuple(c) for c in info.get("commits", []) if len(c) == 3]
    L += ["", "## Qué no va al repo", "- El repo es público: solo juego, textos públicos y herramientas genéricas de Faro. Nada de la bóveda salvo lo que Nawe decida publicar."]
    txt = "\n".join(L) + "\n"
    fp = os.path.join(root, REPO_NOTE); os.makedirs(os.path.dirname(fp), exist_ok=True)
    try:
        with open(fp, encoding="utf-8") as f:
            if f.read() == txt: return
    except OSError: pass
    with open(fp, "w", encoding="utf-8") as f: f.write(txt)

@collector("vault_sweep", 15)
def c_vault_sweep():
    """Red de seguridad del vigía: cada 15 s compara fechas de la bóveda. Si inotify perdió algo (cola llena, carpeta
    nueva, renombrados de Syncthing), la escritura sale igual en la oficina, marcada «sondeo». Las lecturas solo las ve inotify."""
    root = vault_root()
    if not root or not os.path.isdir(root) or VLIVE.get("mode") != "inotify": return None
    cur = {}
    for dp, dns, fns in os.walk(root):
        dns[:] = [x for x in dns if not x.startswith(".")]
        for fn in fns:
            rel = _vrel(root, os.path.join(dp, fn))
            if rel:
                try: cur[rel] = os.path.getmtime(os.path.join(dp, fn))
                except OSError: pass
    prev = VSWEEP.get("mt"); missed = 0
    if prev is not None:
        for k, m in cur.items():
            if (k not in prev or m != prev[k]) and m > VSEEN.get(k, 0) + 1:
                vault_event(k, "write" if k in prev else "new", via="sondeo"); VLIVE["known"].add(k); missed += 1
        for k in prev:
            if k not in cur and k in VLIVE["known"]:
                VLIVE["known"].discard(k); vault_event(k, "del", via="sondeo"); missed += 1
        if missed: _vault_rebuild()
    VSWEEP["mt"] = cur; VSWEEP["missed"] = VSWEEP.get("missed", 0) + missed
    return {"notes": len(cur), "missed_total": VSWEEP["missed"], "at": iso(now())}
VSWEEP = {}

@collector("vault_links", 15)
def c_vault_links():
    """Repasa las conexiones de la bóveda: al instante cuando el vigía ve una escritura y, por si acaso, cada 15 s."""
    v = CFG.get("vault") or {}; root = expand(v.get("path"))
    if not VL or not root or not os.path.isdir(root) or not v.get("write"): return None
    if (CFG.get("vault_links") or {}).get("enabled") is False: return None
    sig = _vault_sig(root)
    if sig == VL_STATE["sig"] and time.time() - VL_STATE["at"] < 1800: return CACHE.get("vault_links")
    extra = []
    ri = REPO.get("info") or {}
    if ri:
        lines = ["- Espejo del repo: [[%s|GitHub CHF_GAME]]" % REPO_NOTE[:-3]]
        if ri.get("commits"): lines.append("- Último cambio publicado del juego: %s · %s" % (ri["commits"][0][0], ri["commits"][0][2]))
        lines += ["- [%s](%s)" % (a, b) for a, b in ri.get("links", [])[:3]]
        extra.append(("repo", "10 Proyectos/CHF.md", lines, "Repositorio (automático)"))
        if ri.get("faro_version"):
            extra.append(("repo", "10 Proyectos/Faro.md", ["- Versión publicada en `faro-buzon`: **%s** · [[%s|espejo del repo]]" % (ri["faro_version"], REPO_NOTE[:-3])], "Versión (automático)"))
    tmark = time.time()
    for rel in list(VLIVE["known"]): SELF_TOUCH[rel] = (tmark, "read")   # el repaso lee todas las notas: no es actividad de nadie
    r = VL.review(root, apply=True, extra_blocks=extra, hook=vmark)
    rp = os.path.join(root, v.get("folder", "Faro"), "Conexiones de la bóveda.md")
    new = VL.report_md(r, now().strftime("%d/%m/%Y %H:%M"))
    try:
        with open(rp, encoding="utf-8") as f: old = f.read()
    except OSError: old = ""
    strip = lambda t: re.sub(r"Revisión automática de Faro: [^.]*\.", "", t)
    if strip(old) != strip(new):
        os.makedirs(os.path.dirname(rp), exist_ok=True); vmark(rp)
        with open(rp, "w", encoding="utf-8") as f: f.write(new)
    VL_STATE.update(sig=None if r["skipped"] else _vault_sig(root), at=time.time())
    if r["changed"]: log("vault_links: arregladas", len(r["changed"]), "notas")
    return {k: len(r[k]) for k in ("orphans", "broken", "duplicates", "ambiguous", "stale", "conflicts_moved", "changed", "skipped")} | {
            "fixed": r["changed"][:20], "at": iso(now())}

@collector("vault_inbox", 20)
def c_vault_inbox():
    """Buzón de órdenes en la bóveda: cualquier nota en _agentes/inbox/faro/ (escrita desde el iPhone, el Mac, Hermes o una
    sesión de Claude) se convierte en una orden de Faro, se reparte como las demás y la respuesta vuelve a _agentes/outbox/."""
    root = expand((CFG.get("vault") or {}).get("path"))
    if not root or not os.path.isdir(root): return None
    base = os.path.join(root, "_agentes"); inbox = os.path.join(base, "inbox", "faro")
    os.makedirs(inbox, exist_ok=True)
    seen = STATE.setdefault("vinbox", {}); new = 0
    for fn in sorted(os.listdir(inbox)):
        fp = os.path.join(inbox, fn)
        if fn.startswith(".") or not fn.endswith(".md") or fn in seen or not os.path.isfile(fp): continue
        if time.time() - os.path.getmtime(fp) < 5: continue   # aún sincronizando
        vmark(fp)
        with open(fp, encoding="utf-8", errors="ignore") as f: raw = f.read(20000)
        meta, body = {}, raw
        m = re.match(r"^---\s*\n(.*?)\n---\s*\n?(.*)$", raw, re.S)
        if m:
            body = m.group(2)
            for line in m.group(1).splitlines():
                if ":" in line: k, v = line.split(":", 1); meta[k.strip().lower()] = v.strip()
        body = body.strip()
        if not body: continue
        to = (meta.get("to") or meta.get("para") or "").lower()
        ex = to if to in CFG.get("executors", {}) and to != "faro" else None
        title = re.sub(r"^\S*→\S+\s*", "", re.sub(r"^\d{4}-\d{2}-\d{2}\s*\d{0,4}\s*", "", fn[:-3])).strip()[:60] or fn[:-3]
        r = new_order(body, "orden", title, None, ex)
        seen[fn] = {"order": (r.get("order") or {}).get("id"), "orders": [o.get("id") for o in (r.get("orders") or []) if o],
                    "from": meta.get("from") or "Nawe", "answered": False}
        new += 1
    # respuestas: cuando la orden termina, se escribe en outbox y la tarea pasa a archivo
    for fn, rec in list(seen.items()):
        if rec.get("answered"): continue
        ids = rec.get("orders") or [rec.get("order")]
        os_ = [o for o in ORDERS if o["id"] in ids]
        if not os_ or any(o["state"] in ("queued", "running") for o in os_): continue
        out = os.path.join(base, "outbox"); os.makedirs(out, exist_ok=True)
        stem = fn[:-3]
        lines = ["---", "thread: %s" % stem, "from: faro", "to: %s" % rec.get("from", "Nawe"),
                 "status: %s" % ("done" if all(o["state"] == "done" for o in os_) else "failed"), "---"]
        for o in os_:
            lines += ["", "## %s · %s" % (ex_label(o["executor"]), {"done": "hecho", "failed": "falló", "cancelled": "cancelada"}.get(o["state"], o["state"])),
                      (o.get("result") or "").strip()[:6000]]
        vmark(os.path.join(out, stem + " · RESPUESTA.md")); vmark(os.path.join(base, "inbox", "faro", fn)); vmark(os.path.join(base, "archivo", fn))
        with open(os.path.join(out, stem + " · RESPUESTA.md"), "w", encoding="utf-8") as f: f.write("\n".join(lines) + "\n")
        arch = os.path.join(base, "archivo"); os.makedirs(arch, exist_ok=True)
        try: os.replace(os.path.join(base, "inbox", "faro", fn), os.path.join(arch, fn))
        except OSError: pass
        rec["answered"] = True
    save_state()
    return {"pending": sum(1 for r in seen.values() if not r.get("answered")), "new": new}

def vault_write():
    """Vuelca a la bóveda un parte diario y cada orden terminada (solo si vault.write está activo)."""
    v = CFG.get("vault") or {}
    root = expand(v.get("path"))
    if not v.get("write") or not root or not os.path.isdir(root): return
    base = os.path.join(root, v.get("folder", "Faro"))
    os.makedirs(os.path.join(base, "Órdenes"), exist_ok=True)
    t = now(); S = STATUS
    lines = ["# Faro · %s" % t.strftime("%d/%m/%Y"), "", "Actualizado: %s" % t.strftime("%H:%M"), "",
             "## Te toca"] + ["- %s" % x["title"] for x in S.get("todo", [])[:15]] + ["", "## Órdenes de hoy"]
    for o in ORDERS:
        if (o.get("created") or "").startswith(t.strftime("%Y-%m-%d")):
            lines.append("- [%s] %s → %s" % ("x" if o["state"] == "done" else " ", o["title"], o["executor"]))
    lines += ["", "## Buzón de sugerencias"] + ["- %s (de %s)" % (x["text"], x["from"]) for x in (SUGG or []) if x["state"] == "open"]
    vmark(os.path.join(base, "Estado %s.md" % t.strftime("%Y-%m-%d")))
    with open(os.path.join(base, "Estado %s.md" % t.strftime("%Y-%m-%d")), "w", encoding="utf-8") as f: f.write("\n".join(lines) + "\n")
    for o in ORDERS:
        if o["state"] == "done" and not o.get("vaulted") and o.get("result"):
            name = re.sub(r'[\\/:*?"<>|]', "", o["title"])[:60].strip() or o["id"]
            fn = os.path.join(base, "Órdenes", "%s %s.md" % ((o.get("finished") or "")[:10], name))
            vmark(fn)
            with open(fn, "w", encoding="utf-8") as f:
                f.write("# %s\n\n- Pedida: %s\n- Hecha por: %s\n- Proyecto: %s\n\n## Orden\n%s\n\n## Resultado\n%s\n"
                        % (o["title"], o["created"], o["executor"], o.get("project") or "-", o["text"], o["result"]))
            o["vaulted"] = True
    save_orders()

@collector("skills", 900)
def c_skills():
    out = []
    for d in CFG.get("skills_dirs", []):
        root = expand(d)
        if not root or not os.path.isdir(root): continue
        src = "Hermes" if ".hermes" in root else "Claude" if ".claude" in root else os.path.basename(root)
        for dp, dns, fns in os.walk(root):
            if "SKILL.md" in fns:
                out.append({"name": os.path.basename(dp), "src": src}); dns[:] = []
    return {"items": sorted(out, key=lambda x: x["name"])[:80]}

def suggestions():
    global SUGG
    if SUGG is None:
        SUGG = [{"id": "s:" + uuid.uuid4().hex[:6], "state": "open", "at": iso(now()), **x} for x in CFG.get("seed_suggestions", [])]
        jsave("suggestions.json", SUGG)
    return SUGG

def suggestion_add(body):
    if not body.get("text"): return {"ok": False, "error": "falta text"}
    s = {"id": "s:" + uuid.uuid4().hex[:6], "from": body.get("from", "?"), "text": body["text"][:200], "why": body.get("why", "")[:300],
         "short": (body.get("short") or "")[:30], "imp": body.get("imp", 2), "ret": body.get("ret", 2), "cost": body.get("cost", 2), "state": "open", "at": iso(now())}
    with LOCK: suggestions().append(s); jsave("suggestions.json", SUGG)
    say(s["from"], "Nawe", s["short"] or s["text"], "buzon")
    build_status(); return {"ok": True, "suggestion": s}

DELEGATE_TXT = ("Nawe te pide que hagas tú esta sugerencia hasta donde puedas sin él: «%s»%s. "
    "Avanza todo lo que no le necesite. No introduzcas contraseñas, tokens ni datos de pago, no envíes mensajes en su nombre, "
    "no muevas dinero y no tomes decisiones irreversibles: deja esos pasos preparados y avísale en Faro como algo que le toca, "
    "con una línea de qué falta y por qué. Informa del avance con tu informe habitual.")

def suggestion_action(sid, typ, text=None):
    if typ in ("reply", "delegate"):
        x = next((s for s in suggestions() if s["id"] == sid), None)
        if not x or (typ == "reply" and not (text or "").strip()): return {"ok": False, "error": "falta la respuesta"}
        frm = (x.get("from") or "").lower()
        ex_ = "claude" if "claude" in frm else "codex" if re.search("codex|gpt", frm) else "hermes" if "hermes" in frm else "local" if "strata" in frm else None
        short = (x.get("short") or x["text"])[:40]
        with LOCK:
            if typ == "reply": x.setdefault("replies", []).append({"at": iso(now()), "text": text.strip()[:2000]}); x["state"] = "answered"
            else: x["state"] = "delegated"; x["delegated_at"] = iso(now())
            jsave("suggestions.json", SUGG)
        say("Nawe", x.get("from") or ex_label(ex_), text.strip() if typ == "reply" else "Hacedlo vosotros: " + short, "respuesta" if typ == "reply" else "encargo")
        if typ == "reply":
            r = new_order("Nawe responde a tu sugerencia «%s»: %s" % (x["text"], text.strip()), kind="nuevo", title="Respuesta: " + short, executor=ex_)
        else:
            extra = (". Nota de Nawe: " + text.strip()[:1000]) if (text or "").strip() else ""
            r = new_order(DELEGATE_TXT % (x["text"] + ((" (" + x["why"] + ")") if x.get("why") else ""), extra), kind="nuevo", title="Hacedlo: " + short, executor=ex_)
        build_status(); return {"ok": True, "order": r.get("order")}
    with LOCK:
        x = next((s for s in suggestions() if s["id"] == sid), None)
        if not x or typ not in ("accept", "dismiss", "done", "open"): return {"ok": False, "error": "no aplicable"}
        x["state"] = {"accept": "accepted", "dismiss": "dismissed", "done": "done", "open": "open"}[typ]; jsave("suggestions.json", SUGG)
    build_status(); return {"ok": True}

def note_event(r):
    ev = {k: r.get(k) for k in ("id", "name", "agent", "action", "skill", "project") if r.get(k)}
    ev["at"] = iso(now())
    if r.get("action") or r.get("skill"):
        EVENTS.append(ev); del EVENTS[:-100]
    if r.get("artifact"):
        a = r["artifact"] if isinstance(r["artifact"], dict) else {"name": str(r["artifact"])}
        ARTS.append({**a, "by": r.get("name") or r.get("agent"), "project": r.get("project"), "at": iso(now())}); del ARTS[:-200]; jsave("artifacts.json", ARTS)
    if r.get("proud"):
        p = r["proud"] if isinstance(r["proud"], dict) else {"title": str(r["proud"])}
        PROUD.append({**p, "by": r.get("name") or r.get("agent"), "project": r.get("project"), "at": iso(now())}); del PROUD[:-100]; jsave("proud.json", PROUD)

# ───────── capa de decisión: importancia × retorno × relevancia / coste ─────────
EXEC_COST = {"faro": 0.5, "local": 1, "hermes": 1.5, "codex": 2, "claude": 2}

def score_item(text, base=None, project=None, executor=None):
    D_ = CFG.get("decision", {})
    m = {"imp": 2, "ret": 2, "cost": 2, "rel": 2}
    if base: m.update({k: v for k, v in base.items() if k in m and v is not None})
    q = (text or "").lower()
    for rule in D_.get("rules", []):
        if any(k in q for k in rule["match"]):
            m.update({k: rule[k] for k in ("imp", "ret", "cost", "rel") if k in rule}); break
    if project: m["rel"] = D_.get("project_relevance", {}).get(project, m["rel"])
    if executor and not (base or {}).get("cost"): m["cost"] = max(m["cost"] * 0 + EXEC_COST.get(executor, 2), 0.5)
    val = m["imp"] * m["ret"] * m["rel"] / max(m["cost"], 0.5)
    hi_ret, lo_cost = m["imp"] * m["ret"] >= 6, m["cost"] <= 1.5
    quad = "hazlo" if hi_ret and lo_cost else "planifica" if hi_ret else "delega" if lo_cost else "descarta"
    return {**m, "score": round(val, 1), "quad": quad}

def infer_project(text):
    q = (text or "").lower()
    for p in CFG.get("projects", []):
        keys = [p["id"], p["name"].lower()] + [k.lower() for k in p.get("keywords", [])]
        if any(k and k in q for k in keys): return p["id"]
    return None

def build_add(pid, why):
    """La obra de cada proyecto: suma una planta cuando se entrega algo y la guarda para retomarla."""
    if not pid: return
    with LOCK:
        b = STATE.setdefault("build", {}).setdefault(pid, {"floors": 1, "log": []})
        b["floors"] = min(b["floors"] + 1, 40); b["last"] = iso(now())
        b["log"] = (b["log"] + [{"at": iso(now()), "why": why[:60]}])[-12:]
        save_state()

def build_decide(todo):
    items = []
    for x in todo:
        items.append({"kind": "toca", "id": x.get("id", ""), "title": x.get("title", ""), **score_item(x.get("title", "") + " " + (x.get("text") or ""), x.get("metrics"), x.get("project"))})
    for o in ORDERS:
        if o.get("state", "") in ("queued", "failed"):
            items.append({"kind": "orden", "id": o.get("id", ""), "title": o.get("title", ""), **score_item(o.get("text", ""), o.get("metrics"), o.get("project"), o.get("executor", ""))})
    for sg in suggestions():
        if sg.get("state", "") == "open":
            items.append({"kind": "buzón", "id": sg.get("id", ""), "title": sg.get("text", ""), "from": sg.get("from", ""), **score_item(sg.get("text", ""), {"imp": sg.get("imp"), "ret": sg.get("ret"), "cost": sg.get("cost")})})
    return sorted(items, key=lambda i: -i["score"])

# ───────── detección automática de agentes en este equipo ─────────
AGENT_PATTERNS = [
    ("hermes", "Hermes · PC", "hermes", re.compile(r"(^|/|\s)hermes(\b|-agent)", re.I)),
    ("codex", "Codex", "gpt", re.compile(r"(^|/)codex(\s|$)", re.I)),
    ("claude-code", "Claude Code", "claude", re.compile(r"(^|/)claude(\s|$)", re.I)),
    ("ollama", "Strata", "local", re.compile(r"ollama (runner|serve)", re.I)),
    ("freqtrade", "freqtrade", "local", re.compile(r"freqtrade", re.I)),
]
PREV_CPU = {}

@collector("procs", 15)
def c_procs():
    if os.name == "nt" or not shutil.which("ps"): return None
    out = subprocess.run(["ps", "-eo", "pid,etimes,pcpu,args"], capture_output=True, text=True, timeout=10).stdout.splitlines()[1:]
    found = {}
    for line in out:
        parts = line.split(None, 3)
        if len(parts) < 4 or "faro.py" in parts[3]: continue
        pid, et, cpu, args = parts
        for key, name, brand, rx in AGENT_PATTERNS:
            if rx.search(args):
                f = found.setdefault(key, {"name": name, "brand": brand, "cpu": 0.0, "n": 0, "since": int(et)})
                f["cpu"] += float(cpu); f["n"] += 1; f["since"] = max(f["since"], int(et))
    # modelos cargados en Ollama = Strata pensando de verdad
    loaded = []
    try:
        loaded = [m.get("name") for m in http_json("http://127.0.0.1:11434/api/ps", timeout=2).get("models", [])]
    except Exception:
        pass
    agents = []
    for key, f in found.items():
        busy = f["cpu"] >= 8 or (key == "ollama" and loaded)
        task = ("usando %s" % ", ".join(loaded)) if key == "ollama" and loaded else ("trabajando · CPU %d%%" % f["cpu"] if busy else "en marcha, sin carga")
        agents.append({"name": f["name"], "brand": f["brand"], "state": "run" if busy else "ok", "task": task, "auto": True})
    return {"agents": agents}

# ───────── Codex: lee su registro de sesiones (~/.codex/sessions) ─────────
CODEX_ACT = [("apply_patch", "code", "edita código"), ("web_search", "web", "busca en la web"), ("update_plan", "think", "planifica"),
             ("shell", "system", "ejecuta comandos"), ("exec_command", "system", "ejecuta comandos"), ("read_file", "obsidian", "lee archivos")]

def codex_state(root, name, active_secs=120):
    """Devuelve el estado del agente Codex a partir de su rollout más reciente (formato JSONL; se lee de forma tolerante)."""
    root = expand(root)
    if not root or not os.path.isdir(root): return None
    newest = None
    for dp, dns, fns in os.walk(root):
        for fn in fns:
            if fn.endswith(".jsonl"):
                fp = os.path.join(dp, fn); m = os.path.getmtime(fp)
                if not newest or m > newest[0]: newest = (m, fp)
    if not newest: return None
    age = time.time() - newest[0]
    with open(newest[1], "rb") as f:
        f.seek(0, 2); size = f.tell(); f.seek(max(0, size - 60000)); tail = f.read().decode("utf-8", "replace").splitlines()
        f.seek(0); head = f.read(40000).decode("utf-8", "replace").splitlines()
    task, action, label = "", None, ""
    for ln in head:
        try: j = json.loads(ln)
        except Exception: continue
        blob = json.dumps(j, ensure_ascii=False)
        if '"role": "user"' in blob or '"type": "user_message"' in blob:
            m = re.search(r'"(?:text|message)": "((?:[^"\\]|\\.){8,})"', blob)
            if m and not m.group(1).startswith("<"): task = json.loads('"%s"' % m.group(1))[:70]; break
    for ln in reversed(tail[-80:]):
        hit = next(((a, l) for k, a, l in CODEX_ACT if '"%s"' % k in ln), None)
        if hit: action, label = hit; break
    busy = age < active_secs
    return {"name": name, "brand": "gpt", "state": "run" if busy else "ok", "action": action if busy else None,
            "task": ((label + " · ") if busy and label else "") + (task or ("activo" if busy else "sin actividad reciente"))}

@collector("codex", 20)
def c_codex():
    st = codex_state(CFG.get("codex_sessions", "~/.codex/sessions"), "Codex · PC")
    return {"agents": [st]} if st else None

# ───────── Sondeo en vivo: Faro pregunta a cada agente local cada 15 s ─────────
# Prueba de trabajo = el agente ha escrito en su registro de sesión hace poco (cada llamada a herramienta,
# cada respuesta). No se usa la CPU. Proceso vivo sin escribir = descansando. Sin proceso = apagado.
LIVE_AGENTS = [
    # clave, nombre, marca, patrón de proceso, carpetas de registro
    ("hermes", "Hermes · PC", "hermes", "hermes", ["~/.hermes/sessions", "~/.hermes/logs", "~/.hermes/state"]),
    ("codex", "Codex · PC", "gpt", "codex", ["~/.codex/sessions"]),
    ("claude-code", "Claude Code · PC", "claude", "claude-code", ["~/.claude/projects"]),
]
ACTIVE_SECS = 120

def newest_mtime(paths, max_files=20000):
    best = None
    for p in paths:
        root = expand(p)
        if not root or not os.path.exists(root): continue
        if os.path.isfile(root):
            m = os.path.getmtime(root); best = m if best is None or m > best else best; continue
        n = 0
        for dp, dns, fns in os.walk(root):
            dns[:] = [d for d in dns if not d.startswith(".") and d not in ("node_modules", "venv", ".venv", "cache", "skills", "hermes-agent", "site-packages", "models")]
            for fn in fns:
                n += 1
                try: m = os.path.getmtime(os.path.join(dp, fn))
                except OSError: continue
                if best is None or m > best: best = m
            if n > max_files: break
    return best

def procs_alive():
    if os.name == "nt" or not shutil.which("ps"): return {}
    out = subprocess.run(["ps", "-eo", "pid,etimes,args"], capture_output=True, text=True, timeout=10).stdout.splitlines()[1:]
    alive = {}
    for line in out:
        parts = line.split(None, 2)
        if len(parts) < 3 or "faro.py" in parts[2]: continue
        for key, name, brand, rx in AGENT_PATTERNS:
            if rx.search(parts[2]): alive[key] = alive.get(key, 0) + 1
    return alive

@collector("live", 15)
def c_live():
    t = time.time(); alive = procs_alive(); agents = []
    cfg_dirs = CFG.get("live_dirs", {})
    for key, name, brand, pkey, dirs in LIVE_AGENTS:
        dirs = cfg_dirs.get(key, dirs)
        if key == "hermes" and not any(os.path.exists(expand(d) or "") for d in dirs): dirs = ["~/.hermes"]
        installed = any(os.path.exists(expand(d) or "") for d in dirs) or bool(shutil.which(pkey.split("-")[0]))
        if not installed: continue
        m = newest_mtime(dirs); age = t - m if m else None
        up = alive.get(pkey, 0) > 0
        a = {"id": "live:" + key, "name": name, "brand": brand, "auto": True, "live": True,
             "seen": iso(dt.datetime.fromtimestamp(m).astimezone()) if m else None}
        if age is not None and age < ACTIVE_SECS:
            a.update(state="run", task="trabajando · última acción " + rel_es(age))
        elif up:
            a.update(state="ok", task="descansando" + (" · última acción " + rel_es(age) if age is not None else ""))
        else:
            a.update(state="off", task="apagado" + (" · última acción " + rel_es(age) if age is not None else ""))
        if key == "codex" and a["state"] == "run":
            st = codex_state(CFG.get("codex_sessions", "~/.codex/sessions"), name, ACTIVE_SECS) or {}
            if st.get("task"): a["task"] = st["task"]
            if st.get("action"): a["action"] = st["action"]
        agents.append(a)
    # Strata como servidor compatible con OpenAI/llama.cpp (p. ej. puerto 18501): listo = descansando; procesando = pensando
    for base in list(dict.fromkeys([u for u in [strata_url()] + list(CFG.get("strata_urls", ["http://127.0.0.1:18501"])) if u])):
        try:
            http_json(base.rstrip("/") + "/v1/models", timeout=2, headers=local_auth(base))
            busy = False
            try: busy = any(x.get("is_processing") for x in http_json(base.rstrip("/") + "/slots", timeout=2, headers=local_auth(base)) or [])
            except Exception: pass
            agents.append({"id": "live:strata", "name": "Strata · local", "brand": "local", "auto": True, "live": True,
                           "state": "run" if busy else "ok", "task": "pensando" if busy else "listo, descansando"})
            return {"agents": agents, "at": iso(now())}
        except Exception: pass
    # Strata: Ollama con un modelo cargado = pensando
    try:
        loaded = [x.get("name") for x in http_json("http://127.0.0.1:11434/api/ps", timeout=2).get("models", [])]
        agents.append({"id": "live:strata", "name": "Strata · local", "brand": "local", "auto": True, "live": True,
                       "state": "run" if loaded else "ok", "task": ("pensando con " + ", ".join(loaded)) if loaded else "descansando"})
    except Exception:
        if alive.get("ollama"):
            agents.append({"id": "live:strata", "name": "Strata · local", "brand": "local", "auto": True, "live": True, "state": "ok", "task": "descansando"})
    return {"agents": agents, "at": iso(now())}

# ───────── Codex en la nube y otros: actividad en GitHub (repos públicos, sin token) ─────────
@collector("github_activity", 300)
def c_github_activity():
    c = src_cfg("github_activity")
    if not c: return None
    agents = []
    for repo in c.get("repos", []):
        evs = http_json("https://api.github.com/repos/%s/events?per_page=20" % repo, timeout=15)
        for e in evs:
            t = parse_iso(e.get("created_at"))
            if not t or (now() - t).total_seconds() > c.get("window_min", 45) * 60: continue
            actor = (e.get("actor") or {}).get("login", "")
            who = "Codex · nube" if re.search(r"codex|openai|chatgpt", actor + json.dumps(e.get("payload", {}))[:2000], re.I) else None
            if who and not any(a["name"] == who for a in agents):
                kind = {"PushEvent": "sube código", "PullRequestEvent": "abre una pull request", "CreateEvent": "crea una rama"}.get(e["type"], "trabaja")
                agents.append({"name": who, "brand": "gpt", "state": "run", "action": "code", "cloud": True, "project": c.get("project"),
                               "task": "%s en %s" % (kind, repo.split("/")[-1])})
    return {"agents": agents}

# ───────── autoactualización desde el buzón público de GitHub ─────────
import hashlib, tarfile, tempfile
UPD = {"checked": None, "latest": None, "error": jload("update-error.json", {}).get("error")}

UPDATE_LOCK = threading.Lock()

def verify_release(blob, base, config):
    """Firma SSH opcional: identidad faro-release, namespace faro-release.
    pubkey es una ruta a la clave pública elegida por el propietario.
    """
    if "pubkey" not in config: return
    pubkey = config["pubkey"]
    if not isinstance(pubkey, str) or not pubkey.strip():
        raise RuntimeError("clave pública de actualización no configurada")
    keypath = os.path.expanduser(pubkey)
    if not os.path.isabs(keypath): keypath = os.path.join(ROOT, keypath)
    with open(keypath, encoding="utf-8") as f: key = f.read().strip()
    if "\n" in key or not key.startswith(("ssh-", "ecdsa-", "sk-ssh-", "sk-ecdsa-")):
        raise RuntimeError("clave pública de actualización no válida")
    sig = http(base + "faro-release.tar.gz.sig?t=%d" % time.time(), timeout=15)
    with tempfile.TemporaryDirectory(prefix="faro-signature-") as td:
        allowed, signature = os.path.join(td, "allowed_signers"), os.path.join(td, "release.sig")
        with open(allowed, "w", encoding="utf-8") as f: f.write("faro-release " + key + "\n")
        with open(signature, "wb") as f: f.write(sig)
        r = subprocess.run(["ssh-keygen", "-Y", "verify", "-f", allowed, "-I", "faro-release",
                            "-n", "faro-release", "-s", signature], input=blob, capture_output=True, timeout=15)
        if r.returncode: raise RuntimeError("firma de actualización no válida")

def release_files(root):
    """Solo código y recursos; nunca configuración, datos o enlaces."""
    files = []
    for dp, dns, fns in os.walk(root, followlinks=False):
        dns[:] = [d for d in dns if d not in ("data", ".git", "__pycache__") and not os.path.islink(os.path.join(dp, d))]
        for fn in fns:
            path = os.path.join(dp, fn)
            if fn == "config.json" or fn.endswith(".pyc") or os.path.islink(path): continue
            files.append(os.path.relpath(path, root))
    return files

def probe_release(files, expected):
    # Copia aislada del código ya instalado: sin datos, credenciales ni recolectores.
    with tempfile.TemporaryDirectory(prefix="faro-probe-") as td:
        for rel in files:
            dst = os.path.join(td, rel); os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(os.path.join(ROOT, rel), dst)
        config = {"bind": "127.0.0.1", "projects": [], "sources": {}, "executors": {}, "update": {"enabled": False}}
        for fn in ("config.json", "config.example.json"):
            with open(os.path.join(td, fn), "w") as f: json.dump(config, f)
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0)); port = sock.getsockname()[1]
        env = {**os.environ, "FARO_PORT": str(port)}
        proc = subprocess.Popen([sys.executable, os.path.join(td, "faro.py"), "--once", "--update-probe"],
                                cwd=td, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            deadline = time.monotonic() + 20
            while time.monotonic() < deadline:
                if proc.poll() is not None: raise RuntimeError("la nueva versión no arranca")
                try:
                    health = http_json("http://127.0.0.1:%d/api/health" % port, timeout=min(1, max(.01, deadline-time.monotonic())))
                    if health.get("ok") is True and health.get("version") == expected: return
                except Exception: pass
                time.sleep(.1)
            raise RuntimeError("la nueva versión no responde /api/health en 20 s")
        finally:
            if proc.poll() is None:
                proc.terminate()
                try: proc.wait(timeout=2)
                except subprocess.TimeoutExpired: proc.kill(); proc.wait()

def _self_update(force=False):
    if os.path.isfile(os.path.join(ROOT, "REAL_ACTIVITY_LOCK")):
        UPD["error"] = "autoactualización en pausa: existe el archivo REAL_ACTIVITY_LOCK en la carpeta de Faro (bórralo para reanudar)"
        return {"updated": False, "version": VERSION, "reason": "local-real-activity-policy", "note": "Revisar actualización antes de sobrescribir la auditoría local."}
    c = CFG.get("update") or {}
    if not c.get("enabled", True) and not force: return None
    base = c.get("url", "https://raw.githubusercontent.com/Nawebaz/CHF_GAME/faro-buzon/release/")
    meta = json.loads(http(base + "VERSION.json?t=%d" % time.time(), headers={"Cache-Control": "no-cache"}, timeout=15))
    UPD["checked"], UPD["latest"] = iso(now()), meta.get("version")
    if meta.get("version") == VERSION: return {"updated": False, "version": VERSION}
    if meta.get("file") != "faro-release.tar.gz": raise RuntimeError("nombre de paquete no válido")
    blob = http(base + meta["file"] + "?t=%d" % time.time(), timeout=60)
    if hashlib.sha256(blob).hexdigest() != meta.get("sha256"): raise RuntimeError("sha256 de descarga no válido")
    verify_release(blob, base, c)
    with tempfile.TemporaryDirectory(prefix="faro-upd-") as tmp:
        with tarfile.open(fileobj=__import__("io").BytesIO(blob), mode="r:gz") as tf:
            members = tf.getmembers()
            for m in members:
                parts = m.name.split("/")
                if m.name.startswith("/") or ".." in parts or parts[0] != "faro" or not (m.isfile() or m.isdir()):
                    raise RuntimeError("ruta o tipo no válido en el paquete")
            tf.extractall(tmp, members=members)
        src = os.path.join(tmp, "faro")
        files = release_files(src)
        if not all(x in files for x in ("faro.py", "VERSION")): raise RuntimeError("paquete incompleto")
        with open(os.path.join(src, "VERSION")) as f:
            if f.read().strip() != meta["version"]: raise RuntimeError("versión del paquete no coincide")
        # Rechazar destinos enlazados antes de tocar código o la copia anterior.
        for rel in files:
            path = ROOT
            for part in rel.split(os.sep):
                path = os.path.join(path, part)
                if os.path.islink(path): raise RuntimeError("destino enlazado no permitido")
            if os.path.isdir(path): raise RuntimeError("archivo de actualización sustituye una carpeta")
        prev = os.path.join(DATA, "prev")
        if os.path.lexists(prev):
            if os.path.islink(prev): raise RuntimeError("copia anterior enlazada no permitida")
            shutil.rmtree(prev)
        os.makedirs(prev)
        old = release_files(ROOT)
        for rel in old:
            dst = os.path.join(prev, rel); os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(os.path.join(ROOT, rel), dst)
        try:
            for rel in files:
                dst = os.path.join(ROOT, rel); os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(os.path.join(src, rel), dst)
            for sh in ("abrir.sh", "actualizar.sh", "linux/install.sh", "tools/faro-report.sh"):
                if os.path.isfile(os.path.join(ROOT, sh)): os.chmod(os.path.join(ROOT, sh), 0o755)
            probe_release(release_files(ROOT), meta["version"])
        except Exception:
            for rel in files:
                if rel not in old and os.path.isfile(os.path.join(ROOT, rel)): os.remove(os.path.join(ROOT, rel))
            for rel in old:
                shutil.copy2(os.path.join(prev, rel), os.path.join(ROOT, rel))
            raise
    UPD["error"] = None
    jsave("update-error.json", {})
    log("actualizado de", VERSION, "a", meta["version"], "· reiniciando")
    def restart():
        time.sleep(1.5); os.execv(sys.executable, [sys.executable] + sys.argv)
    threading.Thread(target=restart, daemon=True).start()
    return {"updated": True, "version": meta["version"]}

def self_update(force=False):
    if not UPDATE_LOCK.acquire(blocking=False): raise RuntimeError("actualización ya en curso")
    try:
        return _self_update(force)
    except Exception as e:
        UPD["error"] = str(e)[:160]
        jsave("update-error.json", {"error": UPD["error"]})
        build_status()
        raise
    finally:
        UPDATE_LOCK.release()

@collector("selfupdate", 600)
def c_selfupdate():
    try:
        r = self_update()
        if r and r.get("reason") == "local-real-activity-policy": raise RuntimeError(UPD["error"])   # que se vea en «Te toca»
        return r
    except Exception as e:
        UPD["error"] = str(e)[:120]; raise

@collector("costs", 3600)
def c_costs():
    rec = CFG.get("recurring", [])
    if not rec: return None
    el = CACHE.get("electricity", {})
    items = []
    for r in rec:
        v = r.get("eur_month")
        if r.get("electricity") and el.get("avg") and el.get("kwh_month"):
            v = round(el["avg"] * el["kwh_month"] + r.get("fixed_eur", 0), 2)
        items.append({"name": r["name"], "eur_month": v})
    return {"items": items, "total": round(sum(i["eur_month"] or 0 for i in items), 2)}

def ollama(prompt, system=None, fmt=None):
    oc = CFG.get("ollama", {})
    body = {"model": oc.get("model", "qwen2.5:7b"), "prompt": prompt, "stream": False,
            "keep_alive": oc.get("keep_alive", "2m"), "options": {"temperature": 0.2, "num_predict": 200}}
    if system: body["system"] = system
    if fmt: body["format"] = fmt
    d = http_json(oc.get("url", "http://127.0.0.1:11434").rstrip("/") + "/api/generate", data=body, timeout=90)
    return d.get("response", "").strip()

def run_collectors(force=False):
    for name, c in COLLECTORS.items():
        if not force and time.time() - c["last"] < c["every"]:
            continue
        c["last"] = time.time()
        try:
            out = c["fn"]()
            if out is not None:
                CACHE[name] = out
            c["error"] = None
        except Exception as e:
            c["error"] = str(e)[:160]
            log("collector", name, "ERROR", e)
    build_status()

# ───────────────────────── composición del estado ─────────────────────────
ORDER = {"bad": 0, "warn": 1, "run": 2, "ok": 3, "off": 4}
STATUS = {"generated": iso(now()), "server": True, "error": "iniciando", "todo": [], "agents": [], "running": [], "projects": []}

def gta_last_report():
    """Máquina de GTA VI: el último informe que trae su bloque «gta», aunque ya no esté en la lista de agentes por viejo.
    Así su monitor en la oficina no se apaga (como el de Strata): enseña si trabaja, el último paso y cuándo dio señal."""
    best = None
    for rid, rep in list(REPORTS.items()):
        g = rep.get("gta") if isinstance(rep, dict) else None
        if not isinstance(g, dict) or not isinstance(g.get("clips"), list) or rep.get("example") or str(rid).startswith("demo-"):
            continue
        if best is None or str(rep.get("at", "")) > str(best.get("at", "")):
            best = {"id": rid, "name": rep.get("name"), "at": rep.get("at"), "state": rep.get("state", "ok"), "ttl": rep.get("ttl", 300),
                    "step": rep.get("step"), "task": rep.get("task"), "project": rep.get("project"), "gta": g}
    return best


def panel_status(status):
    """Office graph and animation history are loaded only by Office."""
    office_only = {"vault", "skills", "events", "artifacts", "proud", "machines", "chat", "build"}
    panel = {k: v for k, v in status.items() if k not in office_only}
    panel["orders"] = [{k: v for k, v in order.items() if k not in ("text", "result")}
                       for order in status.get("orders", [])]
    return panel


def build_status():
    clean_reports()
    t = now()
    errors = {}
    projects, running, agents, todo = {}, [], [], []
    g, pays, paid, streak, radar = {}, [], 0, 0, {}
    try:
        projects = {p.get("id", ""): {**p, "jobs": list(p.get("jobs", [])), "figs": [dict(f) for f in p.get("figs", [])]} for p in CFG.get("projects", [])}
        def proj(pid):
            return projects.setdefault(pid, {"id": pid, "name": pid, "figs": [], "jobs": []})
        for j in CACHE.get("scheduled", {}).get("jobs", []):
            proj(j.get("project", ""))["jobs"].append(j)
        running, agents, todo = [], [], []
        reports_changed = False
        for rid, source_report in list(REPORTS.items()):
            if source_report.get("example") or source_report.get("estimated") or str(rid).startswith("demo-"):
                continue
            r = norm_action(dict(source_report))
            stamp = parse_iso(r.get("at"))
            age = (t - stamp).total_seconds() if stamp else float("inf")
            ttl = r.get("ttl", 300)
            kind = r.get("kind", "job")
            state = r.get("state", "ok")
            invalid = not stamp or age > ttl or age < -60
            if state == "run" and r.get("pid") is not None and not r.get("cloud"):
                try:
                    pid = int(r["pid"])
                    if pid <= 1: raise ValueError("invalid pid")
                    os.kill(pid, 0)
                    with open("/proc/%d/stat" % pid) as pf:
                        if pf.read().split(") ", 1)[1].startswith("Z"):
                            invalid = True
                except (OSError, ValueError, OverflowError):
                    invalid = True
            if invalid and state == "run":
                state = "bad"
                r["task"] = "Sin actualización verificable · " + rel_es(age if stamp else 0)
                source_report.update(state="bad", task=r["task"])
                reports_changed = True
            r["state"] = state
            if kind == "run":
                if state == "run" and r.get("pct", 0) < 100:
                    running.append({**r, "id": rid, "stale": False})
                else:
                    agents.append({**r, "id": rid, "state": "bad" if state == "run" else state})
            elif kind == "agent":
                agents.append({**r, "id": rid})
            elif kind == "todo":
                todo.append({**r, "id": rid})
            elif kind == "job" and not any(s.get("id") == rid for s in CFG.get("scheduled", [])):
                if age > ttl and state == "ok": state, note = "warn", "Sin noticias " + rel_es(age)
                else: note = r.get("note")
                proj(r.get("project", "otros"))["jobs"].append({**r, "state": state, "note": note})
        if reports_changed:
            with LOCK: jsave("reports.json", REPORTS)
    except Exception as e:
        log("status section reports:", type(e).__name__)
        projects, running, agents, todo = {}, [], [], []
        errors["reports"] = "error"
    try:
        # Informes viejos (más de 12 h sin noticias) son historia, no agentes: fuera de la lista.
        keep_h = CFG.get("agents_keep_hours", 12)
        def _age(a):
            st = parse_iso(a.get("at")); return (t - st).total_seconds() if st else float("inf")
        agents = [a for a in agents if _age(a) < keep_h * 3600]
        # Mismo agente con varios ids: se queda el informe más reciente.
        by_name = {}
        for a in sorted(agents, key=_age):
            by_name.setdefault((a.get("name") or a.get("id")).lower(), a)
        agents = list(by_name.values())
    except Exception as e:
        log("status section agents:", type(e).__name__)
        agents = []
        errors["agents"] = "error"
    try:
        # Sondeo en vivo: una ficha por agente local. Si además ha informado de su tarea hace poco, se usa ese texto.
        for la in (CACHE.get("live") or {}).get("agents", []):
            la = dict(la)
            mate = [a for a in agents if not a.get("cloud") and a.get("brand", "") == la.get("brand", "") and _age(a) < 1800]
            mate += [r for r in running if not r.get("cloud") and (r.get("brand") == la.get("brand", "") or la.get("name", "").split(" ")[0].lower() in (r.get("name") or "").lower())]
            if mate:
                m = mate[0]
                if la.get("state", "") != "off" and m.get("task") and not str(m.get("task")).startswith("Sin actualización"):
                    la["task"] = m["task"] + " · " + la["task"].split(" · ")[-1]
                la["project"] = m.get("project") or la.get("project")
                if la.get("state", "") == "run": la["action"] = la.get("action") or m.get("action")
            agents.append(la)
    except Exception as e:
        log("status section live_agents:", type(e).__name__)
        agents = []
        errors["live_agents"] = "error"
    try:
        # Una ficha por agente real. Hermes (o Codex) del PC es UNO aunque informe de nueve tareas con nombres distintos:
        # esas tareas pasan a su ficha (las vencidas, como «sin cierre») en lugar de parecer nueve agentes.
        lives = [a for a in agents if a.get("live")]
        folded = []
        for a in agents:
            if a.get("live") or a.get("cloud") or "mac" in (a.get("name") or "").lower(): continue
            nb = lambda x: "gpt" if x in ("codex", "gpt", "openai") else x   # Codex y GPT son la misma casa
            nm = a.get("name") or ""
            b = nb(brand_of(nm) if re.search(r"codex|gpt|openai|chatgpt|claude|hermes|strata|ollama|qwen", nm, re.I) else (a.get("brand") or brand_of(nm)))
            host = next((l for l in lives if nb(l.get("brand")) == b and (b != "claude" or "code" in (l.get("name") or "").lower())), None)
            if not host: continue
            host.setdefault("tasks", []).append({"title": a.get("task") if not str(a.get("task", "")).startswith("Sin actualización") else (a.get("name") or "").split(" · ", 1)[-1],
                                                 "name": a.get("name"), "state": a.get("state"), "at": a.get("at"), "project": a.get("project"),
                                                 "pct": a.get("pct"), "closed": a.get("state") in ("ok", "done")})
            folded.append(a)
        if folded: agents = [a for a in agents if a not in folded]
        for l in lives:
            if l.get("tasks"): l["tasks"].sort(key=lambda x: x.get("at") or "", reverse=True); l["tasks"] = l["tasks"][:8]
        for a in agents:   # sesiones de la nube que acabaron hace más de 30 min: hechas, no «libres»
            if a.get("cloud") and a.get("state") == "ok" and _age(a) > 1800: a["done"] = True
        agents.sort(key=lambda a: (ORDER.get(a.get("state"), 9) if a.get("state") != "run" else -1, a.get("name") or ""))
        # CPU, sesiones recientes, GitHub y horarios son diagnóstico, no prueba de trabajo.
        # Solo informes explícitos vigentes y órdenes ejecutadas alimentan la oficina.
        for a in agents:
            if not a.get("project"): a["project"] = infer_project((a.get("task") or "") + " " + (a.get("name") or ""))
    except Exception as e:
        log("status section agent_groups:", type(e).__name__)
        agents = []
        errors["agent_groups"] = "error"
    try:
        # Gmail
        g = CACHE.get("gmail", {})
        todo += g.get("todo", [])
        todo += [{**x, "id": x.get("id", "")} for x in CFG.get("static_todo", [])]
        todo = [x for x in todo if x.get("id", "") not in STATE["dismissed"]]
    except Exception as e:
        log("status section gmail:", type(e).__name__)
        g, todo = {}, []
        errors["gmail"] = "error"
    try:
        # pagos
        month = t.strftime("%Y-%m")
        pays = [p for p in g.get("payments", []) if (p.get("date") or "").startswith(month)]
        paid = round(sum(p["amount"] or 0 for p in pays), 2)
        if "pagos" in projects:
            P = projects["pagos"]
            srcs = g.get("sources", [])
            for s in srcs:
                got = [p for p in g.get("payments", []) if p["source"] == s]
                P["jobs"].append({"name": s, "where": "Gmail", "state": "ok" if got else "off",
                                  "note": ("%d avisos; último %s" % (len(got), got[0]["date"][:10])) if got else "Aún sin avisos de cobro."})
            for f in P["figs"]:
                if f.get("bind") == "paid_month": f["value"] = paid if g else None
                if f.get("bind") == "sources_active": f["value"] = sum(1 for j in P["jobs"] if j.get("state", "") == "ok"); f["of"] = str(len(srcs))
    except Exception as e:
        log("status section payments:", type(e).__name__)
        pays, paid = [], 0
        errors["payments"] = "error"
    try:
        # binds de cifras genéricas
        itch = (CACHE.get("itch", {}).get("games") or [{}])[0]
        ft = CACHE.get("freqtrade", {})
        binds = {"itch_views_7d": itch.get("views_7d"), "itch_views": itch.get("views"), "itch_earnings": itch.get("earnings"),
                 "ft_profit": round(ft["profit_pct"], 1) if ft else None, "ft_trades": ft.get("trades"),
                 "paid_month": paid if g else None, "agents_busy": len(running) + sum(1 for o in ORDERS if o.get("state", "") == "running"),
                 "todo_count": len(todo), "itch_downloads": itch.get("downloads"),
                 "orders_queued": sum(1 for o in ORDERS if o.get("state", "") == "queued")}
        for p in projects.values():
            for f in p["figs"]:
                if f.get("bind") == "next_in_project":
                    nx = sorted([j["next"] for j in p["jobs"] if j.get("next")])
                    f["value"] = nx[0] if nx else None; f["kind"] = "when"
                elif f.get("bind") in binds and f.get("bind") not in ("sources_active",):
                    f["value"] = binds[f["bind"]]
            q = p.get("quiet_until_data")
            p["quiet"] = bool(q) and not binds.get(q)
    except Exception as e:
        log("status section project_figures:", type(e).__name__)
        projects = {}
        errors["project_figures"] = "error"
    try:
        if UPD.get("error"):
            todo.append({"id": "update-error", "kind": "task", "state": "warn", "title": "Falla la actualización de Faro", "text": UPD["error"], "reply": False})
        # errores de recolectores como avisos
        vl = CACHE.get("vault_links") or {}
        pend = sum(vl.get(k, 0) for k in ("broken", "duplicates", "stale", "orphans", "ambiguous"))
        if pend:
            todo.append({"id": "vault-links:%s:%d" % (t.strftime("%Y%m%d"), pend), "kind": "task", "state": "warn",
                         "title": "Bóveda: %d conexiones que revisar" % pend, "text": "Detalle en Faro/Conexiones de la bóveda", "reply": False})
        for name, c in COLLECTORS.items():
            if c.get("error", "") and src_cfg(name):
                todo.append({"id": "err:" + name + ":" + t.strftime("%Y%m%d"), "kind": "task", "state": "warn",
                             "title": "Falla la fuente «%s»" % name, "text": c.get("error", ""), "reply": False})
                todo = [x for x in todo if x.get("id", "") not in STATE["dismissed"]]
    except Exception as e:
        log("status section source_alerts:", type(e).__name__)
        todo = []
        errors["source_alerts"] = "error"
    try:
        # ejecutores sin sesión: te lo decimos una vez, con qué hace Faro mientras tanto
        for k, b in EXEC_BLOCK.items():
            if b.get("until", 0) > time.time():
                lab = CFG.get("executors", {}).get(k, {}).get("label", k)
                todo.append({"id": "exec:" + k + ":" + t.strftime("%Y%m%d"), "kind": "task", "state": "warn", "short": lab + " sin sesión",
                             "title": "%s del PC no puede trabajar" % lab, "reply": False,
                             "text": "%s. Mientras tanto Faro le pasa sus órdenes a otro agente. Si no tiene arreglo, descártalo." % b.get("why", "")})
        todo = [x for x in todo if x.get("id", "") not in STATE["dismissed"]]
        for p in projects.values():
            if not p["jobs"]:
                p["jobs"].append({"name": "Sin fuentes conectadas", "where": "-", "state": "off"})
    except Exception as e:
        log("status section executor_alerts:", type(e).__name__)
        todo = []
        errors["executor_alerts"] = "error"
    try:
        # racha sin rojos
        day = t.strftime("%Y-%m-%d")
        reds = any(x.get("state", "") == "bad" for x in todo) or any(j.get("state", "") == "bad" for p in projects.values() for j in p["jobs"])
        STATE["red_days"][day] = STATE["red_days"].get(day, False) or reds
        streak, d = 0, t.date()
        while True:
            k = d.strftime("%Y-%m-%d")
            if k not in STATE["red_days"] or STATE["red_days"][k]: break
            streak += 1; d -= dt.timedelta(days=1)
    except Exception as e:
        log("status section streak:", type(e).__name__)
        streak = 0
        errors["streak"] = "error"
    try:
        radar = {"news": CACHE.get("news", {}).get("items", []), "prices": CACHE.get("prices", {}).get("items", []),
                 "electricity": CACHE.get("electricity"), "costs": CACHE.get("costs"), "income_month": paid if g else None,
                 "income_goal": CFG.get("income_goal_month"),
                 "topics": {k: {"label": v.get("label", k), "color": v.get("color")} for k, v in (CFG.get("sources", {}).get("news", {}).get("topics") or {}).items()},
                 "benchmark": {"name": CFG.get("investing", {}).get("benchmark_name", "tu referencia"), "rate": CFG.get("investing", {}).get("benchmark_rate_pct", 3)}}
    except Exception as e:
        log("status section radar:", type(e).__name__)
        radar = {}
        errors["radar"] = "error"
    result = {"generated": iso(t), "server": True, "errors": errors}
    def section(name, build, empty):
        try:
            result[name] = build()
        except Exception as e:
            log("status section", name, type(e).__name__)
            result[name] = empty
            errors[name] = "error"
    section('version', lambda: VERSION, {})
    section('owner', lambda: CFG.get("owner", ""), {})
    section('streak', lambda: streak, {})
    section('todo', lambda: todo, [])
    section('agents', lambda: agents, [])
    section('running', lambda: running, [])
    section('gta_last', gta_last_report, None)
    section('projects', lambda: list(projects.values()), [])
    section('radar', lambda: radar, {})
    section('game', lambda: {"xp": STATE["xp"], "done": STATE["done"], "dismissed": STATE["dismissed"]}, {})
    section('orders', lambda: [x for x in ORDERS if not x.get("archived")][-30:], [])
    section('build', lambda: STATE.get("build", {}), {})
    section('chat', lambda: MSGS[-40:], [])
    section('machines', lambda: machines(), [])
    section('decide', lambda: build_decide(todo)[:12], [])
    section('vault', lambda: {**(CACHE.get("vault") or {}), "links": CACHE.get("vault_links"), "repo": {"main": ((REPO.get("info") or {}).get("commits") or [None])[0], "faro": (REPO.get("info") or {}).get("faro_version")}, "consulting": [e.get("name") or e.get("agent") for e in EVENTS[-20:]
                                 if e.get("action") == "obsidian" and (t - parse_iso(e["at"])).total_seconds() < 120]}, {})
    section('skills', lambda: (CACHE.get("skills") or {}).get("items", []), [])
    section('events', lambda: EVENTS[-30:], [])
    section('artifacts', lambda: ARTS[-40:], [])
    section('proud', lambda: PROUD[-20:], [])
    section('suggestions', lambda: suggestions(), [])
    section('executors', lambda: {k: {"ok": executor_ok(k), "enabled": v.get("enabled", True), "label": v.get("label", k), "color": v.get("color"), "good_for": v.get("good_for", ""),
                                         "why": EXEC_BLOCK.get(k, {}).get("why") if EXEC_BLOCK.get(k, {}).get("until", 0) > time.time() else None}
                                     for k, v in CFG.get("executors", {}).items()}, {})
    section('income', lambda: {"month": paid if g else None, "goal": CFG.get("income_goal_month"), "count": len(pays)}, {})
    section('sources', lambda: {n: {"ok": not c.get("error", ""), "error": c.get("error", ""), "enabled": bool(src_cfg(n)) or n in ("scheduled", "costs")}
                                   for n, c in COLLECTORS.items()}, {})
    with LOCK:
        STATUS.clear()
        STATUS.update(result)
        jsave("status.json", STATUS)
    try:
        alerts(todo, radar)
    except Exception as e:
        log("status section alerts:", type(e).__name__)
        with LOCK:
            STATUS["errors"]["alerts"] = "error"
            jsave("status.json", STATUS)

def rel_es(sec):
    sec = int(sec)
    if sec < 60: return "hace %d s" % max(sec, 0)
    return "hace %d min" % (sec // 60) if sec < 3600 else "hace %d h" % (sec // 3600) if sec < 86400 else "hace %d d" % (sec // 86400)

# ───────────────────────── avisos (Telegram) ─────────────────────────
def telegram(text):
    c = CFG.get("telegram") or {}
    if not c.get("enabled") or not c.get("token"): return
    http("https://api.telegram.org/bot%s/sendMessage" % c["token"], data={"chat_id": c["chat_id"], "text": text}, timeout=10)

def alerts(todo, radar):
    sent = STATE["alerts_sent"]; new = []
    for x in todo:
        if x["state"] in ("bad", "warn") and x["id"] not in sent:
            new.append(("🔴 " if x["state"] == "bad" else "🟠 ") + x["title"]); sent[x["id"]] = iso(now())
    for p in radar.get("prices") or []:
        k = "px:%s:%s" % (p["id"], now().strftime("%Y%m%d"))
        if p.get("alert") and k not in sent:
            new.append("📈 %s en %s %s" % (p.get("name", p["id"]), p["price"], p.get("unit", ""))); sent[k] = iso(now())
    if new:
        try: telegram("Faro\n" + "\n".join(new[:8]))
        except Exception as e: log("telegram", e)
        save_state()

# ───────────────────────── voz (manos libres) ─────────────────────────
NUM = {"primero": 0, "primera": 0, "segundo": 1, "segunda": 1, "tercero": 2, "tercera": 2, "uno": 0, "dos": 1, "tres": 2, "1": 0, "2": 1, "3": 2}

def voice(text):
    """Recibe lo dictado y devuelve una respuesta corta para leer en voz alta. Primero reglas (coste cero);
    si no encaja ninguna y Ollama está activo, el modelo local elige la acción."""
    q = text.lower().strip()
    S = STATUS
    todo = sorted(S.get("todo", []), key=lambda x: ORDER.get(x["state"], 9))
    def summary():
        bad = sum(1 for x in todo if x["state"] == "bad")
        parts = []
        parts.append("Tienes %d cosa%s pendiente%s" % (len(todo), "" if len(todo) == 1 else "s", "" if len(todo) == 1 else "s") if todo else "No tienes nada pendiente")
        if bad: parts.append("%d urgente%s" % (bad, "" if bad == 1 else "s"))
        if S.get("running"): parts.append("%d trabajo%s en marcha" % (len(S["running"]), "" if len(S["running"]) == 1 else "s"))
        nx = next_job()
        if nx: parts.append("lo próximo es %s, %s" % (nx["name"], when_es(nx["next"])))
        return ". ".join(p[0].upper() + p[1:] for p in parts) + "."
    if re.search(r"\b(resumen|estado|c[oó]mo va|qu[eé] tal|novedades)\b", q):
        return summary()
    if re.search(r"(qu[eé] me toca|pendiente|lista)", q):
        if not todo: return "Nada pendiente."
        return "Te toca: " + "; ".join("%d, %s" % (i + 1, x["title"]) for i, x in enumerate(todo[:3])) + "."
    m = re.search(r"(descarta|hecho|listo|marca)\D*(primero|primera|segundo|segunda|tercero|tercera|uno|dos|tres|\d)", q)
    if m and todo:
        i = NUM.get(m.group(2), 0)
        if i >= len(todo): return "Solo hay %d." % len(todo)
        x = todo[i]; action("dismiss" if m.group(1) == "descarta" else "done", x["id"])
        return ("Descartado: " if m.group(1) == "descarta" else "Hecho: ") + x["title"] + "."
    m = re.search(r"(contesta|responde)\w*\s+(?:al?\s+)?(primero|primera|segundo|segunda|tercero|tercera|uno|dos|tres|\d)?[^:,]*[:,]?\s*(.*)", q)
    if m and todo:
        cand = [x for x in todo if x.get("reply")]
        i = NUM.get(m.group(2) or "primero", 0)
        if not cand: return "Ningún aviso necesita respuesta."
        x = cand[min(i, len(cand) - 1)]
        body = text[text.lower().find(m.group(3)):] if m.group(3) else ""
        if len(body) < 5: return "Dime el texto después de dos puntos. Por ejemplo: contesta al primero, gracias, os llamo el lunes."
        r = action("draft_reply", x["id"], body)
        return "Borrador guardado para %s. No se ha enviado." % x["title"] if r.get("ok") else "No pude guardar el borrador: " + r.get("error", "")
    if re.search(r"(luz|electricidad)", q):
        e = (S.get("radar") or {}).get("electricity")
        if not e or not e.get("now"): return "No tengo el precio de la luz ahora."
        return "La luz está a %s céntimos el kilovatio. Las horas más baratas de hoy son %s." % (fmt_num(e["now"] * 100, 1), ", ".join(e["cheap"]))
    m = re.search(r"(precio|cu[aá]nto (?:vale|est[aá]))\s+(?:de[l]?\s+|el\s+|la\s+)?(.+)", q)
    if m:
        name = m.group(2).strip(" ?.")
        for p in (S.get("radar") or {}).get("prices", []):
            if name in (p.get("name", "") + " " + p["id"]).lower():
                ch = p.get("chg24")
                return "%s está en %s %s%s." % (p.get("name", p["id"]), fmt_num(p["price"]), p.get("unit", ""),
                                               (", %s %s%% en 24 horas" % ("sube" if ch >= 0 else "baja", fmt_num(abs(ch), 1))) if ch is not None else "")
        return "No sigo el precio de %s." % name
    if re.search(r"noticia", q):
        n = (S.get("radar") or {}).get("news", [])[:3]
        return ("Titulares: " + ". ".join(x["title"] for x in n) + ".") if n else "No hay noticias relevantes ahora."
    if re.search(r"(dinero|cobrado|ingres|pagos)", q):
        r = S.get("radar") or {}
        if r.get("income_month") is None: return "Aún no leo los pagos."
        return "Este mes has cobrado %s euros%s." % (fmt_num(r["income_month"]), (" de %s de objetivo" % r["income_goal"]) if r.get("income_goal") else "")
    if re.search(r"(pr[oó]xim|cu[aá]ndo)", q):
        nx = next_job()
        return "Lo próximo es %s, %s." % (nx["name"], when_es(nx["next"])) if nx else "No hay nada programado."
    oc = CFG.get("ollama", {})
    if oc.get("enabled"):
        try:
            ctx = json.dumps({"todo": [x["title"] for x in todo[:6]], "running": [r["name"] for r in S.get("running", [])],
                              "prices": [[p.get("name"), p.get("price")] for p in (S.get("radar") or {}).get("prices", [])]}, ensure_ascii=False)
            out = ollama("Contexto: %s\nPregunta del usuario (está conduciendo): %s\nResponde en español en máximo 2 frases cortas." % (ctx, text),
                         system="Eres Faro, el panel de estado de Nawe. Solo informas; no inventes datos que no estén en el contexto.")
            return out or "No te he entendido."
        except Exception as e:
            log("voice ollama", e)
    return "No te he entendido. Puedes decir: resumen, qué me toca, descarta el primero, contesta al primero, precio de bitcoin o la luz."

def fmt_num(v, d=2):
    if v is None: return "?"
    s = ("%." + str(d) + "f") % v if abs(v) < 1000 else "%d" % round(v)
    return s.replace(".", ",")

def next_job():
    t = now(); best = None
    for p in STATUS.get("projects", []):
        for j in p["jobs"]:
            n = parse_iso(j.get("next"))
            if n and n > t and (not best or n < parse_iso(best["next"])): best = j
    return best

def when_es(s):
    n = parse_iso(s); d = (n.date() - now().date()).days
    day = "hoy" if d == 0 else "mañana" if d == 1 else ["el lunes", "el martes", "el miércoles", "el jueves", "el viernes", "el sábado", "el domingo"][n.weekday()]
    return "%s a las %s" % (day, n.strftime("%H:%M"))

# ───────────────────────── acciones ─────────────────────────
def action(typ, iid=None, text=None):
    with LOCK:
        item = next((x for x in STATUS.get("todo", []) if x["id"] == iid), None)
        if typ in ("dismiss", "done", "draft_reply") and iid:
            if typ == "draft_reply":
                if not item: return {"ok": False, "error": "aviso no encontrado"}
                try:
                    gmail_draft(item, text or "")
                except Exception as e:
                    return {"ok": False, "error": str(e)[:120]}
                STATE["xp"] += CFG.get("xp", {}).get("reply", 25); STATE["done"] += 1
            elif typ == "done":
                STATE["xp"] += CFG.get("xp", {}).get("resolve", 10); STATE["done"] += 1
            STATE["dismissed"][iid] = iso(now())
        elif typ == "undismiss_all":
            STATE["dismissed"] = {}
        elif typ == "hide_news" and iid:
            STATE["news_hidden"][iid] = iso(now())
            n = CACHE.get("news", {}).get("items", [])
            CACHE.get("news", {})["items"] = [x for x in n if x["id"] != iid]
        else:
            return {"ok": False, "error": "acción desconocida"}
        save_state()
    build_status()
    return {"ok": True, "game": STATUS.get("game")}

ACT_OK = {"obsidian", "web", "code", "edit", "write", "skills", "mail", "system", "think", "cards"}
ACT_ES = {"codigo": "code", "código": "code", "programar": "code", "editar": "edit", "montar": "edit", "pensar": "think", "buscar": "web",
          "investigar": "web", "escribir": "write", "redactar": "write", "correo": "mail", "sistema": "system", "instalar": "system",
          "bóveda": "obsidian", "boveda": "obsidian", "skill": "skills"}
def norm_action(r):
    """`action` dice QUÉ usa el agente (código, web, bóveda…). Si llega una frase, es un paso: va a `step` y no se inventa zona."""
    a = r.get("action")
    if not a: return r
    k = str(a).strip().lower()
    if k in ACT_OK: return r
    if k in ACT_ES: r["action"] = ACT_ES[k]; return r
    if not r.get("step"): r["step"] = str(a)[:120]
    r["action"] = None
    return r

def report(body):
    """Informe de un agente o tarea. Campos: id (obligatorio), kind (job|run|agent|todo), project, name, where,
    state (ok|run|warn|bad|off), pct, step, note, next, last, ttl (segundos sin noticias antes de avisar)."""
    try:
        body = validate_report(body)
    except (ValueError, TypeError) as e:
        return {"ok": False, "error": str(e)}
    rid = body["id"]
    with LOCK:
        prev = REPORTS.get(rid, {})
        r = validate_report({**prev, **body, "at": body.get("src_at") or iso(now())})
        if r.get("kind") == "run" and "pct" in body and isinstance(prev.get("pct"), (int, float)) and prev.get("at"):
            mins = (now() - parse_iso(prev["at"])).total_seconds() / 60
            if mins > 0.05 and body["pct"] >= prev["pct"]:
                inst = (body["pct"] - prev["pct"]) / mins
                r["rate"] = round(inst if not prev.get("rate") else prev["rate"] * 0.5 + inst * 0.5, 3)
        if r.get("state") == "ok" and r.get("kind", "job") == "job" and "last" not in body:
            r["last"] = r["at"]
        REPORTS[rid] = r
        jsave("reports.json", REPORTS)
        note_event(body)
    # notas que el agente dice haber leído o escrito (sesiones en la nube o en el Mac, que el vigía del PC no ve)
    nts = body.get("notes")
    if nts:
        nk = json.dumps([nts, body.get("src_at") or body.get("at")], ensure_ascii=False)
        if nk != prev.get("notes_key"):
            with LOCK: REPORTS[rid]["notes_key"] = nk
            kind = body.get("notes_kind") if body.get("notes_kind") in ("read", "write", "new") else "read"
            for p_ in (nts if isinstance(nts, list) else str(nts).split(";"))[:24]:
                p_ = str(p_).strip().replace("\\", "/")
                if p_.endswith(".md"): p_ = p_[:-3]
                if p_: vault_event(p_, kind, who=body.get("name") or rid, via="agente")
    sy = body.get("say")
    if sy and sy != prev.get("say"):  # el buzón de GitHub reenvía los mismos informes: solo cuenta lo nuevo
        sy = sy if isinstance(sy, dict) else {"text": str(sy)}
        say(body.get("name") or body.get("agent") or rid, sy.get("to"), sy.get("text"), "informe")
    pj = r.get("project") or infer_project((r.get("task") or "") + " " + (r.get("name") or ""))
    if body.get("artifact") or (prev.get("state") == "run" and body.get("state") in ("ok", "done")):
        build_add(pj, body.get("task") or r.get("name") or rid)
    build_status()
    return {"ok": True}

# ───────────────────────── órdenes: reparto entre IAs ─────────────────────────
ORDERS = jload("orders.json", [])
DEMO = "--demo" in sys.argv
OQ = threading.Condition(LOCK)

def save_orders():
    with LOCK:
        del ORDERS[:-200]
        jsave("orders.json", ORDERS)

def brand_of(n):
    n = (n or "").lower()
    for k, rx in (("gpt", r"codex|gpt|openai|chatgpt"), ("claude", r"claude"), ("hermes", r"hermes"), ("local", r"strata|ollama|local|qwen")):
        if re.search(rx, n): return k
    return "hermes"

EXEC_BLOCK = {}
AUTH_RE = re.compile(r"not logged in|/login|please log in|unauthori[sz]ed|\b401\b|authentication|invalid api key|organization has disabled|subscription", re.I)

def local_auth(url, e=None):
    """Cabecera de acceso de un servidor de IA local (Strata). La clave vive solo en el PC, en data/secrets/strata.json
    (la deja ahí tools/conectar-strata.sh, sin mostrarla) y solo se envía a localhost: nunca a otra dirección."""
    host = (urllib.parse.urlparse(url or "").hostname or "").lower()
    if host not in ("127.0.0.1", "localhost", "::1"): return {}
    fp = os.path.expanduser((e or {}).get("key_file") or os.path.join(ROOT, "data", "secrets", "strata.json"))
    try:
        st = os.stat(fp); c = _AUTH_CACHE.get(fp)
        if not c or c[0] != st.st_mtime:
            with open(fp, encoding="utf-8") as f: k = json.load(f)
            c = _AUTH_CACHE[fp] = (st.st_mtime, {str(k["header"]): str(k["value"])})
        return dict(c[1])
    except Exception: return {}
_AUTH_CACHE = {}

_HEAL = {"t": 0}
def strata_heal():
    """Si Strata deja de responder donde estaba (al reiniciar elige el primer puerto libre desde 18500), lo busca en
    18500-18505 con su misma cabecera, solo en localhost, y guarda el puerto nuevo. Como mucho una vez por minuto."""
    if time.time() - _HEAL["t"] < 60: return None
    _HEAL["t"] = time.time()
    fp = os.path.join(ROOT, "data", "secrets", "strata.json")
    try:
        with open(fp, encoding="utf-8") as f: k = json.load(f)
    except Exception: return None
    hdr = {str(k["header"]): str(k["value"])} if k.get("header") else {}
    for port in range(18500, 18506):
        u = "http://127.0.0.1:%d" % port
        if u == k.get("url"): continue
        try: http_json(u + "/v1/models", timeout=1.5, headers=hdr)
        except Exception: continue
        k["url"] = u; tmp = fp + ".tmp"
        with os.fdopen(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w", encoding="utf-8") as f: json.dump(k, f)
        os.replace(tmp, fp); log("Strata responde ahora en %s" % u); return u
    return None

def strata_url(default=None):
    """Puerto real de Strata, si conectar-strata.sh lo encontró (p. ej. 18500 del perfil app-1)."""
    try:
        with open(os.path.join(ROOT, "data", "secrets", "strata.json"), encoding="utf-8") as f: u = json.load(f).get("url")
        if u and (urllib.parse.urlparse(u).hostname or "") in ("127.0.0.1", "localhost", "::1"): return u
    except Exception: pass
    return default

def executor_ok(name):
    e = CFG.get("executors", {}).get(name)
    if not e or not e.get("enabled", True): return False
    b = EXEC_BLOCK.get(name)
    if b and time.time() < b["until"]: return False
    if e.get("type") == "cmd": return bool(shutil.which(e["cmd"][0]))
    if e.get("type") in ("openai", "ollama"):   # solo si el servidor local responde (se mira como mucho una vez por minuto)
        c = PROBE.get(name)
        if not c or time.time() - c[0] > 60:
            url = (strata_url(e.get("url")) if e.get("type") == "openai" else e.get("url")) or CFG.get("ollama", {}).get("url", "http://127.0.0.1:11434")
            try: http_json(url.rstrip("/") + ("/v1/models" if e["type"] == "openai" else "/api/tags"), timeout=2, headers=local_auth(url, e)); ok = True
            except Exception: ok = bool(e.get("type") == "openai" and strata_heal())
            c = PROBE[name] = (time.time(), ok)
        return c[1]
    return True
PROBE = {}

def route(text, wanted=None):
    """Decide quién ejecuta la orden y con qué prioridad. Reglas primero (coste cero); si ninguna encaja
    y hay IA local, ella clasifica; si no, el primer ejecutor disponible de la lista de reserva."""
    R = CFG.get("routing", {})
    q = " " + text.lower() + " "
    prio = "normal"
    for p, kws in R.get("priority", {}).items():
        if any(k in q for k in kws): prio = p; break
    if wanted and executor_ok(wanted):
        return {"executor": wanted, "priority": prio, "reason": "Elegido por ti"}
    missing = (" · %s no está disponible en el PC" % ex_label(wanted)) if wanted else ""
    for rule in R.get("rules", []):
        if any(k in q for k in rule["match"]):
            for i, ex in enumerate(rule["to"]):
                if executor_ok(ex):
                    why = rule.get("why", "Regla: " + rule["match"][0].strip())
                    if i: why += " (%s no disponible)" % CFG.get("executors", {}).get(rule["to"][0], {}).get("label", rule["to"][0])
                    return {"executor": ex, "priority": prio, "reason": why}
    if R.get("llm_classify") and executor_ok("local"):
        try:
            opts = [k for k in CFG.get("executors", {}) if executor_ok(k)]
            desc = {k: CFG["executors"][k].get("good_for", "") for k in opts}
            out = ollama('Elige quién debe ejecutar esta orden. Opciones: %s. Responde JSON {"executor":..., "reason": "máx 8 palabras"}.\nOrden: %s'
                         % (json.dumps(desc, ensure_ascii=False), text), fmt="json")
            d = json.loads(out)
            if d.get("executor") in opts:
                return {"executor": d["executor"], "priority": prio, "reason": "IA local: " + d.get("reason", "")[:60]}
        except Exception as e:
            log("route llm", e)
    for ex in R.get("fallback", ["faro"]):
        if executor_ok(ex):
            return {"executor": ex, "priority": prio, "reason": "Reserva" + missing}
    return {"executor": "faro", "priority": prio, "reason": "Sin ejecutores disponibles: Faro responde con sus datos" + missing}

PRIO_ORDER = {"alta": 0, "normal": 1, "baja": 2, "noche": 3}

ACTION_HINTS = [("obsidian", r"obsidian|b[oó]veda|\bnotas?\b|_agentes"), ("code", r"c[oó]digo|script|programa|repositorio|bug|github"),
                ("web", r"busca en (la )?(web|internet)|noticias|navega|p[aá]gina web"), ("edit", r"v[ií]deo|clip|montaje|render|ffmpeg|subt[ií]tulo"),
                ("mail", r"correo|email|gmail"), ("system", r"instala|reinicia|servicio|systemctl|carpeta|archivo|copia|mueve"),
                ("write", r"escribe|redacta|resume|resumen|traduce|propuesta|gui[oó]n")]
def infer_action(text):
    t = (text or "").lower()
    for k, rx in ACTION_HINTS:
        if re.search(rx, t): return k
    return None

NAMES_RE = {"hermes": r"\bhermes\b", "claude": r"\bclaude\b", "codex": r"\bc[oó]dex\b", "local": r"\b(strata|ia local)\b"}

def new_order(text, kind="orden", title=None, thread=None, executor=None):
    text = (text or "").strip()
    if not text: return {"ok": False, "error": "orden vacía"}
    if not executor:  # «Hermes, Codex y Claude, haced…» → una orden para cada uno
        named = [k for k, rx in NAMES_RE.items() if re.search(rx, text, re.I) and k in CFG.get("executors", {})]
        if len(named) > 1:
            outs = [new_order(text, kind, title, thread, k) for k in named]
            return {"ok": True, "order": outs[0].get("order"), "orders": [x.get("order") for x in outs], "fanout": named}
    r = route(text, executor)
    if executor and r["executor"] != executor and executor in CFG.get("executors", {}):
        r = {"executor": executor, "priority": r["priority"], "reason": "Para %s; espera a que esté disponible en el PC" % ex_label(executor)}
    if r["executor"] == "faro" and (executor or kind == "nuevo"):
        # una respuesta o un encargo para un agente no lo «contesta» Faro: espera a que ese agente esté disponible
        r = {"executor": executor or "claude", "priority": r["priority"], "reason": "Esperando a que %s esté disponible en el PC" % ex_label(executor or "claude")}
    o = {"id": "o:" + uuid.uuid4().hex[:8], "text": text, "kind": kind, "title": title or text[:60], "project": infer_project(text), "action": infer_action(text),
         "thread": thread or (None if kind == "orden" else "t:" + uuid.uuid4().hex[:6]),
         "executor": r["executor"], "priority": r["priority"], "reason": r["reason"],
         "state": "queued", "created": iso(now()), "started": None, "finished": None, "result": None}
    with OQ:
        ORDERS.append(o); save_orders(); OQ.notify_all()
    if kind != "nuevo" or not title or not title.startswith(("Respuesta:", "Hacedlo:")):
        say("Nawe", ex_label(o["executor"]), o["title"], "orden")
    build_status()
    return {"ok": True, "order": o}

def thread_context(o):
    if not o.get("thread"): return ""
    prev = [x for x in ORDERS if x.get("thread") == o["thread"] and x["id"] != o["id"] and x.get("result")][-3:]
    return "".join("Antes pediste: %s\nResultado: %s\n\n" % (x["text"][:300], x["result"][:600]) for x in prev)

DEFAULT_PREAMBLE = ("Recibes esta orden de Nawe a través de Faro, su panel. Hazla de verdad y responde en español, breve: "
    "qué has hecho, dónde está el resultado y qué falta. Trabaja en la carpeta actual salvo que la orden diga otra. "
    "No escribas contraseñas ni tokens, no pagues ni muevas dinero, no envíes mensajes ni correos en su nombre (déjalos en borrador) "
    "y no hagas nada irreversible: si algo lo necesita, prepáralo y dilo en tu respuesta como pendiente para Nawe. "
    "La bóveda de Obsidian de Nawe se puede leer; si escribes en ella, solo dentro de _agentes/.")

def execute(o):
    name = o["executor"]
    if DEMO and name != "faro":
        time.sleep(4); return "(demo) Aquí iría la respuesta de %s." % name
    e = CFG.get("executors", {}).get(name, {})
    pre = e.get("preamble", CFG.get("preamble", DEFAULT_PREAMBLE))
    prompt = (pre + "\n\n" + thread_context(o) + o["text"]).strip()
    if name == "faro" or e.get("type") == "faro":
        return voice(o["text"])
    if e.get("type") == "ollama":
        oc = {**CFG.get("ollama", {}), **e}
        body = {"model": oc.get("model"), "prompt": prompt, "stream": False, "keep_alive": oc.get("keep_alive", "2m")}
        return http_json(oc.get("url", "http://127.0.0.1:11434").rstrip("/") + "/api/generate", data=body, timeout=e.get("timeout", 600)).get("response", "")
    if e.get("type") == "openai":   # servidor local compatible con OpenAI (Strata en el PC): coste cero
        body = {"messages": [{"role": "user", "content": prompt}], "temperature": 0.3, "stream": False}
        if e.get("model"): body["model"] = e["model"]
        u = strata_url(e.get("url", "http://127.0.0.1:18501")); t0 = time.time()
        d = http_json(u.rstrip("/") + "/v1/chat/completions", data=body, timeout=e.get("timeout", 900), headers=local_auth(u, e))
        try: strata_timings(d, time.time() - t0)
        except Exception: pass
        return ((d.get("choices") or [{}])[0].get("message") or {}).get("content", "").strip()
    if e.get("type") == "cmd":
        args = [a.replace("{prompt}", prompt) for a in e["cmd"]]
        cwd = os.path.expanduser(e.get("cwd") or CFG.get("work_dir") or "~/FaroTrabajo")  # nunca dentro de Faro
        os.makedirs(cwd, exist_ok=True)
        args = norm_cmd(args)
        p = subprocess.run(args, capture_output=True, text=True, timeout=e.get("timeout", 1800), cwd=cwd,
                           input=prompt if e.get("stdin") else None, stdin=None if e.get("stdin") else subprocess.DEVNULL)
        out = (p.stdout or "").strip()
        if p.returncode != 0:
            raise RuntimeError(((p.stderr or "") + out)[-400:] or "código %d" % p.returncode)
        return out
    raise RuntimeError("ejecutor sin tipo")

_CODEX_HELP = {}
def _codex_has(prog, flag):
    """¿Esta versión de Codex entiende la bandera? (se mira una vez su ayuda)"""
    if prog not in _CODEX_HELP:
        try: _CODEX_HELP[prog] = subprocess.run([prog, "exec", "--help"], capture_output=True, text=True, timeout=20, stdin=subprocess.DEVNULL).stdout
        except Exception: _CODEX_HELP[prog] = ""
    return flag in _CODEX_HELP[prog]

def norm_cmd(args):
    """Banderas imprescindibles para que cada CLI trabaje sin nadie delante (aunque config.json traiga un comando antiguo).
    A Codex le abre además la bóveda y localhost (Claude ya tenía la bóveda); el resto, nada nuevo."""
    a = list(args); prog = os.path.basename(a[0]) if a else ""
    vp = expand((CFG.get("vault") or {}).get("path"))
    if prog == "codex" and "exec" in a and "--skip-git-repo-check" not in a:
        a.insert(a.index("exec") + 1, "--skip-git-repo-check")       # FaroTrabajo no es un repositorio git
    if prog == "codex" and "exec" in a:
        i = a.index("exec") + 1
        # su caja de arena solo dejaba escribir en ~/FaroTrabajo y cortaba localhost: la bóveda (como a Claude) y la red
        # para poder informar a Faro en 127.0.0.1
        if vp and os.path.isdir(vp) and vp not in a and _codex_has(a[0], "--add-dir"): a[i:i] = ["--add-dir", vp]
        # sin modo explícito, «codex exec» trabaja en solo lectura (así venía el config.json del PC): escritura en su carpeta
        if not any(x in ("-s", "--sandbox", "--full-auto", "--dangerously-bypass-approvals-and-sandbox") or x.startswith("--sandbox=") for x in a):
            a[i:i] = ["-s", "workspace-write"]
        if not any("network_access" in x for x in a): a[i:i] = ["-c", "sandbox_workspace_write.network_access=true"]
    if prog == "claude" and "-p" not in a and "--print" not in a:
        a.insert(1, "-p")
    if prog == "claude" and not any(x.startswith("--permission-mode") or x == "--dangerously-skip-permissions" for x in a):
        a[1:1] = ["--permission-mode", "acceptEdits"]                  # editar en ~/FaroTrabajo sin preguntar; nada de comandos libres
    if prog == "claude" and vp and os.path.isdir(vp) and vp not in a:
        a[1:1] = ["--add-dir", vp]                                     # la bóveda: para leer y escribir solo en _agentes/
    if prog == "hermes" and "chat" in a and "-Q" not in a and "--quiet" not in a and "--oneshot" not in a:
        a.insert(a.index("chat") + 1, "-Q")                            # una respuesta y salir
    return a

QUOTA_RE = re.compile(r"quota|\b429\b|rate.?limit|usage limit|too many requests", re.I)

def worker(name):
    while True:
        with OQ:
            def pick():
                h = now().hour
                if name != "faro" and not executor_ok(name): return None   # desactivado o sin instalar: la orden espera
                ready = [o for o in ORDERS if o["state"] == "queued" and o["executor"] == name
                         and (o["priority"] != "noche" or 1 <= h < 7)]
                return sorted(ready, key=lambda o: (PRIO_ORDER.get(o["priority"], 1), o["created"]))[0] if ready else None
            o = pick()
            while not o:
                OQ.wait(30); o = pick()
            o["state"] = "running"; o["started"] = iso(now()); save_orders()
        build_status()
        try:
            res = execute(o); st = "done"
        except Exception as ex:
            res = "Error: %s" % ex; st = "failed"
            if QUOTA_RE.search(str(ex)):  # sin cuota: no es un fallo de la tarea; espera y se reintenta sola
                m = re.search(r"retry after (\d+)\s*s", str(ex), re.I); wait = min(int(m.group(1)) if m else 1800, 6 * 3600)
                EXEC_BLOCK[name] = {"until": time.time() + wait, "why": "sin cuota hasta las %s" % (now() + dt.timedelta(seconds=wait)).strftime("%H:%M"), "at": iso(now())}
                st = "requeue"
            elif AUTH_RE.search(str(ex)):   # sin sesión: no mandarle más órdenes hasta que alguien la arregle
                EXEC_BLOCK[name] = {"until": time.time() + 6 * 3600, "why": "sin sesión iniciada: " + str(ex)[-120:], "at": iso(now())}
        if st == "requeue":
            with OQ:
                o["state"] = "queued"; o["started"] = None; o["reason"] = "%s · %s; se reintenta sola" % (ex_label(name), EXEC_BLOCK[name]["why"]); save_orders()
            say(ex_label(name), "Nawe", "Sin cuota: retomo «%s» %s" % (o["title"][:60], EXEC_BLOCK[name]["why"].replace("sin cuota ", "")), "fallo")
            build_status(); continue
        with OQ:
            o["state"] = st; o["finished"] = iso(now()); o["result"] = (res or "")[-4000:]
            if st == "done": STATE["xp"] += CFG.get("xp", {}).get("order", 5); save_state(); build_add(o.get("project"), o["title"])
            save_orders()
        first = next((l.strip() for l in (res or "").splitlines() if l.strip()), "")
        say(ex_label(name), "Nawe", ("Hecho: " if st == "done" else "No he podido: ") + (first[:160] or o["title"]), "entrega" if st == "done" else "fallo")
        build_status()
        if st == "failed":
            try: telegram("Faro: falló «%s» en %s" % (o["title"], name))
            except Exception: pass

def order_action(oid, typ, executor=None):
    with OQ:
        o = next((x for x in ORDERS if x["id"] == oid), None)
        if not o: return {"ok": False, "error": "no existe"}
        if typ == "reassign" and executor and o["state"] in ("queued", "failed"):
            o["executor"] = executor; o["reason"] = "Reasignada por ti"; o["state"] = "queued"
        elif typ == "retry" and o["state"] == "failed":
            o["state"] = "queued"
        elif typ == "cancel" and o["state"] == "queued":
            o["state"] = "cancelled"
        elif typ == "archive":
            o["archived"] = True
        else:
            return {"ok": False, "error": "no aplicable"}
        save_orders(); OQ.notify_all()
    build_status()
    return {"ok": True}

# ───────────────────────── servidor HTTP ─────────────────────────
class H(BaseHTTPRequestHandler):
    server_version = "Faro/" + VERSION
    def log_message(self, *a): pass
    def _send(self, code, body, ctype="application/json; charset=utf-8", cache=None):
        if isinstance(body, (dict, list)): body = json.dumps(body, ensure_ascii=False).encode()
        elif isinstance(body, str): body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype); self.send_header("Cache-Control", cache or "no-store")
        if urllib.parse.urlparse(self.path).path == "/api/report": self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def _auth(self):
        """Red local, Tailscale (100.64.0.0/10) y el propio equipo entran sin token; desde fuera hace falta el token."""
        tok = CFG.get("token")
        if not tok: return True
        import ipaddress
        try:
            ip = ipaddress.ip_address(self.client_address[0])
            if ip.is_private or ip.is_loopback or ip in ipaddress.ip_network("100.64.0.0/10"): return True
        except Exception:
            pass
        got = self.headers.get("X-Faro-Token") or urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("token", [""])[0]
        return got == tok
    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path in ("/", "/index.html"):
            with open(os.path.join(WEB, "index.html"), "rb") as f: return self._send(200, f.read(), "text/html; charset=utf-8")
        if re.fullmatch(r"/[\w.-]+\.(js|svg|css|png|webp|ttf|html)", path):
            fp = os.path.join(WEB, path[1:])
            if os.path.isfile(fp):
                ext = path.rsplit(".", 1)[1]
                ct = {"js": "text/javascript; charset=utf-8", "svg": "image/svg+xml", "css": "text/css", "png": "image/png", "webp": "image/webp", "ttf": "font/ttf", "html": "text/html; charset=utf-8"}[ext]
                cache = "public, max-age=2592000, immutable" if ext in ("png", "webp") and "v=" in (urllib.parse.urlparse(self.path).query or "") else None
                with open(fp, "rb") as f: return self._send(200, f.read(), ct, cache=cache)
        if path == "/api/order":
            query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            oid = query.get("id", [""])[0]
            with LOCK:
                order = next((o for o in STATUS.get("orders", []) if o.get("id") == oid), None)
                return self._send(200 if order else 404, order or {"error": "not found"})
        if path == "/api/office":
            with LOCK:
                panel = panel_status(STATUS)
                return self._send(200, {k: v for k, v in STATUS.items() if k not in panel or k == "orders"})
        if path in ("/status.json", "/api/status"):
            with LOCK: return self._send(200, panel_status(STATUS))
        if path == "/api/ticks":
            with LOCK: return self._send(200, TICKS)
        if path == "/api/vault/live":   # la oficina pregunta cada ~1 s: qué notas se han tocado y, si cambió, el grafo nuevo
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            try: since, gv = int(q.get("since", ["0"])[0] or 0), int(q.get("gv", ["-1"])[0] or -1)
            except ValueError: since, gv = 0, -1
            return self._send(200, vault_live(since, gv))
        if path == "/api/machines":
            return self._send(200, {"at": iso(now()), "machines": machines(), "strata": strata_live()})
        if path == "/api/health":
            return self._send(200, {"ok": True, "version": VERSION, "update": UPD, "sources": STATUS.get("sources"),
                "executors": {k: {"ok": executor_ok(k), "enabled": e.get("enabled", True), "path": shutil.which(e["cmd"][0]) if e.get("type") == "cmd" else None,
                                  "blocked": EXEC_BLOCK.get(k, {}).get("why") if EXEC_BLOCK.get(k, {}).get("until", 0) > time.time() else None}
                              for k, e in CFG.get("executors", {}).items()}})
        if path == "/api/voice":
            if not self._auth(): return self._send(401, {"error": "token"})
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("q", [""])[0]
            return self._send(200, voice(q), "text/plain; charset=utf-8")
        self._send(404, {"error": "no existe"})
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Faro-Token"); self.end_headers()
    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path in ("/api/action", "/api/update", "/api/machine", "/api/suggestion/action"):
            if not self._auth(): return self._send(401, {"error": "token"})
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b""
        try: body = json.loads(raw or b"{}")
        except Exception: body = {"text": raw.decode("utf-8", "replace")}
        if path == "/api/action":
            return self._send(200, action(body.get("type"), body.get("id"), body.get("text")))
        if path == "/api/machine":   # el vigía del Mac (u otro equipo) manda su CPU/RAM/gráfica
            nm = str(body.get("name") or "")[:20]
            if not nm: return self._send(400, {"ok": False})
            keep = {k: body.get(k) for k in ("name", "kind", "cpu", "ncpu", "ram", "ram_gb", "ram_total_gb", "gpu", "vram_gb", "vram_total_gb", "gpu_temp", "gpu_w", "gpu_name", "top", "gpu_apps")}
            MACHINES[nm] = {**keep, "at": iso(now())}; return self._send(200, {"ok": True})
        if path == "/api/executor":
            if not self._auth(): return self._send(401, {"error": "token"})
            ch = {k: v for k, v in body.items() if k != "name"}
            return self._send(200, set_executor(body.get("name"), ch))
        if path == "/api/update":
            try: return self._send(200, {"ok": True, **(self_update(force=True) or {})})
            except Exception as e: return self._send(200, {"ok": False, "error": str(e)[:160]})
        if path == "/api/suggestion":
            if not self._auth(): return self._send(401, {"error": "token"})
            return self._send(200, suggestion_add(body))
        if path == "/api/suggestion/action":
            return self._send(200, suggestion_action(body.get("id"), body.get("type"), body.get("text")))
        if path == "/api/order":
            if not self._auth(): return self._send(401, {"error": "token"})
            return self._send(200, new_order(body.get("text"), body.get("kind", "orden"), body.get("title"), body.get("thread"), body.get("executor")))
        if path == "/api/order/action":
            if not self._auth(): return self._send(401, {"error": "token"})
            return self._send(200, order_action(body.get("id"), body.get("type"), body.get("executor")))
        if not self._auth(): return self._send(401, {"error": "token"})
        if path == "/api/report":
            items = body if isinstance(body, list) else [body]
            res = [report(b) for b in items]
            return self._send(200, res[0] if len(res) == 1 else res)
        if path == "/api/message":
            say(body.get("from"), body.get("to"), body.get("text"), "msg"); build_status(); return self._send(200, {"ok": True})
        if path == "/api/voice":
            return self._send(200, voice(body.get("text") or body.get("q") or ""), "text/plain; charset=utf-8")
        self._send(404, {"error": "no existe"})

def loop():
    last_vault = 0
    while True:
        if time.time() - last_vault > 900:
            last_vault = time.time()
            try: vault_write()
            except Exception as e: log("vault_write", e)
        try: run_collectors()
        except Exception: log(traceback.format_exc())
        time.sleep(CFG.get("tick", 5))

def main():
    port = int(os.environ.get("FARO_PORT") or CFG.get("port", 8787))
    if "--demo" in sys.argv:
        raise SystemExit("Modo demo deshabilitado: Faro solo admite datos reales.")
    if "--once" in sys.argv and "--update-probe" in sys.argv:
        # Arranque HTTP sin recolectores, ejecutores ni escrituras en la bóveda.
        ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever(); return
    if "--once" in sys.argv:
        run_collectors(force=True); print(json.dumps(STATUS.get("sources"), ensure_ascii=False, indent=1)); return
    run_collectors(force=True)
    threading.Thread(target=loop, daemon=True).start()
    threading.Thread(target=vault_watch, daemon=True).start()
    for name in CFG.get("executors", {}) or {"faro": {}}:
        threading.Thread(target=worker, args=(name,), daemon=True).start()
    with LOCK:
        for o in ORDERS:
            if o["state"] == "running": o["state"] = "queued"  # se reanudan tras un reinicio
    srv = ThreadingHTTPServer((CFG.get("bind", "0.0.0.0"), port), H)
    log("Faro escuchando en http://%s:%d" % (CFG.get("bind", "0.0.0.0"), port))
    srv.serve_forever()

if __name__ == "__main__":
    main()
