#!/usr/bin/env python3
"""Faro: panel de estado personal. Un solo proceso, sin dependencias externas (Python 3.9+).

  python faro.py                 arranca servidor + recolectores
  python faro.py --once          ejecuta los recolectores una vez y escribe data/status.json
  python faro.py --demo          arranca con datos de demostración (sin red)

Configuración: config.json (copia de config.example.json). Todo lo personal vive ahí.
"""
import base64, shutil, subprocess, uuid, datetime as dt, email.header, email.message, email.utils, html, imaplib, json, os, re, sys, threading, time, traceback
import urllib.parse, urllib.request, xml.etree.ElementTree as ET
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")
WEB = os.path.join(ROOT, "web")
os.makedirs(DATA, exist_ok=True)
LOCK = threading.RLock()

def _fix_path():
    """El servicio de usuario de systemd arranca con un PATH mínimo: sin esto Faro no encuentra claude, codex ni hermes."""
    home = os.path.expanduser("~"); extra = [os.path.join(home, d) for d in (".local/bin", "bin", ".npm-global/bin", ".bun/bin", ".cargo/bin", ".volta/bin", ".claude/local")]
    extra += ["/usr/local/bin", "/snap/bin", "/opt/homebrew/bin"]
    nvm = os.path.join(home, ".nvm/versions/node")
    if os.path.isdir(nvm):
        extra += [os.path.join(nvm, v, "bin") for v in sorted(os.listdir(nvm), reverse=True)]
    cur = os.environ.get("PATH", "").split(os.pathsep)
    os.environ["PATH"] = os.pathsep.join(cur + [d for d in extra if os.path.isdir(d) and d not in cur])
_fix_path()
VERSION = "1.0"
try:
    with open(os.path.join(ROOT, "VERSION"), encoding="utf-8") as _f: VERSION = _f.read().strip() or VERSION
except Exception:
    pass

# ───────────────────────── utilidades ─────────────────────────
def now():
    return dt.datetime.now().astimezone()

def iso(t):
    return t.isoformat(timespec="seconds") if t else None

def parse_iso(s):
    try:
        t = dt.datetime.fromisoformat(str(s).replace("Z", "+00:00"))
        return t if t.tzinfo else t.astimezone()
    except Exception:
        return None

def jload(name, default):
    p = os.path.join(DATA, name)
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def jsave(name, obj):
    p = os.path.join(DATA, name)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)

def log(*a):
    line = now().strftime("%Y-%m-%d %H:%M:%S") + " " + " ".join(str(x) for x in a)
    print(line, flush=True)
    try:
        with open(os.path.join(DATA, "faro.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

def http(url, data=None, headers=None, timeout=20, method=None):
    h = {"User-Agent": "Faro/" + VERSION}
    h.update(headers or {})
    if isinstance(data, (dict, list)):
        data = json.dumps(data).encode()
        h.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()

def http_json(url, **kw):
    return json.loads(http(url, **kw).decode("utf-8", "replace"))

def load_config():
    """config.example.json da los valores por defecto (y las novedades de cada versión); config.json manda."""
    def rd(name):
        try:
            with open(os.path.join(ROOT, name), encoding="utf-8") as f: return json.load(f)
        except FileNotFoundError: return {}
    base, user = rd("config.example.json"), rd("config.json")
    out = {**base, **user}
    for k in ("sources", "executors", "routing", "decision", "vault"):
        if isinstance(base.get(k), dict) and isinstance(user.get(k), dict):
            out[k] = {**base[k], **user[k]}
    return out

CFG = load_config()

# ───────────────────────── cron mínimo ─────────────────────────
def _field(spec, lo, hi):
    out = set()
    for part in spec.split(","):
        step = 1
        if "/" in part:
            part, s = part.split("/"); step = int(s)
        if part in ("*", ""):
            a, b = lo, hi
        elif "-" in part:
            a, b = map(int, part.split("-"))
        else:
            a = b = int(part)
            if step > 1: b = hi
        out.update(range(a, b + 1, step))
    return out

def cron_next(expr, after=None):
    """Siguiente ejecución de una expresión cron de 5 campos (admite prefijo CRON_TZ=Zona)."""
    tz = None
    expr = expr.strip()
    if expr.startswith("CRON_TZ="):
        name, expr = expr[8:].split(" ", 1)
        try:
            from zoneinfo import ZoneInfo
            tz = ZoneInfo(name)
        except Exception:
            tz = None  # Windows sin tzdata: se usa la hora local del equipo
    m, h, dom, mon, dow = expr.split()
    M, H, DOM, MON = _field(m, 0, 59), _field(h, 0, 23), _field(dom, 1, 31), _field(mon, 1, 12)
    DOW = {d % 7 for d in _field(dow, 0, 7)}
    dom_any, dow_any = dom == "*", dow == "*"
    t = (after or now())
    t = t.astimezone(tz) if tz else t
    t = t.replace(second=0, microsecond=0) + dt.timedelta(minutes=1)
    for _ in range(60 * 24 * 400):
        if t.month in MON and t.hour in H and t.minute in M:
            d_ok = t.day in DOM
            w_ok = ((t.weekday() + 1) % 7) in DOW
            if dom_any and dow_any: ok = True
            elif dom_any: ok = w_ok
            elif dow_any: ok = d_ok
            else: ok = d_ok or w_ok
            if ok:
                return t.astimezone()
        t += dt.timedelta(minutes=1)
    return None

# ───────────────────────── estado persistente ─────────────────────────
STATE = jload("state.json", {"xp": 0, "done": 0, "dismissed": {}, "news_hidden": {}, "alerts_sent": {}, "red_days": {}})
REPORTS = jload("reports.json", {})
HISTORY = jload("history.json", {})
CACHE = {}  # salida de cada recolector: nombre -> dict

def save_state():
    with LOCK:
        jsave("state.json", STATE)

def push_history(key, value, keep=400):
    with LOCK:
        arr = HISTORY.setdefault(key, [])
        stamp = iso(now())
        if arr and arr[-1][0][:13] == stamp[:13]:
            arr[-1] = [stamp, value]  # un punto por hora como máximo
        else:
            arr.append([stamp, value])
        del arr[:-keep]
        jsave("history.json", HISTORY)

def hist(key):
    return HISTORY.get(key, [])

# ───────────────────────── recolectores ─────────────────────────
COLLECTORS = {}
def collector(name, every):
    def deco(fn):
        COLLECTORS[name] = {"fn": fn, "every": every, "last": 0, "error": None}
        return fn
    return deco

def src_cfg(name):
    c = CFG.get("sources", {}).get(name)
    return c if c and c.get("enabled", True) else None

@collector("scheduled", 60)
def c_scheduled():
    """Tareas con horario conocido (p. ej. tareas programadas en la nube). El estado de la última
    ejecución llega por informe (/api/report) con el mismo id; si no hay informe, queda 'sin datos'."""
    jobs = []
    for j in CFG.get("scheduled", []):
        nxt = cron_next(j["cron"]) if j.get("cron") else None
        rep = REPORTS.get(j["id"], {})
        jobs.append({"project": j["project"], "name": j["name"], "where": j.get("where", "nube"),
                     "state": rep.get("state", "off"), "last": rep.get("last") or j.get("last"),
                     "next": iso(nxt), "every": j.get("every_days"),
                     "note": rep.get("note") or j.get("note") or ("" if rep else "Sin informe de la última ejecución.")})
    return {"jobs": jobs}

@collector("gmail", 300)
def c_gmail():
    c = src_cfg("gmail")
    if not c: return None
    M = imaplib.IMAP4_SSL("imap.gmail.com")
    M.login(c["user"], c["app_password"])
    try:
        M.select('"[Gmail]/All Mail"' if c.get("all_mail_name") is None else c["all_mail_name"], readonly=True)
    except Exception:
        M.select("INBOX", readonly=True)
    def search(q, limit=20):
        typ, data = M.uid("SEARCH", "X-GM-RAW", '"' + q.replace('"', '\\"') + '"')
        ids = (data[0] or b"").split()[-limit:]
        out = []
        for uid in reversed(ids):
            typ, msg = M.uid("FETCH", uid, "(X-GM-THRID BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE MESSAGE-ID)] BODY.PEEK[TEXT]<0.4000>)")
            hdr, body, thr = b"", b"", ""
            for part in msg:
                if isinstance(part, tuple):
                    meta = part[0].decode(errors="ignore")
                    m = re.search(r"X-GM-THRID (\d+)", meta)
                    if m: thr = m.group(1)
                    if "HEADER" in meta: hdr = part[1]
                    else: body = part[1]
            em = email.message_from_bytes(hdr)
            subj = str(email.header.make_header(email.header.decode_header(em.get("Subject", ""))))
            frm = email.utils.parseaddr(em.get("From", ""))[1]
            date = email.utils.parsedate_to_datetime(em.get("Date")) if em.get("Date") else None
            text = re.sub(r"<[^>]+>", " ", body.decode("utf-8", "replace"))
            text = html.unescape(re.sub(r"=\r?\n", "", text))
            out.append({"thr": thr, "subject": subj, "from": frm, "date": iso(date), "text": re.sub(r"\s+", " ", text)[:1500],
                        "msgid": em.get("Message-ID", "")})
        return out
    todo, pays = [], []
    for rule in c.get("todo_rules", []):
        for m in search(rule["query"], rule.get("limit", 10)):
            tid = "gm:" + m["thr"]
            todo.append({"id": tid, "kind": "email", "state": rule.get("state", "warn"),
                         "title": rule.get("title") or m["subject"][:80], "text": m["subject"] if rule.get("title") else m["text"][:180],
                         "from": m["from"], "date": m["date"], "reply": rule.get("reply", False),
                         "msgid": m["msgid"], "subject": m["subject"], "project": rule.get("project")})
    selfre = [re.compile(s, re.I) for s in c.get("exclude_self", [])]
    for p in c.get("payment_rules", []):
        for m in search(p["query"], 40):
            blob = m["subject"] + " " + m["text"]
            if any(r.search(blob) for r in selfre):
                continue
            am = re.search(p.get("amount_regex", r"(\d{1,3}(?:[.\s]\d{3})*(?:,\d{2})|\d+(?:[.,]\d{2}))\s?(?:€|EUR)"), blob)
            val = None
            if am:
                s = am.group(1).replace(" ", "")
                s = s.replace(".", "").replace(",", ".") if "," in s else s
                try: val = float(s)
                except Exception: val = None
            pays.append({"id": "pay:" + m["thr"], "source": p["source"], "amount": val, "date": m["date"], "subject": m["subject"][:90]})
    M.logout()
    return {"todo": todo, "payments": pays, "sources": [p["source"] for p in c.get("payment_rules", [])]}

def gmail_draft(item, text):
    c = src_cfg("gmail")
    if not c or not c.get("allow_drafts", True):
        raise RuntimeError("borradores desactivados")
    msg = email.message.EmailMessage()
    msg["From"] = c["user"]; msg["To"] = item.get("from", "")
    subj = item.get("subject", "")
    msg["Subject"] = subj if subj.lower().startswith("re:") else "Re: " + subj
    if item.get("msgid"):
        msg["In-Reply-To"] = item["msgid"]; msg["References"] = item["msgid"]
    msg["Date"] = email.utils.formatdate(localtime=True)
    msg.set_content(text)
    M = imaplib.IMAP4_SSL("imap.gmail.com"); M.login(c["user"], c["app_password"])
    box = None
    for line in M.list()[1]:
        if b"\\Drafts" in line:
            box = line.decode().split(' "/" ')[-1]; break
    M.append(box or '"[Gmail]/Drafts"', "(\\Draft)", imaplib.Time2Internaldate(time.time()), msg.as_bytes())
    M.logout()

@collector("github_inbox", 60)
def c_github_inbox():
    """Buzón para tareas en la nube que no llegan a tu red: escriben informes en un JSON de un repo privado
    de GitHub y Faro los recoge. Formato del archivo: lista de informes (mismos campos que /api/report)."""
    c = src_cfg("github_inbox")
    if not c: return None
    if c.get("url"):  # buzón público: sin token
        raw = http(c["url"] + ("&" if "?" in c["url"] else "?") + "t=%d" % time.time(), headers={"Cache-Control": "no-cache"})
    else:
        raw = http("https://api.github.com/repos/%s/contents/%s" % (c["repo"], c.get("path", "faro/reports.json")),
                   headers={"Authorization": "Bearer " + c["token"], "Accept": "application/vnd.github.raw"})
    items = json.loads(raw.decode("utf-8"))
    n = 0
    for r in items if isinstance(items, list) else [items]:
        if r.get("id") and r.get("at") != REPORTS.get(r["id"], {}).get("src_at"):
            report({"cloud": True, **r, "src_at": r.get("at")}); n += 1
    return {"imported": n}

@collector("itch", 1800)
def c_itch():
    c = src_cfg("itch")
    if not c: return None
    d = http_json("https://itch.io/api/1/%s/my-games" % c["api_key"])
    out = []
    for g in d.get("games", []):
        key = "itch:%s:views" % g["id"]
        push_history(key, g.get("views_count", 0))
        h = hist(key); week = [v for t, v in h if parse_iso(t) and parse_iso(t) > now() - dt.timedelta(days=7)]
        out.append({"title": g.get("title"), "views": g.get("views_count", 0), "downloads": g.get("downloads_count", 0),
                    "purchases": g.get("purchases_count", 0), "views_7d": (week[-1] - week[0]) if len(week) > 1 else None,
                    "earnings": sum(e.get("amount", 0) for e in g.get("earnings", []) or []) / 100 if g.get("earnings") else 0})
    return {"games": out}

@collector("freqtrade", 300)
def c_freqtrade():
    c = src_cfg("freqtrade")
    if not c: return None
    auth = "Basic " + base64.b64encode(("%s:%s" % (c["user"], c["password"])).encode()).decode()
    base = c["url"].rstrip("/")
    prof = http_json(base + "/api/v1/profit", headers={"Authorization": auth})
    st = http_json(base + "/api/v1/status", headers={"Authorization": auth})
    return {"profit_pct": prof.get("profit_all_ratio", 0) * 100, "trades": prof.get("trade_count"),
            "winrate": (prof.get("winrate") or 0) * 100, "open": len(st) if isinstance(st, list) else 0,
            "first": prof.get("first_trade_humanized")}

@collector("prices", 900)
def c_prices():
    c = src_cfg("prices")
    if not c: return None
    items = []
    cg = [w for w in c.get("watch", []) if w.get("kind") == "crypto"]
    if cg:
        ids = ",".join(w["id"] for w in cg)
        d = http_json("https://api.coingecko.com/api/v3/simple/price?ids=%s&vs_currencies=eur&include_24hr_change=true" % ids)
        for w in cg:
            v = d.get(w["id"], {})
            if "eur" in v:
                items.append({**w, "price": v["eur"], "chg24": v.get("eur_24h_change"), "unit": "€"})
    for w in [w for w in c.get("watch", []) if w.get("kind") == "stooq"]:
        try:
            row = http("https://stooq.com/q/l/?s=%s&f=sd2t2ohlcv&h&e=csv" % w["id"]).decode().splitlines()[1].split(",")
            close, opn = float(row[6]), float(row[3])
            items.append({**w, "price": close, "chg24": (close / opn - 1) * 100 if opn else None, "unit": w.get("unit", "")})
        except Exception as e:
            items.append({**w, "price": None, "error": str(e)[:80]})
    for it in items:
        if it.get("price") is None: continue
        key = "px:" + it["id"]; push_history(key, it["price"])
        h = [v for t, v in hist(key) if parse_iso(t) and parse_iso(t) > now() - dt.timedelta(days=30)]
        it["spark"] = [round(v, 6) for v in h[-48:]]
        if len(h) >= 24:
            avg = sum(h) / len(h); it["vs30"] = (it["price"] / avg - 1) * 100
        lo, hi = it.get("alert_below"), it.get("alert_above")
        it["alert"] = (lo is not None and it["price"] <= lo) or (hi is not None and it["price"] >= hi)
    return {"items": items}

TICKS = jload("ticks.json", {})

@collector("ticks", 30)
def c_ticks():
    """Cotizaciones casi en tiempo real (cripto, cada 30 s) para las gráficas en vivo."""
    c = src_cfg("prices")
    if not c: return None
    cg = [w for w in c.get("watch", []) if w.get("kind") == "crypto"]
    if not cg: return None
    d = http_json("https://api.coingecko.com/api/v3/simple/price?ids=%s&vs_currencies=eur" % ",".join(w["id"] for w in cg), timeout=10)
    t = int(time.time())
    with LOCK:
        for w in cg:
            v = d.get(w["id"], {}).get("eur")
            if v is None: continue
            arr = TICKS.setdefault(w["id"], {"name": w.get("name", w["id"]), "unit": "€", "points": []})["points"]
            arr.append([t, v]); del arr[:-480]  # unas 4 horas a 30 s
        if t % 300 < 30: jsave("ticks.json", TICKS)
    return {"n": len(cg)}

@collector("electricity", 3600)
def c_electricity():
    c = src_cfg("electricity")
    if not c: return None
    today = now().date()
    url = ("https://apidatos.ree.es/es/datos/mercados/precios-mercados-tiempo-real?start_date=%sT00:00&end_date=%sT23:59&time_trunc=hour"
           % (today, today))
    d = http_json(url)
    vals = []
    for inc in d.get("included", []):
        if "PVPC" in inc.get("attributes", {}).get("title", "") or inc.get("type") == "PVPC (€/MWh)":
            vals = inc["attributes"]["values"]; break
    if not vals: return {"error": "sin PVPC hoy"}
    pts = [(parse_iso(v["datetime"]), v["value"] / 1000) for v in vals]
    cur = next((p for t, p in pts if t and t.hour == now().hour), pts[-1][1])
    cheap = sorted(pts, key=lambda x: x[1])[:3]
    avg = sum(p for _, p in pts) / len(pts)
    push_history("pvpc:avg", round(avg, 4))
    return {"now": round(cur, 4), "avg": round(avg, 4), "cheap": [t.strftime("%H:%M") for t, _ in sorted(cheap)],
            "hours": [round(p, 4) for _, p in pts], "kwh_month": c.get("kwh_month")}

@collector("news", 1800)
def c_news():
    c = src_cfg("news")
    if not c: return None
    topics = c.get("topics", {})
    items = []
    for feed in c.get("feeds", []):
        try:
            root = ET.fromstring(http(feed["url"], timeout=15))
        except Exception as e:
            log("news", feed["url"], e); continue
        ns = {"a": "http://www.w3.org/2005/Atom"}
        entries = root.findall(".//item") or root.findall(".//a:entry", ns)
        for e in entries[:30]:
            g = lambda tag: (e.findtext(tag) or e.findtext("a:" + tag, namespaces=ns) or "").strip()
            title = html.unescape(re.sub(r"<[^>]+>", "", g("title")))
            link = g("link") or (e.find("a:link", ns).get("href") if e.find("a:link", ns) is not None else "")
            summ = html.unescape(re.sub(r"<[^>]+>", " ", g("description") or g("summary")))[:400]
            date = None
            for tag in ("pubDate", "published", "updated"):
                if g(tag):
                    try: date = email.utils.parsedate_to_datetime(g(tag))
                    except Exception: date = parse_iso(g(tag))
                    if date: break
            if date and date < now() - dt.timedelta(days=c.get("max_age_days", 3)):
                continue
            blob = (title + " " + summ).lower()
            score, hits = 0, []
            if feed.get("topic"):
                score += topics.get(feed["topic"], {}).get("weight", 1); hits.append(feed["topic"])
            for topic, spec in topics.items():
                for kw in spec["keywords"]:
                    if kw.lower() in blob:
                        score += spec.get("weight", 1); hits.append(topic); break
            if score <= 0: continue
            nid = "n:" + str(abs(hash(link or title)) % 10**12)
            if nid in STATE["news_hidden"]: continue
            items.append({"id": nid, "title": title, "link": link, "summary": re.sub(r"\s+", " ", summ).strip(),
                          "source": feed.get("name", ""), "date": iso(date), "score": score, "topics": sorted(set(hits))})
    seen, uniq = set(), []
    for it in sorted(items, key=lambda x: (x["score"], x["date"] or ""), reverse=True):
        k = re.sub(r"\W+", "", it["title"].lower())[:60]
        if k in seen: continue
        seen.add(k); uniq.append(it)
    capped, per = [], {}
    for it in uniq:
        main = it["topics"][0] if it["topics"] else ""
        cap = topics.get(main, {}).get("max")
        if cap is not None and per.get(main, 0) >= cap: continue
        per[main] = per.get(main, 0) + 1; capped.append(it)
    uniq = capped[: c.get("max_items", 12)]
    oc = CFG.get("ollama")
    if oc and oc.get("enabled") and uniq:
        prev = CACHE.get("news", {}).get("items", [])
        known = {p["id"]: p.get("why") for p in prev if p.get("why")}
        for it in uniq[:5]:
            if it["id"] in known: it["why"] = known[it["id"]]; continue
            try:
                it["why"] = ollama("En una frase de máximo 20 palabras, en español, di por qué esta noticia le importa a alguien "
                                   "con estos intereses: %s.\nNoticia: %s. %s" % (", ".join(topics), it["title"], it["summary"][:300]))
            except Exception as e:
                log("ollama", e); break
    return {"items": uniq}

# ───────── bóveda de Obsidian, skills, buzón, artefactos y orgullo ─────────
SUGG = jload("suggestions.json", None)
ARTS = jload("artifacts.json", [])
PROUD = jload("proud.json", [])
EVENTS = []
MSGS = jload("chat.json", [])

def say(frm, to, text, kind="msg"):
    """Registro de mensajes reales del sistema: sugerencias, respuestas, encargos, entregas y lo que los agentes se dicen por informe."""
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    if not text or not frm: return
    with LOCK:
        MSGS.append({"id": "m:" + uuid.uuid4().hex[:8], "from": str(frm)[:40], "to": str(to or "Nawe")[:40], "text": text[:280], "kind": kind, "at": iso(now())})
        del MSGS[:-150]; jsave("chat.json", MSGS)

def ex_label(k): return CFG.get("executors", {}).get(k, {}).get("label", k or "?")

def expand(p):
    return os.path.abspath(os.path.expanduser(p)) if p else None

@collector("vault", 120)
def c_vault():
    v = CFG.get("vault") or {}
    root = expand(v.get("path"))
    if not root or not os.path.isdir(root): return None
    notes = []
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if not d.startswith(".")]
        for fn in fns:
            if fn.endswith(".md"):
                fp = os.path.join(dp, fn)
                try: notes.append((os.path.getmtime(fp), os.path.relpath(fp, root)[:-3]))
                except OSError: pass
        if len(notes) > 5000: break
    notes.sort(reverse=True)
    return {"total": len(notes), "recent": [{"title": os.path.basename(n), "path": n, "mtime": iso(dt.datetime.fromtimestamp(m).astimezone())} for m, n in notes[:24]]}

def vault_write():
    """Vuelca a la bóveda un parte diario y cada orden terminada (solo si vault.write está activo)."""
    v = CFG.get("vault") or {}
    root = expand(v.get("path"))
    if not v.get("write") or not root or not os.path.isdir(root): return
    base = os.path.join(root, v.get("folder", "Faro"))
    os.makedirs(os.path.join(base, "Órdenes"), exist_ok=True)
    t = now(); S = STATUS
    lines = ["# Faro · %s" % t.strftime("%d/%m/%Y"), "", "Actualizado: %s" % t.strftime("%H:%M"), "",
             "## Te toca"] + ["- %s" % x["title"] for x in S.get("todo", [])[:15]] + ["", "## Órdenes de hoy"]
    for o in ORDERS:
        if (o.get("created") or "").startswith(t.strftime("%Y-%m-%d")):
            lines.append("- [%s] %s → %s" % ("x" if o["state"] == "done" else " ", o["title"], o["executor"]))
    lines += ["", "## Buzón de sugerencias"] + ["- %s (de %s)" % (x["text"], x["from"]) for x in (SUGG or []) if x["state"] == "open"]
    with open(os.path.join(base, "Estado %s.md" % t.strftime("%Y-%m-%d")), "w", encoding="utf-8") as f: f.write("\n".join(lines) + "\n")
    for o in ORDERS:
        if o["state"] == "done" and not o.get("vaulted") and o.get("result"):
            name = re.sub(r'[\\/:*?"<>|]', "", o["title"])[:60].strip() or o["id"]
            fn = os.path.join(base, "Órdenes", "%s %s.md" % ((o.get("finished") or "")[:10], name))
            with open(fn, "w", encoding="utf-8") as f:
                f.write("# %s\n\n- Pedida: %s\n- Hecha por: %s\n- Proyecto: %s\n\n## Orden\n%s\n\n## Resultado\n%s\n"
                        % (o["title"], o["created"], o["executor"], o.get("project") or "-", o["text"], o["result"]))
            o["vaulted"] = True
    save_orders()

@collector("skills", 900)
def c_skills():
    out = []
    for d in CFG.get("skills_dirs", []):
        root = expand(d)
        if not root or not os.path.isdir(root): continue
        src = "Hermes" if ".hermes" in root else "Claude" if ".claude" in root else os.path.basename(root)
        for dp, dns, fns in os.walk(root):
            if "SKILL.md" in fns:
                out.append({"name": os.path.basename(dp), "src": src}); dns[:] = []
    return {"items": sorted(out, key=lambda x: x["name"])[:80]}

def suggestions():
    global SUGG
    if SUGG is None:
        SUGG = [{"id": "s:" + uuid.uuid4().hex[:6], "state": "open", "at": iso(now()), **x} for x in CFG.get("seed_suggestions", [])]
        jsave("suggestions.json", SUGG)
    return SUGG

def suggestion_add(body):
    if not body.get("text"): return {"ok": False, "error": "falta text"}
    s = {"id": "s:" + uuid.uuid4().hex[:6], "from": body.get("from", "?"), "text": body["text"][:200], "why": body.get("why", "")[:300],
         "short": (body.get("short") or "")[:30], "imp": body.get("imp", 2), "ret": body.get("ret", 2), "cost": body.get("cost", 2), "state": "open", "at": iso(now())}
    with LOCK: suggestions().append(s); jsave("suggestions.json", SUGG)
    say(s["from"], "Nawe", s["short"] or s["text"], "buzon")
    build_status(); return {"ok": True, "suggestion": s}

DELEGATE_TXT = ("Nawe te pide que hagas tú esta sugerencia hasta donde puedas sin él: «%s»%s. "
    "Avanza todo lo que no le necesite. No introduzcas contraseñas, tokens ni datos de pago, no envíes mensajes en su nombre, "
    "no muevas dinero y no tomes decisiones irreversibles: deja esos pasos preparados y avísale en Faro como algo que le toca, "
    "con una línea de qué falta y por qué. Informa del avance con tu informe habitual.")

def suggestion_action(sid, typ, text=None):
    if typ in ("reply", "delegate"):
        x = next((s for s in suggestions() if s["id"] == sid), None)
        if not x or (typ == "reply" and not (text or "").strip()): return {"ok": False, "error": "falta la respuesta"}
        frm = (x.get("from") or "").lower()
        ex_ = "claude" if "claude" in frm else "codex" if re.search("codex|gpt", frm) else "hermes" if "hermes" in frm else "local" if "strata" in frm else None
        short = (x.get("short") or x["text"])[:40]
        with LOCK:
            if typ == "reply": x.setdefault("replies", []).append({"at": iso(now()), "text": text.strip()[:2000]}); x["state"] = "answered"
            else: x["state"] = "delegated"; x["delegated_at"] = iso(now())
            jsave("suggestions.json", SUGG)
        say("Nawe", x.get("from") or ex_label(ex_), text.strip() if typ == "reply" else "Hacedlo vosotros: " + short, "respuesta" if typ == "reply" else "encargo")
        if typ == "reply":
            r = new_order("Nawe responde a tu sugerencia «%s»: %s" % (x["text"], text.strip()), kind="nuevo", title="Respuesta: " + short, executor=ex_)
        else:
            extra = (". Nota de Nawe: " + text.strip()[:1000]) if (text or "").strip() else ""
            r = new_order(DELEGATE_TXT % (x["text"] + ((" (" + x["why"] + ")") if x.get("why") else ""), extra), kind="nuevo", title="Hacedlo: " + short, executor=ex_)
        build_status(); return {"ok": True, "order": r.get("order")}
    with LOCK:
        x = next((s for s in suggestions() if s["id"] == sid), None)
        if not x or typ not in ("accept", "dismiss", "done", "open"): return {"ok": False, "error": "no aplicable"}
        x["state"] = {"accept": "accepted", "dismiss": "dismissed", "done": "done", "open": "open"}[typ]; jsave("suggestions.json", SUGG)
    build_status(); return {"ok": True}

def note_event(r):
    ev = {k: r.get(k) for k in ("id", "name", "agent", "action", "skill", "project") if r.get(k)}
    ev["at"] = iso(now())
    if r.get("action") or r.get("skill"):
        EVENTS.append(ev); del EVENTS[:-100]
    if r.get("artifact"):
        a = r["artifact"] if isinstance(r["artifact"], dict) else {"name": str(r["artifact"])}
        ARTS.append({**a, "by": r.get("name") or r.get("agent"), "project": r.get("project"), "at": iso(now())}); del ARTS[:-200]; jsave("artifacts.json", ARTS)
    if r.get("proud"):
        p = r["proud"] if isinstance(r["proud"], dict) else {"title": str(r["proud"])}
        PROUD.append({**p, "by": r.get("name") or r.get("agent"), "project": r.get("project"), "at": iso(now())}); del PROUD[:-100]; jsave("proud.json", PROUD)

# ───────── capa de decisión: importancia × retorno × relevancia / coste ─────────
EXEC_COST = {"faro": 0.5, "local": 1, "hermes": 1.5, "codex": 2, "claude": 2}

def score_item(text, base=None, project=None, executor=None):
    D_ = CFG.get("decision", {})
    m = {"imp": 2, "ret": 2, "cost": 2, "rel": 2}
    if base: m.update({k: v for k, v in base.items() if k in m and v is not None})
    q = (text or "").lower()
    for rule in D_.get("rules", []):
        if any(k in q for k in rule["match"]):
            m.update({k: rule[k] for k in ("imp", "ret", "cost", "rel") if k in rule}); break
    if project: m["rel"] = D_.get("project_relevance", {}).get(project, m["rel"])
    if executor and not (base or {}).get("cost"): m["cost"] = max(m["cost"] * 0 + EXEC_COST.get(executor, 2), 0.5)
    val = m["imp"] * m["ret"] * m["rel"] / max(m["cost"], 0.5)
    hi_ret, lo_cost = m["imp"] * m["ret"] >= 6, m["cost"] <= 1.5
    quad = "hazlo" if hi_ret and lo_cost else "planifica" if hi_ret else "delega" if lo_cost else "descarta"
    return {**m, "score": round(val, 1), "quad": quad}

def infer_project(text):
    q = (text or "").lower()
    for p in CFG.get("projects", []):
        keys = [p["id"], p["name"].lower()] + [k.lower() for k in p.get("keywords", [])]
        if any(k and k in q for k in keys): return p["id"]
    return None

def build_add(pid, why):
    """La obra de cada proyecto: suma una planta cuando se entrega algo y la guarda para retomarla."""
    if not pid: return
    with LOCK:
        b = STATE.setdefault("build", {}).setdefault(pid, {"floors": 1, "log": []})
        b["floors"] = min(b["floors"] + 1, 40); b["last"] = iso(now())
        b["log"] = (b["log"] + [{"at": iso(now()), "why": why[:60]}])[-12:]
        save_state()

def build_decide(todo):
    items = []
    for x in todo:
        items.append({"kind": "toca", "id": x["id"], "title": x["title"], **score_item(x["title"] + " " + (x.get("text") or ""), x.get("metrics"), x.get("project"))})
    for o in ORDERS:
        if o["state"] in ("queued", "failed"):
            items.append({"kind": "orden", "id": o["id"], "title": o["title"], **score_item(o["text"], o.get("metrics"), o.get("project"), o["executor"])})
    for sg in suggestions():
        if sg["state"] == "open":
            items.append({"kind": "buzón", "id": sg["id"], "title": sg["text"], "from": sg["from"], **score_item(sg["text"], {"imp": sg.get("imp"), "ret": sg.get("ret"), "cost": sg.get("cost")})})
    return sorted(items, key=lambda i: -i["score"])

# ───────── detección automática de agentes en este equipo ─────────
AGENT_PATTERNS = [
    ("hermes", "Hermes · PC", "hermes", re.compile(r"(^|/|\s)hermes(\b|-agent)", re.I)),
    ("codex", "Codex", "gpt", re.compile(r"(^|/)codex(\s|$)", re.I)),
    ("claude-code", "Claude Code", "claude", re.compile(r"(^|/)claude(\s|$)", re.I)),
    ("ollama", "Strata", "local", re.compile(r"ollama (runner|serve)", re.I)),
    ("freqtrade", "freqtrade", "local", re.compile(r"freqtrade", re.I)),
]
PREV_CPU = {}

@collector("procs", 15)
def c_procs():
    if os.name == "nt" or not shutil.which("ps"): return None
    out = subprocess.run(["ps", "-eo", "pid,etimes,pcpu,args"], capture_output=True, text=True, timeout=10).stdout.splitlines()[1:]
    found = {}
    for line in out:
        parts = line.split(None, 3)
        if len(parts) < 4 or "faro.py" in parts[3]: continue
        pid, et, cpu, args = parts
        for key, name, brand, rx in AGENT_PATTERNS:
            if rx.search(args):
                f = found.setdefault(key, {"name": name, "brand": brand, "cpu": 0.0, "n": 0, "since": int(et)})
                f["cpu"] += float(cpu); f["n"] += 1; f["since"] = max(f["since"], int(et))
    # modelos cargados en Ollama = Strata pensando de verdad
    loaded = []
    try:
        loaded = [m.get("name") for m in http_json("http://127.0.0.1:11434/api/ps", timeout=2).get("models", [])]
    except Exception:
        pass
    agents = []
    for key, f in found.items():
        busy = f["cpu"] >= 8 or (key == "ollama" and loaded)
        task = ("usando %s" % ", ".join(loaded)) if key == "ollama" and loaded else ("trabajando · CPU %d%%" % f["cpu"] if busy else "en marcha, sin carga")
        agents.append({"name": f["name"], "brand": f["brand"], "state": "run" if busy else "ok", "task": task, "auto": True})
    return {"agents": agents}

# ───────── Codex: lee su registro de sesiones (~/.codex/sessions) ─────────
CODEX_ACT = [("apply_patch", "code", "edita código"), ("web_search", "web", "busca en la web"), ("update_plan", "think", "planifica"),
             ("shell", "system", "ejecuta comandos"), ("exec_command", "system", "ejecuta comandos"), ("read_file", "obsidian", "lee archivos")]

def codex_state(root, name, active_secs=120):
    """Devuelve el estado del agente Codex a partir de su rollout más reciente (formato JSONL; se lee de forma tolerante)."""
    root = expand(root)
    if not root or not os.path.isdir(root): return None
    newest = None
    for dp, dns, fns in os.walk(root):
        for fn in fns:
            if fn.endswith(".jsonl"):
                fp = os.path.join(dp, fn); m = os.path.getmtime(fp)
                if not newest or m > newest[0]: newest = (m, fp)
    if not newest: return None
    age = time.time() - newest[0]
    with open(newest[1], "rb") as f:
        f.seek(0, 2); size = f.tell(); f.seek(max(0, size - 60000)); tail = f.read().decode("utf-8", "replace").splitlines()
        f.seek(0); head = f.read(40000).decode("utf-8", "replace").splitlines()
    task, action, label = "", None, ""
    for ln in head:
        try: j = json.loads(ln)
        except Exception: continue
        blob = json.dumps(j, ensure_ascii=False)
        if '"role": "user"' in blob or '"type": "user_message"' in blob:
            m = re.search(r'"(?:text|message)": "((?:[^"\\]|\\.){8,})"', blob)
            if m and not m.group(1).startswith("<"): task = json.loads('"%s"' % m.group(1))[:70]; break
    for ln in reversed(tail[-80:]):
        hit = next(((a, l) for k, a, l in CODEX_ACT if '"%s"' % k in ln), None)
        if hit: action, label = hit; break
    busy = age < active_secs
    return {"name": name, "brand": "gpt", "state": "run" if busy else "ok", "action": action if busy else None,
            "task": ((label + " · ") if busy and label else "") + (task or ("activo" if busy else "sin actividad reciente"))}

@collector("codex", 20)
def c_codex():
    st = codex_state(CFG.get("codex_sessions", "~/.codex/sessions"), "Codex · PC")
    return {"agents": [st]} if st else None

# ───────── Codex en la nube y otros: actividad en GitHub (repos públicos, sin token) ─────────
@collector("github_activity", 300)
def c_github_activity():
    c = src_cfg("github_activity")
    if not c: return None
    agents = []
    for repo in c.get("repos", []):
        evs = http_json("https://api.github.com/repos/%s/events?per_page=20" % repo, timeout=15)
        for e in evs:
            t = parse_iso(e.get("created_at"))
            if not t or (now() - t).total_seconds() > c.get("window_min", 45) * 60: continue
            actor = (e.get("actor") or {}).get("login", "")
            who = "Codex · nube" if re.search(r"codex|openai|chatgpt", actor + json.dumps(e.get("payload", {}))[:2000], re.I) else None
            if who and not any(a["name"] == who for a in agents):
                kind = {"PushEvent": "sube código", "PullRequestEvent": "abre una pull request", "CreateEvent": "crea una rama"}.get(e["type"], "trabaja")
                agents.append({"name": who, "brand": "gpt", "state": "run", "action": "code", "cloud": True, "project": c.get("project"),
                               "task": "%s en %s" % (kind, repo.split("/")[-1])})
    return {"agents": agents}

# ───────── autoactualización desde el buzón público de GitHub ─────────
import hashlib, tarfile, tempfile
UPD = {"checked": None, "latest": None, "error": None}

def self_update(force=False):
    c = CFG.get("update") or {}
    if not c.get("enabled", True) and not force: return None
    base = c.get("url", "https://raw.githubusercontent.com/Nawebaz/CHF_GAME/faro-buzon/release/")
    meta = json.loads(http(base + "VERSION.json?t=%d" % time.time(), headers={"Cache-Control": "no-cache"}, timeout=15))
    UPD["checked"], UPD["latest"] = iso(now()), meta.get("version")
    if meta.get("version") == VERSION: return {"updated": False, "version": VERSION}
    blob = http(base + meta["file"] + "?t=%d" % time.time(), timeout=60)
    if hashlib.sha256(blob).hexdigest() != meta.get("sha256"): raise RuntimeError("la descarga no coincide con su firma")
    tmp = tempfile.mkdtemp(prefix="faro-upd-")
    with tarfile.open(fileobj=__import__("io").BytesIO(blob), mode="r:gz") as tf:
        for m in tf.getmembers():
            if m.name.startswith("/") or ".." in m.name: raise RuntimeError("ruta no válida en el paquete")
        tf.extractall(tmp)
    src = os.path.join(tmp, "faro")
    for dp, dns, fns in os.walk(src):
        rel = os.path.relpath(dp, src)
        if rel.split(os.sep)[0] in ("data",): continue
        os.makedirs(os.path.join(ROOT, rel), exist_ok=True)
        for fn in fns:
            if fn == "config.json" or fn.endswith(".pyc"): continue
            shutil.copy2(os.path.join(dp, fn), os.path.join(ROOT, rel, fn))
    for sh in ("abrir.sh", "actualizar.sh", "linux/install.sh", "tools/faro-report.sh"):
        try: os.chmod(os.path.join(ROOT, sh), 0o755)
        except OSError: pass
    log("actualizado de", VERSION, "a", meta["version"], "· reiniciando")
    def restart():
        time.sleep(1.5); os.execv(sys.executable, [sys.executable] + sys.argv)
    threading.Thread(target=restart, daemon=True).start()
    return {"updated": True, "version": meta["version"]}

@collector("selfupdate", 600)
def c_selfupdate():
    try:
        return self_update()
    except Exception as e:
        UPD["error"] = str(e)[:120]; raise

@collector("costs", 3600)
def c_costs():
    rec = CFG.get("recurring", [])
    if not rec: return None
    el = CACHE.get("electricity", {})
    items = []
    for r in rec:
        v = r.get("eur_month")
        if r.get("electricity") and el.get("avg") and el.get("kwh_month"):
            v = round(el["avg"] * el["kwh_month"] + r.get("fixed_eur", 0), 2)
        items.append({"name": r["name"], "eur_month": v})
    return {"items": items, "total": round(sum(i["eur_month"] or 0 for i in items), 2)}

def ollama(prompt, system=None, fmt=None):
    oc = CFG.get("ollama", {})
    body = {"model": oc.get("model", "qwen2.5:7b"), "prompt": prompt, "stream": False,
            "keep_alive": oc.get("keep_alive", "2m"), "options": {"temperature": 0.2, "num_predict": 200}}
    if system: body["system"] = system
    if fmt: body["format"] = fmt
    d = http_json(oc.get("url", "http://127.0.0.1:11434").rstrip("/") + "/api/generate", data=body, timeout=90)
    return d.get("response", "").strip()

def run_collectors(force=False):
    for name, c in COLLECTORS.items():
        if not force and time.time() - c["last"] < c["every"]:
            continue
        c["last"] = time.time()
        try:
            out = c["fn"]()
            if out is not None:
                CACHE[name] = out
            c["error"] = None
        except Exception as e:
            c["error"] = str(e)[:160]
            log("collector", name, "ERROR", e)
    build_status()

# ───────────────────────── composición del estado ─────────────────────────
ORDER = {"bad": 0, "warn": 1, "run": 2, "ok": 3, "off": 4}
STATUS = {}

def build_status():
    t = now()
    projects = {p["id"]: {**p, "jobs": list(p.get("jobs", [])), "figs": [dict(f) for f in p.get("figs", [])]} for p in CFG.get("projects", [])}
    def proj(pid):
        return projects.setdefault(pid, {"id": pid, "name": pid, "figs": [], "jobs": []})
    for j in CACHE.get("scheduled", {}).get("jobs", []):
        proj(j["project"])["jobs"].append(j)
    running, agents, todo = [], [], []
    for rid, r in list(REPORTS.items()):
        age = (t - (parse_iso(r.get("at")) or t)).total_seconds()
        ttl = r.get("ttl", 3600)
        kind = r.get("kind", "job")
        if kind == "run":
            if r.get("pct", 0) >= 100 or age > ttl * 3:
                continue
            running.append({**r, "id": rid, "stale": age > ttl})
        elif kind == "agent":
            st = r.get("state", "ok") if age <= ttl else "off"
            agents.append({**r, "state": st, "task": r.get("task", "") if age <= ttl else "sin noticias " + rel_es(age)})
        elif kind == "todo":
            todo.append({**r, "id": rid})
        elif kind == "job" and not any(s.get("id") == rid for s in CFG.get("scheduled", [])):
            st = r.get("state", "ok")
            if age > ttl and st == "ok": st, note = "warn", "Sin noticias " + rel_es(age)
            else: note = r.get("note")
            proj(r.get("project", "otros"))["jobs"].append({**r, "state": st, "note": note})
    # agentes detectados solos (procesos del PC) y tareas programadas en su ventana de ejecución
    named = {a.get("name") for a in agents}
    extra = (CACHE.get("codex") or {}).get("agents", []) + (CACHE.get("github_activity") or {}).get("agents", [])
    for a in extra:
        if a["name"] not in named: agents.append(a); named.add(a["name"])
    for a in (CACHE.get("procs") or {}).get("agents", []):
        if a["name"] not in named and not (a["name"] == "Codex" and "Codex · PC" in named): agents.append(a)
    for sj in CFG.get("scheduled", []):
        if not sj.get("cron") or sj.get("enabled") is False: continue
        prev = cron_next(sj["cron"], t - dt.timedelta(minutes=sj.get("minutes", 20)))
        nm = sj.get("agent", "Claude · " + sj["name"][:18])
        if prev and prev <= t:
            agents.append({"name": nm, "brand": "claude", "state": "run", "task": sj["name"] + " (estimado)", "project": sj["project"], "estimated": True, "cloud": True})
        else:
            nxt = cron_next(sj["cron"], t)
            agents.append({"name": nm, "brand": "claude", "state": "ok", "task": "próxima: " + when_es(iso(nxt)) if nxt else "en espera", "project": sj["project"], "cloud": True})
    for a in agents:
        if not a.get("project"): a["project"] = infer_project((a.get("task") or "") + " " + (a.get("name") or ""))
    # Gmail
    g = CACHE.get("gmail", {})
    todo += g.get("todo", [])
    todo += [{**x, "id": x["id"]} for x in CFG.get("static_todo", [])]
    todo = [x for x in todo if x["id"] not in STATE["dismissed"]]
    # pagos
    month = t.strftime("%Y-%m")
    pays = [p for p in g.get("payments", []) if (p.get("date") or "").startswith(month)]
    paid = round(sum(p["amount"] or 0 for p in pays), 2)
    if "pagos" in projects:
        P = projects["pagos"]
        srcs = g.get("sources", [])
        for s in srcs:
            got = [p for p in g.get("payments", []) if p["source"] == s]
            P["jobs"].append({"name": s, "where": "Gmail", "state": "ok" if got else "off",
                              "note": ("%d avisos; último %s" % (len(got), got[0]["date"][:10])) if got else "Aún sin avisos de cobro."})
        for f in P["figs"]:
            if f.get("bind") == "paid_month": f["value"] = paid if g else None
            if f.get("bind") == "sources_active": f["value"] = sum(1 for j in P["jobs"] if j["state"] == "ok"); f["of"] = str(len(srcs))
    # binds de cifras genéricas
    itch = (CACHE.get("itch", {}).get("games") or [{}])[0]
    ft = CACHE.get("freqtrade", {})
    binds = {"itch_views_7d": itch.get("views_7d"), "itch_views": itch.get("views"), "itch_earnings": itch.get("earnings"),
             "ft_profit": round(ft["profit_pct"], 1) if ft else None, "ft_trades": ft.get("trades"),
             "paid_month": paid if g else None, "agents_busy": len(running) + sum(1 for o in ORDERS if o["state"] == "running"),
             "todo_count": len(todo), "itch_downloads": itch.get("downloads"),
             "orders_queued": sum(1 for o in ORDERS if o["state"] == "queued")}
    for p in projects.values():
        for f in p["figs"]:
            if f.get("bind") == "next_in_project":
                nx = sorted([j["next"] for j in p["jobs"] if j.get("next")])
                f["value"] = nx[0] if nx else None; f["kind"] = "when"
            elif f.get("bind") in binds and f.get("bind") not in ("sources_active",):
                f["value"] = binds[f["bind"]]
        q = p.get("quiet_until_data")
        p["quiet"] = bool(q) and not binds.get(q)
    # errores de recolectores como avisos
    for name, c in COLLECTORS.items():
        if c["error"] and src_cfg(name):
            todo.append({"id": "err:" + name + ":" + t.strftime("%Y%m%d"), "kind": "task", "state": "warn",
                         "title": "Falla la fuente «%s»" % name, "text": c["error"], "reply": False})
            todo = [x for x in todo if x["id"] not in STATE["dismissed"]]
    for p in projects.values():
        if not p["jobs"]:
            p["jobs"].append({"name": "Sin fuentes conectadas", "where": "-", "state": "off"})
    # racha sin rojos
    day = t.strftime("%Y-%m-%d")
    reds = any(x["state"] == "bad" for x in todo) or any(j["state"] == "bad" for p in projects.values() for j in p["jobs"])
    STATE["red_days"][day] = STATE["red_days"].get(day, False) or reds
    streak, d = 0, t.date()
    while True:
        k = d.strftime("%Y-%m-%d")
        if k not in STATE["red_days"] or STATE["red_days"][k]: break
        streak += 1; d -= dt.timedelta(days=1)
    radar = {"news": CACHE.get("news", {}).get("items", []), "prices": CACHE.get("prices", {}).get("items", []),
             "electricity": CACHE.get("electricity"), "costs": CACHE.get("costs"), "income_month": paid if g else None,
             "income_goal": CFG.get("income_goal_month"),
             "topics": {k: {"label": v.get("label", k), "color": v.get("color")} for k, v in (CFG.get("sources", {}).get("news", {}).get("topics") or {}).items()},
             "benchmark": {"name": CFG.get("investing", {}).get("benchmark_name", "tu referencia"), "rate": CFG.get("investing", {}).get("benchmark_rate_pct", 3)}}
    with LOCK:
        STATUS.clear()
        STATUS.update({"generated": iso(t), "server": True, "version": VERSION, "owner": CFG.get("owner", ""), "streak": streak,
                       "todo": todo, "agents": agents, "running": running, "projects": list(projects.values()), "radar": radar,
                       "game": {"xp": STATE["xp"], "done": STATE["done"], "dismissed": STATE["dismissed"]},
                       "orders": [x for x in ORDERS if not x.get("archived")][-30:], "build": STATE.get("build", {}), "chat": MSGS[-40:],
                       "decide": build_decide(todo)[:12],
                       "vault": {**(CACHE.get("vault") or {}), "consulting": [e.get("name") or e.get("agent") for e in EVENTS[-20:]
                                 if e.get("action") == "obsidian" and (t - parse_iso(e["at"])).total_seconds() < 120]},
                       "skills": (CACHE.get("skills") or {}).get("items", []), "events": EVENTS[-30:],
                       "artifacts": ARTS[-40:], "proud": PROUD[-20:], "suggestions": suggestions(),
                       "executors": {k: {"ok": executor_ok(k), "label": v.get("label", k), "color": v.get("color"),
                                         "good_for": v.get("good_for", "")} for k, v in CFG.get("executors", {}).items()},
                       "income": {"month": paid if g else None, "goal": CFG.get("income_goal_month"), "count": len(pays)},
                       "sources": {n: {"ok": not c["error"], "error": c["error"], "enabled": bool(src_cfg(n)) or n in ("scheduled", "costs")}
                                   for n, c in COLLECTORS.items()}})
        jsave("status.json", STATUS)
    alerts(todo, radar)

def rel_es(sec):
    sec = int(sec)
    return "hace %d min" % (sec // 60) if sec < 3600 else "hace %d h" % (sec // 3600) if sec < 86400 else "hace %d d" % (sec // 86400)

# ───────────────────────── avisos (Telegram) ─────────────────────────
def telegram(text):
    c = CFG.get("telegram") or {}
    if not c.get("enabled") or not c.get("token"): return
    http("https://api.telegram.org/bot%s/sendMessage" % c["token"], data={"chat_id": c["chat_id"], "text": text}, timeout=10)

def alerts(todo, radar):
    sent = STATE["alerts_sent"]; new = []
    for x in todo:
        if x["state"] in ("bad", "warn") and x["id"] not in sent:
            new.append(("🔴 " if x["state"] == "bad" else "🟠 ") + x["title"]); sent[x["id"]] = iso(now())
    for p in radar.get("prices") or []:
        k = "px:%s:%s" % (p["id"], now().strftime("%Y%m%d"))
        if p.get("alert") and k not in sent:
            new.append("📈 %s en %s %s" % (p.get("name", p["id"]), p["price"], p.get("unit", ""))); sent[k] = iso(now())
    if new:
        try: telegram("Faro\n" + "\n".join(new[:8]))
        except Exception as e: log("telegram", e)
        save_state()

# ───────────────────────── voz (manos libres) ─────────────────────────
NUM = {"primero": 0, "primera": 0, "segundo": 1, "segunda": 1, "tercero": 2, "tercera": 2, "uno": 0, "dos": 1, "tres": 2, "1": 0, "2": 1, "3": 2}

def voice(text):
    """Recibe lo dictado y devuelve una respuesta corta para leer en voz alta. Primero reglas (coste cero);
    si no encaja ninguna y Ollama está activo, el modelo local elige la acción."""
    q = text.lower().strip()
    S = STATUS
    todo = sorted(S.get("todo", []), key=lambda x: ORDER.get(x["state"], 9))
    def summary():
        bad = sum(1 for x in todo if x["state"] == "bad")
        parts = []
        parts.append("Tienes %d cosa%s pendiente%s" % (len(todo), "" if len(todo) == 1 else "s", "" if len(todo) == 1 else "s") if todo else "No tienes nada pendiente")
        if bad: parts.append("%d urgente%s" % (bad, "" if bad == 1 else "s"))
        if S.get("running"): parts.append("%d trabajo%s en marcha" % (len(S["running"]), "" if len(S["running"]) == 1 else "s"))
        nx = next_job()
        if nx: parts.append("lo próximo es %s, %s" % (nx["name"], when_es(nx["next"])))
        return ". ".join(p[0].upper() + p[1:] for p in parts) + "."
    if re.search(r"\b(resumen|estado|c[oó]mo va|qu[eé] tal|novedades)\b", q):
        return summary()
    if re.search(r"(qu[eé] me toca|pendiente|lista)", q):
        if not todo: return "Nada pendiente."
        return "Te toca: " + "; ".join("%d, %s" % (i + 1, x["title"]) for i, x in enumerate(todo[:3])) + "."
    m = re.search(r"(descarta|hecho|listo|marca)\D*(primero|primera|segundo|segunda|tercero|tercera|uno|dos|tres|\d)", q)
    if m and todo:
        i = NUM.get(m.group(2), 0)
        if i >= len(todo): return "Solo hay %d." % len(todo)
        x = todo[i]; action("dismiss" if m.group(1) == "descarta" else "done", x["id"])
        return ("Descartado: " if m.group(1) == "descarta" else "Hecho: ") + x["title"] + "."
    m = re.search(r"(contesta|responde)\w*\s+(?:al?\s+)?(primero|primera|segundo|segunda|tercero|tercera|uno|dos|tres|\d)?[^:,]*[:,]?\s*(.*)", q)
    if m and todo:
        cand = [x for x in todo if x.get("reply")]
        i = NUM.get(m.group(2) or "primero", 0)
        if not cand: return "Ningún aviso necesita respuesta."
        x = cand[min(i, len(cand) - 1)]
        body = text[text.lower().find(m.group(3)):] if m.group(3) else ""
        if len(body) < 5: return "Dime el texto después de dos puntos. Por ejemplo: contesta al primero, gracias, os llamo el lunes."
        r = action("draft_reply", x["id"], body)
        return "Borrador guardado para %s. No se ha enviado." % x["title"] if r.get("ok") else "No pude guardar el borrador: " + r.get("error", "")
    if re.search(r"(luz|electricidad)", q):
        e = (S.get("radar") or {}).get("electricity")
        if not e or not e.get("now"): return "No tengo el precio de la luz ahora."
        return "La luz está a %s céntimos el kilovatio. Las horas más baratas de hoy son %s." % (fmt_num(e["now"] * 100, 1), ", ".join(e["cheap"]))
    m = re.search(r"(precio|cu[aá]nto (?:vale|est[aá]))\s+(?:de[l]?\s+|el\s+|la\s+)?(.+)", q)
    if m:
        name = m.group(2).strip(" ?.")
        for p in (S.get("radar") or {}).get("prices", []):
            if name in (p.get("name", "") + " " + p["id"]).lower():
                ch = p.get("chg24")
                return "%s está en %s %s%s." % (p.get("name", p["id"]), fmt_num(p["price"]), p.get("unit", ""),
                                               (", %s %s%% en 24 horas" % ("sube" if ch >= 0 else "baja", fmt_num(abs(ch), 1))) if ch is not None else "")
        return "No sigo el precio de %s." % name
    if re.search(r"noticia", q):
        n = (S.get("radar") or {}).get("news", [])[:3]
        return ("Titulares: " + ". ".join(x["title"] for x in n) + ".") if n else "No hay noticias relevantes ahora."
    if re.search(r"(dinero|cobrado|ingres|pagos)", q):
        r = S.get("radar") or {}
        if r.get("income_month") is None: return "Aún no leo los pagos."
        return "Este mes has cobrado %s euros%s." % (fmt_num(r["income_month"]), (" de %s de objetivo" % r["income_goal"]) if r.get("income_goal") else "")
    if re.search(r"(pr[oó]xim|cu[aá]ndo)", q):
        nx = next_job()
        return "Lo próximo es %s, %s." % (nx["name"], when_es(nx["next"])) if nx else "No hay nada programado."
    oc = CFG.get("ollama", {})
    if oc.get("enabled"):
        try:
            ctx = json.dumps({"todo": [x["title"] for x in todo[:6]], "running": [r["name"] for r in S.get("running", [])],
                              "prices": [[p.get("name"), p.get("price")] for p in (S.get("radar") or {}).get("prices", [])]}, ensure_ascii=False)
            out = ollama("Contexto: %s\nPregunta del usuario (está conduciendo): %s\nResponde en español en máximo 2 frases cortas." % (ctx, text),
                         system="Eres Faro, el panel de estado de Nawe. Solo informas; no inventes datos que no estén en el contexto.")
            return out or "No te he entendido."
        except Exception as e:
            log("voice ollama", e)
    return "No te he entendido. Puedes decir: resumen, qué me toca, descarta el primero, contesta al primero, precio de bitcoin o la luz."

def fmt_num(v, d=2):
    if v is None: return "?"
    s = ("%." + str(d) + "f") % v if abs(v) < 1000 else "%d" % round(v)
    return s.replace(".", ",")

def next_job():
    t = now(); best = None
    for p in STATUS.get("projects", []):
        for j in p["jobs"]:
            n = parse_iso(j.get("next"))
            if n and n > t and (not best or n < parse_iso(best["next"])): best = j
    return best

def when_es(s):
    n = parse_iso(s); d = (n.date() - now().date()).days
    day = "hoy" if d == 0 else "mañana" if d == 1 else ["el lunes", "el martes", "el miércoles", "el jueves", "el viernes", "el sábado", "el domingo"][n.weekday()]
    return "%s a las %s" % (day, n.strftime("%H:%M"))

# ───────────────────────── acciones ─────────────────────────
def action(typ, iid=None, text=None):
    with LOCK:
        item = next((x for x in STATUS.get("todo", []) if x["id"] == iid), None)
        if typ in ("dismiss", "done", "draft_reply") and iid:
            if typ == "draft_reply":
                if not item: return {"ok": False, "error": "aviso no encontrado"}
                try:
                    gmail_draft(item, text or "")
                except Exception as e:
                    return {"ok": False, "error": str(e)[:120]}
                STATE["xp"] += CFG.get("xp", {}).get("reply", 25); STATE["done"] += 1
            elif typ == "done":
                STATE["xp"] += CFG.get("xp", {}).get("resolve", 10); STATE["done"] += 1
            STATE["dismissed"][iid] = iso(now())
        elif typ == "undismiss_all":
            STATE["dismissed"] = {}
        elif typ == "hide_news" and iid:
            STATE["news_hidden"][iid] = iso(now())
            n = CACHE.get("news", {}).get("items", [])
            CACHE.get("news", {})["items"] = [x for x in n if x["id"] != iid]
        else:
            return {"ok": False, "error": "acción desconocida"}
        save_state()
    build_status()
    return {"ok": True, "game": STATUS.get("game")}

def report(body):
    """Informe de un agente o tarea. Campos: id (obligatorio), kind (job|run|agent|todo), project, name, where,
    state (ok|run|warn|bad|off), pct, step, note, next, last, ttl (segundos sin noticias antes de avisar)."""
    rid = body.get("id")
    if not rid: return {"ok": False, "error": "falta id"}
    with LOCK:
        prev = REPORTS.get(rid, {})
        r = {**prev, **body, "at": body.get("src_at") or iso(now())}
        if r.get("kind") == "run" and "pct" in body and prev.get("pct") is not None and prev.get("at"):
            mins = (now() - parse_iso(prev["at"])).total_seconds() / 60
            if mins > 0.05 and body["pct"] >= prev["pct"]:
                inst = (body["pct"] - prev["pct"]) / mins
                r["rate"] = round(inst if not prev.get("rate") else prev["rate"] * 0.5 + inst * 0.5, 3)
        if r.get("state") == "ok" and r.get("kind", "job") == "job" and "last" not in body:
            r["last"] = r["at"]
        REPORTS[rid] = r
        jsave("reports.json", REPORTS)
        note_event(body)
    sy = body.get("say")
    if sy and sy != prev.get("say"):  # el buzón de GitHub reenvía los mismos informes: solo cuenta lo nuevo
        sy = sy if isinstance(sy, dict) else {"text": str(sy)}
        say(body.get("name") or body.get("agent") or rid, sy.get("to"), sy.get("text"), "informe")
    pj = r.get("project") or infer_project((r.get("task") or "") + " " + (r.get("name") or ""))
    if body.get("artifact") or (prev.get("state") == "run" and body.get("state") in ("ok", "done")):
        build_add(pj, body.get("task") or r.get("name") or rid)
    build_status()
    return {"ok": True}

# ───────────────────────── órdenes: reparto entre IAs ─────────────────────────
ORDERS = jload("orders.json", [])
DEMO = "--demo" in sys.argv
OQ = threading.Condition(LOCK)

def save_orders():
    with LOCK:
        del ORDERS[:-200]
        jsave("orders.json", ORDERS)

def executor_ok(name):
    e = CFG.get("executors", {}).get(name)
    if not e or not e.get("enabled", True): return False
    if e.get("type") == "cmd": return bool(shutil.which(e["cmd"][0]))
    return True

def route(text, wanted=None):
    """Decide quién ejecuta la orden y con qué prioridad. Reglas primero (coste cero); si ninguna encaja
    y hay IA local, ella clasifica; si no, el primer ejecutor disponible de la lista de reserva."""
    R = CFG.get("routing", {})
    q = " " + text.lower() + " "
    prio = "normal"
    for p, kws in R.get("priority", {}).items():
        if any(k in q for k in kws): prio = p; break
    if wanted and executor_ok(wanted):
        return {"executor": wanted, "priority": prio, "reason": "Elegido por ti"}
    missing = (" · %s no está disponible en el PC" % ex_label(wanted)) if wanted else ""
    for rule in R.get("rules", []):
        if any(k in q for k in rule["match"]):
            for i, ex in enumerate(rule["to"]):
                if executor_ok(ex):
                    why = rule.get("why", "Regla: " + rule["match"][0].strip())
                    if i: why += " (%s no disponible)" % CFG.get("executors", {}).get(rule["to"][0], {}).get("label", rule["to"][0])
                    return {"executor": ex, "priority": prio, "reason": why}
    if R.get("llm_classify") and executor_ok("local"):
        try:
            opts = [k for k in CFG.get("executors", {}) if executor_ok(k)]
            desc = {k: CFG["executors"][k].get("good_for", "") for k in opts}
            out = ollama('Elige quién debe ejecutar esta orden. Opciones: %s. Responde JSON {"executor":..., "reason": "máx 8 palabras"}.\nOrden: %s'
                         % (json.dumps(desc, ensure_ascii=False), text), fmt="json")
            d = json.loads(out)
            if d.get("executor") in opts:
                return {"executor": d["executor"], "priority": prio, "reason": "IA local: " + d.get("reason", "")[:60]}
        except Exception as e:
            log("route llm", e)
    for ex in R.get("fallback", ["faro"]):
        if executor_ok(ex):
            return {"executor": ex, "priority": prio, "reason": "Reserva" + missing}
    return {"executor": "faro", "priority": prio, "reason": "Sin ejecutores disponibles: Faro responde con sus datos" + missing}

PRIO_ORDER = {"alta": 0, "normal": 1, "baja": 2, "noche": 3}

def new_order(text, kind="orden", title=None, thread=None, executor=None):
    text = (text or "").strip()
    if not text: return {"ok": False, "error": "orden vacía"}
    r = route(text, executor)
    o = {"id": "o:" + uuid.uuid4().hex[:8], "text": text, "kind": kind, "title": title or text[:60], "project": infer_project(text),
         "thread": thread or (None if kind == "orden" else "t:" + uuid.uuid4().hex[:6]),
         "executor": r["executor"], "priority": r["priority"], "reason": r["reason"],
         "state": "queued", "created": iso(now()), "started": None, "finished": None, "result": None}
    with OQ:
        ORDERS.append(o); save_orders(); OQ.notify_all()
    if kind != "nuevo" or not title or not title.startswith(("Respuesta:", "Hacedlo:")):
        say("Nawe", ex_label(o["executor"]), o["title"], "orden")
    build_status()
    return {"ok": True, "order": o}

def thread_context(o):
    if not o.get("thread"): return ""
    prev = [x for x in ORDERS if x.get("thread") == o["thread"] and x["id"] != o["id"] and x.get("result")][-3:]
    return "".join("Antes pediste: %s\nResultado: %s\n\n" % (x["text"][:300], x["result"][:600]) for x in prev)

DEFAULT_PREAMBLE = ("Recibes esta orden de Nawe a través de Faro, su panel. Hazla de verdad y responde en español, breve: "
    "qué has hecho, dónde está el resultado y qué falta. Trabaja en la carpeta actual salvo que la orden diga otra. "
    "No escribas contraseñas ni tokens, no pagues ni muevas dinero, no envíes mensajes ni correos en su nombre (déjalos en borrador) "
    "y no hagas nada irreversible: si algo lo necesita, prepáralo y dilo en tu respuesta como pendiente para Nawe.")

def execute(o):
    name = o["executor"]
    if DEMO and name != "faro":
        time.sleep(4); return "(demo) Aquí iría la respuesta de %s." % name
    e = CFG.get("executors", {}).get(name, {})
    pre = e.get("preamble", CFG.get("preamble", DEFAULT_PREAMBLE))
    prompt = (pre + "\n\n" + thread_context(o) + o["text"]).strip()
    if name == "faro" or e.get("type") == "faro":
        return voice(o["text"])
    if e.get("type") == "ollama":
        oc = {**CFG.get("ollama", {}), **e}
        body = {"model": oc.get("model"), "prompt": prompt, "stream": False, "keep_alive": oc.get("keep_alive", "2m")}
        return http_json(oc.get("url", "http://127.0.0.1:11434").rstrip("/") + "/api/generate", data=body, timeout=e.get("timeout", 600)).get("response", "")
    if e.get("type") == "cmd":
        args = [a.replace("{prompt}", prompt) for a in e["cmd"]]
        cwd = os.path.expanduser(e.get("cwd") or CFG.get("work_dir") or "~/FaroTrabajo")  # nunca dentro de Faro
        os.makedirs(cwd, exist_ok=True)
        p = subprocess.run(args, capture_output=True, text=True, timeout=e.get("timeout", 1800), cwd=cwd,
                           input=prompt if e.get("stdin") else None)
        out = (p.stdout or "").strip()
        if p.returncode != 0:
            raise RuntimeError(((p.stderr or "") + out)[-400:] or "código %d" % p.returncode)
        return out
    raise RuntimeError("ejecutor sin tipo")

def worker(name):
    while True:
        with OQ:
            def pick():
                h = now().hour
                ready = [o for o in ORDERS if o["state"] == "queued" and o["executor"] == name
                         and (o["priority"] != "noche" or 1 <= h < 7)]
                return sorted(ready, key=lambda o: (PRIO_ORDER.get(o["priority"], 1), o["created"]))[0] if ready else None
            o = pick()
            while not o:
                OQ.wait(30); o = pick()
            o["state"] = "running"; o["started"] = iso(now()); save_orders()
        build_status()
        try:
            res = execute(o); st = "done"
        except Exception as ex:
            res = "Error: %s" % ex; st = "failed"
        with OQ:
            o["state"] = st; o["finished"] = iso(now()); o["result"] = (res or "")[-4000:]
            if st == "done": STATE["xp"] += CFG.get("xp", {}).get("order", 5); save_state(); build_add(o.get("project"), o["title"])
            save_orders()
        first = next((l.strip() for l in (res or "").splitlines() if l.strip()), "")
        say(ex_label(name), "Nawe", ("Hecho: " if st == "done" else "No he podido: ") + (first[:160] or o["title"]), "entrega" if st == "done" else "fallo")
        build_status()
        if st == "failed":
            try: telegram("Faro: falló «%s» en %s" % (o["title"], name))
            except Exception: pass

def order_action(oid, typ, executor=None):
    with OQ:
        o = next((x for x in ORDERS if x["id"] == oid), None)
        if not o: return {"ok": False, "error": "no existe"}
        if typ == "reassign" and executor and o["state"] in ("queued", "failed"):
            o["executor"] = executor; o["reason"] = "Reasignada por ti"; o["state"] = "queued"
        elif typ == "retry" and o["state"] == "failed":
            o["state"] = "queued"
        elif typ == "cancel" and o["state"] == "queued":
            o["state"] = "cancelled"
        elif typ == "archive":
            o["archived"] = True
        else:
            return {"ok": False, "error": "no aplicable"}
        save_orders(); OQ.notify_all()
    build_status()
    return {"ok": True}

# ───────────────────────── servidor HTTP ─────────────────────────
class H(BaseHTTPRequestHandler):
    server_version = "Faro/" + VERSION
    def log_message(self, *a): pass
    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)): body = json.dumps(body, ensure_ascii=False).encode()
        elif isinstance(body, str): body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype); self.send_header("Cache-Control", "no-store")
        if urllib.parse.urlparse(self.path).path == "/api/report": self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def _auth(self):
        """Red local, Tailscale (100.64.0.0/10) y el propio equipo entran sin token; desde fuera hace falta el token."""
        tok = CFG.get("token")
        if not tok: return True
        import ipaddress
        try:
            ip = ipaddress.ip_address(self.client_address[0])
            if ip.is_private or ip.is_loopback or ip in ipaddress.ip_network("100.64.0.0/10"): return True
        except Exception:
            pass
        got = self.headers.get("X-Faro-Token") or urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("token", [""])[0]
        return got == tok
    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path in ("/", "/index.html"):
            with open(os.path.join(WEB, "index.html"), "rb") as f: return self._send(200, f.read(), "text/html; charset=utf-8")
        if re.fullmatch(r"/[\w.-]+\.(js|svg|css|png)", path):
            fp = os.path.join(WEB, path[1:])
            if os.path.isfile(fp):
                ct = {"js": "text/javascript; charset=utf-8", "svg": "image/svg+xml", "css": "text/css", "png": "image/png"}[path.rsplit(".", 1)[1]]
                with open(fp, "rb") as f: return self._send(200, f.read(), ct)
        if path in ("/status.json", "/api/status"):
            with LOCK: return self._send(200, STATUS)
        if path == "/api/ticks":
            with LOCK: return self._send(200, TICKS)
        if path == "/api/health":
            return self._send(200, {"ok": True, "version": VERSION, "update": UPD, "sources": STATUS.get("sources"),
                "executors": {k: {"ok": executor_ok(k), "enabled": e.get("enabled", True), "path": shutil.which(e["cmd"][0]) if e.get("type") == "cmd" else None}
                              for k, e in CFG.get("executors", {}).items()}})
        if path == "/api/voice":
            if not self._auth(): return self._send(401, {"error": "token"})
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("q", [""])[0]
            return self._send(200, voice(q), "text/plain; charset=utf-8")
        self._send(404, {"error": "no existe"})
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*"); self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Faro-Token"); self.end_headers()
    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b""
        try: body = json.loads(raw or b"{}")
        except Exception: body = {"text": raw.decode("utf-8", "replace")}
        if path == "/api/action":
            return self._send(200, action(body.get("type"), body.get("id"), body.get("text")))
        if path == "/api/update":
            try: return self._send(200, {"ok": True, **(self_update(force=True) or {})})
            except Exception as e: return self._send(200, {"ok": False, "error": str(e)[:160]})
        if path == "/api/suggestion":
            if not self._auth(): return self._send(401, {"error": "token"})
            return self._send(200, suggestion_add(body))
        if path == "/api/suggestion/action":
            return self._send(200, suggestion_action(body.get("id"), body.get("type"), body.get("text")))
        if path == "/api/order":
            if not self._auth(): return self._send(401, {"error": "token"})
            return self._send(200, new_order(body.get("text"), body.get("kind", "orden"), body.get("title"), body.get("thread"), body.get("executor")))
        if path == "/api/order/action":
            if not self._auth(): return self._send(401, {"error": "token"})
            return self._send(200, order_action(body.get("id"), body.get("type"), body.get("executor")))
        if not self._auth(): return self._send(401, {"error": "token"})
        if path == "/api/report":
            items = body if isinstance(body, list) else [body]
            res = [report(b) for b in items]
            return self._send(200, res[0] if len(res) == 1 else res)
        if path == "/api/message":
            say(body.get("from"), body.get("to"), body.get("text"), "msg"); build_status(); return self._send(200, {"ok": True})
        if path == "/api/voice":
            return self._send(200, voice(body.get("text") or body.get("q") or ""), "text/plain; charset=utf-8")
        self._send(404, {"error": "no existe"})

def loop():
    last_vault = 0
    while True:
        if time.time() - last_vault > 900:
            last_vault = time.time()
            try: vault_write()
            except Exception as e: log("vault_write", e)
        try: run_collectors()
        except Exception: log(traceback.format_exc())
        time.sleep(30)

def demo():
    """Datos simulados para probar sin red."""
    t = now()
    report({"id": "demo-run", "kind": "run", "project": "trading", "name": "Backtest (demo)", "agent": "Hermes · PC", "pct": 30, "step": "Par 2 de 8"})
    REPORTS["demo-run"]["at"] = iso(t - dt.timedelta(minutes=5)); report({"id": "demo-run", "pct": 40})
    report({"id": "hermes-pc", "kind": "agent", "name": "Hermes · PC", "where": "Windows", "state": "run", "task": "demo"})
    report({"id": "demo-todo", "kind": "todo", "state": "warn", "title": "Aviso de demostración", "text": "Generado por --demo", "reply": False})
    CACHE["prices"] = {"items": [{"id": "bitcoin", "name": "Bitcoin", "kind": "crypto", "price": 61234.5, "chg24": -1.8, "unit": "€",
                                  "spark": [60000 + i * 50 for i in range(30)], "vs30": -3.2, "alert": False}]}
    CACHE["electricity"] = {"now": 0.1234, "avg": 0.1102, "cheap": ["03:00", "04:00", "15:00"], "hours": [0.1 + (i % 6) / 100 for i in range(24)], "kwh_month": 250}
    CACHE["news"] = {"items": [{"id": "n:1", "title": "Noticia de demostración sobre IA y vídeo", "link": "https://example.com", "summary": "Resumen.",
                                "source": "Demo", "date": iso(t), "score": 3, "topics": ["ia"], "why": "Te afecta porque editas vídeo con IA."}]}

def main():
    port = int(os.environ.get("FARO_PORT") or CFG.get("port", 8787))
    if "--demo" in sys.argv:
        demo()
    if "--once" in sys.argv:
        run_collectors(force=True); print(json.dumps(STATUS.get("sources"), ensure_ascii=False, indent=1)); return
    run_collectors(force=True)
    threading.Thread(target=loop, daemon=True).start()
    for name in CFG.get("executors", {}) or {"faro": {}}:
        threading.Thread(target=worker, args=(name,), daemon=True).start()
    with LOCK:
        for o in ORDERS:
            if o["state"] == "running": o["state"] = "queued"  # se reanudan tras un reinicio
    srv = ThreadingHTTPServer((CFG.get("bind", "0.0.0.0"), port), H)
    log("Faro escuchando en http://%s:%d" % (CFG.get("bind", "0.0.0.0"), port))
    srv.serve_forever()

if __name__ == "__main__":
    main()
