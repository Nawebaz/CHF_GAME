#!/usr/bin/env bash
# Abre Faro: si el servidor no está en marcha lo arranca y abre el navegador.
DIR="$(cd "$(dirname "$0")" && pwd)"
PORT="${FARO_PORT:-8787}"
if ! curl -s -m 2 "http://127.0.0.1:$PORT/api/health" >/dev/null; then
  if systemctl --user list-unit-files faro.service >/dev/null 2>&1 && systemctl --user start faro 2>/dev/null; then :; else
    [ -f "$DIR/config.json" ] || cp "$DIR/config.example.json" "$DIR/config.json"
    nohup python3 "$DIR/faro.py" >> "$DIR/data/arranque.log" 2>&1 &
  fi
  for i in $(seq 1 20); do curl -s -m 1 "http://127.0.0.1:$PORT/api/health" >/dev/null && break; sleep 0.5; done
fi
xdg-open "http://127.0.0.1:$PORT" >/dev/null 2>&1 || echo "Abre en el navegador: http://127.0.0.1:$PORT"
